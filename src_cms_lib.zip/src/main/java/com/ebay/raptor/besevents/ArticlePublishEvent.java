package com.ebay.raptor.besevents;

import com.ebay.bes.common.BusinessEventInitializer;

public class ArticlePublishEvent extends ArticleEvent {
	
	private String userIp;
	/**
	 * User agent string of the web browser submitting the comment - typically
	 * the HTTP_USER_AGENT cgi variable. Not to be confused with the user agent
	 * of your Akismet library. (required)
	 */
	private String userAgent;

	/** The content of the HTTP_REFERER header should be sent here. */
	private String referrer;

	private String commentType;

	/** Name submitted with the comment */
	private String commentAuthor;

	/** Email address submitted with the comment */
	private String commentAuthorEmail;

	/** URL submitted with comment */
	private String commentAuthorUrl;

	/** The content that was submitted. */
	private String commentContent;
	
	public ArticlePublishEvent() {
		m_eventType = BusinessEventInitializer.getInstance().getEventType(ConsumerConstants.ARTICLE_PUBLISH_EVENT);
	}




	public String getUserIp() {
		return userIp;
	}




	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}




	public String getUserAgent() {
		return userAgent;
	}




	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}




	public String getReferrer() {
		return referrer;
	}




	public void setReferrer(String referrer) {
		this.referrer = referrer;
	}




	public String getCommentType() {
		return commentType;
	}




	public void setCommentType(String commentType) {
		this.commentType = commentType;
	}




	public String getCommentAuthor() {
		return commentAuthor;
	}




	public void setCommentAuthor(String commentAuthor) {
		this.commentAuthor = commentAuthor;
	}




	public String getCommentAuthorEmail() {
		return commentAuthorEmail;
	}




	public void setCommentAuthorEmail(String commentAuthorEmail) {
		this.commentAuthorEmail = commentAuthorEmail;
	}




	public String getCommentAuthorUrl() {
		return commentAuthorUrl;
	}




	public void setCommentAuthorUrl(String commentAuthorUrl) {
		this.commentAuthorUrl = commentAuthorUrl;
	}




	public String getCommentContent() {
		return commentContent;
	}




	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}




	@Override
	public String toString() {
		return "ArticlePublishEvent [userIp=" + userIp + ", userAgent="
				+ userAgent + ", referrer=" + referrer + ", commentType="
				+ commentType + ", commentAuthor=" + commentAuthor
				+ ", commentAuthorEmail=" + commentAuthorEmail
				+ ", commentAuthorUrl=" + commentAuthorUrl
				+ ", commentContent=" + commentContent + "]";
	}



	


	
	
}