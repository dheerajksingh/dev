package com.ebay.raptor.besevents;

public class ConsumerConstants {
	public static final String ARTICLE_PUBLISH_EVENT = "ARTICLE.PUBLISH";
	public static final String ARTICLE_STATUSCHANGE_EVENT = "ARTICLE.STATUSCHANGE";
	public static final String ARTICLE_DELETE_EVENT = "ARTICLE.DELETE";
	public static final String ARTICLE_BULK_UPLOAD_EVENT = "ARTICLE.BULK_UPLOAD";

}
