package com.ebay.raptor.cmseditor.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.dao.BasicDAO;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentsResponse;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.mongodb.ReadPreference;

@Component
@Repository("contentPublishDAO")
public class ContentPublishDao  extends  BasicDAO<PublishedContentEntity, ObjectId>{
	
	private static final String DAO_NAME = "ContentPublishDao";
	private static final String CONTENT_ID="contentId";
	private static final String USER_ID = "authorId";
	private static final String ACCESS_CONTROL_LIST="accessControlList";
	
	private static final Logger LOGGER = Logger.getInstance(ContentPublishDao.class);
	
	@Inject private QueryHelper queryHelper;

	@Autowired
	public ContentPublishDao(AdvancedDatastore ds) {
		super(ds);
	}
	
	public ContentPublishDao(AdvancedDatastore ds,QueryHelper queryHelper){
		super(ds);
		this.queryHelper=queryHelper;
	}
	
	
	public PublishedContentEntity findContentById(String contentId) throws Exception{
		Query<PublishedContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		return queryHelper.get(query, DAO_NAME, "findContentById");
	}
	
	
	
	public PublishedContentsResponse findContentByUserId(String userId, int limit,
			int offset, String sort,List<String> statuses,List<String> moderationStatuses) throws Exception{
		return findContentByUserId(userId, limit, offset, sort, statuses,moderationStatuses,false);
	}
	
	public PublishedContentEntity findContentByIdAndUserId(String contentId,String userId) throws Exception {
		Query<PublishedContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		List<String> users = new ArrayList<String>();
		users.add(userId);
		query.criteria(ACCESS_CONTROL_LIST).hasAnyOf(users);
		return queryHelper.get(query, DAO_NAME, "findContentByIdAndUserId");
	}

	private PublishedContentsResponse findContentByUserId(String userId, int limit,
			int offset, String sort, List<String> statuses,List<String> moderationStatuses,boolean primaryOnly) throws Exception{
		Query<PublishedContentEntity> query = createQuery();
		query.disableValidation();
		query.limit(limit);
		query.offset(offset);
		query.order(sort);
		List<String> users = new ArrayList<String>();
		users.add(userId);
		query.criteria(ACCESS_CONTROL_LIST).hasAnyOf(users);
		if(!CollectionUtils.isEmpty(statuses)){
			query.criteria(ContentFields.contentStatus.getFieldName()).in(statuses);
		}
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		if(!CollectionUtils.isEmpty(moderationStatuses)){
			query.criteria(ContentFields.moderationStatus.getFieldName()).in(moderationStatuses);
		}
		if (primaryOnly) {
			query.useReadPreference(ReadPreference.primaryPreferred());
		}
		query.enableValidation();
		List<PublishedContentEntity> publishedArticles= queryHelper.asList(query, DAO_NAME, "findContentByUserId");
		PublishedContentsResponse response = new PublishedContentsResponse();
		response.setPublishedContents(publishedArticles);
		response.setCount(queryHelper.count(query, DAO_NAME, "findContentByUserId"));
		return response;
	}
	
	public List<PublishedContentEntity> findContents(int limit,int offset,String sort,List<String> statuses,List<String> moderationStatuses){
		Query<PublishedContentEntity> query = createQuery();
		query.limit(limit);
		query.offset(offset);
		query.order(sort);
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		if(!CollectionUtils.isEmpty(statuses)){
			query.criteria(ContentFields.contentStatus.getFieldName()).in(statuses);
		}
		if(!CollectionUtils.isEmpty(moderationStatuses)){
			query.criteria(ContentFields.moderationStatus.getFieldName()).in(moderationStatuses);
		}
		return queryHelper.asList(query, DAO_NAME, "findContents");
	}
	
	public PublishedContentEntity findContentByContentId(String contentId) {
		Query<PublishedContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.getFieldName()).equal(false);
		return query.get();
	}

	
	public List<String> findContentAccessControlListByContentId(String contentId) {
		List<String> accessControlList = null;
		if(StringUtils.isEmpty(contentId)){
			return null;
		}
		List<String> contentIds = new ArrayList<String>();
		contentIds.add(contentId);
		Map<String, ContentEntity> accessControlListsMap = findContentAccessControlListByContentIds(contentIds);
		if (accessControlListsMap != null) {
			accessControlList = accessControlListsMap.get(contentId).getAccessControlList();
		}
		return accessControlList;
	}
	
	public Map<String, ContentEntity> findContentAccessControlListByContentIds(List<String> contentIds) {
		Map<String, ContentEntity> accessControlListsMap = new HashMap<String, ContentEntity>();
		
		if(CollectionUtils.isEmpty(contentIds)) {
			return accessControlListsMap;
		}
		
		Query<PublishedContentEntity> query = createQuery();
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for (String contentId:contentIds) {
			objectIds.add(new ObjectId(contentId));
		}
		query.criteria(CONTENT_ID).in(objectIds);
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		query.retrievedFields(true, USER_ID, ACCESS_CONTROL_LIST,CONTENT_ID);
		List<PublishedContentEntity> contents = queryHelper.asList(query, DAO_NAME, "findContentAccessControlListByContentIds");
		if(contents != null) {
			for (PublishedContentEntity content:contents) {
				if  (content.getAccessControlList() != null) {
					accessControlListsMap.put(content.getContentId().toString(), content);
				}
			}
		}
		return accessControlListsMap;
	}

	public int updateContentField(String contentId, List<? extends KeyValue> keyValues){	
		UpdateOperations<PublishedContentEntity> updateOperations = createUpdateOperations();
		updateOperations.disableValidation();
		for(KeyValue kv:keyValues) {
			updateOperations.set((String) kv.getKey(), kv.getValue());
		}
		updateOperations.enableValidation();
		
		Query<PublishedContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.getFieldName()).equal(false);
		UpdateResults results=update(createQuery().filter(CONTENT_ID, new ObjectId(contentId)),updateOperations);
		
		return results.getUpdatedCount();
	}
	
	public void updateContentFieldForContentIds(List<String> contentIds, List<? extends KeyValue> keyValues){	
		UpdateOperations<PublishedContentEntity> updateOperations = createUpdateOperations();
		updateOperations.disableValidation();
		for(KeyValue kv:keyValues) {
			updateOperations.set((String) kv.getKey(), kv.getValue());
		}
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for(String contentId:contentIds) {
			objectIds.add(new ObjectId(contentId));
		}
		updateOperations.enableValidation();
		Query<PublishedContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).in(objectIds);
		update(query, updateOperations);
	}
	
	public void updateContentFieldForContentIdsInResponses(List<BulkAdaptorResponse> responses, List<? extends KeyValue> keyValues){	
		UpdateOperations<PublishedContentEntity> updateOperations = createUpdateOperations();
		updateOperations.disableValidation();
		for(KeyValue kv:keyValues) {
			updateOperations.set((String) kv.getKey(), kv.getValue());
		}
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for (BulkAdaptorResponse response:responses) {
			try{
				objectIds.add(new ObjectId(response.getContentId()));
			}catch(IllegalArgumentException i){
				LOGGER.log(LogLevel.ERROR,i);
				response.setStatus(CmsEditorStatus.INVALID_CONTENT_ID);
			}
		}		
		updateOperations.enableValidation();
		Query<PublishedContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).in(objectIds);		
		update(query, updateOperations);
	}
	
	public void updateContent(String contentId,PublishedContentEntity content){
		save(content);
	}
	
	public List<String> createContent(List<PublishedContentEntity> contents){
		List<String> contentIds = new ArrayList<String>();
		for(PublishedContentEntity content:contents){
			try{
				Key<PublishedContentEntity> key = save(content);
				contentIds.add(key.getId().toString());
			}catch(Exception e){
				LOGGER.log(LogLevel.ERROR,e);
			}
		}
		return contentIds;
	}
	
	public void createBulkContents(List<BulkAdaptorResponse> contents){
		List<String> contentIds = new ArrayList<String>();
		for(BulkAdaptorResponse content:contents){
			if(content.getStatus()!=CmsEditorStatus.BULK_CREATE_SUCCESS){
				continue;
			}
			try{
				Key<PublishedContentEntity> key = save((PublishedContentEntity) content.getEntity());
				contentIds.add(key.getId().toString());
				content.setContentId(key.getId().toString());
			}catch(Exception e){
				LOGGER.log(LogLevel.ERROR,e);
				content.setStatus(CmsEditorStatus.CREATE_ERROR);
			}
		}
	}
	
	
	/**
	 * Delete by contentIds
	 * @param contentIds
	 */
	public void deleteByContentIds(List<BulkAdaptorResponse> responses){
		deleteByContentIdsAndUserId(responses, null);
	}
	
	/**
	 * Delete by contentIds and userId
	 * @param contentIds
	 * @param userId
	 */
	public void deleteByContentIdsAndUserId(List<BulkAdaptorResponse> responses, String userId){
		if(CollectionUtils.isEmpty(responses)){
			return;
		}
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for(BulkAdaptorResponse response:responses) {
			try{
				objectIds.add(new ObjectId(response.getContentId()));
			}catch(IllegalArgumentException i){
				LOGGER.log(LogLevel.ERROR,i);
				response.setStatus(CmsEditorStatus.INVALID_CONTENT_ID);
			}
		}
		Query<PublishedContentEntity > deleteQuery = createQuery();
		deleteQuery.criteria(CONTENT_ID).in(objectIds);
		if(!StringUtils.isEmpty(userId)) {
			deleteQuery.criteria(USER_ID).equals(userId);
		}
			deleteByQuery(deleteQuery);
	}
}
