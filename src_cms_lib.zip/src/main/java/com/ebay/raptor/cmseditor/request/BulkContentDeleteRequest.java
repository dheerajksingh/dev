package com.ebay.raptor.cmseditor.request;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.google.common.base.Splitter;

public class BulkContentDeleteRequest {

	private List<String> contentIds = new ArrayList<String>();
	private ArticleStatusEnum status;
	
	public List<String> getContentIds() {
		return contentIds;
	}
	public void setContentIds(List<String> contentIds) {
		this.contentIds = contentIds;
	}
	public ArticleStatusEnum getStatus() {
		return status;
	}
	public void setStatus(ArticleStatusEnum status) {
		this.status = status;
	}	
	
	public void populateContentIds(String contentIds) throws CmsEditorException{
		if(StringUtils.isEmpty(contentIds)){
			throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_IDS);
		}
		
		try{
			Iterable<String> ids =Splitter.on(",").split(contentIds);
			for(String s:ids){
				if(StringUtils.isEmpty(s)){
					throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_IDS);
				}
				this.contentIds.add(s);
			}
			}catch(Exception e){
				throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_IDS,e);
			}
		
	}
	
}