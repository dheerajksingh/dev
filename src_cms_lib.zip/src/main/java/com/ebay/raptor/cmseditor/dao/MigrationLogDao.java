package com.ebay.raptor.cmseditor.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.collections.KeyValue;
import org.bson.types.ObjectId;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.dao.BasicDAO;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.MigrationLog;
import com.ebay.raptor.cmseditor.dao.entities.MigrationLogResponse;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;

@Component
@Repository("migrationLogDao")
public class MigrationLogDao extends  BasicDAO<MigrationLog, ObjectId>{
	
	private static final String ORACLE_CONTENT_ID="oracleContentId";
	private static final String MONGO_ARTICLE_ID="mongoArticleId";
	private static final String REDIRECT_TO_MONGO="redirectToMongo";
	private static final String DAO_NAME = "MigrationLogDao";
	
private static final Logger LOGGER = Logger.getInstance(MigrationLogDao.class);
	
	@Inject private QueryHelper queryHelper;

	@Autowired
	public MigrationLogDao(AdvancedDatastore ds) {
		super(ds);
	}
	
	public MigrationLogDao(AdvancedDatastore ds,QueryHelper queryHelper){
		super(ds);
		this.queryHelper=queryHelper;
	}

	public MigrationLog findMigrationLogByOracleContentId(String oracleContentId){
		Query<MigrationLog> query = createQuery();
		query.criteria(ORACLE_CONTENT_ID).equal(oracleContentId);
		return queryHelper.get(query, DAO_NAME, "findMigrationLogByOracleContentId");
	}
	
	public MigrationLog findMigrationLogByMongoArticleId(String mongoArticleId){
		Query<MigrationLog> query = createQuery();
		query.criteria(MONGO_ARTICLE_ID).equal(mongoArticleId);
		return queryHelper.get(query, DAO_NAME, "findMigrationLogByMongoArticleId");
	}
	
	public List<MigrationLog> findMigrationLogsByMongoArticleIds(List<String> mongoArticleIds){
		
		Query<MigrationLog> query = createQuery();
		query.criteria(MONGO_ARTICLE_ID).in(mongoArticleIds);
		return queryHelper.asList(query, DAO_NAME, "findMigrationLogsByMongoArticleIds");
		
	}
	
public List<MigrationLog> findMigrationLogsByOracleoArticleIds(List<String> oracleArticleIds){
		
		Query<MigrationLog> query = createQuery();
		query.criteria(ORACLE_CONTENT_ID).in(oracleArticleIds);
		return queryHelper.asList(query, DAO_NAME, "findMigrationLogsByOracleArticleIds");
		
	}
	
	public void updateRedirectToMongoWithOracleId(String oracleContentId,boolean redirectToMongo){
		UpdateOperations<MigrationLog> updateOperations = createUpdateOperations();
		updateOperations.set(REDIRECT_TO_MONGO,redirectToMongo);
		update(createQuery().filter(ORACLE_CONTENT_ID, oracleContentId),updateOperations);
	}
	
	public void updateRedirectToMongoWithMongoId(String mongoArticleId,boolean redirectToMongo){
		UpdateOperations<MigrationLog> updateOperations = createUpdateOperations();
		updateOperations.set(REDIRECT_TO_MONGO,redirectToMongo);
		update(createQuery().filter(MONGO_ARTICLE_ID, mongoArticleId),updateOperations);
	}
	
	
public MigrationLogResponse findMigrationLogs(int limit,int offset){
		
		Query<MigrationLog> query = createQuery();
		query.limit(limit);
		query.offset(offset);
		List<MigrationLog> logs= queryHelper.asList(query, DAO_NAME, "findMigrationLogs");
		long count=queryHelper.countAll(query, DAO_NAME, "findMigrationLogs");
		MigrationLogResponse migrationLog = new MigrationLogResponse();
		migrationLog.setCount(count);
		migrationLog.setMigrationLogs(logs);
		return migrationLog;
		
	}
}
