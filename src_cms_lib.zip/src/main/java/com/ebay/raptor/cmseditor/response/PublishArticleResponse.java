package com.ebay.raptor.cmseditor.response;

public class PublishArticleResponse extends CmsEditorResponse{
	
	private String articleId;

	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

}
