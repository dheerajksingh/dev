package com.ebay.raptor.cmseditor.request;

public enum SortOrder {
	
	DATE_MODIFIED_ASC("-dateModified"),
	DATE_MODIFIED_DESC("dateModified");
//	TITLE_ASC("-title"),
//	TITLE_DESC("title");
	
	private String sort;
	
	SortOrder(String sort){
		this.sort=sort;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}
	
	public static SortOrder getSortByName(String sort){
		for(SortOrder sortOrder:SortOrder.values()){
			if(sortOrder.getSort().equalsIgnoreCase(sort)){
				return sortOrder;
			}
		}
		return SortOrder.DATE_MODIFIED_DESC;
	}

}
