package com.ebay.raptor.cmseditor.response;

import java.util.List;

public class BulkArticleResponse extends CmsEditorResponse{
	
	private List<BulkResponse> payload;
	
	private int statusCode;
	
	private List<String> articleIds;

	public List<String> getArticleIds() {
		return articleIds;
	}

	public void setArticleIds(List<String> contentIds) {
		this.articleIds = contentIds;
	}

	public List<BulkResponse> getPayload() {
		return payload;
	}

	public void setPayload(List<BulkResponse> payload) {
		this.payload = payload;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	
	
	

}
