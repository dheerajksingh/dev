package com.ebay.raptor.cmseditor.dao.entities;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Property;

public class ContentEntity {

	@Id
	@Property("id")
	private ObjectId id;
	
	private ObjectId contentId;
	// DRAFT,PUBLISHED
	private String contentStatus;
	private boolean blacklisted;

	// HOW_TO,LONG_FORM,LIST,QUIZ
	private String templateType;

	private Date dateCreated;
	private Date dateModified;
	private List<String> accessControlList;

	private UserGeneratedContentEntity userGeneratedContent;

	private long authorId;
	private String authorName;
	private String publicAuthorId;
	private long lastModifiedUser;
	private Date scheduledStartDate;
	private Date scheduledEndDate;
	private String draftId;
	//PRIVATE,PUBLIC
	private String visibilityLevel;
	private String marketPlaceId;
	private String locale;
	
	//MODERATED,NOT_MODERATED,NEEDS_MODERATION
	private String moderationStatus;
	private long lastModeratedUser;
	//SYSTEM,USER,MODERATOR
	private String lastModerationActor;
	private Set<String> usersMarkedSpam;
	private int usersMarkedSpamCount;
	
	private String markedAsProcessing;
	private boolean isDeleted;
	private int version;
	

	public ContentEntity() {

	}

	public String getVisibilityLevel() {
		return visibilityLevel;
	}



	public void setVisibilityLevel(String visibilityLevel) {
		this.visibilityLevel = visibilityLevel;
	}



	public String getMarketPlaceId() {
		return marketPlaceId;
	}



	public void setMarketPlaceId(String marketPlaceId) {
		this.marketPlaceId = marketPlaceId;
	}



	public String getLocale() {
		return locale;
	}



	public void setLocale(String locale) {
		this.locale = locale;
	}



	public String getModerationStatus() {
		return moderationStatus;
	}



	public void setModerationStatus(String moderationStatus) {
		this.moderationStatus = moderationStatus;
	}



	



	public String getMarkedAsProcessing() {
		return markedAsProcessing;
	}



	public void setMarkedAsProcessing(String markedAsProcessing) {
		this.markedAsProcessing = markedAsProcessing;
	}


	public String getContentStatus() {
		return contentStatus;
	}

	public void setContentStatus(String contentStatus) {
		this.contentStatus = contentStatus;
	}



	public List<String> getAccessControlList() {
		return accessControlList;
	}

	public void setAccessControlList(List<String> accessControlList) {
		this.accessControlList = accessControlList;
	}

	

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public ObjectId getContentId() {
		return contentId;
	}

	public void setContentId(ObjectId contentId) {
		this.contentId = contentId;
	}

	public UserGeneratedContentEntity getUserGeneratedContent() {
		return userGeneratedContent;
	}
	
	public void setUserGeneratedContent(UserGeneratedContentEntity userGeneratedContent) {
		this.userGeneratedContent = userGeneratedContent;
	}






	public Date getDateCreated() {
		return dateCreated;
	}



	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}



	public Date getDateModified() {
		return dateModified;
	}



	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}



	


	public long getAuthorId() {
		return authorId;
	}



	public void setAuthorId(long authorId) {
		this.authorId = authorId;
	}



	public String getAuthorName() {
		return authorName;
	}



	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}



	public long getLastModifiedUser() {
		return lastModifiedUser;
	}



	public void setLastModifiedUser(long lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}



	public Date getScheduledStartDate() {
		return scheduledStartDate;
	}



	public void setScheduledStartDate(Date scheduledStartDate) {
		this.scheduledStartDate = scheduledStartDate;
	}



	public Date getScheduledEndDate() {
		return scheduledEndDate;
	}



	public void setScheduledEndDate(Date scheduledEndDate) {
		this.scheduledEndDate = scheduledEndDate;
	}



	public String getDraftId() {
		return draftId;
	}



	public void setDraftId(String draftId) {
		this.draftId = draftId;
	}



	public long getLastModeratedUser() {
		return lastModeratedUser;
	}



	public void setLastModeratedUser(long lastModeratedUser) {
		this.lastModeratedUser = lastModeratedUser;
	}



	public boolean isDeleted() {
		return isDeleted;
	}



	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}



	public boolean isBlacklisted() {
		return blacklisted;
	}



	public void setBlacklisted(boolean blacklisted) {
		this.blacklisted = blacklisted;
	}



	public String getLastModerationActor() {
		return lastModerationActor;
	}



	public void setLastModerationActor(String lastModerationActor) {
		this.lastModerationActor = lastModerationActor;
	}



	public Set<String> getUsersMarkedSpam() {
		return usersMarkedSpam;
	}



	public void setUsersMarkedSpam(Set<String> usersMarkedSpam) {
		this.usersMarkedSpam = usersMarkedSpam;
	}



	public int getUsersMarkedSpamCount() {
		return usersMarkedSpamCount;
	}



	public void setUsersMarkedSpamCount(int usersMarkedSpamCount) {
		this.usersMarkedSpamCount = usersMarkedSpamCount;
	}



	public int getVersion() {
		return version;
	}



	public void setVersion(int version) {
		this.version = version;
	}

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getPublicAuthorId() {
		return publicAuthorId;
	}

	public void setPublicAuthorId(String publicAuthorId) {
		this.publicAuthorId = publicAuthorId;
	}

	

	

}
