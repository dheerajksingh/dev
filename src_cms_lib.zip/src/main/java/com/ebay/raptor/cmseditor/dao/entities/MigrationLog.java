package com.ebay.raptor.cmseditor.dao.entities;

import java.util.Date;

import org.mongodb.morphia.annotations.Id;


public class MigrationLog {
	
	@Id
	private String oracleContentId;
	
	private String title;
	private String author;
	private String mongoArticleId;
	private String currentUrl;
	private String newUrl;
	private boolean redirectToMongo;
	private Date migratedDate;

	public String getOracleContentId() {
		return oracleContentId;
	}

	public void setOracleContentId(String oracleContentId) {
		this.oracleContentId = oracleContentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getMongoArticleId() {
		return mongoArticleId;
	}

	public void setMongoArticleId(String mongoArticleId) {
		this.mongoArticleId = mongoArticleId;
	}

	public boolean isRedirectToMongo() {
		return redirectToMongo;
	}

	public void setRedirectToMongo(boolean redirectToMongo) {
		this.redirectToMongo = redirectToMongo;
	}

	public String getCurrentUrl() {
		return currentUrl;
	}

	public void setCurrentUrl(String currentUrl) {
		this.currentUrl = currentUrl;
	}

	public String getNewUrl() {
		return newUrl;
	}

	public void setNewUrl(String newUrl) {
		this.newUrl = newUrl;
	}

	public Date getMigratedDate() {
		return migratedDate;
	}

	public void setMigratedDate(Date migratedDate) {
		this.migratedDate = migratedDate;
	}
	
	

}