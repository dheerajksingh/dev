package com.ebay.raptor.cmseditor.request;

import org.apache.commons.collections.KeyValue;

public class KeyValueImpl implements KeyValue{
	
	private String key;
	private Object value;

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public Object getValue() {
		return value;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setValue(Object value) {
		this.value = value;
	}
	
	

}
