package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;

public class PublishedContentsResponse {
	
	private List<PublishedContentEntity> publishedArticles;
	private Long count;
	public List<PublishedContentEntity> getPublishedContents() {
		return publishedArticles;
	}
	public void setPublishedContents(List<PublishedContentEntity> publishedArticles) {
		this.publishedArticles = publishedArticles;
	}
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	
	

}
