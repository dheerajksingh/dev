package com.ebay.raptor.cmseditor.response;


public enum CmsEditorResponseStatus {
	SUCCESS,FAILURE,WARNING
}
