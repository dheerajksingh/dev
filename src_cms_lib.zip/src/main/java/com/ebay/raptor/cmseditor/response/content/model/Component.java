package com.ebay.raptor.cmseditor.response.content.model;

import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.codehaus.jackson.annotate.JsonTypeInfo.As;
import org.codehaus.jackson.annotate.JsonTypeInfo.Id;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Represents a component : PARAGRAPH,IMAGE,VIDEO,HEADING,BLOCK_QUOTE,COLLECTION,TABLE,DIVIDER
 * @author kravikumar
 *
 */
@JsonTypeInfo(use=Id.NAME, include=As.PROPERTY,property="type")
@JsonSubTypes({
  @JsonSubTypes.Type(value = StandardComponent.class, name = "standard"),
  @JsonSubTypes.Type(value = MediaComponent.class, name = "media"),
  @JsonSubTypes.Type(value = EntityComponent.class, name = "entity"),
})
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class Component {
	
	//PARAGRAPH,IMAGE,VIDEO,HEADING,BLOCK_QUOTE,COLLECTION,TABLE,DIVIDER
	private String componentType;
	private String caption;
	
	public String getComponentType() {
		return componentType;
	}
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	
	

}
