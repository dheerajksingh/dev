package com.ebay.raptor.cmseditor.bulk;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;

public class BulkAdaptorResponse {
	
	@JsonIgnore
	private ContentEntity entity;
	
	private String title;
	private String author;
	private String contentId;
	private CmsEditorStatus status;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public CmsEditorStatus getStatus() {
		return status;
	}
	public void setStatus(CmsEditorStatus status) {
		this.status = status;
	}
	public ContentEntity getEntity() {
		return entity;
	}
	public void setEntity(ContentEntity entity) {
		this.entity = entity;
	}
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	
	
	
	

}
