package com.ebay.raptor.cmseditor.dao.entities;

public class PublishedContentEntity extends ContentEntity{
	
	private ComputedArticleDetailsEntity computedArticleDetailsEntity;

	public ComputedArticleDetailsEntity getComputedArticleDetailsEntity() {
		return computedArticleDetailsEntity;
	}

	public void setComputedArticleDetailsEntity(
			ComputedArticleDetailsEntity computedArticleDetailsEntity) {
		this.computedArticleDetailsEntity = computedArticleDetailsEntity;
	}
	
}
