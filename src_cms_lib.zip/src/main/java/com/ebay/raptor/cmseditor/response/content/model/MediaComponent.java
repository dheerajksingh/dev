package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;

import com.ebay.cos.type.v3.core.listing.DigitalMedia;

public class MediaComponent extends Component{
	
	private DigitalMedia media;
	
	private List<String> categoryIds;
	private String categoryLevel;
	public List<String> getCategoryIds() {
		return categoryIds;
	}
	public void setCategoryIds(List<String> categoryIds) {
		this.categoryIds = categoryIds;
	}
	public String getCategoryLevel() {
		return categoryLevel;
	}
	public void setCategoryLevel(String categoryLevel) {
		this.categoryLevel = categoryLevel;
	}
	

	public DigitalMedia getMedia() {
		return media;
	}

	public void setMedia(DigitalMedia media) {
		this.media = media;
	}
	
	

}
