package com.ebay.raptor.cmseditor.request;

import org.springframework.context.ApplicationContext;

public class CmsEditorRequest {
	
	private String contentId;
	private boolean blackList;
	private ApplicationContext applicationContext;
	private Long userId;
	
	private Selector selector;
	private UpdateGroupRequest updateGroupRequest;
	private UpdateSectionRequest updateSectionRequest;
	private BulkCreateArticleRequest createBulkContentRequest;
	private ContentReadRequest contentReadRequest;
	private ContentReadAllRequest contentReadAllRequest;
	private DeleteSectionRequest deleteModuleRequest;
	private DeleteGroupRequest deleteGroupRequest;
	private GetForEditRequest getForEditRequest;
	private ContentUpdateRequest contentUpdateRequest;
	private ArticleUpdateFieldRequest contentUpdateFieldRequest;
	private BulkContentDeleteRequest bulkContentDeleteRequest;
	private ContentPublishRequest contentPublishRequest;
	private CreateDraftRequest createContentRequest;
	private DeleteContentRequest deleteContentRequest;
	private UpdateModerationStatusRequest flagContentRequest;

	public DeleteContentRequest getDeleteContentRequest() {
		return deleteContentRequest;
	}

	public void setDeleteContentRequest(DeleteContentRequest deleteContentRequest) {
		this.deleteContentRequest = deleteContentRequest;
	}

	public ContentUpdateRequest getContentUpdateRequest() {
		return contentUpdateRequest;
	}

	public void setContentUpdateRequest(ContentUpdateRequest contentUpdateRequest) {
		this.contentUpdateRequest = contentUpdateRequest;
	}

	public ArticleUpdateFieldRequest getContentUpdateFieldRequest() {
		return contentUpdateFieldRequest;
	}

	public void setContentUpdateFieldRequest(
			ArticleUpdateFieldRequest contentUpdateFieldRequest) {
		this.contentUpdateFieldRequest = contentUpdateFieldRequest;
	}	

	public ContentPublishRequest getContentPublishRequest() {
		return contentPublishRequest;
	}

	public void setContentPublishRequest(ContentPublishRequest contentPublishRequest) {
		this.contentPublishRequest = contentPublishRequest;
	}

	public GetForEditRequest getGetForEditRequest() {
		return getForEditRequest;
	}

	public void setGetForEditRequest(GetForEditRequest getForEditRequest) {
		this.getForEditRequest = getForEditRequest;
	}

	public DeleteSectionRequest getDeleteSectionRequest() {
		return deleteModuleRequest;
	}

	public void setDeleteModuleRequest(DeleteSectionRequest deleteGroupRequest) {
		this.deleteModuleRequest = deleteGroupRequest;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public boolean isBlackList() {
		return blackList;
	}

	public void setBlackList(boolean blackList) {
		this.blackList = blackList;
	}

	public ContentReadAllRequest getContentReadAllRequest() {
		return contentReadAllRequest;
	}

	public void setContentReadAllRequest(ContentReadAllRequest contentReadAllRequest) {
		this.contentReadAllRequest = contentReadAllRequest;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public ContentReadRequest getContentReadRequest() {
		return contentReadRequest;
	}

	public void setContentReadRequest(ContentReadRequest contentReadRequest) {
		this.contentReadRequest = contentReadRequest;
	}	

	public BulkContentDeleteRequest getBulkContentDeleteRequest() {
		return bulkContentDeleteRequest;
	}

	public void setBulkContentDeleteRequest(
			BulkContentDeleteRequest bulkContentDeleteRequest) {
		this.bulkContentDeleteRequest = bulkContentDeleteRequest;
	}

	public BulkCreateArticleRequest getCreateBulkContentRequest() {
		return createBulkContentRequest;
	}

	public void setCreateBulkContentRequest(
			BulkCreateArticleRequest createBulkContentRequest) {
		this.createBulkContentRequest = createBulkContentRequest;
	}

	public CreateDraftRequest getCreateContentRequest() {
		return createContentRequest;
	}

	public void setCreateContentRequest(CreateDraftRequest createContentRequest) {
		this.createContentRequest = createContentRequest;
	}

	public UpdateSectionRequest getUpdateSectionRequest() {
		return updateSectionRequest;
	}

	public void setUpdateSectionRequest(UpdateSectionRequest updateSectionRequest) {
		this.updateSectionRequest = updateSectionRequest;
	}

	public Selector getSelector() {
		return selector;
	}

	public void setSelector(Selector selector) {
		this.selector = selector;
	}

	public void setUpdateGroupRequest(UpdateGroupRequest updateGroupRequest) {
		this.updateGroupRequest = updateGroupRequest;
	}
	
	public UpdateGroupRequest getUpdateGroupRequest() {
		return updateGroupRequest;
	}

	public DeleteGroupRequest getDeleteGroupRequest() {
		return deleteGroupRequest;
	}

	public void setDeleteGroupRequest(DeleteGroupRequest deleteGroupRequest) {
		this.deleteGroupRequest = deleteGroupRequest;
	}

	public UpdateModerationStatusRequest getFlagContentRequest() {
		return flagContentRequest;
	}

	public void setFlagContentRequest(UpdateModerationStatusRequest flagContentRequest) {
		this.flagContentRequest = flagContentRequest;
	}
	
}
