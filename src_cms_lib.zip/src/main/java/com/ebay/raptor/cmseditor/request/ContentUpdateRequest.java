package com.ebay.raptor.cmseditor.request;

import com.ebay.raptor.cmseditor.response.content.model.Article;

public class ContentUpdateRequest {

	private String contentId;
	private Article contentEntity;
	private ArticleStatusEnum status;
	
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	public Article getContentEntity() {
		return contentEntity;
	}
	public void setContentEntity(Article contentEntity) {
		this.contentEntity = contentEntity;
	}
	public ArticleStatusEnum getStatus() {
		return status;
	}
	public void setStatus(ArticleStatusEnum status) {
		this.status = status;
	}

}
