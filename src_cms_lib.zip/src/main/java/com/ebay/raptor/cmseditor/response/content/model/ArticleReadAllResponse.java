package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ebay.raptor.cmseditor.response.CmsEditorResponse;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ArticleReadAllResponse extends  CmsEditorResponse {
	
	private List<Article> articles;
	private Long draftArticlesCount;
	private Long publishedArticlesCount;

	public List<Article> getArticles() {
		return articles;
	}

	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}

	public Long getDraftArticlesCount() {
		return draftArticlesCount;
	}

	public void setDraftArticlesCount(Long draftArticlesCount) {
		this.draftArticlesCount = draftArticlesCount;
	}

	public Long getPublishedArticlesCount() {
		return publishedArticlesCount;
	}

	public void setPublishedArticlesCount(Long publishedArticlesCount) {
		this.publishedArticlesCount = publishedArticlesCount;
	}

	

}