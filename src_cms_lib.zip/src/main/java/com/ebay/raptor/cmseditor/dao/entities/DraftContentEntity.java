package com.ebay.raptor.cmseditor.dao.entities;

public class DraftContentEntity extends ContentEntity{
	
	private static final String DRAFT="DRAFT";
	
	public DraftContentEntity(){
		
	}
	
	public DraftContentEntity(ContentEntity content){
		
		this.setAccessControlList(content.getAccessControlList());
		this.setAuthorName(content.getAuthorName());
		this.setAuthorId(content.getAuthorId());
		this.setPublicAuthorId(content.getPublicAuthorId());
		this.setBlacklisted(content.isBlacklisted());
		this.setContentStatus(DRAFT);
		this.setDateCreated(content.getDateCreated());
		this.setDateModified(content.getDateModified());
		this.setLastModeratedUser(content.getLastModeratedUser());
		this.setLastModifiedUser(content.getLastModifiedUser());
		this.setLocale(content.getLocale());
		this.setMarkedAsProcessing(content.getMarkedAsProcessing());
		this.setScheduledEndDate(content.getScheduledEndDate());
		this.setScheduledStartDate(content.getScheduledStartDate());
		this.setMarketPlaceId(content.getMarketPlaceId());
		this.setTemplateType(content.getTemplateType());
		this.setUserGeneratedContent(content.getUserGeneratedContent());
		this.setVisibilityLevel(content.getVisibilityLevel());
		
	}
}
