package com.ebay.raptor.cmseditor.request;

public enum ModerationStatusEnum {
	
	MODERATED,NOT_MODERATED,NEEDS_MODERATION;
}
