package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ebay.cos.raptor.service.annotations.ApiDescription;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class Section implements Comparable<Section>{
	
	@ApiDescription("Possible values: IMAGE_TEXT,TEXT_IMAGE,IMAGE_SLIDER")
	private String alignment;
	private List<Component> components;
	private String sectionId;
	@ApiDescription("The position of this section in the list of sections")
	private int sequence;
	
	public String getAlignment() {
		return alignment;
	}
	public void setAlignment(String alignment) {
		this.alignment = alignment;
	}	
	
	public List<Component> getComponents() {
		return components;
	}
	public void setComponents(List<Component> components) {
		this.components = components;
	}
	
	public String getSectionId() {
		return sectionId;
	}
	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	
	@Override
	public int compareTo(Section module) {
		if(this.sequence < module.sequence)
			return -1;
		else 
			return this.sequence == module.sequence ? 0 : 1;
	}

}