package com.ebay.raptor.cmseditor.dao.entities;

public enum ContentFields {
	id("_id"),
	draftId("draftId"),
	authorName("authorName"),
	contentStatus("contentStatus"),
	moderationStatus("moderationStatus"),
	lastModeratedUser("lastModeratedUser"),
	lastModerationActor("lastModerationActor"),
	isDeleted("isDeleted"),
	usersMarkedSpam("usersMarkedSpam"),
	usersMarkedSpamCount("usersMarkedSpamCount"),
	dateModified("dateModified"),
	version("version");
	
	final String fieldName;

	ContentFields(String fieldName) {
		this.fieldName = fieldName;
	}

	ContentFields() {
		this.fieldName = this.name();
	}

	public String getFieldName() {
		return fieldName;
	}
}
