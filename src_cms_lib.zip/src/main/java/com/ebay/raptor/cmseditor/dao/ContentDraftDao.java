package com.ebay.raptor.cmseditor.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.dao.BasicDAO;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentsResponse;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.mongodb.ReadPreference;

@Component
@Repository("contentDraftDAO")
public class ContentDraftDao extends BasicDAO<DraftContentEntity, ObjectId> {

	private static final String DAO_NAME = "ContentDraftDAO";
	private static final String CONTENT_ID = "contentId";
	private static final String USER_ID = "authorId";
	private static final String VERSION = "-version";
	private static final String ACCESS_CONTROL_LIST = "accessControlList";

	private static final Logger LOGGER = Logger
			.getInstance(ContentDraftDao.class);

	@Inject
	private QueryHelper queryHelper;

	@Autowired
	public ContentDraftDao(AdvancedDatastore ds) {
		super(DraftContentEntity.class,ds);
	}

	public ContentDraftDao(AdvancedDatastore ds, QueryHelper queryHelper) {
		super(ds);
		this.queryHelper = queryHelper;
	}

	public DraftContentEntity findContentById(String contentId) throws Exception {
		Query<DraftContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.getFieldName()).equal(false);
		return queryHelper.get(query, DAO_NAME, "findContentById");
	}
	

	public DraftContentEntity findLatestDraftById(ObjectId contentId) {
		Query<DraftContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(contentId);
		query.order(VERSION);
		query.limit(1);
		return queryHelper.get(query, DAO_NAME, "findLatestDraftById");
	}
	
	public DraftContentEntity findContentByIdAndUserId(String contentId,String userId) throws Exception {
		Query<DraftContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		List<String> users = new ArrayList<String>();
		users.add(userId);
		query.criteria(ACCESS_CONTROL_LIST).hasAnyOf(users);
		return queryHelper.get(query, DAO_NAME, "findContentByIdAndUserId");
	}

	public DraftContentsResponse findContentByUserId(String userId, int limit,
			int offset, String sort,List<String> statuses,List<String> moderationStatuses) throws Exception{
		return findContentByUserId(userId, limit, offset, sort, statuses,moderationStatuses,false);
	}

	private DraftContentsResponse findContentByUserId(String userId, int limit,
			int offset, String sort, List<String> statuses,List<String> moderationStatuses,boolean primaryOnly) throws Exception{
		Query<DraftContentEntity> query = createQuery();
		query.disableValidation();
		query.limit(limit);
		query.offset(offset);
		query.order(sort);
		List<String> users = new ArrayList<String>();
		users.add(userId);
		query.criteria(ACCESS_CONTROL_LIST).hasAnyOf(users);
		query.criteria(ContentFields.isDeleted.toString()).equal(false);

		if(!CollectionUtils.isEmpty(statuses)){
			query.criteria(ContentFields.contentStatus.getFieldName()).in(statuses);
		}
		
		if (primaryOnly) {
			query.useReadPreference(ReadPreference.primaryPreferred());
		}
		query.enableValidation();
		List<DraftContentEntity> drafts= queryHelper.asList(query, DAO_NAME, "findContentByUserId");
		DraftContentsResponse response = new DraftContentsResponse();
		response.setCount(queryHelper.count(query, DAO_NAME, "findContentByUserId"));
		response.setDrafts(drafts);
		return response;
	}
	
	public List<DraftContentEntity> findContents(int limit,int offset,String sort,List<String> statuses,List<String> moderationStatuses){
		Query<DraftContentEntity> query = createQuery();
		query.limit(limit);
		query.offset(offset);
		query.order(sort);
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		if(!CollectionUtils.isEmpty(statuses)){
			query.criteria(ContentFields.contentStatus.getFieldName()).in(statuses);
		}
		
		return queryHelper.asList(query, DAO_NAME, "findContents");
	}
	
	public List<String> findContentAccessControlListByContentId(String contentId) {
		List<String> accessControlList = null;
		if(StringUtils.isEmpty(contentId)){
			return null;
		}
		List<String> contentIds = new ArrayList<String>();
		contentIds.add(contentId);
		Map<String, ContentEntity> accessControlListsMap = findContentAccessControlListByContentIds(contentIds);
		if (accessControlListsMap != null) {
			accessControlList = accessControlListsMap.get(contentId).getAccessControlList();
		}
		return accessControlList;
	}

	public Map<String, ContentEntity> findContentAccessControlListByContentIds(List<String> contentIds) {
		Map<String, ContentEntity> accessControlListsMap = new HashMap<String, ContentEntity>();
		Query<DraftContentEntity> query = createQuery();
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for (String contentId:contentIds) {
			objectIds.add(new ObjectId(contentId));
		}
		query.criteria(CONTENT_ID).in(objectIds);
		query.criteria(ContentFields.isDeleted.toString()).equal(false);
		query.retrievedFields(true, CONTENT_ID, USER_ID, ACCESS_CONTROL_LIST);
		List<DraftContentEntity> contents = queryHelper.asList(query, DAO_NAME, "findContentAccessControlListByContentIds");
		if(contents != null) {
			for (DraftContentEntity content:contents) {
				if  (content.getAccessControlList() != null) {
					accessControlListsMap.put(content.getContentId().toString(), content);
				}
			}
		}
		return accessControlListsMap;
	}
	
	/**
	 * Update Content.
	 * 
	 * @param content
	 */
	public int updateContentModule(String contentId, String groupId, ModuleEntity module) throws Exception {
		String moduleId = module.getModuleId();
		UpdateOperations<DraftContentEntity> updateOperations = createUpdateOperations()
				.disableValidation()
				.set("userGeneratedContent.groups.$.moduleMap." + moduleId, module).set(ContentFields.dateModified.name(), new Date())
				.enableValidation();
		Query<DraftContentEntity> query = createQuery();

		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria("userGeneratedContent.groups.groupId").equal(groupId);
		UpdateResults results = update(query, updateOperations);
		return results.getUpdatedCount();

	}

	public int deleteContentModule(String contentId, String groupId,
			String moduleId) throws Exception{
		UpdateOperations<DraftContentEntity> updateOperations = createUpdateOperations()
				.disableValidation().unset("userGeneratedContent.groups.$.moduleMap." + moduleId)
				.enableValidation();
			Query<DraftContentEntity> query = createQuery();

			query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
			query.criteria("userGeneratedContent.groups.groupId").equal(groupId);
			UpdateResults results = update(query, updateOperations);
			return results.getUpdatedCount();
	}

	public void updateContentField(String contentId, List<? extends KeyValue> keyValues) {	
		UpdateOperations<DraftContentEntity> updateOperations = createUpdateOperations();
		updateOperations.disableValidation();
		for (KeyValue kv:keyValues) {
			if(kv.getValue() == null) {
				updateOperations.unset((String) kv.getKey());
			} else {
				updateOperations.set((String) kv.getKey(), kv.getValue());
			}
		}
		updateOperations.set(ContentFields.dateModified.name(), new Date());
		updateOperations.enableValidation();
		
		Query<DraftContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).equal(new ObjectId(contentId));
		query.criteria(ContentFields.isDeleted.getFieldName()).equal(false);
		update(query, updateOperations);
	}

	public void updateContentFieldForContentIdsInResponses(List<BulkAdaptorResponse> responses, List<? extends KeyValue> keyValues){	
		UpdateOperations<DraftContentEntity> updateOperations = createUpdateOperations();
		updateOperations.disableValidation();
		for(KeyValue kv:keyValues) {
			updateOperations.set((String) kv.getKey(), kv.getValue());
		}
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for (BulkAdaptorResponse response:responses) {
			try{
				objectIds.add(new ObjectId(response.getContentId()));
			}catch(IllegalArgumentException i){
				LOGGER.log(LogLevel.ERROR,i);
				response.setStatus(CmsEditorStatus.INVALID_CONTENT_ID);
			}
		}		
		updateOperations.enableValidation();
		Query<DraftContentEntity> query = createQuery();
		query.criteria(CONTENT_ID).in(objectIds);		
		update(query, updateOperations);
	}
	
	
	public List<String> createContent(List<DraftContentEntity> contents) {
		List<String> contentIds = new ArrayList<String>();
		for (DraftContentEntity content : contents) {
			try{
				Key<DraftContentEntity> key = save(content);
				contentIds.add(key.getId().toString());
			}catch(Exception e){
				LOGGER.log(LogLevel.ERROR,e);
			}
		}
		return contentIds;
	}
	
	public String createContent(DraftContentEntity content) throws Exception{
		System.out.println(content.toString());
				Key<DraftContentEntity> key = save(content);
				return key.getId().toString();
	}

	public void updateContent(String contentId, DraftContentEntity content) {
		save(content);
	}
	
	public void createBulkContents(List<BulkAdaptorResponse> contents){
		List<String> contentIds = new ArrayList<String>();
		for(BulkAdaptorResponse content:contents){
			if(content.getStatus()!=CmsEditorStatus.BULK_CREATE_SUCCESS){
				continue;
			}
			try{
				Key<DraftContentEntity> key = save((DraftContentEntity) content.getEntity());
				contentIds.add(key.getId().toString());
				content.setContentId(key.getId().toString());
			}catch(Exception e){
				LOGGER.log(LogLevel.ERROR,e);
				content.setStatus(CmsEditorStatus.CREATE_ERROR);
			}
		}
	}


	/**
	 * Delete by contentIds
	 * @param contentIds
	 */
	public void deleteByContentIds(List<BulkAdaptorResponse> responses){
		deleteByContentIdsAndUserId(responses, null);
	}
	
	/**
	 * Delete by contentIds and userId
	 * @param contentIds
	 * @param userId
	 */
	public void deleteByContentIdsAndUserId(List<BulkAdaptorResponse> responses, String userId){
		if(CollectionUtils.isEmpty(responses)){
			return;
		}
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for(BulkAdaptorResponse response:responses) {
			try{
				objectIds.add(new ObjectId(response.getContentId()));
			}catch(IllegalArgumentException i){
				LOGGER.log(LogLevel.ERROR,i);
				response.setStatus(CmsEditorStatus.INVALID_CONTENT_ID);
			}
		}
		Query<DraftContentEntity > deleteQuery = createQuery();
		deleteQuery.criteria(CONTENT_ID).in(objectIds);
		if(!StringUtils.isEmpty(userId)) {
			deleteQuery.criteria(USER_ID).equals(userId);
		}
		deleteByQuery(deleteQuery);
	}

}
