package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ebay.cos.raptor.service.annotations.ApiDescription;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.base.TimeDuration;
import com.ebay.cos.type.v3.core.listing.Image;


@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserGeneratedContent {
	
	private Text title;
	private Text synopsis;
	private Text conclusionTitle;
	private Text conclusionDescription;
	private Image coverImage;
	private List<String> tags;
	private List<Group> groups;
	@ApiDescription("Estimated Time to complete the steps in this article")
	private TimeDuration estimatedTime;
	@ApiDescription("Possible values: LOW,MEDIUM,HIGH")
	private String costRange;
	@ApiDescription("Possible values: LOW,MEDIUM,HIGH")
	private String difficultyLevel;
	@ApiDescription("List of materials needed to complete the steps in this article")
	private List<Text> materialsNeeded;
	@ApiDescription("List of tools needed to perform the steps in this article")
	private List<Text> toolsNeeded;
	@ApiDescription("Represents the marketing assets for different social sites like Facebook, Instagram")
	private MarketingAssets marketingAssets;
	@ApiDescription("A map with key as the category level and value as the id. Represents the categories with which this article has been tagged")
	private Map<String, String> categories;
	
	
	public List<Group> getGroups() {
		return groups;
	}
	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}
	
	
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public Text getTitle() {
		return title;
	}
	public void setTitle(Text title) {
		this.title = title;
	}
	public Text getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(Text synopsis) {
		this.synopsis = synopsis;
	}
	public Image getCoverImage() {
		return coverImage;
	}
	public void setCoverImage(Image coverImage) {
		this.coverImage = coverImage;
	}
	public TimeDuration getEstimatedTime() {
		return estimatedTime;
	}
	public void setEstimatedTime(TimeDuration estimatedTime) {
		this.estimatedTime = estimatedTime;
	}
	public String getCostRange() {
		return costRange;
	}
	public void setCostRange(String costRange) {
		this.costRange = costRange;
	}
	public String getDifficultyLevel() {
		return difficultyLevel;
	}
	public void setDifficultyLevel(String difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}
	public List<Text> getMaterialsNeeded() {
		return materialsNeeded;
	}
	public void setMaterialsNeeded(List<Text> materialsNeeded) {
		this.materialsNeeded = materialsNeeded;
	}
	public List<Text> getToolsNeeded() {
		return toolsNeeded;
	}
	public void setToolsNeeded(List<Text> toolsNeeded) {
		this.toolsNeeded = toolsNeeded;
	}
	public Text getConclusionTitle() {
		return conclusionTitle;
	}
	public void setConclusionTitle(Text conclusionTitle) {
		this.conclusionTitle = conclusionTitle;
	}
	public Text getConclusionDescription() {
		return conclusionDescription;
	}
	public void setConclusionDescription(Text conclusionDescription) {
		this.conclusionDescription = conclusionDescription;
	}
	public MarketingAssets getMarketingAssets() {
		return marketingAssets;
	}
	public void setMarketingAssets(MarketingAssets marketingAssets) {
		this.marketingAssets = marketingAssets;
	}
	public Map<String, String> getCategories() {
		return categories;
	}
	public void setCategories(Map<String, String> categories) {
		this.categories = categories;
	}
	
	

}