package com.ebay.raptor.cmseditor.response.content.model;

public class StandardComponent extends Component {
	
	private String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
	

}
