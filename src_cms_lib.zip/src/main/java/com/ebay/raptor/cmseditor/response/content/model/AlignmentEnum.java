package com.ebay.raptor.cmseditor.response.content.model;

public enum AlignmentEnum {

	IMAGE_TEXT,TEXT_IMAGE,IMAGE_SLIDER;
}
