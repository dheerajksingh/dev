package com.ebay.raptor.cmseditor.adapter;

import java.util.Collection;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.pegdown.PegDownProcessor;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.response.content.model.ModuleType;

public class PlainTextBuilder {

	PegDownProcessor processor;

	private static final Logger LOGGER = Logger
			.getInstance(PlainTextBuilder.class);
	
	public PlainTextBuilder(){
		try{
			this.processor = new PegDownProcessor();
		}catch(Exception e){
			System.out.println("int palin text builder "+e.getMessage());
			e.printStackTrace();
		}
	}

	public String convertToPlainText(ContentEntity model) {
		try {
			String markdownText = extractMarkdown(model);
			if (!StringUtils.isEmpty(markdownText)) {
				String htmlText = processor.markdownToHtml(markdownText);
				if (!StringUtils.isEmpty(htmlText)) {
					String cleanText = Jsoup.clean(htmlText, new Whitelist());
					return cleanText;
				}
			}
		} catch (Exception e) {
			LOGGER.log(LogLevel.ERROR, e);
			e.printStackTrace();
		}
		return null;
	}
	
	private String extractMarkdown(ContentEntity model) {
		UserGeneratedContentEntity content = model.getUserGeneratedContent();
		StringBuilder builder = new StringBuilder();
		if (content != null) {
			if (content.getTitle() != null
					&& !StringUtils.isEmpty(content.getTitle())) {
				builder.append(content.getTitle());
			}
			if (content.getSynopsis() != null
					&& !StringUtils.isEmpty(content.getSynopsis())) {
				builder.append(content.getSynopsis());
			}
			List<GroupEntity> groups = content.getGroups();
			if (!CollectionUtils.isEmpty(groups)) {
				for (GroupEntity group : groups) {
					if (group.getTitle() != null
							&& !StringUtils.isEmpty(group.getTitle()
									.getContent())) {
						builder.append(group.getTitle().getContent());
					}
					Collection<ModuleEntity> sections = group.getModuleMap().values();
					if (!CollectionUtils.isEmpty(sections)) {
						for (ModuleEntity section : sections) {
							List<SingleModuleEntity> components = section.getData();
							if (!CollectionUtils.isEmpty(components)) {
								for (SingleModuleEntity component : components) {
									String componentType = component.getEntityType();
									if (!StringUtils.isEmpty(componentType)) {
										if (componentType
												.equals(ModuleType.BLOCK_QUOTE
														.name())
												|| componentType
														.equals(ModuleType.HEADING
																.name())
												|| componentType
														.equals(ModuleType.PARAGRAPH
																.name())) {
											if (!StringUtils
													.isEmpty(component
															.getData())) {
												builder.append(component
														.getData());
											}
										}
									}
								}
							}
						}
					}
				}
			}

		}
		return builder.toString();
	}

}
