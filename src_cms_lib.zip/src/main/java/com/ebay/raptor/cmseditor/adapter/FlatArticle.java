package com.ebay.raptor.cmseditor.adapter;

import java.util.Date;
import java.util.List;

public class FlatArticle {
	
	private String id;
	private String title;
	private String synopsis;
	private String templateType;
	private List<String> tags;
	private List<String> systemTags;
	private String content;
	private String summary;
	private String siteId;
	private String locale;
	private Date creationDate;
	private Date lastModifiedDate;
	private Integer[] allCats;
	private List<String> allCatsName;
	private int leafCat;
	private String leafCatName;
	private String authorLoginName;
	private long authorId;
	private String authorImage;
	private int authorRankScore;
	private int authorType;
	private int numPics;
	private int numVideos;
	private boolean pictureBroken;
	private long likeCount;
	private long viewCount;
	private long commentCount;
	private double qualityScore;
	private int sponsored;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public String getTemplateType() {
		return templateType;
	}
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public List<String> getSystemTags() {
		return systemTags;
	}
	public void setSystemTags(List<String> systemTags) {
		this.systemTags = systemTags;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Integer[] getAllCats() {
		return allCats;
	}
	public void setAllCats(Integer[] allCats) {
		this.allCats = allCats;
	}
	public List<String> getAllCatsName() {
		return allCatsName;
	}
	public void setAllCatsName(List<String> allCatsName) {
		this.allCatsName = allCatsName;
	}
	public int getLeafCat() {
		return leafCat;
	}
	public void setLeafCat(int leafCat) {
		this.leafCat = leafCat;
	}
	public String getLeafCatName() {
		return leafCatName;
	}
	public void setLeafCatName(String leafCatName) {
		this.leafCatName = leafCatName;
	}
	public String getAuthorLoginName() {
		return authorLoginName;
	}
	public void setAuthorLoginName(String authorLoginName) {
		this.authorLoginName = authorLoginName;
	}
	public long getAuthorId() {
		return authorId;
	}
	public void setAuthorId(long authorId) {
		this.authorId = authorId;
	}
	public String getAuthorImage() {
		return authorImage;
	}
	public void setAuthorImage(String authorImage) {
		this.authorImage = authorImage;
	}
	public int getAuthorRankScore() {
		return authorRankScore;
	}
	public void setAuthorRankScore(int authorRankScore) {
		this.authorRankScore = authorRankScore;
	}
	public int getAuthorType() {
		return authorType;
	}
	public void setAuthorType(int authorType) {
		this.authorType = authorType;
	}
	public int getNumPics() {
		return numPics;
	}
	public void setNumPics(int numPics) {
		this.numPics = numPics;
	}
	public int getNumVideos() {
		return numVideos;
	}
	public void setNumVideos(int numVideos) {
		this.numVideos = numVideos;
	}
	public boolean isPictureBroken() {
		return pictureBroken;
	}
	public void setPictureBroken(boolean pictureBroken) {
		this.pictureBroken = pictureBroken;
	}
	public long getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(long likeCount) {
		this.likeCount = likeCount;
	}
	public long getViewCount() {
		return viewCount;
	}
	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}
	public long getCommentCount() {
		return commentCount;
	}
	public void setCommentCount(long commentCount) {
		this.commentCount = commentCount;
	}
	public double getQualityScore() {
		return qualityScore;
	}
	public void setQualityScore(double qualityScore) {
		this.qualityScore = qualityScore;
	}
	public int getSponsored() {
		return sponsored;
	}
	public void setSponsored(int sponsored) {
		this.sponsored = sponsored;
	}
}