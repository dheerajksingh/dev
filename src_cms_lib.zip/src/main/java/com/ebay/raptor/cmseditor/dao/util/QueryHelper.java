package com.ebay.raptor.cmseditor.dao.util;

import java.util.List;

import org.mongodb.morphia.query.Query;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;

import com.ebay.kernel.calwrapper.CalTransaction;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class QueryHelper {
	
	private static CALLogger cal = new CALLogger();

	public  <T> List<T> asList(Query<T> query, String daoName, String queryName) {
		CalTransaction calT = cal.get(daoName, queryName);
	    final long startTime = System.currentTimeMillis();
        try {
            return query.asList();
        } finally {
            cal.log(daoName, queryName, query, timeTaken(startTime));
            if (calT != null) {
                cal.close(calT);
            }
        }
	}
	
	public <T> long countAll(Query<T> query, String daoName, String queryName) {
		CalTransaction calT = cal.get(daoName, queryName);
	    final long startTime = System.currentTimeMillis();
        try {
            return query.countAll();
        } finally {
            cal.log(daoName, queryName, query, timeTaken(startTime));
            if (calT != null) {
                cal.close(calT);
            }
        }
	}
	
	public <T> Long  count(Query<T> query, String daoName, String queryName) {
		CalTransaction calT = cal.get(daoName, queryName);
	    final long startTime = System.currentTimeMillis();
        try {
            return query.countAll();
        } finally {
            cal.log(daoName, queryName, query, timeTaken(startTime));
            if (calT != null) {
                cal.close(calT);
            }
        }
	}
	
	public  <T> T get(Query<T> query, String daoName, String queryName) {
		CalTransaction calT = cal.get(daoName, queryName);
	    final long startTime = System.currentTimeMillis();
        try {
            return query.get();
        } finally {
            cal.log(daoName, queryName, query, timeTaken(startTime));
            if (calT != null) {
                cal.close(calT);
            }
        }
	}

	private static long timeTaken(long startTime) {
		return System.currentTimeMillis() - startTime;
	}
}
