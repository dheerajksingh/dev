package com.ebay.raptor.cmseditor.dao.entities;

import java.util.Map;

import com.ebay.cos.type.v3.base.Text;

/**
 * 
 * 
 * @author kravikumar
 *
 */
public class GroupEntity {

	
	private Text title;
	
	//REQUIREMENTS,STANDARD
	private String groupType;
	
	private String groupId;
	
	//This captures attributes like time to complete,materials required etc
	private Map<String, String> attributes;
	
	private Map<String,ModuleEntity> moduleMap;


	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}
	
	public Text getTitle() {
		return title;
	}

	public void setTitle(Text title) {
		this.title = title;
	}

	public Map<String, ModuleEntity> getModuleMap() {
		return moduleMap;
	}

	public void setModuleMap(Map<String, ModuleEntity> moduleMap) {
		this.moduleMap = moduleMap;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public Map<String, String> getAttributes() {
		return attributes;
	}

	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}
	
}
