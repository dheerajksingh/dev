package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ebay.cos.raptor.service.annotations.ApiDescription;
import com.ebay.cos.type.v3.base.Text;


@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class Group {
	
	private Text title;

	@ApiDescription("STANDARD,STEP,LIST")
	private String groupType;

	private String groupId;


	private List<Section> sections;

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	public List<Section> getSections() {
		return sections;
	}

	public void setSections(List<Section> sections) {
		this.sections = sections;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public Text getTitle() {
		return title;
	}

	public void setTitle(Text title) {
		this.title = title;
	}
	

}