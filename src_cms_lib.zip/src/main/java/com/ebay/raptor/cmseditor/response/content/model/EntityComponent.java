package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;

public class EntityComponent extends Component{
	
	private List<String> entityIds;
	private String entityType;
	
	public List<String> getEntityIds() {
		return entityIds;
	}

	public void setEntityIds(List<String> entityIds) {
		this.entityIds = entityIds;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	
}
