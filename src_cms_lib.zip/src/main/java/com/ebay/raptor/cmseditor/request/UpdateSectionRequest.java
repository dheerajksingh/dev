package com.ebay.raptor.cmseditor.request;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ebay.raptor.cmseditor.response.content.model.Section;

public class UpdateSectionRequest {
	
	@JsonIgnore
	private String articleId;
	
	@JsonIgnore
	private String userId;
	
	private Section section;
	
	@JsonIgnore
	private String groupId;
	
	
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Section getSection() {
		return section;
	}
	public void setSection(Section section) {
		this.section = section;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	

}