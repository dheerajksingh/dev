package com.ebay.raptor.cmseditor.response;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.ebayopensource.ginger.common.types.ErrorData;
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class BulkResponse {
	
	private int httpStatus;
	private BulkPayload payload;
	private ErrorData error;
	public int getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(int httpStatus) {
		this.httpStatus = httpStatus;
	}
	
	public ErrorData getError() {
		return error;
	}
	public void setError(ErrorData error) {
		this.error = error;
	}
	public BulkPayload getPayload() {
		return payload;
	}
	public void setPayload(BulkPayload payload) {
		this.payload = payload;
	}
	

	
}
