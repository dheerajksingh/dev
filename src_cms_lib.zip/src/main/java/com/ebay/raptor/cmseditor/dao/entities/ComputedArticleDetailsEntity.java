package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;

public class ComputedArticleDetailsEntity {

	private double qualityScore;
	private List<String> recommendedTags;
	private long likeCount;
	private long viewCount;
	private long commentCount;
	private String authorImageUrl;
	private int authorRankScore;
	private int authorType;
	private boolean pictureBroken;
	private boolean sponsored;
	
	public double getQualityScore() {
		return qualityScore;
	}
	public void setQualityScore(double qualityScore) {
		this.qualityScore = qualityScore;
	}
	public List<String> getRecommendedTags() {
		return recommendedTags;
	}
	public void setRecommendedTags(List<String> recommendedTags) {
		this.recommendedTags = recommendedTags;
	}
	public long getLikeCount() {
		return likeCount;
	}
	public void setLikeCount(long likeCount) {
		this.likeCount = likeCount;
	}
	public long getViewCount() {
		return viewCount;
	}
	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}
	public long getCommentCount() {
		return commentCount;
	}
	public void setCommentCount(long commentCount) {
		this.commentCount = commentCount;
	}
	public String getAuthorImageUrl() {
		return authorImageUrl;
	}
	public void setAuthorImageUrl(String authorImageUrl) {
		this.authorImageUrl = authorImageUrl;
	}
	public int getAuthorRankScore() {
		return authorRankScore;
	}
	public void setAuthorRankScore(int authorRankScore) {
		this.authorRankScore = authorRankScore;
	}
	public int getAuthorType() {
		return authorType;
	}
	public void setAuthorType(int authorType) {
		this.authorType = authorType;
	}
	public boolean isPictureBroken() {
		return pictureBroken;
	}
	public void setPictureBroken(boolean pictureBroken) {
		this.pictureBroken = pictureBroken;
	}
	public boolean isSponsored() {
		return sponsored;
	}
	public void setSponsored(boolean sponsored) {
		this.sponsored = sponsored;
	}
	
}
