package com.ebay.raptor.cmseditor.error;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.ebayopensource.ginger.common.types.ErrorData;
import org.ebayopensource.ginger.common.types.ErrorMessage;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;

public class ErrorBuilder {
	
	private static final String DOMAIN="Buying";
	
	public void buildErrorMessage(CmsEditorResponse response,
			List<CmsEditorStatus> errors) {
		if (!CollectionUtils.isEmpty(errors)) {
			ErrorMessage errorMessage = new ErrorMessage();

			for (CmsEditorStatus error : errors) {
				ErrorData errorData = getError(error);
				if (errorData == null) {
					continue;
				}
				errorMessage.getError().add(errorData);
			}
			response.setErrorMessage(errorMessage);
		}
	}

	public ErrorData getError(CmsEditorStatus error) {
		ErrorData data = new ErrorData();
		data.setSeverity(error.getSeverity());
		data.setDomain(DOMAIN);
		data.setErrorId(error.getId());
		data.setMessage(error.getMessage());
		return data;
	}

}
