package com.ebay.raptor.cmseditor.request;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ebay.cos.raptor.service.annotations.ApiDescription;
import com.ebay.raptor.cmseditor.response.content.model.Article;

public class BulkCreateArticleRequest {
	
	@JsonIgnore
	private String userId;
	
	private List<Article> articles;
	
	@ApiDescription("Possible values:DRAFT,PUBLISHED")
	private String mode;
	
	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public List<Article> getArticles() {
		return articles;
	}

	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
