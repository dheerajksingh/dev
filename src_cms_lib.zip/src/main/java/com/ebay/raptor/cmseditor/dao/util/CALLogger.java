package com.ebay.raptor.cmseditor.dao.util;

import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.QueryImpl;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.ebay.kernel.calwrapper.CalEventFactory;
import com.ebay.kernel.calwrapper.CalTransaction;
import com.ebay.kernel.calwrapper.CalTransactionFactory;

@Component
@Configuration("FountainAdminLogger")
public class CALLogger {
	public void close(CalTransaction calTransaction) {
		calTransaction.completed();
	}

	public void close(CalTransaction calTransaction, Throwable t) {
		calTransaction.setStatus(t);
		calTransaction.completed();
	}

	public CalTransaction get(String type, String name) {
		CalTransaction calTransaction = null;
		try {
			calTransaction = CalTransactionFactory
					.create(type);
			calTransaction.setName(name);
			calTransaction.setStatus("0");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return calTransaction;
	}
	
	@SuppressWarnings("rawtypes")
	public void log(String name, String message, Query query, long timeTaken) {
		logEvent("Info", name, message, query, "0", timeTaken);
	}
	
	@SuppressWarnings("rawtypes")
	private void logEvent(String type, String name, String message, Query query, String status, long timeTaken) {
		String msg = String.format("%s %s Time taken:%d", message, query == null? "" : ((QueryImpl)query).getQueryObject().toString(), timeTaken);
     	CalEventFactory.create(type, name, status, msg).completed();
	}
}