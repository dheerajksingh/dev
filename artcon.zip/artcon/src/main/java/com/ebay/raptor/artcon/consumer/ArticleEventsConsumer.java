package com.ebay.raptor.artcon.consumer;

import javax.inject.Inject;

import com.ebay.bes.consumer.ConfigurationException;
import com.ebay.bes.consumer.Consumer;
import com.ebay.bes.consumer.ConsumerDynamicConfig;
import com.ebay.bes.consumer.ConsumerRegistry;
import com.ebay.bes.consumer.EventProcessor;
import com.ebay.bes.consumer.SubscriptionStatus;
import com.ebay.kernel.bean.configuration.BeanConfigCategoryInfo;
import com.ebay.kernel.bean.configuration.ConfigCategoryCreateException;
import com.ebay.kernel.initialization.InitializationException;
import com.ebay.raptor.artcon.processor.ArticleEventProcessor;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.ebay.raptor.besevents.ArticleDeleteEvent;
import com.ebay.raptor.besevents.ArticlePublishEvent;
import com.ebay.raptor.besevents.ArticleStatusChangeEvent;
import com.ebay.raptor.besevents.ConsumerConstants;

public class ArticleEventsConsumer extends Consumer<ConsumerDynamicConfig>{

	public static final String CONSUMER_NAME = "UserArticleEventsConsumer";
	
	@Inject ArticleEventProcessor eventProcessor;
	
	public void init(){
BeanConfigCategoryInfo configCategory = null;
		
		try {
			try {
				configCategory = BeanConfigCategoryInfo.createBeanConfigCategoryInfo(
						CONSUMER_NAME,      
						CONSUMER_NAME,      
				        "BESConsumerGroup",  
				        true,                
				        true,                
				        null,                
				        "To consume all events related to articles",
				        true
				    );			
			} catch (ConfigCategoryCreateException e) {
				throw new InitializationException(e);
			}
			
			m_config = new ConsumerDynamicConfig(configCategory, CONSUMER_NAME,
			        SubscriptionStatus.MARK_UP);
			registerEvents();
				ConsumerRegistry.getInstance().registerConsumer(this); 			
		} catch (Exception e) {
			e.printStackTrace();
			 throw new InitializationException(e);
		}
	}
	
	public void registerEvents(){
		try {
			m_config.createEventSubscriptionConfig(ConsumerConstants.ARTICLE_PUBLISH_EVENT,
					ArticlePublishEvent.class, 
 			        SubscriptionStatus.MARK_UP);
			m_config.createEventSubscriptionConfig(ConsumerConstants.ARTICLE_STATUSCHANGE_EVENT,
					ArticleStatusChangeEvent.class, 
 			        SubscriptionStatus.MARK_UP);
			m_config.createEventSubscriptionConfig(ConsumerConstants.ARTICLE_DELETE_EVENT,
					ArticleDeleteEvent.class, 
 			        SubscriptionStatus.MARK_UP); 
			m_config.createEventSubscriptionConfig(ConsumerConstants.ARTICLE_BULK_UPLOAD_EVENT,
					ArticleBulkUploadEvent.class, 
 			        SubscriptionStatus.MARK_UP); 
		} catch (ConfigurationException e) {
			e.printStackTrace();
			throw new InitializationException(e);
		}
	}
	
	@Override
	public EventProcessor getEventProcessor(String eventType) {
		return eventProcessor;
	}

}

