package com.ebay.raptor.artcon.task;

import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient;
import com.ebay.raptor.artcon.task.BulkContentCreateTask;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.ebay.raptor.orchestration.ITaskOrchestrator;
import com.ebay.raptor.orchestration.ITaskResult;
import com.ebay.raptor.orchestration.TaskExecutionException;
import com.ebay.raptor.orchestration.TaskOrchestratorFactory;

public class BulkContentTaskManager {

    protected ITaskOrchestrator orchestrator;
    protected SingleFilesDao singleFilesDao;    
    protected CmsEditorServiceClient cmsEditorServiceClient;

    
	
	public BulkContentTaskManager(){
		this.cmsEditorServiceClient =  new CmsEditorServiceClient();
	//	this.orchestrator = TaskOrchestratorFactory.create();
	}
	
	public void setSingleFilesDao(SingleFilesDao singleFilesDao) {
		if(this.singleFilesDao==null)
		this.singleFilesDao = singleFilesDao;
	}	
	
	
    public ITaskResult<Object> createBulkUploadTask(BaseArticle article,String id) throws TaskExecutionException {
        this.orchestrator = TaskOrchestratorFactory.create();
        		return  this.orchestrator.execute(new BulkContentCreateTask(article,cmsEditorServiceClient,singleFilesDao,id));

        
    }
    
    public ITaskResult<Object> createBulkUpdateTask(Article article,String id) throws TaskExecutionException {
    	this.orchestrator = TaskOrchestratorFactory.create();
    	return this.orchestrator.execute(new BulkContentUpdateTask(article,cmsEditorServiceClient,singleFilesDao,id));
    	
    }
    
	
}
