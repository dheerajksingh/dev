package com.ebay.raptor.artcon.handler;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import com.ebay.bes.common.BusinessEvent;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.artcon.indexer.ArticleSolrIndexer;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.artcon.utils.PlainTextBuilder;
import com.ebay.raptor.besevents.ArticleStatusChangeEvent;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.spam.akismet.Akismet;
import com.ebay.spam.akismet.AkismetComment;

public class ArticleStatusChangeEventHandler implements ArticleEventHandler {

	private static final Logger LOGGER = Logger
			.getInstance(ArticleStatusChangeEventHandler.class);

	@Inject
	Akismet akismet;
	
	ArticleSolrIndexer articleSolrIndexer = new ArticleSolrIndexer();

	private static final String SPAM = "SPAM";
	private static final String HAM = "HAM";

	@Override
	/**
	 * 	Payload should have prev status, actor.
		
		1.) If actor is system then do nothing.
		2.) If actor is moderator and status is live, then push it to elastic.
		3.) If actor is moderator and status is blacklisted, then remove from elastic.
		4.) Based on prev and current status send feedback to akismet.
	 */
	public void processEvent(BusinessEvent event) throws Exception {
		ArticleStatusChangeEvent statusChangeEvent = (ArticleStatusChangeEvent) event;
		CALUtil.logCALEvent("ARTCON-INFO-RECEIVED_EVENT", "ARTICLE.STATUSCHANGE", statusChangeEvent.getArticleId());
		updateAkismetAndIndexIfNeeded(statusChangeEvent);
		CALUtil.logCALEvent("ARTCON-INFO-SUCESS", "ARTICLE.STATUSCHANGE", statusChangeEvent.getArticleId());
	}

	private void updateAkismetAndIndexIfNeeded(ArticleStatusChangeEvent statusChangeEvent) {
		try {
			if (SPAM.equals(statusChangeEvent.getStatus())) {
				CALUtil.logCALEvent("ARTCON-INFO", "Removing from Solr", statusChangeEvent.getArticleId());
				articleSolrIndexer.remove(statusChangeEvent.getArticleId());
			}
			CmsEditorServiceClient cmsEditorServiceClient = new CmsEditorServiceClient();
			Article article = cmsEditorServiceClient
					.getPublishedContent(statusChangeEvent.getArticleId());
			PlainTextBuilder plainText = new PlainTextBuilder();
			String response = plainText.convertToPlainText(article);
			if (StringUtils.isEmpty(response)) {
				return;
			}
			AkismetComment comment = new AkismetComment();
			comment.setCommentContent(response);
			 comment.setCommentAuthor(statusChangeEvent.getCommentAuthor());
			 comment.setCommentType(statusChangeEvent.getCommentType());
			 comment.setReferrer(statusChangeEvent.getReferrer());
			 comment.setUserAgent(statusChangeEvent.getUserAgent());
			 comment.setUserIp(statusChangeEvent.getUserIp());
			if (HAM.equals(statusChangeEvent.getStatus())) {
				CALUtil.logCALEvent("ARTCON-INFO", "Indexing article", statusChangeEvent.getArticleId());
				articleSolrIndexer.index(article);
				akismet.submitHam(comment);
			} else if (statusChangeEvent.getStatus() == SPAM) {
				akismet.submitSpam(comment);
			}

		} catch (Exception e) {
			LOGGER.log(LogLevel.ERROR, e);
		}
	}
}
