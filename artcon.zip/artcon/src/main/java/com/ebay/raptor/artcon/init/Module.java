package com.ebay.raptor.artcon.init;


import com.ebay.bes.common.V3BESConfig;
import com.ebay.bes.consumer.framework.V3ConsumerMonitor;
import com.ebay.kernel.initialization.BaseInitializable;
import com.ebay.kernel.initialization.BaseInitializationManager;
import com.ebay.kernel.initialization.BaseModule;
import com.ebay.kernel.initialization.InitializationContext;
import com.ebay.kernel.initialization.ModuleInterface;
import com.ebay.raptor.kernel.lifecycle.ModuleInitializer;

@ModuleInitializer
public class Module extends BaseModule {
	private static Module s_Module = new Module();

	private Module() {
		super(new InitializationManager());
	}


	public static ModuleInterface getInstance() {
		return s_Module;
	}
	
	 static class InitializationManager extends BaseInitializationManager {

		final static  ModuleInterface [] DEPENDENT_MODULES = {
			com.ebay.bes.consumer.Module.getInstance(),
		};

		InitializationManager() {
			super(DEPENDENT_MODULES);
			getInitializationHelper().add(createBesconsumer());
			getInitializationHelper().add(MapInitializer.getInitializable());
			getInitializationHelper().add(CacheInitializer.getInitializable());
		}
		
		   private BaseInitializable createBesconsumer() {
		        return new BaseInitializable() {
		            @SuppressWarnings("resource")
					public void initialize(InitializationContext context) {
		            		V3BESConfig.getInstance().setPropertyValue("LOW_MEMORY_THRESHOLD",
		            				Integer.valueOf(0));
		            		V3ConsumerMonitor.getInstance().startAll();
		            		new SampleArticleBesProducer();
		            		System.out.println("InitializationManager gets inited!!!!!");
		            }
		            
		            public void shutdown(InitializationContext context) {
		            }
		        };
			}

	};
}