package com.ebay.raptor.artcon.utils;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.CommonParams;
import org.apache.solr.common.params.MoreLikeThisParams;

import com.ebay.raptor.artcon.config.ConfigParam;
import com.ebay.raptor.artcon.serviceclient.CategoryServiceClient;

public class CategoryHelper {

	protected CategoryServiceClient catServiceClient;
	protected HttpSolrServer solrServer;
	
	public CategoryHelper() {
		String solrHostStr = ConfigParam.INFER_CAT_HOST.getStringValue();
		solrServer = new HttpSolrServer(solrHostStr);
		catServiceClient = new CategoryServiceClient();
	}

	public List<Long> findMltCategories(String terms) throws IOException,
			SolrServerException {
		SolrQuery query = new SolrQuery();
		query.setRequestHandler("/" + MoreLikeThisParams.MLT);
		query.set("stream.body", URLEncoder.encode(terms, "UTF-8"));
		query.set("mlt.fl", "words_txm");
		query.set(MoreLikeThisParams.MATCH_INCLUDE, true);
		query.set(MoreLikeThisParams.MIN_DOC_FREQ, 2);
		query.set(MoreLikeThisParams.MIN_TERM_FREQ, 1);
		query.set(MoreLikeThisParams.MIN_WORD_LEN, 2);
		query.set(MoreLikeThisParams.BOOST, true);
		query.set(MoreLikeThisParams.MAX_QUERY_TERMS, 50);
		query.set(CommonParams.FL, "id");
		query.set(CommonParams.ROWS, 10);
		QueryResponse response = solrServer.query(query);
		SolrDocumentList resultList = response.getResults();

		List<Long> resultCatIds = new ArrayList<Long>();
		for (SolrDocument doc : resultList) {
			resultCatIds.add(Long.valueOf(doc.get("id").toString()));
		}
		return resultCatIds;
	}

	public List<Integer> getCategoryPath(int siteId, long categoryId)
			throws Exception {
		List<Integer> path = new ArrayList<Integer>(10);
		Map<Long, Long> leafCategoryIdSiteIdMap = new HashMap<>();
		leafCategoryIdSiteIdMap.put(Long.valueOf(siteId),
				Long.valueOf(categoryId));

		Map<Long, List<Integer>> catFullPathMp = catServiceClient
				.getCategoryFullPath(leafCategoryIdSiteIdMap);
		path = catFullPathMp.get(categoryId);
		// Reverse the order

		int i = 0;
		int j = path.size() - 1;

		while (i < j) {

			// Swap
			Integer cId = path.get(i);
			path.set(i, path.get(j));
			path.set(j, cId);

			i++;
			j--;
		}

		return path;
	}

}
