package com.ebay.raptor.artcon.handler;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.ebay.bes.common.BusinessEvent;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient;
import com.ebay.spam.akismet.Akismet;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.artcon.config.ConfigParam;
import com.ebay.raptor.artcon.indexer.ArticleSolrIndexer;
import com.ebay.raptor.artcon.init.ArticleInit;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.artcon.utils.PlainTextBuilder;
import com.ebay.raptor.besevents.ArticlePublishEvent;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.spam.akismet.AkismetComment;

public class ArticlePublishEventHandler implements ArticleEventHandler {
	
	private static final Logger LOGGER = Logger.getInstance(ArticlePublishEventHandler.class);	
	
	@Inject 
	protected Akismet akismet;
	@Autowired 
	protected ApplicationContext context;
	@Inject 
	protected ArticleInit init;
	
	protected ArticleSolrIndexer articleSolrIndexer;
	protected CmsEditorServiceClient cmsEditorServiceClient;

	private static final String SPAM = "SPAM_SUSPECTED";
	private static final String LIVE = "PUBLISHED";
	
	public ArticlePublishEventHandler() {
		cmsEditorServiceClient = new CmsEditorServiceClient();
		articleSolrIndexer = new ArticleSolrIndexer();
	}
	
	/**
	 *  1.) Run spam detection
		2.) If is good mark it as Live by calling the service and also put in elastic search
		3.) If it is bad call the service mark it as blacklisted.
	 */
	@Override
	public void processEvent(BusinessEvent event) throws Exception {
		ArticlePublishEvent publishEvent = (ArticlePublishEvent) event;
		CALUtil.logCALEvent("ARTCON-INFO-RECEIVED_EVENT", "ARTICLE.PUBLISH", publishEvent.getArticleId());
		handleSpamCheck(publishEvent);
		CALUtil.logCALEvent("ARTCON-INFO-SUCESS", "ARTICLE.PUBLISH", publishEvent.getArticleId());
	}

	private void handleSpamCheck(ArticlePublishEvent publishEvent) {
		try {
			Article article  = cmsEditorServiceClient.getPublishedContent(publishEvent.getArticleId());		
			PlainTextBuilder plainText = new PlainTextBuilder();
			String response = plainText.convertToPlainText(article);
			if (StringUtils.isEmpty(response)) {
				return;
			}
			if(ConfigParam.SPAM_CHECK_ON.getBooleanValue()){
				AkismetComment comment = new AkismetComment();
				comment.setCommentContent(response);
				comment.setCommentAuthor(publishEvent.getCommentAuthor());
				comment.setCommentType(publishEvent.getCommentType());
				comment.setReferrer(publishEvent.getReferrer());
				comment.setUserAgent(publishEvent.getUserAgent());
				comment.setUserIp(publishEvent.getUserIp());
				
				boolean hasSpam = akismet.commentCheck(comment);
				if (hasSpam) {
					CALUtil.logCALEvent("ARTCON-INFO", "Found spam", publishEvent.getArticleId());
					cmsEditorServiceClient.updateModerationStatus(
							publishEvent.getArticleId(), SPAM);
					articleSolrIndexer.remove(article.getArticleId());
				} else {
					cmsEditorServiceClient.updateModerationStatus(
							publishEvent.getArticleId(), LIVE);
					articleSolrIndexer.index(article);
				}
			}else{
				cmsEditorServiceClient.updateModerationStatus(
						publishEvent.getArticleId(), LIVE);
				articleSolrIndexer.index(article);
			}
		} catch (Exception e) {
			LOGGER.log(LogLevel.ERROR, e);
			CALUtil.logCALEvent("ARTCON-INFO-FAILED", "Spam detection failed", publishEvent.getArticleId());
		}
	}

}
