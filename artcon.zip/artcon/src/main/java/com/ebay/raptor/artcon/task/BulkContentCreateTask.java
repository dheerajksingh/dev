package com.ebay.raptor.artcon.task;

import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.response.BulkCreateDraftResponse;
import com.ebay.raptor.artcon.response.BulkPublishArticleResponse;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.ebay.raptor.orchestration.Callable;

public class BulkContentCreateTask {
	  
	   protected BaseArticle baseArticle;
	   protected CmsEditorServiceClient cmsEditorServiceClient;
	   protected String id ;
       protected SingleFilesDao singleFilesDao;
       
       private String UPLOAD="UPLOAD";
       
		public BulkContentCreateTask(BaseArticle baseArticle,CmsEditorServiceClient cmsEditorServiceClient,SingleFilesDao singleFilesDao,String id){
			this.baseArticle=baseArticle;
			this.cmsEditorServiceClient=cmsEditorServiceClient;
			this.singleFilesDao=singleFilesDao;
			this.id=id;
		}
	
		@SuppressWarnings("unused")
		@Callable(name="BulkContentCreateTask")
		public PublishArticleResponse performTask() {
	
			// Perform Task  - Create Draft 
			
			BulkCreateDraftResponse draftResp=uploadContent();
			if(draftResp==null){
				this.singleFilesDao.updateSingleFileDraft(id, "DRAFT_FAILED",null,null,null,UPLOAD);
				CALUtil.logCALEvent("ARTCON-BULKPLOAD-DRAFT-TASK-FAILED","FILE_ID "+id,"CREATE_DRAFT_FAILED");
				return null;
			}
			CALUtil.logCALEvent("ARTCON-BULKPLOAD-DRAFT-TASK","FILE_ID "+id,draftResp.getCreateDraftResponse().getStatus().name());
			if(draftResp.getCreateDraftResponse().getStatus()==CmsEditorResponseStatus.SUCCESS)
			this.singleFilesDao.updateSingleFileDraft(id, "DRAFT",draftResp.getCreateDraftResponse().getContentId(),null,draftResp.getRlogId(),UPLOAD);
			else
				this.singleFilesDao.updateSingleFileDraft(id, "DRAFT_FAILED",draftResp.getCreateDraftResponse().getContentId(),draftResp.getError(),draftResp.getRlogId(),UPLOAD);

			// Perform Task  - Publish
	
			BulkPublishArticleResponse publishResp=publishContent(draftResp.getCreateDraftResponse());	
			if(publishResp==null){
				this.singleFilesDao.updateSingleFilePublished(this.id,"PUBLISH_FAILED",null,null,null,UPLOAD);
				CALUtil.logCALEvent("ARTCON-BULKPLOAD-PUBLISH-TASK-FAILED","FILE_ID "+id,"PUBLISH_FAILED");
				return null;
			}
			CALUtil.logCALEvent("ARTCON-BULKPLOAD-PUBLISH-TASK","FILE_ID "+id,publishResp.getPublishArticleResponse().getStatus().name());
			if(publishResp.getPublishArticleResponse().getStatus()==CmsEditorResponseStatus.SUCCESS)
			this.singleFilesDao.updateSingleFilePublished(this.id,"PUBLISHED",publishResp.getPublishArticleResponse().getArticleId(),null,publishResp.getRlogId(),UPLOAD);
			else
				this.singleFilesDao.updateSingleFilePublished(this.id,"PUBLISH_FAILED",null,publishResp.getError(),publishResp.getRlogId(),UPLOAD);

			return publishResp.getPublishArticleResponse();
		}
		
		// commenting out retry mechanism
		
		private BulkPublishArticleResponse publishContent(CreateDraftResponse draftResp){
			BulkPublishArticleResponse publishResp=null;
				publishResp=cmsEditorServiceClient.publishContent(draftResp.getContentId());
				return publishResp;

			
		}
		private BulkCreateDraftResponse uploadContent(){
			BulkCreateDraftResponse draftResp=null;
				draftResp=cmsEditorServiceClient.uploadContent(baseArticle);
				return draftResp;
		}
		

		
	}



