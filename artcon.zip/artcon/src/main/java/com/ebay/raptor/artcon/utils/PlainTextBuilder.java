package com.ebay.raptor.artcon.utils;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.pegdown.PegDownProcessor;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.ModuleType;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;

public class PlainTextBuilder {

	PegDownProcessor processor;

	private static final Logger LOGGER = Logger
			.getInstance(PlainTextBuilder.class);
	
	public PlainTextBuilder(){
		try{
		this.processor=new PegDownProcessor();
		}catch(Exception e){
			System.out.println("int palin text builder "+e.getMessage());
			e.printStackTrace();
		}
	}

	public String convertToPlainText(Article model) {
		try {
			String markdownText = extractMarkdown(model);
			if (!StringUtils.isEmpty(markdownText)) {
				String htmlText = processor.markdownToHtml(markdownText);
				if (!StringUtils.isEmpty(htmlText)) {
					String cleanText = Jsoup.clean(htmlText, new Whitelist());
					return cleanText;
				}
			}
		} catch (Exception e) {
			LOGGER.log(LogLevel.ERROR, e);
			e.printStackTrace();
		}
		return null;
	}
	
	private String extractMarkdown(Article model) {
		UserGeneratedContent content = model.getUserGeneratedContent();
		StringBuilder builder = new StringBuilder();
		if (content != null) {
			if (content.getTitle() != null
					&& !StringUtils.isEmpty(content.getTitle().getContent())) {
				builder.append(content.getTitle().getContent());
			}
			if (content.getSynopsis() != null
					&& !StringUtils.isEmpty(content.getSynopsis().getContent())) {
				builder.append(content.getSynopsis().getContent());
			}
			List<Group> groups = content.getGroups();
			if (!CollectionUtils.isEmpty(groups)) {
				for (Group group : groups) {
					if (group.getTitle() != null
							&& !StringUtils.isEmpty(group.getTitle()
									.getContent())) {
						builder.append(group.getTitle().getContent());
					}
					List<Section> sections = group.getSections();
					if (!CollectionUtils.isEmpty(sections)) {
						for (Section section : sections) {
							List<Component> components = section.getComponents();
							if (!CollectionUtils.isEmpty(components)) {
								for (Component component : components) {
									String componentType = component.getComponentType();
									if (!StringUtils.isEmpty(componentType)) {
										if (componentType
												.equals(ModuleType.BLOCK_QUOTE
														.name())
												|| componentType
														.equals(ModuleType.HEADING
																.name())
												|| componentType
														.equals(ModuleType.PARAGRAPH
																.name())) {
											StandardComponent standardComponent = (StandardComponent) component;
											if (!StringUtils
													.isEmpty(standardComponent
															.getData())) {
												builder.append(standardComponent
														.getData());
											}
										}
									}
								}
							}
						}
					}
				}
			}

		}
		return builder.toString();
	}

}
