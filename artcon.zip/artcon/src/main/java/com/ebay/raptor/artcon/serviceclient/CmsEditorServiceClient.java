package com.ebay.raptor.artcon.serviceclient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.ebay.platform.raptor.cosadaptor.exceptions.TokenCreationException;
import com.ebay.platform.raptor.cosadaptor.token.SecureTokenFactory;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.internal.GingerClientFactory.ClientCreationException;
import org.ebayopensource.ginger.client.internal.GingerClientManager;
import org.ebayopensource.ginger.client.internal.GingerClientManager.ClientAlreadyRegisteredException;
import org.ebayopensource.ginger.client.internal.InitGingerClientConfigFactory.ConfigCreationException;
import org.ebayopensource.ginger.common.types.ErrorData;

import com.ebay.raptor.artcon.response.BulkCreateDraftResponse;
import com.ebay.raptor.artcon.response.BulkPublishArticleResponse;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadResponse;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.sun.jersey.core.util.MultivaluedMapImpl;


public class CmsEditorServiceClient {

	private static final String CLIENT_ID = "CmsEditorServiceClient";
	private static final String SERVICE_NAME = "cmseditorsvc";
	private static final String RLOGID="RlogId";

	//Endpoints
	private static final String ARTICLE_FOR_MODERATION= "/article/{articleId}";
	private static final String MODERATION="/article/{articleId}/update_status";
	private static final String ARTICLE_UPLOAD="/article";
	private static final String ARTICLE_PUBLISH="/article/{articleId}/publish";
	private static final String ARTICLE_GET_FOR_PUBLISH = "/article/{articleId}/edit_published";
	private static final String ARTICLE_UPDATE = "/article/{articleId}";

	protected  GingerClient client;

	@SuppressWarnings({"rawtypes","unchecked"}) 
	public boolean updateArticleDraft(Article article){
		try{
			MultivaluedMap headers = new MultivaluedMapImpl();
			client =getGingerClient();
			String token = this.getToken();
			headers.add("Authorization", token); 
			String target = ARTICLE_UPDATE.replace("{articleId}",article.getArticleId() );
			GingerWebTarget webTarget = client.target(target);
			Invocation.Builder resourceBuilder = (Builder) webTarget.queryParam("articleId", article.getArticleId())
					.request(MediaType.APPLICATION_JSON).headers(headers);
			System.out.println("Uri updateArticleDraft -- "+webTarget.getUri());
			GingerClientResponse response=(GingerClientResponse)resourceBuilder.put(Entity.entity(article, MediaType.APPLICATION_JSON));
			return( response.getEntity(CmsEditorResponse.class)!=null);	
		}catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "getpublishedContent", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "getpublishedContent", ExceptionUtils.getFullStackTrace(e));			
		}
		return false;
	}
	
	@SuppressWarnings({"rawtypes","unchecked"}) 
	public Article getPublishedForEdit(String articleId){
		try{
			MultivaluedMap headers = new MultivaluedMapImpl();
			client =getGingerClient();
			String token = this.getToken();
			headers.add("Authorization", token); 
			String target = ARTICLE_GET_FOR_PUBLISH.replace("{articleId}",articleId );
			GingerWebTarget webTarget = client.target(target);
			Invocation.Builder resourceBuilder = (Builder) webTarget.queryParam("articleId", articleId)
					.request(MediaType.APPLICATION_JSON).headers(headers);
			System.out.println("Uri getPublishedForEdit -- "+webTarget.getUri());
			GingerClientResponse response=(GingerClientResponse)resourceBuilder.post(Entity.entity(articleId, MediaType.APPLICATION_JSON));
			ArticleReadResponse  articleReadResponse = response.getEntity(ArticleReadResponse.class);	
			return articleReadResponse.getArticle();
		}catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "getpublishedContent", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "getpublishedContent", ExceptionUtils.getFullStackTrace(e));			
		}
		return null;
	}
	
	private String getToken() throws TokenCreationException{
		
		int count=0;
		String token=null;
		while(count<3){
			try{
				token=this.generateAppToken();
				break;
			}catch(TokenCreationException e ){
				if(count>=3)
					throw e;
				else
					count++;
			}
		}
			
		return token;
	}
	
	@SuppressWarnings({"rawtypes", "unchecked" })
	public Article getPublishedContent(String articleId) {
		try {
			MultivaluedMap headers = new MultivaluedMapImpl();
			GingerClient client = getGingerClient();
			String token = this.getToken();
			headers.add("Authorization", token); 
			GingerWebTarget webTarget = client.target(ARTICLE_FOR_MODERATION.replace("{articleId}",articleId));
			Invocation.Builder resourceBuilder = (Builder) webTarget
					.queryParam("mode", "PUBLISHED")
					.request(MediaType.APPLICATION_JSON).headers(headers);
			System.out.println(" uri get Published conent "+webTarget.getUri());
			GingerClientResponse response = (GingerClientResponse) resourceBuilder.get();
			
			if(!isSuccess(response)) {
				throw new Exception("Response Status: " + (response == null ? "null" : response.getStatus()));
			}
			ArticleReadResponse articleResp =response.getEntity(ArticleReadResponse.class);
			Article article = articleResp.getArticle();
			return article;
		} catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "getpublishedContent", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "getpublishedContent", ExceptionUtils.getFullStackTrace(e));			
		}
		return null;
	}
	
	@SuppressWarnings({"rawtypes", "unchecked" })
	public BulkPublishArticleResponse publishContent(String contentId) {	
		BulkPublishArticleResponse bulkPublishArticleResponse = null;
		try {
			MultivaluedMap headers = new MultivaluedMapImpl();
			client =getGingerClient();
			String token = this.getToken();
			headers.add("Authorization", token); 
			String target = ARTICLE_PUBLISH.replace("{articleId}",contentId );
			GingerWebTarget webTarget = client.target(target);
			Invocation.Builder resourceBuilder = (Builder) webTarget.queryParam("articleId", contentId)
					.request(MediaType.APPLICATION_JSON).headers(headers);
			GingerClientResponse response=(GingerClientResponse)resourceBuilder.post(Entity.entity(contentId, MediaType.APPLICATION_JSON));
			System.out.println("Uri publish -- "+webTarget.getUri()+"  contentid"+contentId);
			  bulkPublishArticleResponse = new BulkPublishArticleResponse();
			  PublishArticleResponse  publishArticleResponse = response.getEntity(PublishArticleResponse.class);	
			  bulkPublishArticleResponse.setPublishArticleResponse(publishArticleResponse);
			  if(publishArticleResponse.getErrorMessage()!=null){
				  bulkPublishArticleResponse.setError(errorBuilder(publishArticleResponse.getErrorMessage().getError()));
			  }
				 String rlogid=(response.getMetadata().containsKey(RLOGID)?response.getMetadata().get(RLOGID).toString():null);
				 bulkPublishArticleResponse.setRlogId(rlogid);			  
			if(!isSuccess(response)) {
				throw new Exception("Response Status: " + (response == null ? "null" : response.getStatus()) +" Thread id - "+Thread.currentThread().getId());
			}

		} catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			System.out.println(" Publish ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException   "+e.getMessage());
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "publishedContent", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			System.out.println(" Publish Exception  -   "+e.getMessage());
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "publishedContent", ExceptionUtils.getFullStackTrace(e));			
		}
		return bulkPublishArticleResponse;
	}
	
	private String errorBuilder(List<ErrorData> list){
		StringBuilder sb = new StringBuilder();
		for(ErrorData data:list){
			sb.append(data.getLongMessage()).append("\t");
		}
		return sb.toString();
	}
	
	@SuppressWarnings({"rawtypes", "unchecked" })
	public BulkCreateDraftResponse uploadContent(BaseArticle baseArticle) {
		BulkCreateDraftResponse draftResponse=null;
		try {
			MultivaluedMap headers = new MultivaluedMapImpl();
			GingerClient client =getGingerClient();
			String token = this.getToken();
			headers.add("Authorization", token);
			GingerWebTarget webTarget = client.target(ARTICLE_UPLOAD);
			Invocation.Builder resourceBuilder = (Builder) webTarget
					.request(MediaType.APPLICATION_JSON).headers(headers);
			System.out.println("Uri upload  -- "+webTarget.getUri());
			GingerClientResponse response=(GingerClientResponse)resourceBuilder.post(Entity.entity(baseArticle, MediaType.APPLICATION_JSON));
			CreateDraftResponse createDraftResponse=response.getEntity(CreateDraftResponse.class);
			draftResponse = new BulkCreateDraftResponse();
			 draftResponse.setCreateDraftResponse(createDraftResponse);
			  if(createDraftResponse.getErrorMessage()!=null){
				  draftResponse.setError(errorBuilder(createDraftResponse.getErrorMessage().getError()));
			  }
			 String rlogid=(response.getMetadata().containsKey(RLOGID)?response.getMetadata().get(RLOGID).toString():null);
			 draftResponse.setRlogId(rlogid);

			 if(!isSuccessBulkUpload(response)) {
				throw new Exception("Response Status: " + (response == null ? "null" : response.getStatus()));
			}
			 
		} catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			System.out.println(" Upload ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException   "+e.getMessage());
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.DRAFT_CONTENT_TASK_EXCEPTION, "uploadContent", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			System.out.println(" Upload Exception  -   "+e.getMessage());
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.DRAFT_CONTENT_TASK_EXCEPTION, "uploadContent", ExceptionUtils.getFullStackTrace(e));			
		}
		return draftResponse;
	}


		
	protected String generateAppToken() throws TokenCreationException {
		return SecureTokenFactory.getInstance().getToken().getAccessToken();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public boolean updateModerationStatus(String articleId,String spamStatus) {
		try {
			GingerClient client = getGingerClient();
			MultivaluedMap headers = new MultivaluedMapImpl();
			String token = generateAppToken();
			headers.add("Authorization", token); 
			GingerWebTarget webTarget = client.target(MODERATION.replace("{articleId}",articleId));
			Invocation.Builder resourceBuilder = (Builder) webTarget
					.request(MediaType.APPLICATION_JSON).headers(headers);
			
			UpdateModerationStatusRequest request = new UpdateModerationStatusRequest();
			request.setStatus(spamStatus);
			GingerClientResponse response = (GingerClientResponse) resourceBuilder.post(Entity.entity(request,
					MediaType.APPLICATION_JSON));
			if(!isSuccess(response)) {
				throw new Exception("Response Status: " + (response == null ? "null" : response.getStatus()));
			}
			return true;
		} catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			CALUtil.logFailedCALEvent(CALUtil.UPDATE_CONTENT_TASK_EXCEPTION, "updateModerationStatus", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.UPDATE_CONTENT_TASK_EXCEPTION, "updateModerationStatus", ExceptionUtils.getFullStackTrace(e));			
		}
		return false;
	}
	
	
	private boolean isSuccessBulkUpload(GingerClientResponse response){
		return response!=null && response.getStatus()==Response.Status.CREATED.getStatusCode();
	}
	
	private boolean isSuccess(GingerClientResponse response){
		return response!=null && (response.getStatus()==Response.Status.OK.getStatusCode() || 	response.getStatus()==Response.Status.NO_CONTENT.getStatusCode());
	}
	
	
	static class UpdateModerationStatusRequest{
		String status;

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
		
	}
	
	private GingerClient getGingerClient() throws ConfigCreationException, ClientCreationException, ClientAlreadyRegisteredException {
		
		if(client != null) {
			return client;
		}
		int count=0;
		synchronized(this){
		  if(client==null){	
			  try{
					while(count<3)
					{
						client= GingerClientManager.get().getOrRegisterClient(CLIENT_ID, SERVICE_NAME);
						System.out.println(" client value "+client);
						break;
					}
			     }
			  catch(ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e){
				  System.out.println(" exception client creation "+ count);
				  if(count>=3){
					  throw e;
				  }
				  else
				  count++;
			 }
		  }
		  return client;
		}
		
	}

}

