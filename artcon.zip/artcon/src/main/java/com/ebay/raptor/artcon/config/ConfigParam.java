package com.ebay.raptor.artcon.config;

import org.apache.commons.collections.KeyValue;
import org.apache.commons.collections.keyvalue.DefaultKeyValue;

public enum ConfigParam {
	USER_ARTICLE_SERVICE_ENDPOINT("USER_ARTICLE_SERVICE_ENDPOINT", "http://cmseditor.stratus.qa.ebay.com/user_content/v1/", ValueType.AString),
	INFER_CAT_HOST("INFER_CAT_HOST", "http://phx5qa01c-7026.stratus.phx.qa.ebay.com:8080/solr/catDict", ValueType.AString),
	MYWORLD_SERVICE_ENDPOINT("MYWORLD_SERVICE_ENDPOINT", "http://myworldsvc.stratus.qa.ebay.com/mywrldsvc/v1/", ValueType.AString),
	ENGACTIV_SERVICE_ENDPOINT("ENGACTIV_SERVICE_ENDPOINT", "http://engactiv.stratus.qa.ebay.com/act/v1/", ValueType.AString),
	SOLR_RAW_PHX_ENDPOINT("SOLR_RAW_PHX_ENDPOINT", "http://phx5qa01c-7026.stratus.phx.qa.ebay.com:8080/solr/", ValueType.AString),
	SOLR_RAW_SLC_ENDPOINT("SOLR_RAW_SLC_ENDPOINT", "http://phx5qa01c-7026.stratus.phx.qa.ebay.com:8080/solr/", ValueType.AString),
	INDEX_TO_BOTH_COLOS_GUIDES("INDEX_TO_BOTH_COLOS_GUIDES", "false", ValueType.ABoolean),
	FOUNTAIN_ADMIN_SERVICE_ENDPOINT("FOUNTAIN_ADMIN_SERVICE_ENDPOINT", "http://www.at.fntnadmin.qa.ebay.com/fountainadmin/v1/", ValueType.AString),
	MONGO_FOUNTAIN_DB_NAME("MONGO_FOUNTAIN_DB_NAME", "curatedcollection2db", ValueType.AString),
	MONGO_FOUNTAIN_SERVER_ADDRESS("MONGO_FOUNTAIN_SERVER_ADDRESS", "mongodb://sm-curatedcollection21.db.stratus.qa.ebay.com:27017,sm-curatedcollection22.db.stratus.qa.ebay.com:27017,sm-curatedcollection23.db.stratus.qa.ebay.com:27017", ValueType.AString),
	BULK_UPLOAD_FILE_LOCATION("BULK_UPLOAD_FILE_LOCATION","//Users//dheersingh//data_files//",ValueType.AString),
	STOP_WORDS("STOP_WORDS", "", ValueType.AString),
	AUTHOR_FEEDBACK_THRESHOLD("AUTHOR_FEEDBACK_THRESHOLD", "0", ValueType.AnInteger),
	ENGLISH_WORDS_THRESHOLD("ENGLISH_WORDS_THRESHOLD", "0.7", ValueType.ADouble),
	CHECK_TAGS_IN_BIZ_RULE("CHECK_TAGS_IN_BIZ_RULE", "true", ValueType.ABoolean),
	SPAM_CHECK_ON("SPAM_CHECK_ON","false",ValueType.ABoolean);

	final String key;
    final String defaultValue;
    public final ValueType valueType;

    private ConfigParam(String key, String defaultValue, ValueType valueType) {
		this.key = key;
		this.defaultValue = defaultValue;
        this.valueType = valueType;
	}

    public enum ValueType {
        AString, ABoolean, ALong, AnInteger, ADouble
    }
    
    public String getStringValue(){
    	return ConfigUtil.getString(key, defaultValue, -1);
    }

	public boolean getBooleanValue() {
		return ConfigUtil.getBoolean(key, Boolean.valueOf(defaultValue), -1);
	}

	public long getLongValue() {
		return ConfigUtil.getLong(key, Long.valueOf(defaultValue), -1);
	}

	public int getIntValue() {
		return ConfigUtil.getInt(key, Integer.valueOf(defaultValue), -1);
	}
	
	public double getDoubleValue() {
		return ConfigUtil.getDouble(key, Double.valueOf(defaultValue), -1);
	}

    public KeyValue getKeyValue() {
        switch (valueType) {
            case ABoolean:
                return new DefaultKeyValue(key, getBooleanValue());
            case ADouble:
                return new DefaultKeyValue(key, getDoubleValue());
            case ALong:
                return new DefaultKeyValue(key, getLongValue());
            case AnInteger:
                return new DefaultKeyValue(key, getIntValue());
            default:
                return new DefaultKeyValue(key, getStringValue());
        }
    }
}
