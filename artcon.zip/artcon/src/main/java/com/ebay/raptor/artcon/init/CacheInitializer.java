package com.ebay.raptor.artcon.init;

import java.util.HashSet;
import java.util.Set;

import com.ebay.integ.batchjob.BatchJobCacheBean;
import com.ebay.integ.metadatalabel.MetadataLabelCacheBean;
import com.ebay.integ.partnercontingency.PartnerContingencyCacheBean;
import com.ebay.kernel.initialization.BaseInitializable;
import com.ebay.kernel.initialization.Initializable;
import com.ebay.kernel.initialization.InitializationContext;

public class CacheInitializer extends
		com.ebay.integ.dal.cache2.CacheInitializer {
	private static CacheInitializer m_Instance = null;

	private static Initializable s_initializable = null;

	private static boolean s_initialized = false;

	public static synchronized Initializable getInitializable() {
		if (s_initializable != null) {
			return s_initializable;
		}

		BaseInitializable initializable = new BaseInitializable() {
			protected void initialize(final InitializationContext context) {
				CacheInitializer.initialize(context);
			}

			protected void shutdown(final InitializationContext context) {
				s_initializable = null;
			}

			public synchronized Set getCharacteristics() {
				HashSet<Initializable.CharacteristicEnum> characteristics = new HashSet<Initializable.CharacteristicEnum>(
						1);
				characteristics
						.add(Initializable.CharacteristicEnum.NO_LAZY_INIT);
				return characteristics;
			}
		};
		s_initializable = initializable;
		return s_initializable;
	}

	private CacheInitializer() {
		// empty
	}

	synchronized static CacheInitializer getInstance() {
		if (m_Instance == null) {
			m_Instance = new CacheInitializer();
		}
		return m_Instance;
	}

	private static void initialize(InitializationContext context) {
		if (s_initialized) {
			return;
		}
		getInstance().initializeCacheBypassPolicy(
				PartnerContingencyCacheBean.getInstance(), true, "subarumugam");
		
		getInstance().initializeCacheBypassPolicy(
				MetadataLabelCacheBean.getInstance(), true, "subarumugam");
		
		getInstance().initializeCacheBypassPolicy(
				BatchJobCacheBean.getInstance(), true, "subarumugam");

		s_initialized = true;
	}
}