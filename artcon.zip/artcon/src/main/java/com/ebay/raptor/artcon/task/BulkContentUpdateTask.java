package com.ebay.raptor.artcon.task;

import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.response.BulkCreateDraftResponse;
import com.ebay.raptor.artcon.response.BulkPublishArticleResponse;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.ebay.raptor.orchestration.Callable;

public class BulkContentUpdateTask {
	  
	   protected Article article;
	   protected CmsEditorServiceClient cmsEditorServiceClient;
	   protected String id ;
       protected SingleFilesDao singleFilesDao;
       
       private  static final String UPDATE="UPDATE";
       
		public BulkContentUpdateTask(Article article,CmsEditorServiceClient cmsEditorServiceClient,SingleFilesDao singleFilesDao,String id){
			this.article=article;
			this.cmsEditorServiceClient=cmsEditorServiceClient;
			this.singleFilesDao=singleFilesDao;
			this.id=id;
		}
	
		@SuppressWarnings("unused")
		@Callable(name="BulkContentCreateTask")
		public PublishArticleResponse performTask() {
	
			//  Get Published for Update  - This creates a new Draft and returns Article .
			System.out.println("*** articleID for Publish for edit   ************************ "+article.getArticleId());
			Article articleDraft=cmsEditorServiceClient.getPublishedForEdit(article.getArticleId());
			System.out.println("*** after getPublishedForEdit  ************************ "+articleDraft);
			
			if(articleDraft==null){
				this.singleFilesDao.updateSingleFileDraft(id, "DRAFT_FAILED",null,null,null,UPDATE);
				CALUtil.logCALEvent("ARTCON-BULKUPDATE-DRAFT-TASK-FAILED","FILE_ID "+id,"  DRAFT-ID" +article.getArticleId());
				return null;
			}
			CALUtil.logCALEvent("ARTCON-BULKUPDATE-DRAFT-TASK","FILE_ID "+id,"  DRAFT-ID" +article.getArticleId());

			article.setArticleId(articleDraft.getArticleId());
			
			if(!cmsEditorServiceClient.updateArticleDraft(article)){
				this.singleFilesDao.updateSingleFilePublished(this.id,"DRAFT_UPDATE_FAILED",null,null,null,UPDATE);
				CALUtil.logCALEvent("ARTCON-BULKUPDATE-DRAFT-UPDATE-TASK-FAILED","FILE_ID "+id,"  DRAFT-ID" +article.getArticleId());
			}
			else{
				this.singleFilesDao.updateSingleFilePublished(this.id,"DRAFT_UPDATE",articleDraft.getArticleId(),null,null,UPDATE);
				BulkPublishArticleResponse publishResp=cmsEditorServiceClient.publishContent(article.getArticleId());
				System.out.println(" after publish  ************************ "+publishResp.getPublishArticleResponse().getArticleId());

				if(publishResp==null){
					this.singleFilesDao.updateSingleFilePublished(this.id,"PUBLISH_FAILED",null,null,null,UPDATE);
					CALUtil.logCALEvent("ARTCON-BULKPLOAD-PUBLISH-TASK-FAILED","FILE_ID "+id,"PUBLISH_FAILED");
					return null;
				}
				CALUtil.logCALEvent("ARTCON-BULKPLOAD-PUBLISH-TASK","FILE_ID "+id,publishResp.getPublishArticleResponse().getStatus().name());
				if(publishResp.getPublishArticleResponse().getStatus()==CmsEditorResponseStatus.SUCCESS)
				this.singleFilesDao.updateSingleFilePublished(this.id,"PUBLISHED",publishResp.getPublishArticleResponse().getArticleId(),null,publishResp.getRlogId(),UPDATE);
				else
					this.singleFilesDao.updateSingleFilePublished(this.id,"PUBLISH_FAILED",null,publishResp.getError(),publishResp.getRlogId(),UPDATE);
				return publishResp.getPublishArticleResponse();

			}
		return null;
		}
	}



