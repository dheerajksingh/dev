package com.ebay.raptor.artcon.utils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ebay.raptor.artcon.article.model.ArticleModel;
import com.ebay.raptor.artcon.article.model.Author;
import com.ebay.raptor.artcon.config.ConfigParam;

public class BusinessRule {
	public boolean notClean(ArticleModel am) {
		if (am == null) {
			return true;
		}
		if (notEnoughFeedback(am)) {
			return true;
		}
		if (hasExternalUrl(am)) {
			return true;
		}
//		if ( am.getMarketplaceId()!=null && Integer.parseInt(am.getMarketplaceId()) != 77 && notEnoughEnglish(am)) {
//			return true;
//		}
		if (hasBlacklistWords(am)) {
			return true;
		}
		return false;
	}

	public boolean notEnoughFeedback(ArticleModel am) {
		Author author = am.getArticleAuthor();
		if (author != null
				&& author.getFeedbackScore() <= ConfigParam.AUTHOR_FEEDBACK_THRESHOLD.getIntValue()) {
			return true;
		} else {
			return false;
		}
	}

	private boolean hasExternalUrl(ArticleModel am) {
		return false;
	}

	public boolean notEnoughEnglish(ArticleModel am) {
		String content = am.getPlainText();
		if (content == null || content.length() == 0) {
			return false;
		}
		content = content.toLowerCase();
		double countEnglish = 0;
		for (int i = 0; i < content.length(); i++) {
			if (content.charAt(i) >= 'a' && content.charAt(i) <= 'z') {
				countEnglish++;
			}
		}
		return countEnglish / content.length() >= ConfigParam.ENGLISH_WORDS_THRESHOLD.getDoubleValue() ? false : true;
	}

	public boolean hasBlacklistWords(ArticleModel am) {
		Set<String> blacklistWords = AssetRepositoryUtil.getBlacklistWords();
		Set<String> guideWords = new HashSet<String>();
		if (blacklistWords == null || blacklistWords.size() == 0) {
			return false;
		}
		if (am.getUserGeneratedContent() == null || am.getUserGeneratedContent().getTitle() == null
				|| am.getUserGeneratedContent().getTitle().getContent() == null || am.getUserGeneratedContent().getTags() == null) {
			return false;
		}
		String titleContent = am.getUserGeneratedContent().getTitle().getContent();
		List<String> titleWords = Arrays.asList(titleContent.toLowerCase().split(" "));
		guideWords.addAll(titleWords);
		
		if (ConfigParam.CHECK_TAGS_IN_BIZ_RULE.getBooleanValue()) {
			for (String t : am.getUserGeneratedContent().getTags()) {
				t = t.toLowerCase();
				guideWords.add(t);
			}
		}
		
		if (blacklistWords != null) {
			for (String bw : blacklistWords) {
				if (contains(guideWords, bw)) {
					return true;
				}
			}	
		}
		return false;		
	}
	
	private boolean contains(Set<String> dict, String word) {
		String[] tokens = word.split(" ");
		for (String s : tokens) {
			if (!dict.contains(s)) {
				return false;
			}
		}
		return true;
	}
}
