package com.ebay.raptor.artcon.serviceclient;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.InvocationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.internal.GingerClientManager;
import org.ebayopensource.ginger.client.internal.GingerClientFactory.ClientCreationException;
import org.ebayopensource.ginger.client.internal.GingerClientManager.ClientAlreadyRegisteredException;
import org.ebayopensource.ginger.client.internal.InitGingerClientConfigFactory.ConfigCreationException;

import com.ebay.platform.raptor.cosadaptor.token.SecureTokenFactory;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class MyWorldServiceClient {

	protected static String CLIENT_ID = "MyWorldServiceClient";
	private static final String SERVICE_NAME = "myworldsvc";
	private GingerClient client = null;
	
	public MyWorldServiceClient() {}
	
	protected MyWorldServiceClient(GingerClient client) {
		this.client = client;
	}
	
	public UserProfileServiceResponse getUser(String username) {
		if (username == null || username.isEmpty()) {
			return null;
		}
		username = username.trim();
		try {					
			client = getGingerClient();
			GingerWebTarget webTarget = client.target("/myworld/batch/user_lookup");
			String token = SecureTokenFactory.getInstance().getToken().getAccessToken();
			Invocation.Builder resourceBuilder = webTarget.request(MediaType.APPLICATION_JSON)
					.header("Authorization", token);
			UserProfileServiceRequest request = new UserProfileServiceRequest();
			Set<String> usernames = new HashSet<String>();
			usernames.add(username);
			request.setUsernames(usernames);
			
			GingerClientResponse resp = (GingerClientResponse) resourceBuilder.post(Entity.entity(request, MediaType.APPLICATION_JSON));
			return resp.getEntity(UserProfileServiceResponse.class);
		} catch (Exception e) {
			CALUtil.logFailedCALEvent("MyWorldServiceClient", "getUser", username + ExceptionUtils.getFullStackTrace(e));
		}
		return null;
	}
	
	private GingerClient getGingerClient() throws ConfigCreationException, ClientCreationException, ClientAlreadyRegisteredException {
		
		if(client != null) {
			return client;
		}
		client = GingerClientManager.get().getOrRegisterClient(CLIENT_ID, SERVICE_NAME);
		return client;
		
	}
	
}
