package com.ebay.raptor.artcon.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ebay.kernel.context.AppBuildConfig;

public class AssetRepositoryUtil {

	private static Set<String> blacklistWords;
	private static String blacklistWordsFile = "http://assets.vip.ebay.com/seo_data/guides/blacklistWords.txt";
	
	private static final Logger s_logger = LoggerFactory.getLogger(AssetRepositoryUtil.class);

	static {
		if (!AppBuildConfig.getInstance().isQATE()) {
			try {
				initBlacklistWords(blacklistWordsFile);
			} catch (IOException e) {
				s_logger.error( "Error to read blacklist words file");
				e.printStackTrace();
			}
		}
	}
	
	private static void initBlacklistWords(String fileName) throws IOException {
		Set<String> results = new HashSet<String>();
		URL pageUrl = null;
		if (!fileName.startsWith("http")) {
			File readFile = new File(fileName);
			pageUrl = new URL(readFile.toURI().toString());
		} else {
			pageUrl = new URL(fileName);
		}
		URLConnection getConn = pageUrl.openConnection();
		getConn.connect();
		Scanner in = new Scanner(new InputStreamReader(getConn.getInputStream(), "UTF8"));
		while (in.hasNextLine()) {
			results.add(in.nextLine());
		}
		in.close();
		setBlacklistWords(results);
	}
	
	public static Set<String> getBlacklistWords() {
		return blacklistWords;
	}

	public static void setBlacklistWords(Set<String> blacklistWords) {
		AssetRepositoryUtil.blacklistWords = blacklistWords;
	}
}
