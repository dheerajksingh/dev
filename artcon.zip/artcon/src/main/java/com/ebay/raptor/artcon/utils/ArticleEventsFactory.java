package com.ebay.raptor.artcon.utils;

import javax.inject.Inject;

import com.ebay.bes.common.BusinessEvent;
import com.ebay.raptor.artcon.handler.ArticleBulkUploadEventHandler;
import com.ebay.raptor.artcon.handler.ArticleDeleteEventHandler;
import com.ebay.raptor.artcon.handler.ArticleEventHandler;
import com.ebay.raptor.artcon.handler.ArticlePublishEventHandler;
import com.ebay.raptor.artcon.handler.ArticleStatusChangeEventHandler;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.ebay.raptor.besevents.ArticleDeleteEvent;
import com.ebay.raptor.besevents.ArticlePublishEvent;
import com.ebay.raptor.besevents.ArticleStatusChangeEvent;

/**
 * Event handler generator
 * 
 * @author subarumugam
 *
 */

public class ArticleEventsFactory {
	
	private @Inject ArticlePublishEventHandler publishEventHandler; 
	private @Inject ArticleDeleteEventHandler deleteEventHandler;
	private @Inject ArticleStatusChangeEventHandler statusChangeHandler;
	private @Inject ArticleBulkUploadEventHandler bulkUpoadHandler;
	
	public ArticleEventHandler getEventHandler(BusinessEvent event){
		
		if(event instanceof ArticlePublishEvent){
			return publishEventHandler;
		}else if(event instanceof ArticleDeleteEvent){
			return deleteEventHandler;
		}else if(event instanceof ArticleStatusChangeEvent){
			return statusChangeHandler;		
		}else if(event instanceof  ArticleBulkUploadEvent){
			return bulkUpoadHandler;
		}
		return null; 
	}

}
