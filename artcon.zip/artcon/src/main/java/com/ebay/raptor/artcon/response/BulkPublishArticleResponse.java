package com.ebay.raptor.artcon.response;

import com.ebay.raptor.cmseditor.response.PublishArticleResponse;

public class BulkPublishArticleResponse {

	public String RlogId;
	public String error;
	public PublishArticleResponse publishArticleResponse;

	public PublishArticleResponse getPublishArticleResponse() {
		return publishArticleResponse;
	}
	public void setPublishArticleResponse(
			PublishArticleResponse publishArticleResponse) {
		this.publishArticleResponse = publishArticleResponse;
	}
	
	public String getRlogId() {
		return RlogId;
	}
	public void setRlogId(String rlogId) {
		RlogId = rlogId;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
}
