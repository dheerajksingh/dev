package com.ebay.raptor.artcon.handler;

import com.ebay.bes.common.BusinessEvent;
import com.ebay.raptor.artcon.indexer.ArticleSolrIndexer;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.besevents.ArticleDeleteEvent;

public class ArticleDeleteEventHandler implements ArticleEventHandler {

	private ArticleSolrIndexer articleIndexer = new ArticleSolrIndexer();
	
	@Override
	public void processEvent(BusinessEvent event) throws Exception {
		
		//Remove the article from Solr
		
		ArticleDeleteEvent deleteEvent = (ArticleDeleteEvent) event;
		CALUtil.logCALEvent("ARTCON-INFO-RECEIVED_EVENT", "ARTICLE.DELETE", deleteEvent.getArticleId());
		articleIndexer.remove(deleteEvent.getArticleId());
		CALUtil.logCALEvent("ARTCON-INFO-SUCESS", "ARTICLE.DELETE", deleteEvent.getArticleId());
		
	}

}
