package com.ebay.raptor.artcon.init;

import javax.inject.Inject;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.ebay.kernel.context.AppBuildConfig;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.artcon.consumer.ArticleEventsConsumer;
import com.ebay.raptor.artcon.dao.ZipFilesDao;
import com.ebay.raptor.artcon.handler.ArticleBulkUploadEventHandler;
import com.ebay.raptor.artcon.handler.ArticleDeleteEventHandler;
import com.ebay.raptor.artcon.handler.ArticlePublishEventHandler;
import com.ebay.raptor.artcon.handler.ArticleStatusChangeEventHandler;
import com.ebay.raptor.artcon.indexer.ArticleSolrIndexer;
import com.ebay.raptor.artcon.processor.ArticleEventProcessor;
import com.ebay.raptor.artcon.serviceclient.CategoryServiceClient;
import com.ebay.raptor.artcon.utils.ArticleEventsFactory;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;
import com.ebay.security.exceptions.EsamsException;
import com.ebay.security.holders.NonKeyHolder;
import com.ebay.security.nameservice.NameService;
import com.ebay.security.nameservice.NameServiceFactory;
import com.ebay.spam.akismet.Akismet;
import com.ebay.spam.akismet.AkismetException;

import static org.springframework.beans.factory.config.BeanDefinition.SCOPE_SINGLETON;


@Configuration
public class ArticleInit {
	
	private static final String ESAM_AK_CHANNEL_NAME = "site.akismet.key";
	private static final String ESAM_RECAP_CHANNEL_NAME = "site.recaptcha.secret";
	private static final String API_CONSUMER="ebay";
	private static final String PROXY_URL_PROD="httpproxy.vip.ebay.com";
	private static final String PROXY_URL_QA="qa-proxy.qa.ebay.com";
	private static final int CONNECTION_TIMEOUT=2000;
	private static final int SOCKET_TIMEOUT=5000;
	private static final int PORT=80;
	
	
	private static final Logger LOGGER = Logger.getInstance(ArticleInit.class);


	//@Autowired QueryHelper queryHelper;

	
	@Autowired 
	ZipFilesDao zipFilesDao;
	
	@Bean
	public ZipFilesDao getZipFile() {
		return zipFilesDao;
	}



	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public Akismet getAkismet() throws AkismetException {
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();
		String proxyHost = AppBuildConfig.getInstance().isProduction() ? PROXY_URL_PROD :  PROXY_URL_QA ;
		HttpHost proxy =  new HttpHost(proxyHost, PORT);
		if(AppBuildConfig.getInstance().isDev()){
			proxy = null;
		}
		RequestConfig reqConfig = RequestConfig.custom().setConnectTimeout(CONNECTION_TIMEOUT)
				.setSocketTimeout(SOCKET_TIMEOUT).setProxy(proxy).build();
		clientBuilder.setDefaultRequestConfig(reqConfig);
		Akismet akismet = new Akismet(clientBuilder.build());
		akismet.setApiConsumer(API_CONSUMER);
		try {
			//String key = getKey(ESAM_AK_CHANNEL_NAME);
		//	if(key == null) throw new RuntimeException("Akismet key not found in esams.");
			//akismet.setApiKey(key);
			akismet.setApiKey("045ac5289377");
			if (!akismet.verifyKey()) {
				LOGGER.log(LogLevel.ERROR,"Init failed, Akismet key is not valid");
				akismet.setEnabled(false);
			}else{
				LOGGER.log(LogLevel.INFO,"Akismet initialized");
			}
		} catch (Exception e) {
			akismet.setEnabled(false);
			System.out.println("Init failed, Akismet key is not valid.");
			LOGGER.log(LogLevel.INFO,"Init failed, Akismet key is not valid.");
			return akismet;
		} finally {
		}
		return akismet;
	}
	
	@Bean
	public String getRecaptchaSecret(){
		return getKey(ESAM_RECAP_CHANNEL_NAME);
	}
	
	private String getKey(String channel){
		//initialize esams
		try {
			NameService esams =  NameServiceFactory.getInstance();
			NonKeyHolder nonKeyHolder = esams.getNonKey(channel, NameService.VERSION_LAST_ENABLED);
			if(nonKeyHolder != null ){
				System.out.println("esams success");
				LOGGER.log(LogLevel.INFO,"esams success");
			}else{
				LOGGER.log(LogLevel.INFO,"esams key lookup failed and returned null");
			}
			return nonKeyHolder.getNonKey();
		} catch (EsamsException e) {
			LOGGER.log(LogLevel.ERROR,e);
		}catch (Exception e) {
			LOGGER.log(LogLevel.ERROR,e);
		}
		return null;
	}
	

	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleEventsConsumer getConsumer(){
		return new ArticleEventsConsumer();
	}
	
	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticlePublishEventHandler getPublishHandler(){
		return new ArticlePublishEventHandler();
	}
	
	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleDeleteEventHandler getDeleteHandler(){
		return new ArticleDeleteEventHandler();
	}
	
	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleStatusChangeEventHandler getStatusChangeHandler(){
		return new ArticleStatusChangeEventHandler();
	}
	
	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleBulkUploadEventHandler getBulkUploadEventHandler(){
		return new ArticleBulkUploadEventHandler();
	}
	
	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleEventsFactory getEventsFactory(){
		return new ArticleEventsFactory();
	}
	
	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleEventProcessor getEventProcessor(){
		return new ArticleEventProcessor();
	}

	/*@Bean
	@Scope(value = SCOPE_SINGLETON)
	public ArticleSolrIndexer getArticleSolrIndexer(){
		return new ArticleSolrIndexer();
	}

	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public CategoryServiceClient getCategoryServiceClient(){
		return new CategoryServiceClient();
	}*/
}

