package com.ebay.raptor.artcon.indexer;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.globalenv.SiteEnum;
import com.ebay.integ.metadatalabel.MetadataLabelDAO;
import com.ebay.integ.store.UserStoreLookup;
import com.ebay.integ.store.UserStoreLookupDAO;
import com.ebay.integ.usercontent.UserAuthorRank;
import com.ebay.integ.usercontent.UserAuthorRankDAO;
import com.ebay.kernel.context.AppBuildConfig;
import com.ebay.raptor.artcon.article.model.ArticleModel;
import com.ebay.raptor.artcon.article.model.Author;
import com.ebay.raptor.artcon.config.ConfigParam;
import com.ebay.raptor.artcon.serviceclient.EngactivServiceClient;
import com.ebay.raptor.artcon.serviceclient.MyWorldServiceClient;
import com.ebay.raptor.artcon.serviceclient.UserProfile;
import com.ebay.raptor.artcon.serviceclient.UserProfileServiceResponse;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.artcon.utils.CategoryHelper;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.raptor.kernel.util.GlobalIdConverter;

import edu.emory.mathcs.backport.java.util.Arrays;

public class ArticleProcessor {

	private static final Logger s_logger = LoggerFactory.getLogger(ArticleProcessor.class);
	protected static Map<Integer, Integer> siteToLabel = new HashMap<Integer, Integer>();
	protected static CategoryHelper categoryHelper = new CategoryHelper();
	private static EngactivServiceClient engactivClient = new EngactivServiceClient();
	private static List<String> stopWords = new ArrayList<String>();
	private static String poolType;
	private Article article;
	
	
	private final static String USER_AUTHOR_RANK_TABLE_NAME = "USER_AUTHOR_RANK";
		
	static {
		String stopWordsCSV = ConfigParam.STOP_WORDS.getStringValue();
		try {
			String[] stopWordsArray = stopWordsCSV.split(",");
			stopWords = Arrays.asList(stopWordsArray);
		} catch (Exception e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.ARTICLE_SOLR_INDEXER, "Error loading stop words", ExceptionUtils.getFullStackTrace(e));
		}
		
		if (poolType == null) {
			AppBuildConfig config = AppBuildConfig.getInstance();
			if (config.isDev()) {
				poolType = "dev";
			} else if (config.isQATE()) {
				poolType = "staging";
			} else if (config.isPreProd()) {
				poolType = "preprod";
			} else if (config.isProduction()) {
				poolType = "production";
			}
		}
	}
		
	public ArticleModel process(Article content) {
		
		this.article = content;
		
		ArticleModel articleModel = new ArticleModel(); 
		articleModel.setAccessControlList(article.getAccessControlList());
		articleModel.setAuthor(article.getAuthor());
		articleModel.setArticleId(article.getArticleId());
		articleModel.setArticleStatus(article.getArticleStatus());
		articleModel.setDateCreated(article.getDateCreated());
		articleModel.setDateModified(article.getDateModified());
		articleModel.setMarketplaceId(article.getMarketplaceId());
		articleModel.setModerationStatus(article.getModerationStatus());
		articleModel.setTemplateType(article.getTemplateType());
		articleModel.setUserGeneratedContent(article.getUserGeneratedContent());
		articleModel.setLikes(engactivClient.getArticleLikes(article.getArticleId()));
		articleModel.setMarketplaceId(article.getMarketplaceId());
		articleModel.setScheduledStartDate(article.getScheduledStartDate());
		articleModel.setScheduledEndDate(article.getScheduledEndDate());
		articleModel.setSummary(getSummary(articleModel.getPlainText()));
		populateAuthorFields(articleModel);
		populatePictureMetadata(articleModel);
		return articleModel;
	}

	private static String getSummary(String bodyText) {
		String regex = "\\(?\\b(http://|www[.])[-A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]";
		int end = Math.min(300, bodyText.length());
		String summaryWOUrl = bodyText.substring(0, end);
		summaryWOUrl = summaryWOUrl.replaceAll(regex, "...");
		summaryWOUrl = getCleanName(summaryWOUrl);
		end = Math.min(200, summaryWOUrl.length());
		String summary = summaryWOUrl.substring(0, end);
		for (int i = 200; i < Math.min(summaryWOUrl.length(), 220)
				&& summaryWOUrl.charAt(i) != ' '; i++) {
			summary += summaryWOUrl.charAt(i);
		}
		summary += "...";
		return summary;
	}
	

	private static String getCleanName(String userName) {
		String fullCleanName = null;
		if (userName != null) {
			char fakeSpace = 0x07;
			char realSpace = ' ';
			fullCleanName = userName.replace(fakeSpace, realSpace);
		}

		return fullCleanName;
	}
	
	private List<String> getQueryWords(String text) {

		String[] arrays = text.toLowerCase().trim().split("[^a-zA-Z0-9.&\'\"]");

		Map<String, Integer> counter = new HashMap<String, Integer>();

		for (String s : arrays) {
			if (!stopWords.contains((String) s)) {
				if (!counter.containsKey(s)) {
					counter.put(s, 0);
				}
				counter.put(s, counter.get(s) + 1);
			}
		}

		ValueComparator bvc = new ValueComparator(counter);
		TreeMap<String, Integer> sorted_map = new TreeMap<String, Integer>(bvc);
		sorted_map.putAll(counter);

		List<String> queryWords = new ArrayList<String>();

		int index = 0;
		for (String s : sorted_map.keySet()) {
			queryWords.add(s);
			index++;
			if (index >= 20) {
				break;
			}
		}

		return queryWords;
	}
	
	private void populateAuthorFields(ArticleModel articleModel) {
		
		if(article == null || article.getAuthor() == null) {
			return;
		}
		
		Author articleAuthor = new Author();
		articleModel.setArticleAuthor(articleAuthor);
		UserProfileServiceResponse response = new MyWorldServiceClient().getUser(article.getAuthor().getUsername());
		if(response == null || CollectionUtils.isEmpty(response.getResults())) {
			return;
		}
		UserProfile userProfile = response.getResults().iterator().next();
		
		articleAuthor.setUsername(userProfile.getUserName());
		articleAuthor.setId(Long.valueOf(userProfile.getId()));
		articleAuthor.setFullName(userProfile.getFullName());
		articleAuthor.setFeedbackScore(Integer.valueOf(userProfile.getFeedbackScore()));
		articleAuthor.setImageUrl(userProfile.getImage());
		
		long userId = Long.valueOf(userProfile.getId());
		if(article.getMarketplaceId() != null) {
			try {
				SiteEnum siteEnum = GlobalIdConverter.encode(article.getMarketplaceId(), null);
				if(siteEnum == null) {
					throw new Exception("Invalid siteId");
				}
				int siteId = siteEnum.getId();
				UserAuthorRank rank = UserAuthorRankDAO.getInstance().findByPK(userId, siteId, getLabelId(siteId));
				articleAuthor.setReviewRank(rank.getRank());
			}
			catch (Exception e) {
				s_logger.info( "Unable to get rank for user = " + article.getAuthor().getUserId() + " " + e.getMessage());
			}	
		}
		try {
			UserStoreLookup store = UserStoreLookupDAO.getInstance().findByUserID(userId);
			articleAuthor.setIsStoreValid(checkValidStore(store.getName()));
			articleAuthor.setStoreName(store.getName());
			articleAuthor.setStoreUrl(store.getStoreUrl());
		} catch (Exception e) {
			s_logger.info( "Unable to find store for user = " + article.getAuthor().getUserId());
		}	 
	}
	
	private static boolean checkValidStore(String name) {
		URL url = null;
		if (name != null) {
			name = name.replaceAll("[^a-zA-Z0-9]", "");
		}
		try {
			if (poolType.equals("staging")) {
				url = new URL("http://stores.qa.ebay.com/" + name);
			} else {
				url = new URL("http://stores.ebay.com/" + name);
			}
			if (url != null) {
				HttpURLConnection connection = (HttpURLConnection)url.openConnection();
				connection.setInstanceFollowRedirects(false);
				connection.setRequestMethod("GET");
				connection.setConnectTimeout(1000);
				connection.setReadTimeout(5000);
				connection.connect();
				int code = connection.getResponseCode();
				return code == 200;
			}
			
		} catch (MalformedURLException e) {
			CALUtil.logFailedCALEvent(CALUtil.ARTICLE_SOLR_INDEXER, "checkValidStore", "Error while building url " + name );
		} catch (IOException e) {
			CALUtil.logFailedCALEvent(CALUtil.ARTICLE_SOLR_INDEXER, "checkValidStore", "Error while validating store url " + name );
		} 
		return false;
	}
	
	private static int getLabelId(int siteId) {
		if (siteToLabel.containsKey(siteId))
			return siteToLabel.get(siteId);
		int labelId = -1;
		try {
			labelId = MetadataLabelDAO.getInstance().findByPrimaryKey(USER_AUTHOR_RANK_TABLE_NAME, siteId).getLabelId();
		} catch (Exception fe) {
			CALUtil.logFailedCALEvent(CALUtil.ARTICLE_SOLR_INDEXER, "getLabelId", "Error getting user labelId for siteId = " + siteId);
		}
		siteToLabel.put(siteId, labelId);
		return labelId;
	}
	
	private void populatePictureMetadata(ArticleModel articleModel) {
		
		String picUrl = null;
		UserGeneratedContent ugc = articleModel.getUserGeneratedContent();
		
		if(ugc.getCoverImage() != null && !StringUtils.isEmpty(ugc.getCoverImage().getImageURL())) {
			picUrl = ugc.getCoverImage().getImageURL();
		}
		else if(ugc.getGroups() != null) {
			for(Group group:ugc.getGroups()) {
				for(Section section :group.getSections()) {
					for(Component comp:section.getComponents()) {
						if(comp instanceof MediaComponent) {
							MediaComponent mediaComp = (MediaComponent)comp;
							if(mediaComp.getMedia() != null 
									&& mediaComp.getMedia() != null 
									&& !StringUtils.isEmpty(((Image)mediaComp.getMedia()).getImageURL())) {
								picUrl = ((Image)mediaComp.getMedia()).getImageURL();
								break;
							}
						}
					}
				}
			}
		}
		
		
		if(!StringUtils.isEmpty(picUrl)) {
			articleModel.setPictureUrl(picUrl);
			articleModel.setHasPic(true);
			articleModel.setPicBroken(isBrokenPic(picUrl, articleModel.getArticleId()));
		}
	}
	
	private String getCacheInHeader(String urlstr) throws IOException {
		URL url = new URL(urlstr);
		URLConnection c = url.openConnection();
		String result = c.getHeaderField("Cache-Control");
		return result;
	}
	
	private boolean isBrokenPic(String pictureUrl, String articleId) {
		String cacheResult = "";
		if (pictureUrl != null ) {
			try {
				cacheResult = getCacheInHeader(pictureUrl);
			} catch(Exception e) {
				s_logger.error( "Error to check picture for guide" + articleId);
			}
		}

		boolean hasBrokenImage = false;	
		if (cacheResult != null && (cacheResult.equals("max-age=0,no-store,no-cache") || 
									cacheResult.equals("max-age=0,must-revalidate") || 
									cacheResult.equals("no-cache") || 
									cacheResult.equals("max-age=0") || 
									cacheResult.equals("no-store"))) {
			hasBrokenImage = true;
		}
		return hasBrokenImage;
	}
}

class ValueComparator implements Comparator<String> {

	Map<String, Integer> base;

	public ValueComparator(Map<String, Integer> base) {
		this.base = base;
	}

	// Note: this comparator imposes orderings that are inconsistent with
	// equals.
	public int compare(String a, String b) {
		if (base.get(a) > base.get(b)) {
			return -1;
		} else {
			return 1;
		} // returning 0 would merge keys
	}
}
