package com.ebay.raptor.artcon.serviceclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.kernel.calwrapper.CalEventFactory;
import com.ebay.kernel.context.AppBuildConfig;
import com.ebay.marketplace.category.v1.services.CategoryPath;
import com.ebay.marketplace.category.v1.services.GetCategoryPathRequest;
import com.ebay.marketplace.category.v1.services.GetParentCategoryResponse;
import com.ebay.marketplace.category.v1.services.SiteCategoryInputDetail;
import com.ebay.marketplace.services.AckValue;
import com.ebay.marketplace.services.categoryserviceclient.consumer.CategoryServiceConsumer;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.soaframework.common.exceptions.ServiceException;

public class CategoryServiceClient {

	private static final Map<Integer, List<Integer>> categoryFullPathsByCatId = new ConcurrentHashMap<Integer, List<Integer>>();
	private static final String CONSUMER_ID = "urn:ebay-marketplace-consumerid:98a0efe4-545e-4263-9065-6830c1463165";
	protected CategoryServiceConsumer consumer;
	
	public CategoryServiceClient() {}
	
	protected CategoryServiceClient(CategoryServiceConsumer consumer) {
		this.consumer = consumer;
	}
	
	public List<Integer> getCategoryFullPath(int catId, int siteId)  {
		
		List<Integer> allParentToLeaftCats = new ArrayList<Integer>();
		if(catId != -1){
			
			CalEventFactory.create("ServiceRequest", "CategoryService_CatgeoryPath", "0", "catId=" + catId + "&siteId=" + siteId).completed();
			try{
				CategoryServiceConsumer consumer = getConsumer();
				GetCategoryPathRequest request = getCategoryPathRequest(catId, siteId);
				GetParentCategoryResponse response = consumer.getCategoryPath(request);				
				if(response.getAck().equals(AckValue.SUCCESS)){
					List<CategoryPath> rootCats = response.getCategoryPath();
					if(rootCats != null && !rootCats.isEmpty()){
						CategoryPath rootCat = rootCats.get(0);
						allParentToLeaftCats.add(Integer.parseInt(rootCat.getCategoryNodeDetail().getCategoryId()));
						while(rootCat.getImmediateChildCategory() != null){
							rootCat = rootCat.getImmediateChildCategory();
							allParentToLeaftCats.add(Integer.parseInt(rootCat.getCategoryNodeDetail().getCategoryId()));
						}
					}
				}else{
					CALUtil.logFailedCALEvent("CategoryHelper", "getCategoryFullPath", "Category service error");
				}
			} catch (Exception e){
				CALUtil.logFailedCALEvent("CategoryHelper", "getCategoryFullPath", ExceptionUtils.getFullStackTrace(e));
			} 
		}
		categoryFullPathsByCatId.put(new Integer(catId), allParentToLeaftCats);
		return allParentToLeaftCats;
	}
	
	public Map<Long, List<Integer>> getCategoryFullPath(Map<Long, Long> leafCategoryIdSiteIdMap) {
		Map<Long, List<Integer>> categoryPathsByItemId = new HashMap<Long, List<Integer>>();
		for(Map.Entry<Long, Long> entry : leafCategoryIdSiteIdMap.entrySet()) {
			if(categoryFullPathsByCatId.get(entry.getKey()) != null) {
				categoryPathsByItemId.put(entry.getKey(), categoryFullPathsByCatId.get(entry.getKey()));
			} else {
				categoryPathsByItemId.put(entry.getKey(), getCategoryFullPath((entry.getKey()).intValue(), entry.getValue().intValue()));
			}
		}
		return categoryPathsByItemId;
	}
	

	private CategoryServiceConsumer getConsumer() {
		if(consumer != null) 
			return consumer;
		try {
			consumer = new CategoryServiceConsumer("CategoryService", AppBuildConfig.getInstance().getPoolType());
			consumer.getServiceInvokerOptions().setConsumerId(CONSUMER_ID);
		} catch (ServiceException e) {
			CALUtil.logFailedCALEvent("CategoryHelper", "getConsumer", "Category service consumer create error");
		}
		return consumer;
	}
	
	private GetCategoryPathRequest getCategoryPathRequest(int catId, int siteId){
		GetCategoryPathRequest request = new GetCategoryPathRequest();
		SiteCategoryInputDetail requestInput = new SiteCategoryInputDetail();
		requestInput.setCategoryId(Integer.toString(catId));
		requestInput.setSiteId(Integer.toString(siteId));
		request.setSiteCategoryInputDetail(requestInput);
		return request;
	}
	
}
