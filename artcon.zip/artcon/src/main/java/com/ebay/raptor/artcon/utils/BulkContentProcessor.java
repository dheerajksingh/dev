package com.ebay.raptor.artcon.utils;

import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.DigitalMedia;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.Video;
import com.ebay.raptor.artcon.config.ConfigParam;
import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.entities.bulkupload.SingleFiles;
import com.ebay.raptor.artcon.task.BulkContentTaskManager;
import com.ebay.raptor.artcon.utils.BulkContentProcessor;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.EntityComponent;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.ModuleType;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.TemplateType;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.raptor.orchestration.ITaskOrchestrator;
import com.ebay.raptor.orchestration.ITaskResult;
import com.ebay.raptor.orchestration.TaskExecutionException;
import com.ebayinc.config.collect.Lists;

import edu.emory.mathcs.backport.java.util.Arrays;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;



/*
 * Exception performing whole class analysis ignored.
 */
public class BulkContentProcessor {
    public static final String CONTENT_STATUS = "PUBLISHED";
    public static final String fileLocation = ConfigParam.BULK_UPLOAD_FILE_LOCATION.getStringValue();
    public static final String HOW_TO=TemplateType.HOW_TO.name();
    
    // ModuleType
    public static final String PARAGRAPH="PARAGRAPH";
    public static final String BLOCK_QUOTE= "BLOCK_QUOTE";
    public static final String HEADING= "HEADING";
    public static final String  IMAGE="IMAGE";
    public static final String  VIDEO="VIDEO";
    public static final String  COLLECTION="COLLECTION";
    public static final String  TABLE="TABLE";
    public static final String  DIVIDER="DIVIDER";


    protected ITaskOrchestrator orchestrator;
    protected SingleFilesDao singleFilesDao;  
    protected BulkContentTaskManager bcManager;
    
    public BulkContentProcessor(){
    	this.bcManager=new BulkContentTaskManager();
    }
 
	public void setSingleFilesDao(SingleFilesDao singleFilesDao) {
		this.singleFilesDao = singleFilesDao;
		bcManager.setSingleFilesDao(singleFilesDao);
		
	}


	public List<PublishArticleResponse> processBulkContent(ArticleBulkUploadEvent  bulkUploadEvent,SingleFilesDao singleFilesDao) throws Exception {
		setSingleFilesDao(singleFilesDao);
		System.out.println("File name -- "+fileLocation + bulkUploadEvent.getFileName());
		ZipFile zipFile = new ZipFile(fileLocation + bulkUploadEvent.getFileName());   
		System.out.println("Zip file name - "+zipFile.getName()+"   Size of entry "+zipFile.size());
        ArrayList<ITaskResult<Object>> listTaskResult = new ArrayList<ITaskResult<Object>>();
        Enumeration<? extends ZipEntry> e = zipFile.entries();
        while (e.hasMoreElements()) {
        	ZipEntry zEntry = (ZipEntry)e.nextElement();
        	System.out.println("file name "+zEntry.getName());
        	if(zEntry.isDirectory()|| !zEntry.getName().endsWith(".xml"))
        		continue;
        	ArticleAdapter articleAdapter = this.fileParse(zipFile.getInputStream(zEntry));  
            if(articleAdapter!=null){
        	String id = singleFilesDao.createSingleFile(new SingleFiles(bulkUploadEvent.getUserName(), zEntry.getName(),bulkUploadEvent.getFileName() ,
        			"PROCESSING", new Date()));
	        	if(articleAdapter.getArticle().getArticleId()==null){
	        		listTaskResult.add(bcManager.createBulkUploadTask(articleAdapter.getBaseArticle(),id));
	        	}
	        	else{
	        		listTaskResult.add(bcManager.createBulkUpdateTask(articleAdapter.getArticle(),id));
	        	}
            }else
            	singleFilesDao.createSingleFile(new SingleFiles(bulkUploadEvent.getUserName(), zEntry.getName(),bulkUploadEvent.getFileName() ,
            			"FILE_NOT_IN_FORMAT", new Date()));
            	
        }
        zipFile.close();
        return this.convertToPublishResponse(listTaskResult);
    }



    private List<PublishArticleResponse> convertToPublishResponse(List<ITaskResult<Object>> listTaskResult) throws TaskExecutionException {
        ArrayList<PublishArticleResponse> listDraftResponse = new ArrayList<PublishArticleResponse>();
        for (ITaskResult<Object> taskResult : listTaskResult) {
            listDraftResponse.add((PublishArticleResponse)taskResult.getResult());
        }
        return listDraftResponse;
    }

    private ArticleAdapter fileParse(InputStream iStream) {
        CreateContentRequestBuilder contentBuilder = new CreateContentRequestBuilder();
        XMLInputFactory factory = XMLInputFactory.newInstance();
        try {
            XMLStreamReader reader = factory.createXMLStreamReader(iStream);
            while (reader.hasNext()) {
                int event = reader.next();
                if (event != XMLStreamReader.START_ELEMENT) continue;
                contentBuilder.parseElement(reader);
            }
        }
        catch (XMLStreamException e) {
            e.printStackTrace();
            return null;
        }
        
        return new ArticleAdapter(contentBuilder.getArticle(),contentBuilder.getArticleId());  
    }
    
    
    class ArticleAdapter{
    	String articleId;
    	BaseArticle basearticle;
    	
    	
    	private ArticleAdapter(BaseArticle basearticle,String articleId ){
    		this.articleId=articleId;
    		this.basearticle=basearticle;
    	}
    	

    	
    	public BaseArticle getBaseArticle(){
    		return this.basearticle;
    	}
    	
    	public Article getArticle(){
    		Article article = new Article(this.basearticle);
    		article.setArticleId(this.articleId);
    		return article;
    	}
    	
    	
    }
    
	class CreateContentRequestBuilder{
		BaseArticle article;
		String articleId;
		private static final String ID= "id";		
		private static final String ARTICLE= "article";
		private static final String TITLE = "title";
		private static final String SYNOPSIS="synopsis";
		private static final String TEMPLATE_TYPE="templateType";
		private static final String COVER_IMAGE="coverImage";
		private static final String GROUP="Group";
		private static final String GROUP_TYPE="groupType" ;
		private static final String GROUP_TITLE="groupTitle";
		private static final String Section="Section";
		private static final String ALIGNMENT = "alignment";
		private static final String ComponentType= "ComponentType";	
		private static final String CAPTION = "caption";
		private static final String IMAGE_URL= "imageUrl";
		private static final String MARKDOWN="markdown";
		private static final String CategoryLevel="CategoryLevel";
		private static final String CategoryIds="CategoryIds";
		private static final String ResourceUrl="ResourceUrl";
		private static final String CollectionIds="CollectionIds";
		

		CreateContentRequestBuilder(){
		}
		
		
		 public BaseArticle getArticle() {
			return article;
		}

		public String getArticleId() {
			return articleId;
		}


		public void setArticleId(String articleId) {
			this.articleId = articleId;
		}


		public void setContentModel(BaseArticle article) {
			this.article = article;
		}
		
		
		private void  parseElement(XMLStreamReader reader){
				String element = reader.getLocalName(); 

				try{
						switch(element){
						        case CreateContentRequestBuilder.ARTICLE:
						        	createArticle(reader);
									break;
								case CreateContentRequestBuilder.TITLE:
									addTitle(reader.getElementText());	
									break;
								case CreateContentRequestBuilder.SYNOPSIS:
									addSynopsis(reader.getElementText());
									break;
								case CreateContentRequestBuilder.TEMPLATE_TYPE:
									addTemplateType(reader.getElementText());
									break;
								case CreateContentRequestBuilder.COVER_IMAGE:	
									addCoverImage(reader.getElementText());
									break;	
								case CreateContentRequestBuilder.GROUP :	
									createGroup();
									break;
								case CreateContentRequestBuilder.GROUP_TYPE :	
									addGroupType(reader.getElementText());
									break;						
								case CreateContentRequestBuilder.GROUP_TITLE:
									addGroupTitle(reader.getElementText());
									break;
								case CreateContentRequestBuilder.Section:
								addSection();
									break;	
								case CreateContentRequestBuilder.ALIGNMENT:	
									addAlignment(reader.getElementText());
									break;
								case CreateContentRequestBuilder.ComponentType:	
									addComponentType(reader.getElementText());
									break;
								case CreateContentRequestBuilder.CAPTION:
									addCaption(reader.getElementText());
									break;
								case CreateContentRequestBuilder.IMAGE_URL:
									addImageUrl(reader.getElementText());
									break;
								case CreateContentRequestBuilder.MARKDOWN:	
									addMarkDown(reader.getElementText());
									break;
								case CreateContentRequestBuilder.CategoryLevel:	
									addCategoryLevel(reader.getElementText());
									break;
								case CreateContentRequestBuilder.CategoryIds:	
									addCategoryIds(convertIdToList(reader.getElementText()));
									break;
								case CreateContentRequestBuilder.ResourceUrl:	
									addResourceUrl(reader.getElementText());
									break;
								case CreateContentRequestBuilder.CollectionIds:
									addCollectionIds(convertIdToList(reader.getElementText()));
								default:
									break;
						}
					} catch (XMLStreamException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
				}
		
		private List<String> convertIdToList(String catIds){
			List<String> list = new ArrayList();
			if(catIds!=null){
				return Arrays.asList(catIds.split(","));
			}
				
				return list;
		}
		
	    private void createArticle(XMLStreamReader reader){	
			article = new BaseArticle();
			
			// This is to add attribute to article in case of bulk update
			if(reader.getAttributeCount()>0&&reader.getAttributeLocalName(0).equalsIgnoreCase(ID)){
			  this.setArticleId(reader.getAttributeValue(0));	
			}
			
	    	UserGeneratedContent userContent = new UserGeneratedContent();
	    	 List<Group> groups=new ArrayList<Group>();	    	 
	    	 userContent.setGroups(groups);
	    	 article.setUserGeneratedContent(userContent);
	    	 article.setTemplateType(HOW_TO);

	    }
	    
	    private void addTitle(String title){
	    	Text t = new Text();
	    	t.setContent(title);
	    	article.getUserGeneratedContent().setTitle(t);
	    }
	    
	    private void addSynopsis(String synopsis){
	    	Text t = new Text();
	    	t.setContent(synopsis);
	    	article.getUserGeneratedContent().setSynopsis(t);
	    }
	    
	    private void addTemplateType(String templateType){
	    	article.setTemplateType(templateType);

	    }
	    
	    private void addCoverImage(String coverImage){
	    	Image t = new Image();
	    	t.setImageURL(coverImage);
	    	article.getUserGeneratedContent().setCoverImage(t);

	    	}
	    
	    private void createGroup(){
	    	List<Group> listGModel=article.getUserGeneratedContent().getGroups();
	    		Group grp = new Group();
	    		grp.setSections(new ArrayList<Section>());
	    		listGModel.add(grp);
	    	
	    }
	    private void addGroupType(String groupType){
	    	List<Group> listGrp=article.getUserGeneratedContent().getGroups();
	    		Group grp = listGrp.get(listGrp.size()-1);	    		
	    		grp.setGroupType(groupType);
	    	
	    }
	    
	    private void addGroupTitle(String groupTitle){
	    	List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	    	
    		Text text = new Text();
    		text.setContent(groupTitle);
    		grp.setTitle(text);
	    }
	    private void addSection(){
	    	List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		listSection.add(new Section());
	    	
	    }
	    
	    
	    private void addAlignment(String alignment){
	    	List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		sec.setComponents(new ArrayList<Component>());
    		sec.setAlignment(alignment);

	    }

	    
	    private void addComponentType(String componentType){			
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp = null;

    		switch (componentType){
	    		case PARAGRAPH:
	    		case BLOCK_QUOTE:
	    		case HEADING:
	    		case TABLE:
	    		case DIVIDER:
	    			comp = new StandardComponent();   		
	    			break;
	    		case IMAGE:
	    		case VIDEO:
	    			comp=new MediaComponent();
	    			break;
	    		case COLLECTION:
	    			comp = new EntityComponent();
	    			break;
	    			
	    		default:
	    		break;
    		}
    		comp.setComponentType(componentType);
	    	listComponent.add(comp);

	    }
	    
	    private void addCaption(String caption){
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);
    		comp.setCaption(caption);

	    }
	    
	    private void addImageUrl(String imageUrl){	    	
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);

	    	if(comp  instanceof MediaComponent )
	    	{
	    		MediaComponent mcp = (MediaComponent)comp;
	    		Image img = new Image();
	    		img.setImageURL(imageUrl);
	    		mcp.setMedia(img);
	    	}
	    }
	    
	    private void addCategoryLevel(String categoryLevel){	    	
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);

	    	if(comp  instanceof MediaComponent )
	    	{
	    		MediaComponent mcp = (MediaComponent)comp;
	    		mcp.setCategoryLevel(categoryLevel);
	    	}
	    }
	    
	    private void addCategoryIds(List<String> categoryIds){	    	
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);

	    	if(comp  instanceof MediaComponent )
	    	{
	    		MediaComponent mcp = (MediaComponent)comp;
	    		mcp.setCategoryIds(categoryIds);
	    	}
	    }
	    
	    private void addResourceUrl(String resourceUrl){	    	
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);

	    	if(comp  instanceof MediaComponent )
	    	{
	    		MediaComponent mcp = (MediaComponent)comp;
	    		Video video = new Video();
	    		video.setVideoURL(resourceUrl);
	    		mcp.setMedia(video);
	    	}
	    }
	    
	    private void addMarkDown(String markDown){	    	
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);
	    	if(comp  instanceof StandardComponent )
	    	{
	    		StandardComponent ssm = (StandardComponent)comp;
	    		ssm.setData(markDown);
	    	}	    	
	    }
	    
	    private void addCollectionIds(List<String> collectionIds){
    		List<Group> listGrp=article.getUserGeneratedContent().getGroups();
    		Group grp = listGrp.get(listGrp.size()-1);	
    		List<Section> listSection = grp.getSections();
    		Section sec = listSection.get(listSection.size()-1);
    		List<Component> listComponent=sec.getComponents();
    		Component comp =listComponent.get(listComponent.size()-1);
    		if(comp instanceof EntityComponent){
    			((EntityComponent) comp).setEntityIds(collectionIds);
    		}
	    }
	}
	
	public static void main(String args[]) {
		BulkContentProcessor bulkProcessor  = new BulkContentProcessor();
		try{
			ZipFile zipFile = new ZipFile("//Users/dheersingh//Data_Update1.zip");  
	        Enumeration<? extends ZipEntry> e = zipFile.entries();
	        while (e.hasMoreElements()) {
	        	ZipEntry zEntry = (ZipEntry)e.nextElement();
	        	if(zEntry.isDirectory()|| !zEntry.getName().endsWith(".xml")){
	        		continue;
	        	}
	        		ArticleAdapter article = bulkProcessor.fileParse(zipFile.getInputStream(zEntry));  
	        		Article article1 = article.getArticle();
	        		System.out.println("article 1  - template type "+article1.getTemplateType());
	        		
	        }
	        
	        zipFile.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
        
	

}
