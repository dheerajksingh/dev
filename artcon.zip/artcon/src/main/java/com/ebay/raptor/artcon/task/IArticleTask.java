package com.ebay.raptor.artcon.task;

import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.orchestration.Callable;

public interface IArticleTask {
	
	@Callable
	public  CreateDraftResponse performTask();

}
