package com.ebay.raptor.artcon.serviceclient;

import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
@XmlRootElement
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserProfileServiceResponse {
	private ResponseStatus status;
	private Set<UserProfile> results;
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	public Set<UserProfile> getResults() {
		return results;
	}
	public void setResults(Set<UserProfile> results) {
		this.results = results;
	}
}
