package com.ebay.raptor.artcon.utils;

public enum ArticleBulkStatus {

	PUBLISHED_FOR_EDIT_FAILED,PUBLISH_FAILED,DRAFT_FAILED,DRAFT,PUBLISHED ,BULK_UPDATE_DRAFT
}
