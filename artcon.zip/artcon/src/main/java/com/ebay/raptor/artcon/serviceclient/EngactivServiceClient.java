package com.ebay.raptor.artcon.serviceclient;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.InvocationException;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.internal.GingerClientFactory.ClientCreationException;
import org.ebayopensource.ginger.client.internal.GingerClientManager;
import org.ebayopensource.ginger.client.internal.GingerClientManager.ClientAlreadyRegisteredException;
import org.ebayopensource.ginger.client.internal.InitGingerClientConfigFactory.ConfigCreationException;
import org.springframework.util.StringUtils;

import com.ebay.raptor.artcon.utils.CALUtil;

public class EngactivServiceClient {
	
	private static final String CLIENT_ID = "EngactivServiceClient";
	private static final String SERVICE_NAME = "engactivsvc";
	private GingerClient client = null;

	public EngactivServiceClient() {}
	
	public EngactivServiceClient(GingerClient client) {
		this.client = client;
	}
	
	public long getArticleLikes(String articleId) {
		
		if (StringUtils.isEmpty(articleId)) {
			return 0;
		}
		try {
			GingerClient client = getGingerClient(); 
			GingerWebTarget webTarget = client.target("/entity/uid/" + articleId);
			Invocation.Builder resourceBuilder = webTarget.request(MediaType.APPLICATION_JSON);
			GingerClientResponse response = (GingerClientResponse) resourceBuilder.get();
			EngactivServiceResponse engResponse = response.getEntity(EngactivServiceResponse.class);
			if(engResponse.isSuccess()) {
				return engResponse.getTotal_likes();
			}
		} catch (InvocationException e) {
			CALUtil.logFailedCALEvent("EngactivServiceClient", "getArticleLikes", articleId + ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			CALUtil.logFailedCALEvent("EngactivServiceClient", "getArticleLikes", articleId + ExceptionUtils.getFullStackTrace(e));
		}
		return 0;
	}

	private GingerClient getGingerClient() throws ConfigCreationException, ClientCreationException, ClientAlreadyRegisteredException {
		
		if(client != null) {
			return client;
		}
		client = GingerClientManager.get().getOrRegisterClient(CLIENT_ID, SERVICE_NAME);
		return client;
		
	}
}
