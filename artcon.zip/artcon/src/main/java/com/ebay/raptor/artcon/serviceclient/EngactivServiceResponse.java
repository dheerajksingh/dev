package com.ebay.raptor.artcon.serviceclient;

import java.util.List;

public class EngactivServiceResponse {
	
	private boolean success;
	private String id;
	private long total_likes;
	private List<EngActivError> errors;
	
	public long getTotal_likes() {
		return total_likes;
	}
	public void setTotal_likes(long total_likes) {
		this.total_likes = total_likes;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	
	public List<EngActivError> getErrors() {
		return errors;
	}
	public void setErrors(List<EngActivError> errors) {
		this.errors = errors;
	}

	
}
