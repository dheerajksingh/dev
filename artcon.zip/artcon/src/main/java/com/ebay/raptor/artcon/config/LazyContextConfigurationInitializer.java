package com.ebay.raptor.artcon.config;

import com.ebay.kernel.context.AppBuildConfig;
import com.ebay.raptor.kernel.context.DeploymentEnv;
import com.ebayinc.platform.config.api.ContextConfiguration;
import com.ebayinc.platform.config.builder.Builder;
import com.ebayinc.platform.config.impl.mongo.MongoType;
import org.apache.commons.lang3.concurrent.LazyInitializer;

public class LazyContextConfigurationInitializer extends LazyInitializer<ContextConfiguration> {
	
	private String TARGET = "Global";
	private String PROJECT = "artcon";
	private String VERSION = "1.0.0";
	
    @Override
    protected ContextConfiguration initialize() {
        return new Builder().target(TARGET).
                project(PROJECT).config(getPoolType()).releases(
                VERSION).expects(MongoType.INSTANCE).build();
    }

    private static String getPoolType(){
        if(AppBuildConfig.getInstance().isPreProd()){
            return "preprod";
        }else if(AppBuildConfig.getInstance().isLandP()){
            return DeploymentEnv.PoolType.LnP.name();
        }else if(AppBuildConfig.getInstance().isDev()){
            return "staging";
        }
        return AppBuildConfig.getInstance().getPoolType();
    }
}
