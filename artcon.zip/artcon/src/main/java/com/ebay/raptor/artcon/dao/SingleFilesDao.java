package com.ebay.raptor.artcon.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.dao.BasicDAO;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;

import com.ebay.kernel.logger.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ebay.raptor.artcon.entities.bulkupload.SingleFiles;

@Component
@Repository("singleFilesDao")
public class SingleFilesDao extends BasicDAO<SingleFiles, ObjectId> {

	private static final Logger LOGGER = Logger
			.getInstance(SingleFilesDao.class);
	
	
	@Autowired
	public SingleFilesDao(AdvancedDatastore ds) {
		super(SingleFiles.class, ds);
		System.out.println("in constructor SingleFiles Dao  - "+ds);
	}

    
	public String createSingleFile(SingleFiles singleFilesDao) {
		Key<SingleFiles> key = save(singleFilesDao);
		System.out.println(" id returned after save "+key);
		return key.getId().toString();
	}
	
	public void updateSingleFileDraft(String id ,String status,String draftId,String log,String rlogid,String operationType){
		UpdateOperations<SingleFiles> updateOperations = createUpdateOperations();
	
		if(log!=null)
		updateOperations.set("logDetails", log)	;

		if(status!=null)
		updateOperations.set("status", status);

		if(draftId!=null)
			updateOperations.set("draftId", draftId);
		updateOperations.set("dateModified", new Date());

		if(rlogid!=null){
			updateOperations.set("rLogid", rlogid);			
		}
		if(operationType!=null){
			updateOperations.set("operationType", operationType);
		}
		
		Query<SingleFiles> query = createQuery();
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		objectIds.add(new ObjectId(id));

		query.criteria("_id").in(objectIds);		
		update(query, updateOperations);
	}
	public void updateSingleFilePublished(String id ,String status,String publishId,String log,String rlogid,String operationType){
		UpdateOperations<SingleFiles> updateOperations = createUpdateOperations();
		if(log!=null)
		updateOperations.set("logDetails", log)	;
		if(status!=null)
		updateOperations.set("status", status);

		if(publishId!=null)
			updateOperations.set("publishId", publishId);
		
		updateOperations.set("dateModified", new Date());

		if(rlogid!=null){
			updateOperations.set("rLogid", rlogid);			
		}
		updateOperations.set("operationType", operationType);
		
		Query<SingleFiles> query = createQuery();
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		objectIds.add(new ObjectId(id));

		query.criteria("_id").in(objectIds);		
		update(query, updateOperations);
	}
	
	public void updateSingleFileLog(String id ,String status,String log){
		UpdateOperations<SingleFiles> updateOperations = createUpdateOperations();
		updateOperations.set("status", status);
		updateOperations.set("dateModified", new Date());
		updateOperations.set("logDetails", log);

		Query<SingleFiles> query = createQuery();
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		objectIds.add(new ObjectId(id));

		query.criteria("_id").in(objectIds);		
		update(query, updateOperations);
	}
	
}
