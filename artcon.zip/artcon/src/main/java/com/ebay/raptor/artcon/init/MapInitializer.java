package com.ebay.raptor.artcon.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ebay.integ.batchjobparam.BatchJobParamMap;
import com.ebay.integ.contactinfo.ContactInfoMap;
import com.ebay.integ.dal.DalInit;
import com.ebay.integ.dal.init.DALInitPolicyExecutor;
import com.ebay.integ.dal.map.BaseMap2;
import com.ebay.integ.feedback.FeedbackMap;
import com.ebay.integ.metadatalabel.MetadataLabelDAO;
import com.ebay.integ.metadatalabel.MetadataLabelMap;
import com.ebay.integ.partnercontingency.PartnerContingencyDAO;
import com.ebay.integ.partnercontingency.PartnerContingencyMap;
import com.ebay.integ.store.UserStoreLookupDAO;
import com.ebay.integ.store.UserStoreLookupMap;
import com.ebay.integ.sysdatefromdual.SysdateFromDualMap;
import com.ebay.integ.uhslogicalhost.UhsLogicalHostMap;
import com.ebay.integ.user.UserDAO;
import com.ebay.integ.user.UserMap;
import com.ebay.integ.usercontent.UserAuthorRankDAO;
import com.ebay.integ.usercontent.UserAuthorRankMap;
import com.ebay.integ.userlookup.UserLookupMap;
import com.ebay.kernel.initialization.BaseInitializable;
import com.ebay.kernel.initialization.Initializable;
import com.ebay.kernel.initialization.InitializationContext;
import com.ebay.kernel.util.JdkUtil;

public class MapInitializer {

	private static final Logger s_logger = LoggerFactory.getLogger(MapInitializer.class);

	private static Initializable s_Initializable = null;
	
	@SuppressWarnings({ "rawtypes", "deprecation" })
	private final static Class[] CLASSES_TO_INIT = {
		com.ebay.integ.partnercontingency.PartnerContingencyMap.class,
		com.ebay.integ.globalconfig.GlobalConfigMap.class,
        com.ebay.integ.globaltablehostmap.GlobalTableHostMapMap.class,
			JdkUtil.forceInit(UserDAO.class),
			JdkUtil.forceInit(PartnerContingencyDAO.class),
			JdkUtil.forceInit(UserAuthorRankDAO.class),
			JdkUtil.forceInit(MetadataLabelDAO.class),
			JdkUtil.forceInit(UserStoreLookupDAO.class)
	};

	public static synchronized Initializable getInitializable() {
		if (s_Initializable != null) {
			return s_Initializable;
		}

		BaseInitializable initializable = new BaseInitializable() {
			protected void initialize(final InitializationContext context) {
				MapInitializer.initialize();
			}

			protected void shutdown(final InitializationContext context) {
				s_Initializable = null;
			}
		};
		s_Initializable = initializable;
		return s_Initializable;
	}

	private static void initialize() {
		try {			
			DalInit.init();
			DALInitPolicyExecutor.execInit(CLASSES_TO_INIT);
			BaseMap2.initialize();
			MetadataLabelMap.getInstance().init();
			PartnerContingencyMap.getInstance().init();
			ContactInfoMap.getInstance().init();
			FeedbackMap.getInstance().init();
			UhsLogicalHostMap.getInstance().init();
			UserMap.getInstance().init();
			UserLookupMap.getInstance().init();
			UserAuthorRankMap.getInstance().init();
			BatchJobParamMap.getInstance().init();
            UserStoreLookupMap.getInstance().init();
            SysdateFromDualMap.getInstance().init();
			s_logger.info( "DAL initialized");
			s_logger.info( "Cache initialized");
			
		} catch (Exception any) {
			s_logger.error(any.getMessage());
		}
	}

}
