package com.ebay.raptor.artcon.indexer;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.globalenv.SiteEnum;
import com.ebay.raptor.artcon.article.model.ArticleModel;
import com.ebay.raptor.artcon.article.model.Author;
import com.ebay.raptor.artcon.serviceclient.FountainAdminServiceClient;
import com.ebay.raptor.artcon.serviceclient.GetRolesForUserResponse;
import com.ebay.raptor.artcon.utils.BusinessRule;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.artcon.utils.PlainTextBuilder;
import com.ebay.raptor.artcon.utils.SolrUpdateUtil;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.raptor.kernel.util.GlobalIdConverter;

public class ArticleSolrIndexer implements IArticleIndexer {

	private static final String DEFAULT_PREDICTABILITY = "1";
	private static final String DEFAULT_QUALITY_BUCKET = "10";
	private static final String DEFAULT_SPAMICITY = "0";
	private static final String PREMIUM_PUBLISHER = "PREMIUM_PUBLISHER";
	
	@Override
	public boolean index(Article content) {
		return index(content, new ArticleProcessor());
	}
	
	protected boolean index(Article article, ArticleProcessor processor) {
		boolean success = true;
		
		try {
			ArticleModel articleModel= processor.process(article);
			String document = generateSolrDocument(articleModel);
			SolrUpdateUtil.updateCore(document, false);
		} catch (Exception e) {
			e.printStackTrace();
			CALUtil.logFailedCALEvent(CALUtil.ARTICLE_SOLR_INDEXER, "Error indexing article", ExceptionUtils.getFullStackTrace(e));
			success = false;
		}

		return success;
	}

	private String generateSolrDocument(ArticleModel article) {
		
		try {

			PlainTextBuilder plainTextBuilder = new PlainTextBuilder();
			String plainText = plainTextBuilder.convertToPlainText(article);

			StringBuilder buffer = new StringBuilder("");
			buffer.append("<add>\n");
			buffer.append("<doc>\n");

			// unique key, not permitted to do atomic update
			appendField("id", String.valueOf(article.getArticleId()), buffer);
			
			UserGeneratedContent ugc = article.getUserGeneratedContent();
			appendField("title", ugc.getTitle().getContent(), buffer);
			appendField("tags", String.valueOf(ugc.getTags()), buffer);
			appendField("content", plainText, buffer);
			appendField("summary_sx", article.getSummary(), buffer);

			SiteEnum siteEnum = GlobalIdConverter.encode(article.getMarketplaceId(), null);
			if(siteEnum != null) {
				appendField("siteId_ix", String.valueOf(siteEnum.getId()), buffer);
			}			
			appendField("siteId_ix", "0",buffer);
			if ( article.getDateCreated() != null && article.getDateCreated().getValue()!=null) {
				appendField("creationDate_lx", String.valueOf(article.getDateCreated().getValue().getTime()), buffer);
			}
			
			if ( article.getDateModified() != null&& article.getDateModified().getValue()!=null) {
				appendField("lastModifiedDate_lx", String.valueOf(article.getDateModified().getValue().getTime()), buffer);
			}

			if(article.getScheduledStartDate()!=null && article.getScheduledStartDate().getValue()!=null){
				appendField("scheduledStartDate_lx",String.valueOf(article.getScheduledStartDate().getValue().getTime()),buffer);
			}			
			
			
			if(article.getScheduledEndDate()!=null && article.getScheduledEndDate().getValue()!=null){
				appendField("scheduledEndDate_lx",String.valueOf(article.getScheduledEndDate().getValue().getTime()),buffer);
			}
			
			if(article.getScheduledStartDate()!=null){
				appendField("scheduledStartDate_lx",String.valueOf(article.getScheduledStartDate().getValue().getTime()),buffer);
			}			
			
			
			if(article.getScheduledEndDate()!=null){
				appendField("scheduledEndDate_lx",String.valueOf(article.getScheduledEndDate().getValue().getTime()),buffer);
			}
			
			Map<String, String> categories = ugc.getCategories();
			if(categories != null) {
				StringBuilder allCats = new StringBuilder();
				StringBuilder leafCats = new StringBuilder();
				allCats.append(categories.get("L1") + " " + categories.get("L2") + " ");
				if(categories.containsKey("L3")) {
					allCats.append(categories.get("L3"));
					leafCats.append(categories.get("L3"));
				} else {
					leafCats.append(categories.get("L2"));
				}
				appendField("allCats", allCats.toString().trim(), buffer);
				appendField("leafCats", leafCats.toString(), buffer);
			}
			
			appendField("spamiCity_dx", DEFAULT_SPAMICITY, buffer); // Max 1
			appendField("predictedQuality_dv", DEFAULT_PREDICTABILITY, buffer); // Max 1
			appendField("qualityBucket_ix", DEFAULT_QUALITY_BUCKET, buffer); // Max 10
			
			Author author = article.getArticleAuthor();
			if(author != null) {
				appendField("authorLoginName_sx", author.getUsername(), buffer);
				appendField("authorFullName_s", author.getFullName(), buffer);
				appendField("authorId_lx", String.valueOf(author.getId()), buffer);
				appendField("authorFeedbackScore_i", String.valueOf(author.getFeedbackScore()), buffer);
				appendField("authorImage_s", author.getImageUrl(), buffer);
				appendField("authorRankScore_l", String.valueOf(author.getReviewRank()), buffer);
				appendField("storeValid_bx", String.valueOf(author.getIsStoreValid()), buffer);
				appendField("storeName_s", author.getStoreName(), buffer);
				appendField("storeUrl_s", author.getStoreUrl(), buffer);
			}
			
			int authorType = populateAuthorType(author.getId());
			// append spam checking field
			if (authorType == 1) {
				populateWhiteListStatus(article);	
				//appendField("wl_ix", String.valueOf(whiteListedStatus.showStatus()), buffer);
				appendField("wl_ix", "9", buffer);

				appendField("inspectionStatus_ix", String.valueOf(inspectionStatus), buffer);
			} else if (authorType == 0) {
				appendField("wl_ix", String.valueOf(WhiteListedStatus.AUTOGREEN.showStatus()), buffer);
			}


			
			if(!StringUtils.isEmpty(article.getPictureUrl())) {
				appendField("pictureUrl_s", article.getPictureUrl(), buffer);
			}
			appendField("pictureBroken_bx", String.valueOf(article.isPicBroken()), buffer);
			appendField("hasPicture_bx", String.valueOf(article.hasPic()), buffer);
			
			long likes = article.getLikes();
			if (likes >= 100000) {
				appendField("positiveVotes_iv", String.valueOf(likes % 100000), buffer);
				appendField("totalVotes_i", String.valueOf(likes % 100000), buffer);
			} else {
				appendField("positiveVotes_iv", String.valueOf(likes), buffer);
				appendField("totalVotes_i", String.valueOf(likes), buffer);
			}
			
			//appendField("authorType_ix", String.valueOf(authorType), buffer, flag);

			buffer.append("</doc>\n");
			buffer.append("</add>\n");
			return new String(buffer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	private void appendField(String fieldName, String fieldValue,
			StringBuilder buffer) {
		buffer.append("<field name=\"" + fieldName + "\"><![CDATA["
				+ fieldValue + "]]></field>\n");
	}

	@Override
	public boolean remove(String articleId) {
		boolean success = true;		
		
		StringBuilder buffer = new StringBuilder("");
		buffer.append("<delete>\n");
		buffer.append("<id>" + articleId + "</id>");
		buffer.append("</delete>\n");
		
		try {
			SolrUpdateUtil.updateCore(new String(buffer), false);
		} catch (IOException e) {
			CALUtil.logFailedCALEvent(CALUtil.ARTICLE_SOLR_INDEXER, "Error removing article", ExceptionUtils.getFullStackTrace(e));
			success = false;
		}
		
		return success;
	}
	
	public int populateAuthorType(long authorIdLong) {
		int authorType = 1;
		String authorId = null;
		if (authorIdLong > 0) {
			authorId = String.valueOf(authorIdLong);
		}
		GetRolesForUserResponse rolesResponse = new FountainAdminServiceClient().getRolesForUser(authorId);
		if (rolesResponse != null) {
			if (rolesResponse.getRoles() != null) {
				Set<String> roles = rolesResponse.getRoles();
				for (String role: roles) {
					if (PREMIUM_PUBLISHER.equalsIgnoreCase(role)) {
						authorType = 0;
					}
				}
			}
		}
		return authorType;
	}
	
	private WhiteListedStatus whiteListedStatus;
	private int inspectionStatus = -100;
    public enum WhiteListedStatus {
	    AUTOGREEN(1), GREEN(2), HELPCONTENT(10), HUMANJUDGE(11), POOR(12), IRREVELANT(13);
	    int status;
	    WhiteListedStatus(int status) {
	       this.status = status;
	    }
	    int showStatus() {
	       return status;
	    } 
	}

	public void populateWhiteListStatus(ArticleModel am) throws ParseException {
		inspectionStatus = populateInspectionStatus(am);
		switch (inspectionStatus) {
			case 8:// new guide, not clean, qualityBucket >= 6
				whiteListedStatus = WhiteListedStatus.HUMANJUDGE;
				break;
			case 10://new guide, clean, qualityBucket >= 6
				whiteListedStatus = WhiteListedStatus.AUTOGREEN;
				break;
		}
	}
	
	public int populateInspectionStatus(ArticleModel am) throws ParseException {
		BusinessRule br = new BusinessRule();
		if (br.notClean(am)) { // not clean, new guide
				inspectionStatus = 8;
		} else { // clean, new guide
				inspectionStatus = 10;
		}
		return inspectionStatus;
	}	
}
