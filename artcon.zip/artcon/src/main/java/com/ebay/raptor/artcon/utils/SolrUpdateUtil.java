package com.ebay.raptor.artcon.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.kernel.context.AppBuildConfig;
import com.ebay.raptor.artcon.config.ConfigParam;

public class SolrUpdateUtil {
	
	private static String solrRawEndpointPhx = ConfigParam.SOLR_RAW_PHX_ENDPOINT.getStringValue();
	private static String solrRawEndpointSlc = ConfigParam.SOLR_RAW_SLC_ENDPOINT.getStringValue();
	
	private static String poolType;
		
	static {
		if (poolType == null) {
			AppBuildConfig config = AppBuildConfig.getInstance();
			if (config.isDev()) {
				poolType = "dev";
			} else if (config.isQATE()) {
				poolType = "staging";
			} else if (config.isPreProd()) {
				poolType = "preprod";
			} else if (config.isProduction()) {
				poolType = "production";
			}
		}
	}
	
	public static void updateCore(String strToPost, boolean needCommit) throws IOException {
		String urlstrPhx = solrRawEndpointPhx + "guides/update?commit=" + needCommit;
		String urlstrSlc = solrRawEndpointSlc + "guides/update?commit=" + needCommit;
		httpConnect(strToPost, urlstrPhx, "xml");
		httpConnect(strToPost, urlstrSlc, "xml");
	}
	
	private static void httpConnect(String strToPost, String urlstr, String format) throws IOException {
		URL url = new URL(urlstr);
		HttpURLConnection c = null;
		OutputStreamWriter out = null;
		BufferedReader in = null;
		try {
			c = (HttpURLConnection) url.openConnection();
			c.setDoOutput(true);
			c.setDoInput(true);
			c.setUseCaches(false);
			c.setAllowUserInteraction(false);
			c.setRequestMethod("POST");
			if (format.equals("xml")) {
				c.setRequestProperty("Content-Type", "text/xml; charset=UTF-8");
			} else if (format.equals("json")) {
				c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			}
			c.setReadTimeout(60000);
			c.connect();
			out = new OutputStreamWriter(c.getOutputStream(), "UTF-8");
			try {
				out.write(strToPost);
			} finally {
				if (out != null) {
					out.close();
				}
			}
			try {
				in = new BufferedReader(new InputStreamReader(c.getInputStream()));
				String tmp = "";
				StringBuilder solrOutput = new StringBuilder();
				while((tmp = in.readLine()) != null) {
					solrOutput.append(tmp);
				}
				CALUtil.logCALEvent("INFO", "Indexed to Solr", url + " " + solrOutput.toString());
			} finally {
				if (in != null) {
					in.close();
				}
			}
		} catch(Exception ex) {
			CALUtil.logCALEvent("ERROR", "Error Indexing" , url + " Document: " + strToPost + " " + ExceptionUtils.getFullStackTrace(ex));
		} finally {
			if (c != null) {
				c.disconnect();
			}
		}
	}
}
