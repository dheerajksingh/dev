package com.ebay.raptor.artcon.processor;

import java.util.Iterator;

import javax.inject.Inject;

import com.ebay.bes.common.BusinessEvent;
import com.ebay.bes.consumer.BusinessEventBatchSession;
import com.ebay.bes.consumer.EventProcessor;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.artcon.handler.ArticleEventHandler;
import com.ebay.raptor.artcon.utils.ArticleEventsFactory;

public class ArticleEventProcessor implements EventProcessor {

	private static final Logger logger = Logger.getInstance(ArticleEventProcessor.class);
	private static final int MAX_RETRY_LIMIT = 3;
	private static final long RETRY_SECONDS = 60 * 1000 ; // 5 minutes
	
	@Inject ArticleEventsFactory eventFactory;
	
	@Override
	public void processEvents(BusinessEventBatchSession session) {
		Iterator<?> itr = session.getBatch();
		while (itr.hasNext()) {
			final BusinessEvent event = (BusinessEvent) itr.next();
			logger.log(LogLevel.INFO, event.toString());
			processEvent(event, session);
		}
	}

	private void processEvent(BusinessEvent event, BusinessEventBatchSession session) {
				
		boolean isLastTry = false;
		if (session.isRetryEvent(event)) {
			isLastTry = (session.getRetryCount(event) + 1) == MAX_RETRY_LIMIT;
			if (session.getRetryCount(event) >= MAX_RETRY_LIMIT) {
				session.setFailedInfo(event, "Event reached max retry limit ");
				logger.log(LogLevel.ERROR, "Event marked as failed -   " + event.toString());
				return;
			}
		}
		
		ArticleEventHandler eventHandler = eventFactory.getEventHandler(event);
		try {
			eventHandler.processEvent(event);
			session.setSuccess(event);
			logger.log(LogLevel.INFO, "Event successfully consumed" + event.toString());
		} catch (Exception e) {
			logger.log(LogLevel.ERROR, e);
			if (isLastTry) {
				session.setFailedInfo(event, "Event set to failed");
				logger.log(LogLevel.ERROR, "Event marked as failed with last retry: " + event.toString());
			} else {
				session.setRetryInfo(event, RETRY_SECONDS,"Event set to retry due to failure");
				logger.log(LogLevel.ERROR, "Marking event for retry:" + event.toString());			}
		}
		
	}

	@Override
	public void shutdown() {
		logger.log(LogLevel.ERROR, "ArticleEventProcessor shutdown");
	}

	@Override
	public void markdown() {
		logger.log(LogLevel.ERROR, "ArticleEventProcessor markdown");
	}

}
