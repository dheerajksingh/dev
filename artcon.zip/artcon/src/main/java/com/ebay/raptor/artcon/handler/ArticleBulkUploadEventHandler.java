package com.ebay.raptor.artcon.handler;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.ebay.bes.common.BusinessEvent;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.dao.ZipFilesDao;
import com.ebay.raptor.artcon.entities.bulkupload.ZipFiles;
import com.ebay.raptor.artcon.utils.BulkContentProcessor;
import com.ebay.raptor.artcon.utils.CALUtil;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.mongodb.DuplicateKeyException;


public class ArticleBulkUploadEventHandler implements ArticleEventHandler {

	private static final Logger LOGGER = Logger
			.getInstance(ArticleBulkUploadEventHandler.class);
	
	protected BulkContentProcessor bulkContentProcessor;
	  
	@Autowired 
	ZipFilesDao zipFilesDao;
	
	@Autowired 
	SingleFilesDao singleFilesDao;
		
	public ArticleBulkUploadEventHandler (){
		bulkContentProcessor = new BulkContentProcessor();
	}
	
	@Override
	public void processEvent(BusinessEvent event)  {
		
		ArticleBulkUploadEvent bUploadEvent = (ArticleBulkUploadEvent)event;
		CALUtil.logCALEvent("ARTCON-BULKPLOAD-RECEIVED",bUploadEvent.getFileName(),bUploadEvent.getUserName());
		String createZipid = createZipFile(bUploadEvent.getFileName(),bUploadEvent.getUserName());
		
		if(createZipid!=null){
	    	try {
				bulkUploadProcess(event);
				zipFilesDao.updateZipFile(createZipid,"COMPLETED");
			} catch (Exception e) {
				e.printStackTrace();
				CALUtil.logCALEvent("ARTCON-BULKPLOAD",bUploadEvent.getFileName(),"  Exception "+e.getMessage());
				zipFilesDao.updateZipFile(createZipid,"INCOMPLETE");

			}
		}
		
	}
	


	private String createZipFile(String zipFileName,String userId) {
		try{
			ZipFiles zipFiles = new ZipFiles();
			zipFiles.setUserId(userId);
			zipFiles.setStatus("PROCESSING");
			zipFiles.setZipFileName(zipFileName);
			zipFiles.setDateCreated(new Date());
			String key = zipFilesDao.createZipFile(zipFiles);
			return key;
		}
		catch(DuplicateKeyException e){			
			CALUtil.logCALEvent("ARTCON-BULKPLOAD",zipFileName+" -  "+userId , " Duplicate exception "+e.getMessage());
		}
		return null;
	}
	
	
	/* Does:
	 * 1 Parses xml's from a zip file one by one .
	 * 2 for every file parsed spawn a task what calls
	 * cmseditorServcie for creating article.
	 * 
	 * 3 If there is a failure for what ever reason's 
	 * logs in statusDb
	 * 
	 */
	
	private void bulkUploadProcess(BusinessEvent event) throws Exception {
			ArticleBulkUploadEvent bUploadEvent = (ArticleBulkUploadEvent)event;
			bulkContentProcessor.processBulkContent(bUploadEvent,this.singleFilesDao);			
			
	}
		
}
