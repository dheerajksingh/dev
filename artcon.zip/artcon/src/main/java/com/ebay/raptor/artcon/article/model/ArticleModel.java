package com.ebay.raptor.artcon.article.model;

import com.ebay.raptor.artcon.utils.PlainTextBuilder;
import com.ebay.raptor.cmseditor.response.content.model.Article;

public class ArticleModel extends Article {

	private String summary;
	private String allCats;
	private String leafCats;
	private Author articleAuthor;
	private String pictureUrl;
	private boolean hasPic; 
	private boolean picBroken;
	private long likes;
	
	public String getPlainText() {
		PlainTextBuilder plainTextBuilder = new PlainTextBuilder();
		String plainText = plainTextBuilder.convertToPlainText(this);
		return plainText;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getAllCats() {
		return allCats;
	}

	public void setAllCats(String allCats) {
		this.allCats = allCats;
	}

	public String getLeafCats() {
		return leafCats;
	}

	public void setLeafCats(String leafCats) {
		this.leafCats = leafCats;
	}

	public Author getArticleAuthor() {
		return articleAuthor;
	}

	public void setArticleAuthor(Author articleAuthor) {
		this.articleAuthor = articleAuthor;
	}

	public boolean isPicBroken() {
		return picBroken;
	}

	public void setPicBroken(boolean picBroken) {
		this.picBroken = picBroken;
	}

	public boolean hasPic() {
		return hasPic;
	}

	public void setHasPic(boolean hasPic) {
		this.hasPic = hasPic;
	}

	public long getLikes() {
		return likes;
	}

	public void setLikes(long likes) {
		this.likes = likes;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}
	
}
