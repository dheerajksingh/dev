package com.ebay.raptor.artcon.entities.bulkupload;

import java.util.Date;

import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Property;

public class SingleFiles {
	
	@Id
	@Property("id")
	
	private String userId;
	
	private String fileName;
	
    private String zipfile;
    
    private String operationType;
   
    private String status; 
    
    private String draftId;
    
    private String publishId;
    
	private Date dateCreated;
	
	private Date dateModified;
	
	private String logDetails;
	
	private String rLogid;

	
	
	public SingleFiles(String userId, String fileName, String zipfile,
			String status, Date dateCreated, Date dateModified,
			String logDetails,String rlogid,String operationType) {
		super();
		this.userId = userId;
		this.fileName = fileName;
		this.zipfile = zipfile;
		this.status = status;
		this.dateCreated = dateCreated;
		this.dateModified = dateModified;
		this.logDetails = logDetails;
		this.rLogid=rlogid;
		this.operationType=operationType;
	}

	public SingleFiles(String userId, String fileName, String zipfile,
			String status, Date dateCreated) {
		super();
		this.userId = userId;
		this.fileName = fileName;
		this.zipfile = zipfile;
		this.status = status;
		this.dateCreated = dateCreated;

	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getZipfile() {
		return zipfile;
	}

	public void setZipfile(String zipfile) {
		this.zipfile = zipfile;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getDateModified() {
		return dateModified;
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}

	public String getLogDetails() {
		return logDetails;
	}

	public void setLogDetails(String logDetails) {
		this.logDetails = logDetails;
	}

	public String getDraftId() {
		return draftId;
	}

	public void setDraftId(String draftId) {
		this.draftId = draftId;
	}

	public String getPublishId() {
		return publishId;
	}

	public void setPublishId(String publishId) {
		this.publishId = publishId;
	}

	public String getRlogid() {
		return rLogid;
	}

	public void setRlogid(String rlogid) {
		this.rLogid = rlogid;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getrLogid() {
		return rLogid;
	}

	public void setrLogid(String rLogid) {
		this.rLogid = rLogid;
	}
	
}
