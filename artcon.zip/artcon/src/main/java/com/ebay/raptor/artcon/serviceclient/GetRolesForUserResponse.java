package com.ebay.raptor.artcon.serviceclient;

import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = Inclusion.NON_NULL)
@XmlRootElement
@JsonIgnoreProperties(ignoreUnknown=true)

public class GetRolesForUserResponse {
	private ResponseStatus status;
	private Set<String> roles;

	
	public GetRolesForUserResponse(){
		
	}
	
	public GetRolesForUserResponse(Set<String> roles){
		this.roles=roles;
	}

	public Set<String> getRoles() {
		return roles;
	}

	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}
	
	
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

}
