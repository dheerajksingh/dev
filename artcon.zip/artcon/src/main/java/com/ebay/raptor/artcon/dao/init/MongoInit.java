package com.ebay.raptor.artcon.dao.init;

import static org.springframework.beans.factory.config.BeanDefinition.SCOPE_SINGLETON;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.DatastoreImpl;
import org.mongodb.morphia.Morphia;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.ebay.raptor.artcon.config.ConfigParam;
import com.ebay.resource.mddf.MDDFInitializer;
import com.ebayinc.platform.config.impl.mongo.MongoModuleInitializer;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;

@Configuration
public class MongoInit {
	
	private String PACKAGE = "com.ebay.raptor.cmseditor.entities.bulkupload";
	private String USERNAME = "curapp";
	private String PASSWORD = "curapp";
	

	@Bean
	@Scope(value = SCOPE_SINGLETON)
	public AdvancedDatastore getDataStore() throws UnknownHostException {

		MDDFInitializer.initialize(Thread.currentThread().getContextClassLoader(), false);
		new MongoModuleInitializer().init();
		
		MongoClient client = new MongoClient(getServerAddress(), genCredential());
		client.setReadPreference(ReadPreference.secondaryPreferred());
		
		AdvancedDatastore ds = new DatastoreImpl(new Morphia().mapPackage(PACKAGE), client, ConfigParam.MONGO_FOUNTAIN_DB_NAME.getStringValue());
		ds.setDefaultWriteConcern(WriteConcern.ACKNOWLEDGED);
		ds.ensureCaps(); //creates capped collections
		
		return ds;
	}
	
	 private List<MongoCredential> genCredential() {
		 List<MongoCredential> cred = new ArrayList<MongoCredential>();
		 //TODO: Get credentials from ESAMS
		 MongoCredential credential = MongoCredential.createScramSha1Credential(USERNAME, ConfigParam.MONGO_FOUNTAIN_DB_NAME.getStringValue(), PASSWORD.toCharArray()) ;
		 cred.add(credential);
		 return cred;
	 }
	 
	 public List<ServerAddress> getServerAddress() throws UnknownHostException {
		List<ServerAddress> serverAddressesList = new ArrayList<ServerAddress>();
		String serverAddresses = ConfigParam.MONGO_FOUNTAIN_SERVER_ADDRESS.getStringValue().substring(10); // To remove the mongodb:// part from the address string
		String[] serverAddressesArray = serverAddresses.split(",");
		for(String serverAddress:serverAddressesArray) {
			String host = serverAddress.split(":")[0];
			int port = Integer.valueOf(serverAddress.split(":")[1]);
			serverAddressesList.add(new ServerAddress(host, port));
		}
		return serverAddressesList;
	 }
}
