package com.ebay.raptor.artcon.handler;

import com.ebay.bes.common.BusinessEvent;

public interface ArticleEventHandler {
	public void processEvent(BusinessEvent event) throws Exception;
}
