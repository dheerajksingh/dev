package com.ebay.raptor.artcon.article.model;

public class Author {

	private Long id = 0L;
	private String username = "";
	private String fullName = "";
	private Integer feedbackScore = 0;
	private Long reviewRank = 0L;
	private Boolean isEbayAuthor;
	private boolean expert;
	private int type;
	private String imageUrl = "";
	private String storeName = "";
	private String storeUrl = "";
	private boolean isStoreValid = false;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Integer getFeedbackScore() {
		return feedbackScore;
	}
	public void setFeedbackScore(Integer feedbackScore) {
		this.feedbackScore = feedbackScore;
	}
	public Boolean getIsEbayAuthor() {
		return isEbayAuthor;
	}
	public void setIsEbayAuthor(Boolean isEbayAuthor) {
		this.isEbayAuthor = isEbayAuthor;
	}
	public boolean isExpert() {
		return expert;
	}
	public void setExpert(boolean expert) {
		this.expert = expert;
	}
	public Long getReviewRank() {
		return reviewRank;
	}
	public void setReviewRank(Long rank) {
		this.reviewRank = rank;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public boolean getIsStoreValid() {
		return isStoreValid;
	}
	public void setIsStoreValid(boolean isStoreValid) {
		this.isStoreValid = isStoreValid;
	}
	public String getStoreUrl() {
		return storeUrl;
	}
	public void setStoreUrl(String storeUrl) {
		this.storeUrl = storeUrl;
	}
}

