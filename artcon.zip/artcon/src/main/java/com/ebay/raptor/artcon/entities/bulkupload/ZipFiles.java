package com.ebay.raptor.artcon.entities.bulkupload;
	
import java.util.Date;

import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Field;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Index;
import org.mongodb.morphia.annotations.Indexes;
import org.mongodb.morphia.annotations.Property;
import org.mongodb.morphia.annotations.IndexOptions;  

import com.ebayinc.config.primitives.Objects;

@Entity(value="ZipFiles")
@Indexes({
		@Index(fields = {@Field("ZipFileName" ),@Field("userId")},options=@IndexOptions(unique=true))
})

public class ZipFiles{
	
    @Id 
	@Property("id")
	private ObjectId objectId;
    
//    @Indexed(value=IndexDirection.ASC, name="zipfilename_indx", 
//    background=false, unique=true, 
//    dropDups=true, sparse = false, 
//    expireAfterSeconds = -1 )
    
    @Property("ZipFileName")
	private String zipFileName;

//	@Indexed(value=IndexDirection.ASC, name="userid_indx", 
//            background=false, unique=true, 
//            dropDups=true, sparse = false, 
//            expireAfterSeconds = -1 )
	
	@Property("userId")
    private String userId; 
	
	private Date dateCreated;
	private Date dateModified;	

	@Property("status")
	private String status;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getZipFileName() {
		return zipFileName;
	}
	public void setZipFileName(String zipFilename) {
		this.zipFileName = zipFilename;
	}	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public ObjectId getObjectId() {
		return objectId;
	}
	public void setObjectId(ObjectId objectId) {
		this.objectId = objectId;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	public int hashcode(){
		return Objects.hashCode(this.userId,this.zipFileName);	
	}

}
