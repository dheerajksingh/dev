package com.ebay.raptor.artcon.init;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.ebay.kernel.initialization.Initializable;

@Configuration
@Import({ArticleInit.class})
public class ArticleConsumerConfiguration {

	@Inject ArticleInit articleInit;
		
	@PostConstruct
	private void initConsumer () {
		articleInit.getConsumer().init();
	}
}
