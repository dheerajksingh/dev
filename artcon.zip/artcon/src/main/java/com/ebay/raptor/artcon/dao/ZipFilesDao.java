package com.ebay.raptor.artcon.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.dao.BasicDAO;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;

import com.ebay.kernel.logger.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.ebay.raptor.artcon.entities.bulkupload.ZipFiles;

@Component
@Repository("zipFilesDao")
public class ZipFilesDao extends BasicDAO<ZipFiles, ObjectId> {

	private static final Logger LOGGER = Logger
			.getInstance(ZipFilesDao.class);
	
	
//	@Inject
//	private QueryHelper queryHelper;
	
	
	@Autowired
	public ZipFilesDao(AdvancedDatastore ds) {
		super(ZipFiles.class, ds);
		System.out.println("in constructor ZipFiles Dao  - "+ds);
	}


	public String createZipFile(ZipFiles zipFiles) {
		Key<ZipFiles> key = save(zipFiles);
		System.out.println(" id returned after save "+key);
		return key.getId().toString();
	}
	
	public void updateZipFile(String id ,String status){
		UpdateOperations<ZipFiles> updateOperations = createUpdateOperations();
		updateOperations.set("status", status);
		updateOperations.set("dateModified", new Date());

		Query<ZipFiles> query = createQuery();
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		objectIds.add(new ObjectId(id));

		query.criteria("_id").in(objectIds);		
		update(query, updateOperations);
	}
	
}
