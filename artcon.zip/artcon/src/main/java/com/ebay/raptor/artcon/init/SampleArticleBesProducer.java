package com.ebay.raptor.artcon.init;


import com.ebay.bes.common.util.BusinessEventUtil;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.ebay.raptor.besevents.ArticlePublishEvent;


public class SampleArticleBesProducer {

	public SampleArticleBesProducer() {
		new Thread() {
			public void run() {
				int count=1;
				while (true) {

					try {
						
//						ArticlePublishEvent event = new ArticlePublishEvent();
//						event.setArticleId("57f2ae22d532fb6c23ddc414");
//						event.setCommentType("blog-post");
//						event.setUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36");
//						event.setUserIp("0:0:0:0:0:0:0:1");
						//event.setCommentAuthor(commentAuthor);
						ArticleBulkUploadEvent event = new ArticleBulkUploadEvent();
						//event.setArticleId("579249e599a3194f1b314604");
						//event.setFileName("bulk"+count+++".zip");
						event.setFileName("bulk1.xml.zip");
						BusinessEventUtil.publishBusinessEvent(event, "useractivity1host");
						
						//System.out.println("Send Test Event - "+event.getFileName());
						break;
//						if(count>10){							
//							break;
//					    } 
					}
				catch (Exception ex) {
						ex.printStackTrace();
					}

				}
			}
		}.start();
	}

	
}
