package com.ebay.raptor.artcon.utils;

import com.ebay.kernel.calwrapper.CalEvent;
import com.ebay.kernel.calwrapper.CalEventFactory;

public class CALUtil {
	
	public static final String ARTICLE_SOLR_INDEXER = "ARTICLE_SOLR_INDEXER";
	public static final String UPDATE_CONTENT_FIELD_TASK_EXCEPTION = "UPDATE_CONTENT_FIELD_TASK_EXCEPTION";
	public static final String DELETE_CONTENT_TASK_EXCEPTION = "DELETE_CONTENT_TASK_EXCEPTION";
	public static final String UPDATE_CONTENT_TASK_EXCEPTION = "UPDATE_CONTENT_TASK_EXCEPTION";
	public static final String PUBLISH_CONTENT_TASK_EXCEPTION = "PUBLISH_CONTENT_TASK_EXCEPTION";
	public static final String  DRAFT_CONTENT_TASK_EXCEPTION = "DRAFT_CONTENT_TASK_EXCEPTION";
	public static final String FOUNTAIN_ADMIN_SERVICE_EXCEPTION = "FOUNTAIN_ADMIN_SERVICE_EXCEPTION";

    public static void logCALEvent(String type, String name, String data) {
        final CalEvent evt = CalEventFactory.create(type, name, "0", data);
        evt.completed();
    }

    public static void logFailedCALEvent(String type, String name, String data) {
        final CalEvent evt = CalEventFactory.create(type, name, "1",data);
        evt.completed();
    }
	
}
