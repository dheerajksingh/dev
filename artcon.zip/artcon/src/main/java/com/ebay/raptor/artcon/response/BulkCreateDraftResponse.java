package com.ebay.raptor.artcon.response;

import com.ebay.raptor.cmseditor.response.CreateDraftResponse;

public class BulkCreateDraftResponse{

	private String RlogId;
	private String error;
	private CreateDraftResponse createDraftResponse;
	
	public String getRlogId() {
		return RlogId;
	}
	public void setRlogId(String rlogId) {
		RlogId = rlogId;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public CreateDraftResponse getCreateDraftResponse() {
		return createDraftResponse;
	}
	public void setCreateDraftResponse(CreateDraftResponse createDraftResponse) {
		this.createDraftResponse = createDraftResponse;
	}
	
}
