package com.ebay.raptor.artcon.indexer;

import com.ebay.raptor.cmseditor.response.content.model.Article;

public interface IArticleIndexer {

	public boolean index(Article content);
	
	public boolean remove(String articleId);
	
}
