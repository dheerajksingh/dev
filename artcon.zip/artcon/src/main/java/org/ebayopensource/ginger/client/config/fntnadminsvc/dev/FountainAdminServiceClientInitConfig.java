package org.ebayopensource.ginger.client.config.fntnadminsvc.dev;

import org.ebayopensource.ginger.client.config.fntnadminsvc.BaseFountainAdminServiceClientInitConfig;
import com.ebay.raptor.artcon.config.ConfigParam;

public class FountainAdminServiceClientInitConfig extends BaseFountainAdminServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.FOUNTAIN_ADMIN_SERVICE_ENDPOINT.getStringValue();
	}
	
}
