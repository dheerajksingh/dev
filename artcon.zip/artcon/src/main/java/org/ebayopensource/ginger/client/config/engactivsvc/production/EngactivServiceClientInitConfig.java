package org.ebayopensource.ginger.client.config.engactivsvc.production;

import org.ebayopensource.ginger.client.config.engactivsvc.BaseEngactivServiceClientInitConfig;

import com.ebay.raptor.artcon.config.ConfigParam;

public class EngactivServiceClientInitConfig extends BaseEngactivServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.ENGACTIV_SERVICE_ENDPOINT.getStringValue();
	}
	
}
