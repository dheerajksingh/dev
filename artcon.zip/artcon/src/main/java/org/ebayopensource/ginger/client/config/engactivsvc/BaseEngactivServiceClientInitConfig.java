package org.ebayopensource.ginger.client.config.engactivsvc;

import org.ebayopensource.ginger.client.config.DefaultInitGingerClientConfig;
import org.ebayopensource.ginger.core.constants.PayloadLoggerSetting;

import com.ebay.raptor.artcon.utils.JsonObjectMapperProvider;
import com.ebay.raptor.ginger.client.filter.ContextPropagator;
import com.ebay.raptor.ginger.client.filter.RaptorContextInjector;

public abstract class BaseEngactivServiceClientInitConfig extends DefaultInitGingerClientConfig {

	private static final int READ_TIMEOUT = 100;
	private static final int THREAD_POOL_SIZE = 30;
	//TODO: Error threshold set to a higher number
	
	public BaseEngactivServiceClientInitConfig() {
		super();
	}

	@Override
	public int getReadTimeout() {
		return READ_TIMEOUT;
	}

	@Override
	public int getThreadPoolSize() {
		return THREAD_POOL_SIZE;
	}
	
	@Override
	public PayloadLoggerSetting getRequestPayloadLoggerSetting() {
		return PayloadLoggerSetting.ON;
	}

	@Override
	public int getErrorCountThreshold() {
		return 100;
	}
	
	@Override
	public Object[] getProviders() {
		return new Object[] { new ContextPropagator(),
				new RaptorContextInjector(),
				new JsonObjectMapperProvider() 
		};
	}
	
}
