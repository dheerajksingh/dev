package org.ebayopensource.ginger.client.config.myworldsvc.staging;

import org.ebayopensource.ginger.client.config.cmseditorsvc.BaseCmsEditorServiceClientInitConfig;

import com.ebay.raptor.artcon.config.ConfigParam;

public class MyWorldServiceClientInitConfig extends BaseCmsEditorServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.MYWORLD_SERVICE_ENDPOINT.getStringValue();
	}
	
}
