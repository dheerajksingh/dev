package org.ebayopensource.ginger.client.config.cmseditorsvc.staging;

import org.ebayopensource.ginger.client.config.cmseditorsvc.BaseCmsEditorServiceClientInitConfig;

import com.ebay.raptor.artcon.config.ConfigParam;

public class CmsEditorServiceClientInitConfig extends BaseCmsEditorServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.USER_ARTICLE_SERVICE_ENDPOINT.getStringValue();
	}
	
}
