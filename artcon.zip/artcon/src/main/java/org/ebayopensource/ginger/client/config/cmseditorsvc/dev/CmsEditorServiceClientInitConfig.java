package org.ebayopensource.ginger.client.config.cmseditorsvc.dev;

import org.ebayopensource.ginger.client.config.cmseditorsvc.BaseCmsEditorServiceClientInitConfig;

import com.ebay.raptor.artcon.config.ConfigParam;

public class CmsEditorServiceClientInitConfig extends BaseCmsEditorServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return "http://localhost:8084/user_content/v1";
		//return ConfigParam.USER_ARTICLE_SERVICE_ENDPOINT.getStringValue();
	}
	
}
