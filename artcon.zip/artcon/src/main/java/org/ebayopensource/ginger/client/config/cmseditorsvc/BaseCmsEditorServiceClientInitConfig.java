package org.ebayopensource.ginger.client.config.cmseditorsvc;

import java.util.HashSet;
import java.util.Set;

import org.ebayopensource.ginger.client.config.DefaultInitGingerClientConfig;
import org.ebayopensource.ginger.core.constants.PayloadLoggerSetting;

public abstract class BaseCmsEditorServiceClientInitConfig extends DefaultInitGingerClientConfig {

	private static final int READ_TIMEOUT = 5000;
	private static final int THREAD_POOL_SIZE = 30;
	//TODO: Error threshold set to a higher number
	
	public BaseCmsEditorServiceClientInitConfig() {
		super();
	}

	
	@Override
	public Set<String> getScopes() {
		Set<String> scopes = new HashSet<String>();
		scopes.add("https://api.ebay.com/oauth/scope/@public");
		return scopes;
}
	
	@Override
	public int getReadTimeout() {
		return READ_TIMEOUT;
	}

	@Override
	public int getThreadPoolSize() {
		return THREAD_POOL_SIZE;
	}
	
	@Override
	public PayloadLoggerSetting getRequestPayloadLoggerSetting() {
		return PayloadLoggerSetting.ON;
	}


	@Override
	public String getEndPoint() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int getErrorCountThreshold() {
		return 100;
	}
	
	
	
}
