package org.ebayopensource.ginger.client.config.myworldsvc.dev;

import org.ebayopensource.ginger.client.config.myworldsvc.BaseMyWorldServiceClientInitConfig;

import com.ebay.raptor.artcon.config.ConfigParam;

public class MyWorldServiceClientInitConfig extends BaseMyWorldServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.MYWORLD_SERVICE_ENDPOINT.getStringValue();
	}
	
}
