package com.ebay.raptor.artcon.serviceclient;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.internal.GingerClientManager;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ebay.platform.raptor.cosadaptor.exceptions.TokenCreationException;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient.UpdateModerationStatusRequest;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadResponse;


//@RunWith(PowerMockRunner.class)
//@PrepareForTest({ SecureTokenFactory.class})
public class CmsEditorServiceClientTest {

	@Before
	public void setup() {
		//PowerMockito.mockStatic(SecureTokenFactory.class);
	}
	
	@Test
	public void testRetrievingValidArticle() throws TokenCreationException {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		ArticleReadResponse response = new ArticleReadResponse();
		Article article = new Article();
		article.setArticleId("1");
		response.setArticle(article);
		when(gingerResponse.getEntity(ArticleReadResponse.class)).thenReturn(response);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
		when(builder.get()).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		/*OAuthTokenGenerator tokenGenerator = mock(OAuthTokenGenerator.class);
		SecureToken token = mock(SecureToken.class);
		when(token.getAccessToken()).thenReturn("123");
		when(tokenGenerator.getToken()).thenReturn(token);
		PowerMockito.when(SecureTokenFactory.getInstance()).thenReturn(tokenGenerator);*/
		
		Article article1  = client.getPublishedContent("1");
		assertTrue(article1 != null);
		assertTrue(article1.getArticleId().equals("1"));
	}
	
	@Test
	public void testRetrievingWithFailureResponse() throws TokenCreationException {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		Article article = new Article();
		ArticleReadResponse response = new ArticleReadResponse();
		article.setArticleId("1");
		response.setArticle(article);
		when(gingerResponse.getEntity(ArticleReadResponse.class)).thenReturn(response);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.BAD_REQUEST.getStatusCode());
		when(builder.get()).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		Article article1 = client.getPublishedContent("1");
		assertTrue(article1 == null);
	}
	
	@Test
	public void updateModerationStatusTest() {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
		
		UpdateModerationStatusRequest request = new UpdateModerationStatusRequest();
		request.setStatus("LIVE");
		assert(request.getStatus().equals("LIVE"));
		
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		boolean success = client.updateModerationStatus("123", "LIVE");
		assertTrue(success);
	}
	
	@Test
	public void updateModerationStatusFailureTest() {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.BAD_REQUEST.getStatusCode());
		
		UpdateModerationStatusRequest request = new UpdateModerationStatusRequest();
		request.setStatus("LIVE");
		assert(request.getStatus().equals("LIVE"));
		
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		boolean success = client.updateModerationStatus("123", "LIVE");
		assertTrue(!success);
	}
	
	@Test 
	public void testPublishContent(){
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
		
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
	
		PublishArticleResponse response = new PublishArticleResponse();
		response.setStatus(CmsEditorResponseStatus.SUCCESS);
		when(gingerResponse.getEntity(PublishArticleResponse.class)).thenReturn(response);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		String status = client.publishContent("123").getPublishArticleResponse().getStatus().name();
		assertTrue(status.equals("SUCCESS"));
		
	}
	
	@Test 
	public void testUploadContent(){
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.CREATED.getStatusCode());
		
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
	
		CreateDraftResponse response = new CreateDraftResponse();
		response.setStatus(CmsEditorResponseStatus.SUCCESS);
		when(gingerResponse.getEntity(CreateDraftResponse.class)).thenReturn(response);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		String status = client.uploadContent(new Article()).getCreateDraftResponse().getStatus().name();
		assertTrue(status.equals("SUCCESS"));
		
	}
	
	@Test 
	public void testPublishContentFail(){
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.BAD_REQUEST.getStatusCode());
		
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
	
		PublishArticleResponse response = new PublishArticleResponse();
		response.setStatus(CmsEditorResponseStatus.FAILURE);
		when(gingerResponse.getEntity(PublishArticleResponse.class)).thenReturn(response);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		PublishArticleResponse  publishArticleResponse = client.publishContent("123").getPublishArticleResponse();
		assertFalse(publishArticleResponse.getStatus().name().equalsIgnoreCase("SUCCESS"));
	}
	
	@Test 
	public void testUploadContentFail(){
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		when(gingerResponse.getStatus()).thenReturn(Response.Status.BAD_REQUEST.getStatusCode());
		
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(builder.headers(any(MultivaluedMap.class))).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
	
		CreateDraftResponse response = new CreateDraftResponse();
		response.setStatus(CmsEditorResponseStatus.FAILURE);
		when(gingerResponse.getEntity(CreateDraftResponse.class)).thenReturn(response);
		
		CmsEditorServiceClient client = new CmsEditorServiceClient() {
			protected String generateAppToken() throws TokenCreationException {
				return "123";
			}
		};
		client.client = gingerClient;
		CreateDraftResponse  createDraftResponse = client.uploadContent(new Article()).getCreateDraftResponse();
		assertFalse(createDraftResponse.getStatus().name().equalsIgnoreCase("SUCCESS"));

	}
}
