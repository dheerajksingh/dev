package com.ebay.raptor.artcon.handler;

import org.junit.Test;

import static org.mockito.Mockito.doNothing;

import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.dao.ZipFilesDao;
import com.ebay.raptor.artcon.entities.bulkupload.ZipFiles;

import com.ebay.raptor.artcon.utils.BulkContentProcessor;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.ebay.raptor.besevents.ArticleEvent;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ArticleBulkUploadHandlerTest {
	
	@Test
	public void articleBulkUploadEventZipFileCreateSuccessTest() throws Exception{
		ArticleEvent bulkEvent = new ArticleBulkUploadEvent();
		ArticleBulkUploadEventHandler handler = new ArticleBulkUploadEventHandler();

		handler.bulkContentProcessor  = mock(BulkContentProcessor.class);
		handler.zipFilesDao = mock(ZipFilesDao.class);
		handler.singleFilesDao = mock(SingleFilesDao.class);
		String id = new String("123");

		 when(handler.zipFilesDao.createZipFile(any(ZipFiles.class))).thenReturn(id);
	        doNothing().when(handler.zipFilesDao).updateZipFile(id,"COMPLETED");  
	        doNothing().when(handler.zipFilesDao).updateZipFile(id,"INCOMPLETE");        
	        handler.processEvent(bulkEvent);
	}

	
	@Test
	public void articleBulkUploadEventNoZipFileCreatedTest() throws Exception{
		ArticleEvent bulkEvent = new ArticleBulkUploadEvent();
		ArticleBulkUploadEventHandler handler = new ArticleBulkUploadEventHandler();

		handler.bulkContentProcessor  = mock(BulkContentProcessor.class);
		handler.zipFilesDao = mock(ZipFilesDao.class);
		handler.singleFilesDao = mock(SingleFilesDao.class);
		String id = new String("123");
		 when(handler.zipFilesDao.createZipFile(any(ZipFiles.class))).thenReturn(null);
	        doNothing().when(handler.zipFilesDao).updateZipFile(id,"COMPLETED");  
	        doNothing().when(handler.zipFilesDao).updateZipFile(id,"INCOMPLETE");        
	        handler.processEvent(bulkEvent);
	}
	
	@Test
	public void articleBulkUploadEventZipFileCreateExceptionTest() throws Exception{
		ArticleEvent bulkEvent = new ArticleBulkUploadEvent();
		ArticleBulkUploadEventHandler handler = new ArticleBulkUploadEventHandler();

		handler.bulkContentProcessor  = mock(BulkContentProcessor.class);
		handler.zipFilesDao = mock(ZipFilesDao.class);
		handler.singleFilesDao = mock(SingleFilesDao.class);
		String id = new String("123");
		when(handler.bulkContentProcessor.processBulkContent(any(ArticleBulkUploadEvent.class),any(SingleFilesDao.class))).thenThrow(new Exception());			
		when(handler.zipFilesDao.createZipFile(any(ZipFiles.class))).thenReturn(id);
        doNothing().when(handler.zipFilesDao).updateZipFile(id,"COMPLETED");  
        doNothing().when(handler.zipFilesDao).updateZipFile(id,"INCOMPLETE");        
        handler.processEvent(bulkEvent);
	}
	
}