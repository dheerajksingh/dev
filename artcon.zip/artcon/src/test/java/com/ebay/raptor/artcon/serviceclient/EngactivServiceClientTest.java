package com.ebay.raptor.artcon.serviceclient;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;

import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

public class EngactivServiceClientTest {

	@Test
	public void testRetrievingValidEntity() {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		EngactivServiceResponse engResponse = new EngactivServiceResponse();
		engResponse.setSuccess(true);
		engResponse.setTotal_likes(100);
		
		when(gingerResponse.getEntity(EngactivServiceResponse.class)).thenReturn(engResponse);
		when(builder.get()).thenReturn(gingerResponse);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		EngactivServiceClient client = new EngactivServiceClient(gingerClient);
		assertTrue(client.getArticleLikes("0") == 100);	
	}
	
	@Test
	public void testRetrievingInValidEntity() {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		EngactivServiceResponse engResponse = new EngactivServiceResponse();
		engResponse.setSuccess(false);
		
		when(gingerResponse.getEntity(EngactivServiceResponse.class)).thenReturn(engResponse);
		when(builder.get()).thenReturn(gingerResponse);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		EngactivServiceClient client = new EngactivServiceClient(gingerClient);
		assertTrue(client.getArticleLikes("0") == 0);	
	}
	
	@Test
	public void testRetrievingNullEntity() {
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		EngactivServiceResponse engResponse = new EngactivServiceResponse();
		engResponse.setSuccess(false);
		
		when(gingerResponse.getEntity(EngactivServiceResponse.class)).thenReturn(engResponse);
		when(builder.get()).thenReturn(gingerResponse);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		EngactivServiceClient client = new EngactivServiceClient(gingerClient);
		assertTrue(client.getArticleLikes(null) == 0);	
	}
	
}
