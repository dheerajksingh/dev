package com.ebay.raptor.artcon.indexer;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.solr.client.solrj.SolrServerException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.store.UserStoreLookup;
import com.ebay.integ.store.UserStoreLookupDAO;
import com.ebay.integ.usercontent.UserAuthorRank;
import com.ebay.integ.usercontent.UserAuthorRankDAO;
import com.ebay.raptor.artcon.article.model.ArticleModel;
import com.ebay.raptor.artcon.utils.BusinessRule;
import com.ebay.raptor.artcon.utils.CategoryHelper;
import com.ebay.raptor.artcon.utils.SolrUpdateUtil;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ UserAuthorRankDAO.class,  UserStoreLookupDAO.class })

public class ArticleSolrIndexerTest {

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		PowerMockito.mockStatic(UserAuthorRankDAO.class);
		PowerMockito.mockStatic(UserStoreLookupDAO.class);
	}

	@Test
	public void testIndexingValidContent() throws FinderException, IOException, SolrServerException {
		
		Article article = new Article();
		article.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		article.setArticleId("57fc0f6b5504c81595e95fff");
		article.setDateCreated(new DateTime(new Date()));
		article.setDateModified(new DateTime(new Date()));
		article.setMarketplaceId("0");
		article.setModerationStatus(ModerationStatusEnum.NOT_MODERATED);
		article.setTemplateType("HOW_TO");
		 
		
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		article.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		article.setAuthor(author);
		
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/Scheduledstartenddat/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		
		Text title = new Text();
		title.setContent("Scheduledstartenddate");
		ugc.setTitle(title);		
		ugc.setSynopsis(title);		
		
		Group group = new Group();
		group.setGroupId(String.valueOf("0"));
		group.setTitle(title);
		List<Section> sections = new ArrayList<Section>();
		
		Section section1  = new Section();
		section1.setSectionId(String.valueOf("0"));
		
		StandardComponent sComp1 = new StandardComponent();
		sComp1.setComponentType("BLOCK_QUOTE");
		sComp1.setData("Scheduledstartenddate Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
	
		
		StandardComponent sComp2 = new StandardComponent();
		sComp1.setComponentType("HEADING");
		sComp1.setData("Scheduledstartenddate Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		
		StandardComponent sComp3 = new StandardComponent();
		sComp1.setComponentType("PARAGRAPH");
		sComp1.setData("Scheduledstartenddate Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
				
		List<Component> comp = new ArrayList<Component>();
		comp.add(sComp1);
		comp.add(sComp2);
		comp.add(sComp3);
		
		section1.setComponents(comp);
		
		sections.add(section1);
		group.setSections(sections);
		
		
		article.setUserGeneratedContent(ugc);
		
				
		//article.setScheduledStartDate(new DateTime(new Date(System.currentTimeMillis())));
	
		//article.setScheduledStartDate(new DateTime(new Date(System.currentTimeMillis()+24*30*3600*1000l)));
		
		article.setScheduledEndDate(new DateTime(new Date(System.currentTimeMillis()+24*30*3600*1000l)));
		//article.setScheduledEndDate(new DateTime(new Date(System.currentTimeMillis())));
	
		
		UserAuthorRank rank = mock(UserAuthorRank.class);
		when(rank.getRank()).thenReturn(10l);
		UserAuthorRankDAO userRankDao = mock(UserAuthorRankDAO.class);
		when(userRankDao.findByPK(any(Long.class), any(Integer.class), any(Integer.class))).thenReturn(rank);
        PowerMockito.when(UserAuthorRankDAO.getInstance()).thenReturn(userRankDao);
        
        UserStoreLookup store = mock(UserStoreLookup.class);
		when(store.getName()).thenReturn("testname");
		when(store.getStoreUrl()).thenReturn("testurl");
		UserStoreLookupDAO storeDao = mock(UserStoreLookupDAO.class);
		when(storeDao.findByUserID(any(Long.class))).thenReturn(store);
        PowerMockito.when(UserStoreLookupDAO.getInstance()).thenReturn(storeDao);
        
        List<Long> cats = new ArrayList<Long>();
        cats.add(0l);
        CategoryHelper catHelper = mock(CategoryHelper.class);
        when(catHelper.findMltCategories(any(String.class))).thenReturn(cats);
		ArticleProcessor processor = new ArticleProcessor();
		ArticleProcessor.siteToLabel.put(0, 0);
		ArticleProcessor.categoryHelper = catHelper;
		
		ArticleSolrIndexer solrIndexer = new ArticleSolrIndexer();
		assertTrue(solrIndexer.index(article, processor));
	//	assertTrue(solrIndexer.remove(article.getArticleId()));
	}	
	
	@Test
	public void testIndexingWithSolrException() throws FinderException, IOException, SolrServerException {
		
		Article article = new Article();
		article.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		article.setArticleId("0");
		article.setDateCreated(new DateTime(new Date()));
		article.setDateModified(new DateTime(new Date()));
		article.setMarketplaceId("0");
		article.setModerationStatus(ModerationStatusEnum.NOT_MODERATED);
		article.setTemplateType("HOW_TO");
		 
		
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		article.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		article.setAuthor(author);
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		Text title = new Text();
		title.setContent("Title");
		ugc.setTitle(title);
		
		Group group = new Group();
		group.setGroupId(String.valueOf("0"));
		List<Section> sections = new ArrayList<Section>();
		Section section = new Section();
		section.setSectionId(String.valueOf("0"));
		
		StandardComponent sComp = new StandardComponent();
		sComp.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		List<Component> components = new ArrayList<Component>();
		components.add(sComp);
		section.setComponents(components);
		sections.add(section);
		group.setSections(sections);
				
		article.setUserGeneratedContent(ugc);
		
		UserAuthorRank rank = mock(UserAuthorRank.class);
		when(rank.getRank()).thenReturn(10l);
		UserAuthorRankDAO userRankDao = mock(UserAuthorRankDAO.class);
		when(userRankDao.findByPK(any(Long.class), any(Integer.class), any(Integer.class))).thenReturn(rank);
        PowerMockito.when(UserAuthorRankDAO.getInstance()).thenReturn(userRankDao);
        
        UserStoreLookup store = mock(UserStoreLookup.class);
		when(store.getName()).thenReturn("testname");
		when(store.getStoreUrl()).thenReturn("testurl");
		UserStoreLookupDAO storeDao = mock(UserStoreLookupDAO.class);
		when(storeDao.findByUserID(any(Long.class))).thenReturn(store);
        PowerMockito.when(UserStoreLookupDAO.getInstance()).thenReturn(storeDao);
        
        List<Long> cats = new ArrayList<Long>();
        cats.add(0l);
        CategoryHelper catHelper = mock(CategoryHelper.class);
        when(catHelper.findMltCategories(any(String.class))).thenReturn(cats);
		ArticleProcessor processor = new ArticleProcessor();
		ArticleProcessor.siteToLabel.put(0, 0);
		ArticleProcessor.categoryHelper = catHelper;
		
		PowerMockito.mockStatic(SolrUpdateUtil.class);
		Mockito.doThrow(new Exception("Solr update failed")).when(SolrUpdateUtil.class);
		ArticleSolrIndexer solrIndexer = new ArticleSolrIndexer();
		assertTrue(solrIndexer.index(article, processor));
		assertTrue(solrIndexer.remove(article.getArticleId()));
	}	
	
	@Test
	public void testPopulateInspectionStatus() throws FinderException, IOException, SolrServerException, ParseException {
		Article cModel = new Article();
		cModel.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		cModel.setArticleId("0");
		cModel.setDateCreated(new DateTime(new Date()));
		cModel.setDateModified(new DateTime(new Date()));
		cModel.setMarketplaceId("0");
		cModel.setModerationStatus(ModerationStatusEnum.NOT_MODERATED);
		cModel.setTemplateType("HOW_TO");
		
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		cModel.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		cModel.setAuthor(author);
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		Text title = new Text();
		title.setContent("Title");
		ugc.setTitle(title);
		
		Group group = new Group();
		group.setGroupId("0");
		List<Section> listModules = new ArrayList<Section>();
		Section module = new Section();
		module.setSectionId("0");
		StandardComponent sModule = new StandardComponent();
		sModule.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		List<Component> modules = new ArrayList<Component>();
		modules.add(sModule);
		module.setComponents(modules);
		listModules.add(module);
		group.setSections(listModules);
		
		cModel.setUserGeneratedContent(ugc);
		
		ArticleModel am = process(cModel);
		ArticleSolrIndexer solrIndexer = new ArticleSolrIndexer();
		BusinessRule br = mock(BusinessRule.class);
		when(br.hasBlacklistWords(am)).thenReturn(false);
		int inspectionStatus = solrIndexer.populateInspectionStatus(am);
		assertSame(inspectionStatus, 10);
		
	}	

	public ArticleModel process(Article content) {
		Article article = content;
		ArticleModel articleModel = new ArticleModel(); 
		articleModel.setAccessControlList(article.getAccessControlList());
		articleModel.setAuthor(article.getAuthor());
		articleModel.setArticleId(article.getArticleId());
		articleModel.setArticleStatus(article.getArticleStatus());
		articleModel.setDateCreated(article.getDateCreated());
		articleModel.setDateModified(article.getDateModified());
		articleModel.setMarketplaceId(article.getMarketplaceId());
		articleModel.setModerationStatus(article.getModerationStatus());
		articleModel.setTemplateType(article.getTemplateType());
		articleModel.setUserGeneratedContent(article.getUserGeneratedContent());
		return articleModel;
	}
	

}
