package com.ebay.raptor.artcon.serviceclient;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;

import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.junit.Test;

import javax.ws.rs.client.Entity;

public class MyWorldServiceClientTest {

	@Test
	public void testGetUserWithValidUserName() {
		
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		UserProfileServiceResponse response = new UserProfileServiceResponse();
		UserProfile profile = new UserProfile();
		profile.setFullName("FullName");
		Set<UserProfile> profiles = new HashSet<UserProfile>();
		profiles.add(profile);
		response.setResults(profiles);
		
		when(gingerResponse.getEntity(UserProfileServiceResponse.class)).thenReturn(response);
		when(builder.post(any(Entity.class))).thenReturn(gingerResponse);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		MyWorldServiceClient client = new MyWorldServiceClient(gingerClient);
		UserProfileServiceResponse clientResponse = client.getUser("testuser");
		
		assertTrue(clientResponse.getResults().iterator().next().getFullName().equals("FullName"));
		
	}
	
	@Test
	public void testGetUserWithNullUserName() {
		
		MyWorldServiceClient client = new MyWorldServiceClient();
		UserProfileServiceResponse clientResponse = client.getUser(null);
		assertTrue(clientResponse == null);
		
	}
	
	@Test
	public void testGetUserWithEmptyUserName() {
		
		MyWorldServiceClient client = new MyWorldServiceClient();
		UserProfileServiceResponse clientResponse = client.getUser("");
		assertTrue(clientResponse == null);
		
	}
	
	@Test
	public void testGetUserWithInvalidClientId() {
		
		MyWorldServiceClient client = new MyWorldServiceClient();
		client.CLIENT_ID = "Invalid";
		UserProfileServiceResponse clientResponse = client.getUser("testuser");
		assertTrue(clientResponse == null);
		
	}
}
