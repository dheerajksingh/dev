package com.ebay.raptor.artcon.article.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.raptor.artcon.utils.BusinessRule;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;

public class BusinessRuleTest {
	
	@Test
	public void testNotEnoughFeedback() {
		
		Article cModel = new Article();
		cModel.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		cModel.setArticleId("0");
		cModel.setDateCreated(new DateTime(new Date()));
		cModel.setDateModified(new DateTime(new Date()));
		cModel.setMarketplaceId("0");
		cModel.setTemplateType("HOW_TO");
		
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		cModel.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		cModel.setAuthor(author);
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		Text title = new Text();
		title.setContent("Title");
		ugc.setTitle(title);
		
		ugc.setSynopsis(title);
		
		Group group = new Group();
		group.setGroupId("0");
		group.setTitle(title);
		List<Section> listModules = new ArrayList<Section>();
		Section module = new Section();
		module.setSectionId("0");
		StandardComponent sModule1 = new StandardComponent();
		sModule1.setComponentType("BLOCK_QUOTE");
		sModule1.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sModule2 = new StandardComponent();
		sModule2.setComponentType("HEADING");
		sModule2.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sModule3 = new StandardComponent();
		sModule3.setComponentType("PARAGRAPH");
		sModule3.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		List<Component> modules = new ArrayList<Component>();
		modules.add(sModule1);
		modules.add(sModule2);
		modules.add(sModule3);
		module.setComponents(modules);
		listModules.add(module);
		group.setSections(listModules);
		
		cModel.setUserGeneratedContent(ugc);

		ArticleModel am = process(cModel);
		BusinessRule br = new BusinessRule();
		boolean isNotEnoughFeedback = br.notEnoughFeedback(am);
		Assert.assertSame(false, isNotEnoughFeedback);
	}
	
	@Test
	public void testHasBlacklistWords() {
		
		Article cModel = new Article();
		cModel.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		cModel.setArticleId("0");
		cModel.setDateCreated(new DateTime(new Date()));
		cModel.setDateModified(new DateTime(new Date()));
		cModel.setMarketplaceId("0");
		cModel.setModerationStatus(ModerationStatusEnum.NOT_MODERATED);
		cModel.setTemplateType("HOW_TO");
		
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		cModel.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		cModel.setAuthor(author);
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		Text title = new Text();
		title.setContent("Title");
		ugc.setTitle(title);
		
		ugc.setSynopsis(title);
		
		Group group = new Group();
		group.setGroupId("0");
		group.setTitle(title);
		List<Section> listModules = new ArrayList<Section>();
		Section module = new Section();
		module.setSectionId("0");
		StandardComponent sModule1 = new StandardComponent();
		sModule1.setComponentType("BLOCK_QUOTE");
		sModule1.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sModule2 = new StandardComponent();
		sModule2.setComponentType("HEADING");
		sModule2.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sModule3 = new StandardComponent();
		sModule3.setComponentType("PARAGRAPH");
		sModule3.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		List<Component> modules = new ArrayList<Component>();
		modules.add(sModule1);
		modules.add(sModule2);
		modules.add(sModule3);
		module.setComponents(modules);
		listModules.add(module);
		group.setSections(listModules);
		
		cModel.setUserGeneratedContent(ugc);

		ArticleModel am = process(cModel);
		BusinessRule br = new BusinessRule();
		boolean isNotClean = br.hasBlacklistWords(am);
		Assert.assertSame(false, isNotClean);
	}
	
	@Test
	public void testNotClean() {
		
		Article cModel = new Article();
		cModel.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		cModel.setArticleId("0");
		cModel.setDateCreated(new DateTime(new Date()));
		cModel.setDateModified(new DateTime(new Date()));
		cModel.setMarketplaceId("0");
		cModel.setModerationStatus(ModerationStatusEnum.NOT_MODERATED);
		cModel.setTemplateType("HOW_TO");
		
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		cModel.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		cModel.setAuthor(author);
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		Text title = new Text();
		title.setContent("Title");
		ugc.setTitle(title);
		
		ugc.setSynopsis(title);
		
		Group group = new Group();
		group.setGroupId("0");
		group.setTitle(title);
		List<Section> listModules = new ArrayList<Section>();
		Section module = new Section();
		module.setSectionId("0");
		StandardComponent sModule1 = new StandardComponent();
		sModule1.setComponentType("BLOCK_QUOTE");
		sModule1.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sModule2 = new StandardComponent();
		sModule2.setComponentType("HEADING");
		sModule2.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sModule3 = new StandardComponent();
		sModule3.setComponentType("PARAGRAPH");
		sModule3.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		List<Component> modules = new ArrayList<Component>();
		modules.add(sModule1);
		modules.add(sModule2);
		modules.add(sModule3);
		module.setComponents(modules);
		listModules.add(module);
		group.setSections(listModules);
		
		cModel.setUserGeneratedContent(ugc);

		ArticleModel am = process(cModel);
//		AssetRepositoryUtil assetUtil = Mockito.mock(AssetRepositoryUtil.class);
		Set<String> blackListWords = new HashSet<String>();
//		Mockito.when(AssetRepositoryUtil.getBlacklistWords()).thenReturn(blackListWords);
		BusinessRule br = new BusinessRule();
//		when(br.hasBlacklistWords(am)).thenReturn(false);
		boolean isNotClean = br.notClean(am);
		Assert.assertSame(false, isNotClean);
	}
	
	public ArticleModel process(Article content) {
		Article article = content;
		ArticleModel articleModel = new ArticleModel(); 
		articleModel.setAccessControlList(article.getAccessControlList());
		articleModel.setAuthor(article.getAuthor());
		Author articleAuthor = new Author();
		articleAuthor.setFeedbackScore(4);
		articleModel.setArticleAuthor(articleAuthor);
		articleModel.setArticleId(article.getArticleId());
		articleModel.setArticleStatus(article.getArticleStatus());
		articleModel.setDateCreated(article.getDateCreated());
		articleModel.setDateModified(article.getDateModified());
		articleModel.setMarketplaceId(article.getMarketplaceId());
		articleModel.setModerationStatus(article.getModerationStatus());
		articleModel.setTemplateType(article.getTemplateType());
		articleModel.setUserGeneratedContent(article.getUserGeneratedContent());
		return articleModel;
	}

}
