package com.ebay.raptor.artcon.utils;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.ebay.raptor.artcon.dao.SingleFilesDao;
import com.ebay.raptor.artcon.entities.bulkupload.SingleFiles;
import com.ebay.raptor.artcon.task.BulkContentTaskManager;
import com.ebay.raptor.besevents.ArticleBulkUploadEvent;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.ebay.raptor.orchestration.ITaskOrchestrator;
import com.ebay.raptor.orchestration.ITaskResult;
import com.ebay.raptor.orchestration.TaskExecutionException;

public class BulkContentProcessorTest{
	

	  public static final String CONTENT_STATUS = "PUBLISHED";
	    public static final String fileLocation = ".";
	    public static final String HOW_TO="HOW_TO";	    
	    protected ITaskOrchestrator orchestrator;
	    protected SingleFilesDao singleFilesDao;

		@Test
		public void tetFileProcess() throws Exception{
			
			BulkContentProcessor processor = new BulkContentProcessor();
			processor.singleFilesDao=mock(SingleFilesDao.class);
			processor.bcManager=mock(BulkContentTaskManager.class);
			ArticleBulkUploadEvent articleBulkUploadEvent = new ArticleBulkUploadEvent();
			articleBulkUploadEvent.setFileName("bulk_one.zip");
			articleBulkUploadEvent.setUserName("tpaul");
        	String id = "123";	
	        
	        ITaskResult<Object> it = new ITaskResult<Object>(){

				@Override
				public Object getResult() throws TaskExecutionException {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public Object getResult(long timeout, TimeUnit unit)
						throws TaskExecutionException {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public boolean isResultAvailable() {
					// TODO Auto-generated method stub
					return false;
				}};
	        
	        
	        when(processor.singleFilesDao.createSingleFile(any(SingleFiles.class))).thenReturn(id);
	        when(processor.bcManager.createBulkUploadTask(any(Article.class),any(String.class))).thenReturn(it);

	        processor.processBulkContent(articleBulkUploadEvent,processor.singleFilesDao);
		
		}

}
