package com.ebay.raptor.artcon.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.junit.Test;

import com.ebay.raptor.artcon.serviceclient.CategoryServiceClient;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

public class CategoryHelperTest {

	@Test
	public void testGetCategoriesWithValidTerms() throws SolrServerException, IOException {
		CategoryHelper catHelper = new CategoryHelper();
		
		
		HttpSolrServer server = mock(HttpSolrServer.class); 
		QueryResponse response = mock(QueryResponse.class);
		SolrDocumentList resultList = new SolrDocumentList();
		SolrDocument doc = new SolrDocument();
		doc.setField("id", "123");
		resultList.add(doc);
		when(response.getResults()).thenReturn(resultList);
		when(server.query(any(SolrQuery.class))).thenReturn(response);
		
		catHelper.solrServer = server;
		
		List<Long> categories = catHelper.findMltCategories("camera drone");
		assertNotNull(categories);
		assertTrue(categories.size() > 0);
		assertTrue(categories.get(0).equals(123l));
		
	}
	
	@Test(expected = SolrServerException.class) 
	public void testGetCategoriesWithSolrException() throws IOException, SolrServerException {
		CategoryHelper catHelper = new CategoryHelper();
		HttpSolrServer server = mock(HttpSolrServer.class); 
		QueryResponse response = mock(QueryResponse.class);
		SolrDocumentList resultList = new SolrDocumentList();
		SolrDocument doc = new SolrDocument();
		doc.setField("id", "123");
		resultList.add(doc);
		when(response.getResults()).thenReturn(resultList);
		List<Long> categories = null;
		when(server.query(any(SolrQuery.class))).thenThrow(new SolrServerException("Server not reachable"));
		catHelper.solrServer = server;
		categories = catHelper.findMltCategories("camera drone");
		assertNotNull(categories);
		assertTrue(categories.size() == 0);
	}
	
	@Test
	public void testGetCategoryPath() throws Exception {
		/*		List<Integer> path = new ArrayList<Integer>(10);
		Map<Long, Long> leafCategoryIdSiteIdMap = new HashMap<>();
		leafCategoryIdSiteIdMap.put(Long.valueOf(siteId),
				Long.valueOf(categoryId));

		Map<Long, List<Integer>> catFullPathMp = catServiceClient
				.getCategoryFullPath(leafCategoryIdSiteIdMap);
		path = catFullPathMp.get(categoryId);
		// Reverse the order*/
		
		CategoryHelper catHelper = new CategoryHelper();
		CategoryServiceClient client = mock(CategoryServiceClient.class);
		Map<Long, List<Integer>> map = new HashMap<>();
		List<Integer> path = new ArrayList<>();
		path.add(1);
		path.add(2);
		path.add(3);
		map.put(3l, path);
		
		when(client.getCategoryFullPath(any(Map.class))).thenReturn(map);
		catHelper.catServiceClient = client;
		List<Integer> catPath = catHelper.getCategoryPath(0, 3);
		assertNotNull(catPath);
		assertTrue(catPath.size() > 0);
		assertTrue((catPath.get(0) == 3) && (catPath.get(1) == 2) && (catPath.get(2) == 1));
		
	}
	
}
