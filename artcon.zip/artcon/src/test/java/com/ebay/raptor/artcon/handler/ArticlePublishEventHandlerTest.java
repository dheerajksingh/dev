package com.ebay.raptor.artcon.handler;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.raptor.artcon.indexer.ArticleSolrIndexer;
import com.ebay.raptor.artcon.init.ArticleInit;
import com.ebay.raptor.artcon.serviceclient.CmsEditorServiceClient;
import com.ebay.raptor.besevents.ArticlePublishEvent;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.spam.akismet.Akismet;
import com.ebay.spam.akismet.AkismetComment;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

public class ArticlePublishEventHandlerTest {

	@Test
	public void testHandlePublishEvent() throws Exception {
		
		ArticlePublishEventHandler handler = new ArticlePublishEventHandler();
		handler.articleSolrIndexer = mock(ArticleSolrIndexer.class);
		handler.akismet = mock(Akismet.class);
		handler.context = mock(ApplicationContext.class);
		handler.init = mock(ArticleInit.class);
		handler.cmsEditorServiceClient = mock(CmsEditorServiceClient.class);
		
		when(handler.akismet.commentCheck(any(AkismetComment.class))).thenReturn(false);
		Article article  = new Article();
		article.setArticleId("123");
		UserGeneratedContent ugc = new UserGeneratedContent();
		ugc.setTitle(new Text("Title", LanguageEnum.en));
		article.setUserGeneratedContent(ugc);
		when(handler.articleSolrIndexer.index(article)).thenReturn(true);
		when(handler.cmsEditorServiceClient.getPublishedContent(any(String.class))).thenReturn(article);
		when(handler.cmsEditorServiceClient.updateModerationStatus(any(String.class), any(String.class))).thenReturn(true);
		
		ArticlePublishEvent event = new ArticlePublishEvent();
		event.setArticleId("123");
		handler.processEvent(event);
		
	}
	
	@Test
	public void testHandlePublishSpamEventEvent() throws Exception {
		
		ArticlePublishEventHandler handler = new ArticlePublishEventHandler();
		handler.articleSolrIndexer = mock(ArticleSolrIndexer.class);
		handler.akismet = mock(Akismet.class);
		handler.context = mock(ApplicationContext.class);
		handler.init = mock(ArticleInit.class);
		handler.cmsEditorServiceClient = mock(CmsEditorServiceClient.class);
		
		when(handler.akismet.commentCheck(any(AkismetComment.class))).thenReturn(true);
		Article article  = new Article();
		article.setArticleId("123");
		UserGeneratedContent ugc = new UserGeneratedContent();
		ugc.setTitle(new Text("Title", LanguageEnum.en));
		article.setUserGeneratedContent(ugc);
		when(handler.articleSolrIndexer.index(article)).thenReturn(true);
		when(handler.cmsEditorServiceClient.getPublishedContent(any(String.class))).thenReturn(article);
		when(handler.cmsEditorServiceClient.updateModerationStatus(any(String.class), any(String.class))).thenReturn(true);
		
		ArticlePublishEvent event = new ArticlePublishEvent();
		event.setArticleId("123");
		handler.processEvent(event);
		
	}
	
}
