package com.ebay.raptor.artcon.serviceclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

import com.ebay.marketplace.category.v1.services.CategoryNodeDetail;
import com.ebay.marketplace.category.v1.services.CategoryPath;
import com.ebay.marketplace.category.v1.services.GetCategoryPathRequest;
import com.ebay.marketplace.category.v1.services.GetParentCategoryResponse;
import com.ebay.marketplace.services.AckValue;
import com.ebay.marketplace.services.categoryserviceclient.consumer.CategoryServiceConsumer;

public class CategoryServiceClientTest {

	@Test
	public void getCategoryFullPathTestWithValidCategory() {
		
		CategoryServiceConsumer consumer = mock(CategoryServiceConsumer.class);
		
		List<CategoryPath> rootCats = new ArrayList<CategoryPath>();
		CategoryPath cPath = new CategoryPath();
		CategoryNodeDetail nodeDetail = new CategoryNodeDetail();
		nodeDetail.setCategoryId("0");
		cPath.setCategoryNodeDetail(nodeDetail);
		
		CategoryPath childPath = new CategoryPath();
		CategoryNodeDetail childNodeDetail = new CategoryNodeDetail();
		childNodeDetail.setCategoryId("1");
		childPath.setCategoryNodeDetail(childNodeDetail);
		
		cPath.setImmediateChildCategory(childPath);
		
		rootCats.add(cPath);
		
		GetParentCategoryResponse response = mock(GetParentCategoryResponse.class);
		
		when(response.getAck()).thenReturn(AckValue.SUCCESS);
		when(response.getCategoryPath()).thenReturn(rootCats);
		
		when(consumer.getCategoryPath(any(GetCategoryPathRequest.class))).thenReturn(response);
		CategoryServiceClient client = new CategoryServiceClient(consumer);
		List<Integer> path = client.getCategoryFullPath(0, 0);
		assertNotNull(path);
		assertTrue(path.size() > 0);
		
	}
	
	@Test
	public void getCategoryFullPathMapTestWithValidCategory() {
		
		CategoryServiceConsumer consumer = mock(CategoryServiceConsumer.class);
		
		List<CategoryPath> rootCats = new ArrayList<CategoryPath>();
		CategoryPath cPath = new CategoryPath();
		CategoryNodeDetail nodeDetail = new CategoryNodeDetail();
		nodeDetail.setCategoryId("0");
		cPath.setCategoryNodeDetail(nodeDetail);
		
		CategoryPath childPath = new CategoryPath();
		CategoryNodeDetail childNodeDetail = new CategoryNodeDetail();
		childNodeDetail.setCategoryId("1");
		childPath.setCategoryNodeDetail(childNodeDetail);
		
		cPath.setImmediateChildCategory(childPath);
		
		rootCats.add(cPath);
		
		GetParentCategoryResponse response = mock(GetParentCategoryResponse.class);
		
		when(response.getAck()).thenReturn(AckValue.SUCCESS);
		when(response.getCategoryPath()).thenReturn(rootCats);
		
		when(consumer.getCategoryPath(any(GetCategoryPathRequest.class))).thenReturn(response);
		CategoryServiceClient client = new CategoryServiceClient(consumer);
		Map<Long, Long> map = new HashMap<Long, Long>();
		map.put(0l,0l);
		Map<Long, List<Integer>> pathMap = client.getCategoryFullPath(map);
		assertNotNull(pathMap.get(0l));
		assertTrue(pathMap.get(0l).size() > 0);
		
	}
	
	@Test
	public void getCategoryFullPathMapTestWithNullResponse() {
		
		CategoryServiceConsumer consumer = mock(CategoryServiceConsumer.class);
		GetParentCategoryResponse response = mock(GetParentCategoryResponse.class);
		
		when(response.getAck()).thenReturn(AckValue.SUCCESS);
		when(response.getCategoryPath()).thenReturn(null);
		
		when(consumer.getCategoryPath(any(GetCategoryPathRequest.class))).thenReturn(null);
		CategoryServiceClient client = new CategoryServiceClient(consumer);
		Map<Long, Long> map = new HashMap<Long, Long>();
		map.put(0l,0l);
		Map<Long, List<Integer>> pathMap = client.getCategoryFullPath(map);
		assertNotNull(pathMap.get(0l));
		assertTrue(pathMap.get(0l).size() == 0);
	}
	
	@Test
	public void getCategoryFullPathTestWithInValidCategory() {
		
		CategoryServiceConsumer consumer = mock(CategoryServiceConsumer.class);
		CategoryServiceClient client = new CategoryServiceClient(consumer);
		List<Integer> path = client.getCategoryFullPath(-1, 0);
		assertNotNull(path);
		assertTrue(path.size() == 0);
		
	}
	
	@Test
	public void getCategoryFullPathTestWithFailureResponse() {
		
		CategoryServiceConsumer consumer = mock(CategoryServiceConsumer.class);
		GetParentCategoryResponse response = mock(GetParentCategoryResponse.class);
		when(response.getAck()).thenReturn(AckValue.FAILURE);
		when(consumer.getCategoryPath(any(GetCategoryPathRequest.class))).thenReturn(response);
		CategoryServiceClient client = new CategoryServiceClient(consumer);
		List<Integer> path = client.getCategoryFullPath(0, 0);
		assertNotNull(path);
		assertTrue(path.size() == 0);
		
	}
	
	@Test
	public void getCategoryFullPathTestWithDefaultConstructor() {
		
		CategoryServiceConsumer consumer = mock(CategoryServiceConsumer.class);
		GetParentCategoryResponse response = mock(GetParentCategoryResponse.class);
		when(response.getAck()).thenReturn(AckValue.FAILURE);
		when(consumer.getCategoryPath(any(GetCategoryPathRequest.class))).thenReturn(response);
		CategoryServiceClient client = new CategoryServiceClient();
		List<Integer> path = client.getCategoryFullPath(0, 0);
		assertNotNull(path);
		assertTrue(path.size() == 0);
		
	}
}
