package com.ebay.raptor.artcon.indexer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.solr.client.solrj.SolrServerException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.integ.dal.dao.FinderException;
import com.ebay.integ.store.UserStoreLookup;
import com.ebay.integ.store.UserStoreLookupDAO;
import com.ebay.integ.usercontent.UserAuthorRank;
import com.ebay.integ.usercontent.UserAuthorRankDAO;
import com.ebay.raptor.artcon.article.model.ArticleModel;
import com.ebay.raptor.artcon.utils.CategoryHelper;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;

import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ UserAuthorRankDAO.class,  UserStoreLookupDAO.class})
public class ArticleProcessorTest {
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		PowerMockito.mockStatic(UserAuthorRankDAO.class);
		PowerMockito.mockStatic(UserStoreLookupDAO.class);
	}

	@Test
	public void testProcessingValidContent() throws FinderException, IOException, SolrServerException {
		Article article  = new Article();
		article.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		article.setArticleId("0");
		article.setDateCreated(new DateTime());
		article.setDateModified(new DateTime());
		article.setMarketplaceId("0");
		article.setModerationStatus(ModerationStatusEnum.NOT_MODERATED); 
		article.setTemplateType("HOW_TO");
		
		List<String> acl = new ArrayList<String>();
		acl.add("0");
		acl.add("1");
		article.setAccessControlList(acl);
		 
		UserIdentifier author = new UserIdentifier();
		author.setUsername("subbutest");
		article.setAuthor(author);
		
		UserGeneratedContent ugc = new UserGeneratedContent();
		Image img = new Image();
		img.setImageURL("https://upload.wikimedia.org/wikipedia/commons/f/f7/English_Pok%C3%A9mon_logo.svg");
		ugc.setCoverImage(img);
		
		Text title = new Text();
		title.setContent("Title");
		ugc.setTitle(title);
		
		List<Group> groups = new ArrayList<Group>();
		
		Group group = new Group();
		group.setGroupId(String.valueOf(0l));
		group.setTitle(title);
		List<Section> listSections = new ArrayList<Section>();
		Section section = new Section();
		StandardComponent sComponent1 = new StandardComponent();
		sComponent1.setComponentType("BLOCK_QUOTE");
		sComponent1.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");
		
		StandardComponent sComponent2 = new StandardComponent();
		sComponent2.setComponentType("HEADING");
		sComponent2.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");		
		
		StandardComponent sComponent3 = new StandardComponent();
		sComponent3.setComponentType("PARAGRAPH");
		sComponent3.setData("Speaking from my own experience; What peeves me and I am sure a lot of buyers out there is when a seller lists on item with no or little information and/or images. Let us take a laptop for example. The description reads In excellent condition, a must buy!. There is no info and maybe 1 image. I click on to the next product. Also some sellers advertise without specifying the most important information. They do this not on purpose but because they know their product so well they tend to forget that we do not. Is this laptop 1st, 2nd, 3rd or 4th generation? USB 2.0 or 3.0? ");

		List<Component> listComponent = new ArrayList<Component>();
		listComponent.add(sComponent1);
		listComponent.add(sComponent2);
		listComponent.add(sComponent3);
		
		section.setComponents(listComponent);
		
		listSections.add(section);
		group.setSections(listSections);		
		groups.add(group);		
		groups.add(group);
		ugc.setGroups(groups);
		article.setUserGeneratedContent(ugc);
		
		UserAuthorRank rank = mock(UserAuthorRank.class);
		when(rank.getRank()).thenReturn(10l);
		UserAuthorRankDAO userRankDao = mock(UserAuthorRankDAO.class);
		when(userRankDao.findByPK(any(Long.class), any(Integer.class), any(Integer.class))).thenReturn(rank);
        PowerMockito.when(UserAuthorRankDAO.getInstance()).thenReturn(userRankDao);
        
        UserStoreLookup store = mock(UserStoreLookup.class);
		when(store.getName()).thenReturn("testname");
		when(store.getStoreUrl()).thenReturn("testurl");
		UserStoreLookupDAO storeDao = mock(UserStoreLookupDAO.class);
		when(storeDao.findByUserID(any(Long.class))).thenReturn(store);
        PowerMockito.when(UserStoreLookupDAO.getInstance()).thenReturn(storeDao);
        
        List<Long> cats = new ArrayList<Long>();
        cats.add(0l);
        CategoryHelper catHelper = mock(CategoryHelper.class);
        when(catHelper.findMltCategories(any(String.class))).thenReturn(cats);
		ArticleProcessor processor = new ArticleProcessor();
		ArticleProcessor.siteToLabel.put(0, 0);
		ArticleProcessor.categoryHelper = catHelper;
		ArticleModel model = processor.process(article);
		
		assertTrue(model.getAccessControlList().equals(article.getAccessControlList()));
		assertTrue(model.getAllCats() != null);
		assertTrue(model.getArticleAuthor().getId().equals(1304319609l));
		assertTrue(model.getArticleId().equals(article.getArticleId()));
		assertTrue(model.getArticleStatus().name().equals(article.getArticleStatus().name()));
		assertTrue(model.getUserGeneratedContent().equals(article.getUserGeneratedContent()));
	}
	
}
