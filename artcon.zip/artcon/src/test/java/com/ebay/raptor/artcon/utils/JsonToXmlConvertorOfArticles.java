package com.ebay.raptor.artcon.utils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

import org.codehaus.jackson.map.ObjectMapper;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMSource; 
import javax.xml.transform.stream.StreamResult;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.Video;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadAllResponse;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.google.gson.Gson;

public class JsonToXmlConvertorOfArticles{

	 ObjectMapper mapper = new ObjectMapper();
	
	 String  filePath=".//src//test//java//com//ebay//raptor//artcon//utils//Articles.json";

	 	
	 	static String articleFile=".//src//test//java//com//ebay//raptor//artcon//utils//articlefiles/bulk";
	 	static int fileCount=1;

	public static void main(String[] args){
		JsonToXmlConvertorOfArticles JsonToXmlConvertorOfArticles = new JsonToXmlConvertorOfArticles();
		ArticleReadAllResponse resp = JsonToXmlConvertorOfArticles.jsonToArticleResponse();	
		
		int count=0;
		for(Article article:resp.getArticles()){
			try {
				JsonToXmlConvertorOfArticles.createXMLFile(article);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//if(count++>10)break;
		}
	}
		
//	 ArticleReadAllResponse gsonConverter(){
//		File f = new File(filePath);
//		Reader reader;
//		ArticleReadAllResponse articleReadAllResponse= null;
//		try {
//			reader = new InputStreamReader(new FileInputStream(f));	
//			Gson gson = new Gson();
//			articleReadAllResponse= gson.fromJson(reader, ArticleReadAllResponse.class);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return articleReadAllResponse;
//
//	}		
	 ArticleReadAllResponse jsonToArticleResponse(){
		File f = new File(filePath);
		ArticleReadAllResponse articleReadAllResponse=null;
		try {
			 articleReadAllResponse = mapper.readValue(f, ArticleReadAllResponse.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return articleReadAllResponse;
		
	}	
	
	// creates article for in xml format .
		
	
	private  Document initiateDocument() {		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder;
		Document  doc =null;
		
  				try {
					docBuilder = docFactory.newDocumentBuilder();				
				    doc= docBuilder.newDocument();
  				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		
		
		return doc;
	}
	

	private void addComponent(Document doc ,Section section , Element sectionElement ){
		
       if(section.getComponents()==null) return;		
		for(Component comp:section.getComponents()){
			Element compElement  = doc.createElement("Component");
			Element componentTypeElement  = doc.createElement("ComponentType");
			compElement.appendChild(componentTypeElement);
			if(comp instanceof StandardComponent){
				componentTypeElement.setTextContent("PARAGRAPH");
				Element markdownElement  = doc.createElement("markdown");
				markdownElement.setTextContent(((StandardComponent) comp).getData());
				componentTypeElement.appendChild(markdownElement);

			}else if (comp instanceof MediaComponent) {
				Element captionElement  = doc.createElement("caption");
				captionElement.setTextContent(comp.getCaption());
				compElement.appendChild(captionElement);
				if (((MediaComponent) comp).getMedia() != null) {
					if(((MediaComponent) comp).getMedia() instanceof Image){						
						componentTypeElement.setTextContent("IMAGE");
						Element imageUrlElement =doc.createElement("imageUrl");
						compElement.appendChild(imageUrlElement);
						imageUrlElement.setTextContent((((Image)((MediaComponent) comp).getMedia()).getImageURL()));
					}else if(((MediaComponent) comp).getMedia() instanceof Video){
						Element videoUrlElement =doc.createElement("videoUrl");
						componentTypeElement.setTextContent("VIDEO");
						videoUrlElement.setTextContent(((Video)((MediaComponent) comp).getMedia()).getVideoURL());
						compElement.appendChild(videoUrlElement);
					}
				}
			}

			sectionElement.appendChild(compElement);
		}
		
	}
	
	private void addSection(Document doc ,Group group , Element groupElement){
		if(group.getSections()==null) return;
		for(Section section :group.getSections()){
			Element sectionElement  = doc.createElement("Section");
			groupElement.appendChild(sectionElement);
			Element sectionAlignmentElement  = doc.createElement("alignment");
			sectionAlignmentElement.setTextContent(section.getAlignment());
			sectionElement.appendChild(sectionAlignmentElement);
			groupElement.appendChild(sectionElement);
			addComponent(doc,section,sectionElement);
			
		}
	}
	
	private void addGroup(Document doc,Article article,Element rootElement){
		for(Group group : article.getUserGeneratedContent().getGroups()){		
			Element groupElement=doc.createElement("Group");
			Element groupType = doc.createElement("groupType");
			groupType.setTextContent(group.getGroupType());
			Element groupTitle = doc.createElement("groupTitle");
			if(group.getTitle()!=null)
			groupTitle.setTextContent(group.getTitle().getContent());		
			groupElement.appendChild(groupType);
			groupElement.appendChild(groupTitle);			
			rootElement.appendChild(groupElement);
			addSection(doc,group,groupElement);
		}
		
	}
	

	
	
	private void createXMLFile(Article article) throws FileNotFoundException{

		try {
			Document doc =initiateDocument();
		Element rootElement = doc.createElement("article");
		rootElement.setAttribute("id",article.getArticleId());
		
		Element elementTitle=doc.createElement("title");
		if(article.getUserGeneratedContent().getTitle()!=null)
		elementTitle.setTextContent(article.getUserGeneratedContent().getTitle().getContent());;
		rootElement.appendChild(elementTitle);
		
		Element elementsynopsis=doc.createElement("synopsis");
		if(article.getUserGeneratedContent().getSynopsis()!=null)
		elementsynopsis.setTextContent(article.getUserGeneratedContent().getSynopsis().getContent());;
		rootElement.appendChild(elementsynopsis);
				
		Element elementcoverImage=doc.createElement("coverImage");
		if(article.getUserGeneratedContent().getCoverImage()!=null)
		elementcoverImage.setTextContent(article.getUserGeneratedContent().getCoverImage().getImageURL());;	
		rootElement.appendChild(elementcoverImage);
		
		addGroup(doc,article,rootElement);
		
		doc.appendChild(rootElement);
		
		   TransformerFactory tFactory =
				    TransformerFactory.newInstance();
				    Transformer transformer;
						transformer = tFactory.newTransformer();
				    DOMSource source = new DOMSource(doc);
				    FileOutputStream fis = new FileOutputStream(new File(articleFile+fileCount+++".xml"));
				    StreamResult result = new StreamResult(fis);
					transformer.transform(source, result);

		}catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}