package com.ebay.raptor.cmseditor.task;

import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.serviceclient.FountainAdminServiceClient;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.util.UserInfoUtil;

public class GetUserPermissionsTask extends CmsEditorTask{

	public GetUserPermissionsTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		
		if(request.getUserId()==null || request.getUserId()==UserInfoUtil.INVALID_USER_ID){
			return new GetUserPermissionsTaskResponse();
		}
		long userId = request.getUserId();
		
		FountainAdminServiceClient fountainAdminClient = new FountainAdminServiceClient();
		GetUserPermissionsTaskResponse clientResponse = fountainAdminClient.getPermissionsForUser(String.valueOf(userId));
		return clientResponse;
	}

}
