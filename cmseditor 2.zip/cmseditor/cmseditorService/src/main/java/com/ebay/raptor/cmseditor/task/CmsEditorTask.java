package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.orchestration.Callable;

public abstract class CmsEditorTask implements ICmsEditorTask{

	protected CmsEditorRequest request;
	protected List<ICmsEditorTask> providerTasks = new ArrayList<>();
	private CmsEditorTaskResponse taskResponse;
	
	public CmsEditorTask(CmsEditorRequest request,List<ICmsEditorTask> providerTasks){
		this.request = request;
		if(!CollectionUtils.isEmpty(providerTasks)){
			this.providerTasks.addAll(providerTasks);
		}
	}
	

	@Callable
	public  final CmsEditorTaskResponse performTask(){
		CmsEditorTaskResponse response = createResponse();
		this.taskResponse = response;
		return response;
	}
	
	protected abstract CmsEditorTaskResponse createResponse();


	public CmsEditorRequest getRequestContext() {
		return request;
	}


	public void setRequestContext(CmsEditorRequest request) {
		this.request = request;
	}



	public CmsEditorTaskResponse getTaskResponse() {
		return taskResponse;
	}


	public List<ICmsEditorTask> getProviderTasks() {
		return providerTasks;
	}
	
	protected CmsEditorTaskResponse createSuccessResponse(){
		CmsEditorTaskResponse response = new CmsEditorTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}
	
	protected CmsEditorTaskResponse createFailureResponse(){
		CmsEditorTaskResponse response = new CmsEditorTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}

	protected List<CmsEditorTaskResponse> getTaskResponses(){
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<>();
		for(ICmsEditorTask providerTask:providerTasks){
			if(providerTask!=null){
				taskResponses.add(providerTask.getTaskResponse());
			}
		}
		return taskResponses;
	}

}
