package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.bson.types.ObjectId;

import com.ebay.raptor.besevents.ArticlePublishEvent;
import com.ebay.raptor.cmseditor.config.ConfigParam;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentPublishRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.PublishContentTaskResponse;
import com.ebay.raptor.cmseditor.util.BESUtil;
import com.ebay.raptor.cmseditor.util.CALUtil;
import com.ebay.spam.akismet.AkismetComment;

public class PublishContentTask extends CmsEditorTask{

	
	public PublishContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		try {
			ContentDraftDao contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
			ContentPublishDao contentPublishDao = request.getApplicationContext().getBean(ContentPublishDao.class);
			ContentPublishRequest publishRequest = (ContentPublishRequest)request.getContentPublishRequest();
			String draftId = publishRequest.getDraftContentId();
			
			//1.) Retrieving the draft content
			DraftContentEntity draftContent=null;
			try{
				draftContent = contentDraftDao.findContentById(draftId);
			}catch(IllegalArgumentException i){
				PublishContentTaskResponse response = new PublishContentTaskResponse();
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.INVALID_CONTENT_ID);
				return response;
			}
			if(draftContent == null) {
				PublishContentTaskResponse response = new PublishContentTaskResponse();
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
				return response;
			}
			
			//2.) Check if user has rights to publish
			boolean hasUpdatePermissions = hasPermissions(draftContent,
					publishRequest);
			
			//3.) If the user has permissions publish the content
	//		if(hasUpdatePermissions) {
				return publishContent(contentDraftDao, contentPublishDao, draftContent,publishRequest.getAkismetComment());
				
//			} else {
//				PublishContentTaskResponse response = new PublishContentTaskResponse();
//				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
//				response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
//				return response;
//			}
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.PUBLISH_CONTENT_TASK_EXCEPTION, "createResponse", ExceptionUtils.getFullStackTrace(e));
			return createFailureResponse();
		}
	}

	private CmsEditorTaskResponse publishContent(
			ContentDraftDao contentDraftDao,
			ContentPublishDao contentPublishDao, DraftContentEntity draftContent,AkismetComment akismetComment)
			throws Exception {
		PublishedContentEntity publishedContent = getContentToPublish(draftContent, contentPublishDao);
		
		//Deleting old version
		softDeletePublished(contentPublishDao, publishedContent.getContentId().toString());
		
		//Create new version
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		publishedContent.setContentStatus(ArticleStatusEnum.PENDING_SPAM_DETECTION.name());
		entities.add(publishedContent);
		PublishContentTaskResponse response = new PublishContentTaskResponse();
		List<String> contentIds = contentPublishDao.createContent(entities);
		if(CollectionUtils.isEmpty(contentIds)){
			response.setError(CmsEditorStatus.SAVE_ERROR);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}else{
			softDeleteDraft(contentDraftDao, draftContent.getContentId().toString());
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setContentId(publishedContent.getContentId().toString());
			if(ConfigParam.BES_EVENT_FOR_PUBLISH.getBooleanValue()==true){
				if(isPremiumAuthor()){
					publishedContent.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
					contentPublishDao.save(publishedContent);
					BESUtil.dropArticlePublishEvent(buildPublishEvent(response.getContentId(), akismetComment));
				}else{
					BESUtil.dropArticlePublishEvent(buildPublishEvent(response.getContentId(), akismetComment));
				}
			}else{
				publishedContent.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
				contentPublishDao.save(publishedContent);
			}
			return response;
		}
	}

	private void softDeleteDraft(ContentDraftDao contentDraftDao, String contentId) {
		List<KeyValue> kvs = getSoftDeleteKVPair();
		contentDraftDao.updateContentField(contentId, kvs);
	}
	
	private void softDeletePublished(ContentPublishDao contentPublishDao, String contentId) {
		List<KeyValue> kvs = getSoftDeleteKVPair();
		contentPublishDao.updateContentField(contentId, kvs);
	}

	private List<KeyValue> getSoftDeleteKVPair() {
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.toString());
		kv.setValue(true);
		List<KeyValue> kvs = new ArrayList<KeyValue>();
		kvs.add(kv);
		return kvs;
	}
	
	private boolean hasPermissions(DraftContentEntity draftContent,
			ContentPublishRequest publishRequest) {
		boolean hasUpdatePermissions = false;
		for(ICmsEditorTask task: providerTasks) {
			if(task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
				Set<String> permissions = permissionsResponse.getPermissions();
				if(permissions != null && permissions.contains(PermissionEnum.PUBLISH_OTHER_CONTENT.name())) {
					hasUpdatePermissions = true;
				}
				break;
			}
		}
		
		//2.) If user does not have admin rights check if its his own content
		if(!hasUpdatePermissions) {
			List<String> accessControlList = draftContent.getAccessControlList();
			if(accessControlList != null) {
				hasUpdatePermissions = accessControlList.contains(String.valueOf(request.getUserId()));
			}
		}
		return hasUpdatePermissions;
	}

	private PublishedContentEntity getContentToPublish(DraftContentEntity draftContent, ContentPublishDao contentPublishDao) throws Exception {
		String contentId = draftContent.getContentId().toString();
		PublishedContentEntity publishedContent = new PublishedContentEntity();
		publishedContent.setContentId(new ObjectId(contentId));
		publishedContent.setDateCreated(new Date());
		PublishedContentEntity existingPublishedContent = contentPublishDao.findContentByContentId(contentId);
		if(existingPublishedContent == null) {
			publishedContent.setVersion(0);
		} else {
			int currentVersion = existingPublishedContent.getVersion();
			publishedContent.setVersion(currentVersion + 1);
		}
		publishedContent.setAccessControlList(draftContent.getAccessControlList());
		publishedContent.setAuthorId(draftContent.getAuthorId());
		publishedContent.setAuthorName(draftContent.getAuthorName());
		publishedContent.setPublicAuthorId(draftContent.getPublicAuthorId());
		publishedContent.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		publishedContent.setLastModifiedUser(draftContent.getLastModifiedUser());
		publishedContent.setMarkedAsProcessing(draftContent.getMarkedAsProcessing());
		publishedContent.setModerationStatus(ModerationStatusEnum.NOT_MODERATED.name());
		publishedContent.setScheduledEndDate(draftContent.getScheduledEndDate());
		publishedContent.setScheduledStartDate(draftContent.getScheduledStartDate());
		publishedContent.setVisibilityLevel(draftContent.getVisibilityLevel());
		publishedContent.setUserGeneratedContent(draftContent.getUserGeneratedContent());
		publishedContent.setDateCreated(draftContent.getDateCreated());
		publishedContent.setDateModified(new Date());
		publishedContent.setTemplateType(draftContent.getTemplateType());
		publishedContent.setMarketPlaceId(draftContent.getMarketPlaceId());
		return publishedContent;
	}
	
	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		PublishContentTaskResponse response = new PublishContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
	
	private ArticlePublishEvent buildPublishEvent(String contentId,AkismetComment akismetComment){
		
		ArticlePublishEvent event = new ArticlePublishEvent();
		event.setArticleId(contentId);
		event.setCommentAuthor(akismetComment.getCommentAuthor());
		event.setCommentType(akismetComment.getCommentType());
		event.setReferrer(akismetComment.getReferrer());
		event.setUserAgent(akismetComment.getUserAgent());
		event.setUserIp(akismetComment.getUserIp());
		
		return event;
	}
	
	private boolean isPremiumAuthor(){
		for(ICmsEditorTask task: providerTasks) {
			if(task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
				Set<String> permissions = permissionsResponse.getPermissions();
				if(!CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.SCHEDULE_CONTENT.name())){
					return true;
				}
			}
		}
		return false;
	}
}