package com.ebay.raptor.cmseditor.task.response;

public class BlacklistContentTaskResponse extends CmsEditorTaskResponse {

}
