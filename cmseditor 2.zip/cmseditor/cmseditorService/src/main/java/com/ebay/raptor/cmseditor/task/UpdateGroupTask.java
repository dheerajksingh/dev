package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.UpdateGroupRequest;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.response.adaptor.ContentModelAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateGroupTaskResponse;

public class UpdateGroupTask extends CmsEditorTask{
	
	@Inject ContentDraftDao contentDraftDao;
	private static final String EDIT_OTHER_CONTENT="EDIT_OTHER_CONTENT";
	private static final Logger LOGGER = Logger.getInstance(UpdateGroupTask.class);
	private ContentEntityAdaptor contentEntityAdaptor;
	private ContentModelAdaptor contentModelAdaptor;

	public UpdateGroupTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
		contentEntityAdaptor = new ContentEntityAdaptor();
		contentModelAdaptor = new ContentModelAdaptor();
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		List<CmsEditorTaskResponse> taskResponses = getTaskResponses();
		if(CollectionUtils.isEmpty(taskResponses)){
			return createFailureResponse();
		}
		UpdateGroupRequest req = request.getUpdateGroupRequest();
		if(req==null){
			return createFailureResponse();
		}
		boolean isAdmin=false;
		boolean hasAccess=false;
		UpdateGroupTaskResponse response = new UpdateGroupTaskResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses){
			if(taskResponse instanceof GetUserPermissionsTaskResponse){
				Set<String> permissions = ((GetUserPermissionsTaskResponse) taskResponse).getPermissions();
				if(!CollectionUtils.isEmpty(permissions) && permissions.contains(EDIT_OTHER_CONTENT)){
					isAdmin=true;
				}
			} else if(taskResponse instanceof GetAccessControlListTaskResponse) {
				Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) taskResponse)
						.getContentEntityMap();
				if(contentEntityMap != null && contentEntityMap.get(req.getArticleId()) != null) {
					hasAccess = contentEntityMap.get(req.getArticleId())
							.getAccessControlList()
							.contains(String.valueOf(request.getUserId()));
				}		
				
			}
		}
		if(!isAdmin && !hasAccess){
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
			return response;
		}
		
		try{
			//Update the content group in the database.
			GroupEntity group = updateContentGroup(req);
			Group groupModel = contentModelAdaptor.adaptToGroupModel(group);
			response.setGroup(groupModel); 
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

	private GroupEntity updateContentGroup(UpdateGroupRequest req) throws Exception {
		
		//Retrive the draft content from the database
		DraftContentEntity draftContent = contentDraftDao.findContentById(req.getArticleId());
		if(draftContent == null) {
			throw new Exception(CmsEditorStatus.CONTENT_NOT_FOUND.getMessage());
		}
		
		//Find maxGroupId from the list of groups of content
		GroupEntity groupToBeUpdated = null;
		long maxGroupId = 0l;
		String groupId = req.getGroupId();
		if(!CollectionUtils.isEmpty(draftContent.getUserGeneratedContent().getGroups())) {
			for(GroupEntity group:draftContent.getUserGeneratedContent().getGroups()) {
				maxGroupId = Math.max(maxGroupId, Long.parseLong(group.getGroupId()));
				if(groupId != null && groupId.equals(group.getGroupId())) {
					groupToBeUpdated = group;
				}
			}
		}
		
		//If this is a new group then set appropriate groupId and add it to the groups list of content.
		if(groupToBeUpdated == null) {
			groupToBeUpdated = new GroupEntity();
			groupToBeUpdated.setGroupId(String.valueOf(maxGroupId + 1));
			List<GroupEntity> groups = draftContent.getUserGeneratedContent().getGroups();
			if(groups == null) {
				groups = new ArrayList<GroupEntity>();
				draftContent.getUserGeneratedContent().setGroups(groups);
			}
			groups.add(groupToBeUpdated);
		}
		
		//Set title & GroupType for group from the request.
		groupToBeUpdated.setGroupType(req.getGroupType());
		groupToBeUpdated.setTitle(req.getTitle());
		
		//Compute moduleIds for new modules and set moduleMap for Group.
		long maxModuleId = 0l;
		int sortOrder = 0;
		Map<String, ModuleEntity> modulesMap = new HashMap<String, ModuleEntity>();
		List<Section> modules = req.getSections();
		List<Section> newModules = new ArrayList<Section>();
		for(Section module:modules) {
			module.setSequence(sortOrder++);
			if(module.getSectionId() != null) {
				maxModuleId = Math.max(maxModuleId, Long.parseLong(module.getSectionId()));
				modulesMap.put(module.getSectionId(), contentEntityAdaptor.adaptToModuleEntity(module));
			} else {
				newModules.add(module);
			}
		}
		for(Section newModule:newModules) {
			maxModuleId++;
			newModule.setSectionId(String.valueOf(maxModuleId));
			modulesMap.put(newModule.getSectionId(), contentEntityAdaptor.adaptToModuleEntity(newModule));
		}
		groupToBeUpdated.setModuleMap(modulesMap);
		
		//Save the draft content to the database
		draftContent.setDateModified(new Date());
		contentDraftDao.save(draftContent);
		
		return groupToBeUpdated;
	}
}