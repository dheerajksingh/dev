package com.ebay.raptor.cmseditor.task.response;

import java.util.Set;

public class GetUserPermissionsTaskResponse extends CmsEditorTaskResponse {
	
	private Set<String> permissions;

	public Set<String> getPermissions() {
		return permissions;
	}

	public void setPermissions(Set<String> permissions) {
		this.permissions = permissions;
	}

}
