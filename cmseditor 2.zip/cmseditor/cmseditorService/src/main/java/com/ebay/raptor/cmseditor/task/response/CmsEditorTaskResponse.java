package com.ebay.raptor.cmseditor.task.response;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;

public class CmsEditorTaskResponse implements Cloneable{
	
	private CmsEditorTaskStatus taskStatus;
	private CmsEditorStatus error;
	
	

	public CmsEditorStatus getError() {
		return error;
	}

	public void setError(CmsEditorStatus error) {
		this.error = error;
	}

	public CmsEditorTaskStatus getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(CmsEditorTaskStatus taskStatus) {
		this.taskStatus = taskStatus;
	}

	@Override
	protected CmsEditorTaskResponse clone() throws CloneNotSupportedException {
		return (CmsEditorTaskResponse)super.clone();
	}
	

}
