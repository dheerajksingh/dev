package com.ebay.raptor.cmseditor.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.ebay.raptor.cmseditor.config.ConfigParam;
import com.ebay.raptor.kernel.context.RaptorContextFactory;
import com.ebay.raptor.kernel.util.RaptorConstants;
import com.google.common.base.Splitter;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public  class UserInfoUtil {
	
	public static final long INVALID_USER_ID = -1;
	private static final String CLIENT_ID="clientId";
	

    public  long getSignedInUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String userId = (String) auth.getPrincipal();
        if (!StringUtils.isBlank(userId)) {
            return Long.valueOf(userId);
        }
        
        return INVALID_USER_ID;
    }
    
    @SuppressWarnings("unchecked")
	public  boolean isAuthorizedApplication() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(auth!=null && auth.getDetails()!=null){
        	ConcurrentHashMap<String, Object> details=(ConcurrentHashMap<String, Object>) auth.getDetails();
        	if(details.get(CLIENT_ID)!=null){
        	String consumerId=(String) details.get(CLIENT_ID);
        	String consumers = ConfigParam.BES_CONSUMER.getStringValue();
        	if(StringUtils.isEmpty(consumers)){
        		return false;
        	}
        	Iterable<String> consumerList =Splitter.on(",").split(consumers);
        	for(String consumer:consumerList){
        		if(consumerId.equalsIgnoreCase(consumer)){
        			return true;
        		}
        	}
        	}
        }
        return false;
    }
    
    @SuppressWarnings("unchecked")
	public static String getMarketPlaceId() {
    	Map<String, Object> outboundContext = 
    			(Map<String, Object>) RaptorContextFactory.getCtx().getSysInfo().get(
				RaptorConstants.SYSINFO_OUTBOUND_CONTEXT);
		return (String)outboundContext.get(
						RaptorConstants.SYS_CONTEXT_HEADER_MARKETPLACE_ID);
    }
	
}