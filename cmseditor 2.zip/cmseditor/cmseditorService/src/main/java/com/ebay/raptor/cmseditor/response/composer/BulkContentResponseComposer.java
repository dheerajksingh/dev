package com.ebay.raptor.cmseditor.response.composer;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response.Status;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.error.ErrorBuilder;
import com.ebay.raptor.cmseditor.response.BulkArticleResponse;
import com.ebay.raptor.cmseditor.response.BulkPayload;
import com.ebay.raptor.cmseditor.response.BulkResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.task.response.BulkContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;

public class BulkContentResponseComposer implements IResponseComposer{

	private List<CmsEditorTaskResponse> taskResponses;
	
	private static final int MULTI_STATUS_CODE=207;
		
		public BulkContentResponseComposer(List<CmsEditorTaskResponse> taskResponses) {
			this.taskResponses = taskResponses;
		}
		
		@Override
		public CmsEditorResponse compose() throws CmsEditorException{
			BulkArticleResponse response = new BulkArticleResponse();
			if(CollectionUtils.isEmpty(taskResponses)){
				throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR);
			}
			for(CmsEditorTaskResponse taskResponse:taskResponses) {
				if(taskResponse instanceof BulkContentTaskResponse) {
					if(taskResponse.getTaskStatus()!=null && taskResponse.getTaskStatus().equals(CmsEditorTaskStatus.SUCCESS)) {
						return createBulkResponses(((BulkContentTaskResponse) taskResponse).getResponses());
					}
					else{
						throw new CmsEditorException(taskResponse.getError());
					}
				}
			}
			return response;
		}

		private BulkArticleResponse createBulkResponses(List<BulkAdaptorResponse> adaptorResponses){
			BulkArticleResponse contentResponse = new BulkArticleResponse();
			if(CollectionUtils.isEmpty(adaptorResponses)){
				return contentResponse;
			}
			List<BulkResponse> bulkResponses = new ArrayList<BulkResponse>();
			boolean isPartialSuccess=false;
			boolean isBulkDelete=false;
			ErrorBuilder builder = new ErrorBuilder();
			for(BulkAdaptorResponse adaptorResponse:adaptorResponses){
				BulkResponse response = new BulkResponse();
				BulkPayload payload = new BulkPayload();
				payload.setAuthor(adaptorResponse.getAuthor());
				payload.setContentId(adaptorResponse.getContentId());
				payload.setTitle(adaptorResponse.getTitle());
				response.setPayload(payload);
				if(adaptorResponse.getStatus()!=CmsEditorStatus.BULK_CREATE_SUCCESS && adaptorResponse.getStatus()!=CmsEditorStatus.BULK_DELETE_SUCCESS){
					isPartialSuccess=true;
					response.setHttpStatus(adaptorResponse.getStatus().getStatus());
					response.setError(builder.getError(adaptorResponse.getStatus()));
				}else{
					response.setHttpStatus(adaptorResponse.getStatus().getStatus());
					if(adaptorResponse.getStatus()==CmsEditorStatus.BULK_DELETE_SUCCESS){
						isBulkDelete=true;
					}
					//response.setError(builder.getError(adaptorResponse.getStatus()));
				}
				bulkResponses.add(response);
			}
			contentResponse.setStatus(CmsEditorResponseStatus.SUCCESS);
			if(isPartialSuccess){
				contentResponse.setStatusCode(MULTI_STATUS_CODE);
			}else{
				if(isBulkDelete){
					contentResponse.setStatusCode(Status.OK.getStatusCode());
				}else{
					contentResponse.setStatusCode(Status.CREATED.getStatusCode());
				}
			}
			contentResponse.setPayload(bulkResponses);
			return contentResponse;
		}
}
