package com.ebay.raptor.cmseditor.task;

import java.util.List;

import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.orchestration.Callable;

public interface ICmsEditorTask {

	@Callable
	public  CmsEditorTaskResponse performTask();
	
	public List<ICmsEditorTask> getProviderTasks();
	
	public CmsEditorTaskResponse getTaskResponse();
}
