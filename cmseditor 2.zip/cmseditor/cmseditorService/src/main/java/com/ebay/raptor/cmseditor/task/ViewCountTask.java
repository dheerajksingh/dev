package com.ebay.raptor.cmseditor.task;

import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;

public class ViewCountTask extends CmsEditorTask{

	public ViewCountTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		return null;
	}

}
