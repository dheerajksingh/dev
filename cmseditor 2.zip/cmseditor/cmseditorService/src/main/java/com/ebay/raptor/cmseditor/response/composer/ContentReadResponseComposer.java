package com.ebay.raptor.cmseditor.response.composer;

import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.adaptor.ContentModelAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadResponse;
import com.ebay.raptor.cmseditor.response.content.model.AuthorType;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class ContentReadResponseComposer implements IResponseComposer{
private List<CmsEditorTaskResponse> taskResponses;
private ContentModelAdaptor adaptor;
	
	public ContentReadResponseComposer(List<CmsEditorTaskResponse> taskResponses) {
		this.taskResponses = taskResponses;
		adaptor = new ContentModelAdaptor();
	}
	
	@Override
	public CmsEditorResponse compose() throws CmsEditorException{
		ArticleReadResponse response = new ArticleReadResponse();
		if(CollectionUtils.isEmpty(taskResponses)){
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
		for(CmsEditorTaskResponse taskResponse:taskResponses) {
			if(taskResponse instanceof ContentReadTaskResponse) {
				if(taskResponse.getTaskStatus()!=null && taskResponse.getTaskStatus().equals(CmsEditorTaskStatus.SUCCESS)) {
					ContentReadTaskResponse contentReadTaskResponse = (ContentReadTaskResponse) taskResponse;
					response.setArticle(adaptor.adaptToContentModel(contentReadTaskResponse.getContent()));
					response.getArticle().setViewCount(contentReadTaskResponse.getViewCount());
					response.status=CmsEditorResponseStatus.SUCCESS;
				} else {
					throw new CmsEditorException(taskResponse.getError());
				}
				break;
			}
		}
		
		for(CmsEditorTaskResponse taskResponse:taskResponses){
			if(taskResponse instanceof GetUserPermissionsTaskResponse){
				Article article = response.getArticle();
				article.setAuthorType(getAuthorType(((GetUserPermissionsTaskResponse) taskResponse).getPermissions()));
				response.setArticle(article);
			}
		}
		return response;
	}

	public void setAdaptor(ContentModelAdaptor adaptor) {
		this.adaptor = adaptor;
	}

	private AuthorType getAuthorType(Set<String> permissions){
		if(CollectionUtils.isEmpty(permissions)){
			return AuthorType.AUTHOR;
		}
		if(permissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name())){
			return AuthorType.ADMINISTRATOR;
		}
		if(permissions.contains(PermissionEnum.SCHEDULE_CONTENT.name())){
			return AuthorType.PREMIUM_AUTHOR;
		}
		if(permissions.contains(PermissionEnum.BLACKLIST_CONTENT.name())){
			return AuthorType.MODERATOR;
		}
		return AuthorType.AUTHOR;
	}
	
}
