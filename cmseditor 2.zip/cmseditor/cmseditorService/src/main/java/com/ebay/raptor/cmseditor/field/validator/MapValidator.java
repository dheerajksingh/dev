package com.ebay.raptor.cmseditor.field.validator;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

public class MapValidator implements IFieldValidator{

	@SuppressWarnings("unchecked")
	@Override
	public void validate(KeyValueImpl keyValue) throws CmsEditorException {
		
		if(StringUtils.isEmpty(keyValue.getKey())){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		
		if(!AllowedFields.getAllowedFields().contains(keyValue.getKey())){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		
		try{
		LinkedHashMap<Object, Object> value = (LinkedHashMap<Object, Object>) keyValue.getValue();
		Map<String, String> map = new HashMap<String, String>();
		for(Map.Entry<Object, Object> inputMap:value.entrySet()){
			String valueString="";
			if(inputMap.getValue()!=null && !StringUtils.isEmpty((String)inputMap.getValue())){
				valueString=(String)inputMap.getValue();
			}
			map.put((String)inputMap.getKey(), valueString);
		}
		keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
		keyValue.setValue(map);
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
	}
	

}
