package com.ebay.raptor.cmseditor.task.response;

import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;

public class ContentReadTaskResponse extends CmsEditorTaskResponse{
	
	
	private ContentEntity content;
	private long viewCount;

	public ContentEntity getContent() {
		return content;
	}

	public void setContent(ContentEntity content) {
		this.content = content;
	}

	public long getViewCount() {
		return viewCount;
	}

	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}
	
}
