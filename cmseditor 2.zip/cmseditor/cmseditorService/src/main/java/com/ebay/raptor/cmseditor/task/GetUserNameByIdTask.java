package com.ebay.raptor.cmseditor.task;

import java.util.List;

import javax.ws.rs.core.Response.Status;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserNameByIdTaskResponse;
import com.ebay.raptor.cmseditor.util.UserInfoUtil;
import com.ebay.userlookup.UserLookup;
import com.ebay.userlookup.common.ClientException;

public class GetUserNameByIdTask extends CmsEditorTask{
	
	private UserLookup userLookup;
	
	private static final Logger LOGGER = Logger.getInstance(GetUserNameByIdTask.class);

	public GetUserNameByIdTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		this.userLookup=new UserLookup();
	}
	
	public GetUserNameByIdTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,UserLookup userLookup) {
		super(request, providerTasks);
		this.userLookup=userLookup;
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		Long userId= request.getUserId();
		if(userId==null || userId==UserInfoUtil.INVALID_USER_ID){
			return new GetUserNameByIdTaskResponse();
		}
		GetUserNameByIdTaskResponse response = new GetUserNameByIdTaskResponse();
		try{
		String userName = getUserName(userId);
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		response.setUserName(userName);
		return response;
		}catch(CmsEditorException c){
			response.setError(c.getError());
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
	}
	
	private String getUserName(long internalId) throws CmsEditorException{
		try {
			String userName= userLookup.getUsernameByInternalId(internalId);	
			return userName;
		} catch (ClientException e) {
			LOGGER.log(LogLevel.ERROR,e);
			if(e.getStatusCode()==Status.NOT_FOUND.getStatusCode()){
				throw new CmsEditorException(CmsEditorStatus.USER_DOES_NOT_EXIST, e);
			}
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR, e);
		}
	}
	
}
