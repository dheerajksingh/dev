package com.ebay.raptor.cmseditor.task.factory;

import java.util.ArrayList;
import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.GetForEditTask;
import com.ebay.raptor.cmseditor.task.GetUserPermissionsTask;
import com.ebay.raptor.cmseditor.task.ICmsEditorTask;

public class GetForEditTaskFactory implements ICmsEditorTaskFactory{
	
	private List<ICmsEditorTask> tasks = new ArrayList<>();

	public GetForEditTaskFactory(CmsEditorRequest request) {
		
		GetUserPermissionsTask permissionsTask = new GetUserPermissionsTask(request, new ArrayList<ICmsEditorTask>());

		tasks.add(permissionsTask);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		providerTasks.add(permissionsTask);
		
		GetForEditTask getForEditTask = new GetForEditTask(request, providerTasks);
		tasks.add(getForEditTask);
	}

	@Override
	public List<ICmsEditorTask> getTasks() {
		return tasks;
	}

}
