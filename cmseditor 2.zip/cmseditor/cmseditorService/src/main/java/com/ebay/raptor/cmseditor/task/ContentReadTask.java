package com.ebay.raptor.cmseditor.task;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentReadRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetArticleViewsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.util.CALUtil;

/**
 * Reads a single content by Id SELECTOR: READ_CONTENT
 * 
 * @author kravikumar
 *
 */
public class ContentReadTask extends CmsEditorTask {

	private ContentDraftDao contentDraftDao;
	private ContentPublishDao contentPublishDao;

	private static final Logger LOGGER = Logger
			.getInstance(ContentReadTask.class);

	public ContentReadTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao = request.getApplicationContext().getBean(
				ContentDraftDao.class);
		contentPublishDao = request.getApplicationContext().getBean(
				ContentPublishDao.class);
	}
	
	public ContentReadTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao,ContentPublishDao contentPublishDao) {
		super(request, providerTasks);
		this.contentDraftDao = contentDraftDao;
		this.contentPublishDao = contentPublishDao;
	} 

	@Override
	protected CmsEditorTaskResponse createResponse() {
		ContentReadRequest req = request.getContentReadRequest();
		if (req == null || req.getStatus() == null) {
			return createFailureResponse();
		}
		ContentEntity content = null;
		ContentReadTaskResponse response = new ContentReadTaskResponse();
		Set<String> permissions = findPermissions();
		response.setViewCount(getViewCount(req.getContentId()));
		try {
			if (ArticleStatusEnum.isDraftContent(req.getStatus())) {
				//USER HAS TO BE SIGNED IN TO SEE DRAFT
				if(StringUtils.isEmpty(req.getUserId())){
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					response.setError(CmsEditorStatus.USER_NOT_SIGNED_IN_ERROR);
					return response;
				}
				content = contentDraftDao.findContentById(req.getContentId());
				if(content==null){
					return createFailureResponse(CmsEditorStatus.CONTENT_NOT_FOUND);
				}
				List<String> accessControlList=content.getAccessControlList();
				if(CollectionUtils.isEmpty(accessControlList)){
					return createFailureResponse();
				}
				boolean hasAdminPermissions = !CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name());
				if(!accessControlList.contains(String.valueOf(request.getUserId())) && !hasAdminPermissions){
					return createFailureResponse(CmsEditorStatus.USER_ACCESS_ERROR);
				}
			} else if (ArticleStatusEnum.isPublishedContent(req.getStatus())) {
				if(StringUtils.isEmpty(req.getUserId()) && !req.isAuthorizedApplication()){
					//A NON SIGNED IN USER CAN ONLY SEE LIVE CONTENT
					if(req.getStatus()!=ArticleStatusEnum.SUBMITTED){
						response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
						response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
						return response;
					}
				}
				content = contentPublishDao.findContentById(req.getContentId());
			}
		} catch (IllegalArgumentException i) {
			LOGGER.log(LogLevel.ERROR, i);
			return createFailureResponse(CmsEditorStatus.INVALID_CONTENT_ID);
		} catch (Exception e) {
			LOGGER.log(LogLevel.ERROR, e);
			return createFailureResponse();
		}
		if (content == null) {
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
			return response;
		}
		String status = content.getContentStatus();
		if (StringUtils.isEmpty(status)) {
			return createFailureResponse();
		}
		try {
			ArticleStatusEnum contentStatus = ArticleStatusEnum.valueOf(status);
			if(req.getStatus()!=ArticleStatusEnum.SUBMITTED && req.getStatus()!=contentStatus){
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
				return response;
			}
			//IF THE CONTENT IS SPAM OR PENDING SPAM DETECTION THEN THE OWNER MUST SEE AN APPROPRIATE MESSAGE. OTHER USERS SHOULD NOT BE ABLE TO SEE THIS CONTENT
			if (ArticleStatusEnum.isSpam(contentStatus) || ArticleStatusEnum.PENDING_SPAM_DETECTION==contentStatus) {
				return handleSpamContent(content, response, permissions);
			}
		} catch (IllegalArgumentException i) {
			return createFailureResponse();
		}

		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		response.setContent(content);
		return response;
	}

	private CmsEditorTaskResponse handleSpamContent(ContentEntity content,
			ContentReadTaskResponse response, Set<String> permissions) {
		CALUtil.logCALEvent("SPAM_STATE", "SPAM_STATE", "SPAM_STATE "+content.getContentStatus());
		if(request.getContentReadRequest().isAuthorizedApplication()){
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setContent(content);
			return response;
		}
		if (request.getUserId() == null || request.getUserId() <= 0) {
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
			return response;
		} else if (!CollectionUtils.isEmpty(content
				.getAccessControlList())
				&& content.getAccessControlList().contains(
						String.valueOf(request.getUserId()))) {
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setContent(content);
			return response;
		} else if (!CollectionUtils.isEmpty(permissions) && hasPermissions(permissions)){
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setContent(content);
			return response;
		} else {
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
			return response;
		}
	}

	private Set<String> findPermissions() {
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse) ((GetUserPermissionsTask) task)
						.getTaskResponse());
				Set<String> permissions = permissionsResponse.getPermissions();
				return permissions;
			}
		}
		return new HashSet<String>();
	}
	
	private long getViewCount(String articleId) {
		
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetArticleViewsTask) {
				GetArticleViewsTaskResponse viewsTaskResponse = ((GetArticleViewsTaskResponse) ((GetArticleViewsTask) task)
						.getTaskResponse());
				Map<String, Long> map = viewsTaskResponse.getArticleViewsMap();
				if(map.containsKey(articleId)) {
					return map.get(articleId);
				}
			}
		}
		return 0l;
		
	}

	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		ContentReadTaskResponse response = new ContentReadTaskResponse();
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		return response;
	}

	protected CmsEditorTaskResponse createFailureResponse(CmsEditorStatus error) {
		ContentReadTaskResponse response = new ContentReadTaskResponse();
		response.setError(error);
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		return response;
	}
	
	private boolean hasPermissions(Set<String> permissions){
		
		return permissions.contains(PermissionEnum.BLACKLIST_CONTENT.name()) || permissions.contains(PermissionEnum.UNBLACKLIST_CONTENT.name());
	}
}
