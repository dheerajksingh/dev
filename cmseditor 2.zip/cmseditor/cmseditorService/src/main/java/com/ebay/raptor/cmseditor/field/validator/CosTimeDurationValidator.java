package com.ebay.raptor.cmseditor.field.validator;

import java.util.LinkedHashMap;

import org.apache.commons.lang.StringUtils;

import com.ebay.cos.type.v3.base.TimeDuration;
import com.ebay.cos.type.v3.base.TimeDurationUnitEnum;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

public class CosTimeDurationValidator implements IFieldValidator {

	@SuppressWarnings("unchecked")
	@Override
	public void validate(KeyValueImpl keyValue) throws CmsEditorException {
		
		if (StringUtils.isEmpty(keyValue.getKey())) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		if (!AllowedFields.getAllowedFields().contains(keyValue.getKey())) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		try{
		LinkedHashMap<Object, Object> cosTimeDuration = (LinkedHashMap<Object, Object>) keyValue.getValue();
		Long timeValue =  Long.valueOf(String.valueOf(cosTimeDuration.get("value")));
		TimeDurationUnitEnum timeUnit = TimeDurationUnitEnum.valueOf((String) cosTimeDuration.get("unit"));
		if(timeValue == null || timeUnit == null){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
		TimeDuration timeDuration = new TimeDuration();
		timeDuration.setValue(timeValue);
		timeDuration.setUnit(timeUnit);
		keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
		keyValue.setValue(timeDuration);
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
	}

}
