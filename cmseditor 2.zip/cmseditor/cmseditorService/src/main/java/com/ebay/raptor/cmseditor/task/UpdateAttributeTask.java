package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleUpdateFieldRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateContentFieldTaskResponse;
import com.ebay.raptor.cmseditor.util.CALUtil;

/**
 * Updates a specific field - like blacklist status or title
 * SELECTOR: UPDATE_CONTENT_FIELD
 * @author kravikumar
 *
 */
public class UpdateAttributeTask extends CmsEditorTask{

	ContentDraftDao contentDraftDao;
	
	
	public UpdateAttributeTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		this.contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
	}
	
	public UpdateAttributeTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao) {
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
	}
	
	

	@Override
	protected CmsEditorTaskResponse createResponse() {
		UpdateContentFieldTaskResponse response = new UpdateContentFieldTaskResponse();
		try {
			//ContentPublishDao contentPublishDao = request.getApplicationContext().getBean(ContentPublishDao.class);
			ArticleUpdateFieldRequest updateFieldRequest = (ArticleUpdateFieldRequest)request.getContentUpdateFieldRequest();
			
			//1.) Check if user has admin rights to update or blacklist
			Set<String> requiredPermisisons = getRequiredPermissions(updateFieldRequest);
			boolean hasUpdatePermissions = false;
			List<String> accessControlList = new ArrayList<String>();
			for(ICmsEditorTask task: providerTasks) {
				if(task instanceof GetUserPermissionsTask) {
					GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
					Set<String> permissions = permissionsResponse.getPermissions();
					if(permissions != null && permissions.containsAll(requiredPermisisons)) {
						hasUpdatePermissions = true;
					}
				} else if(task instanceof GetAccessControlListTask) {
					Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) task.getTaskResponse())
							.getContentEntityMap();
					if(contentEntityMap != null && contentEntityMap.get(updateFieldRequest.getArticleId()) != null) {
						accessControlList.addAll(contentEntityMap.get(updateFieldRequest.getArticleId())
								.getAccessControlList());
								
					}
				}
			}
			
			//2.) If user does not have admin rights check if its his own content
			if(!hasUpdatePermissions) {
				if(CollectionUtils.isEmpty(accessControlList)){
					response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					return response;
				}
				hasUpdatePermissions = accessControlList.contains(String.valueOf(request.getUserId()));
			}
			
			//3.) If the user has permissions update the content fields
			if(hasUpdatePermissions) {
				contentDraftDao.updateContentField(updateFieldRequest.getArticleId(), updateFieldRequest.getKeyValues());
				response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
				return response;
			} else {
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
				return response;
			}
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.UPDATE_CONTENT_FIELD_TASK_EXCEPTION, "createResponse", ExceptionUtils.getFullStackTrace(e));
			return createFailureResponse();
		}
	}

	private Set<String> getRequiredPermissions(
			ArticleUpdateFieldRequest updateFieldRequest) {
		Set<String> requiredPermissions = new HashSet<String>();
		requiredPermissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		return requiredPermissions;
	}
}
