package com.ebay.raptor.cmseditor.resource;

import com.ebay.cos.raptor.service.annotations.Api;
import com.ebay.cos.raptor.service.annotations.Service;


@Service(name="User Article Service", version="1.0.0", description="API to read, create and update user generated content",
api = {
    @Api(
            name="user_content",
            title="User Article API",
            description="API to read, create and update user generated content",
            documentationLink="https://wiki.vip.corp.ebay.com/display/SocialPM/User+Article+Service",
            versionInResources=true
        )
}
)
public class CmsEditorServiceDescriptor {

}
