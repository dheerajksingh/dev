package com.ebay.raptor.cmseditor.response.composer;

import java.util.List;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.UpdateGroupResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.UpdateGroupTaskResponse;

public class UpdateGroupResponseComposer implements IResponseComposer{

	private List<CmsEditorTaskResponse> taskResponses;
	
	public UpdateGroupResponseComposer(List<CmsEditorTaskResponse> taskResponses) {
		this.taskResponses = taskResponses;
	}
	
	@Override
	public CmsEditorResponse compose() throws CmsEditorException{
		UpdateGroupResponse response = new UpdateGroupResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses) {
			if(taskResponse instanceof UpdateGroupTaskResponse) {
				if(taskResponse.getTaskStatus().equals(CmsEditorTaskStatus.SUCCESS)) {
					response.setGroup(((UpdateGroupTaskResponse) taskResponse).getGroup());
					response.status=CmsEditorResponseStatus.SUCCESS;
				} else{
					throw new CmsEditorException(taskResponse.getError());
				}
				break;
			}
		}
		return response;
	}

}