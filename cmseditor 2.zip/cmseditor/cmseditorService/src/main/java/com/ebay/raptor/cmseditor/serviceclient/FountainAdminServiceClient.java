package com.ebay.raptor.cmseditor.serviceclient;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.internal.GingerClientFactory.ClientCreationException;
import org.ebayopensource.ginger.client.internal.GingerClientManager;
import org.ebayopensource.ginger.client.internal.GingerClientManager.ClientAlreadyRegisteredException;
import org.ebayopensource.ginger.client.internal.InitGingerClientConfigFactory.ConfigCreationException;


import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.util.CALUtil;

public class FountainAdminServiceClient {

	private static final String CLIENT_ID = "FountainAdminServiceClient";
	private static final String SERVICE_NAME = "fntnadminsvc";
	
	//Endpoints
	private static final String ENDPOINT_GET_PERMISSIONS_FOR_USER = "getPermissionsForUser";
	
	//Query Params
	private static final String QUERY_PARAM_USER_ID = "userId";
	private static final String QUERY_PARAM_DOMAIN = "domain";
	private static final String QUERY_PARAM_VALUE_DOMAIN = "Fountain";
	
	
	public GetUserPermissionsTaskResponse getPermissionsForUser(String userId) {
		try {
			GingerClient client = GingerClientManager.get().getOrRegisterClient(CLIENT_ID, SERVICE_NAME);
			GingerWebTarget webTarget = client.target(ENDPOINT_GET_PERMISSIONS_FOR_USER);
			Invocation.Builder resourceBuilder = webTarget.queryParam(QUERY_PARAM_USER_ID, userId)
					.queryParam(QUERY_PARAM_DOMAIN, QUERY_PARAM_VALUE_DOMAIN)
					.request(MediaType.APPLICATION_JSON);
			GingerClientResponse response = (GingerClientResponse) resourceBuilder.get();
			
			if(response == null || response.getStatus() != Response.Status.OK.getStatusCode()) {
				int statusCode = response.getStatus();
				//If the user is not found from admin service return empty permissions
				if(statusCode == Response.Status.NOT_FOUND.getStatusCode()) {
					return new GetUserPermissionsTaskResponse();
				}
				throw new Exception("Response Status: " + (response == null ? "null" : response.getStatus()));
			}
			return response.getEntity(GetUserPermissionsTaskResponse.class);
		} catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			CALUtil.logFailedCALEvent(CALUtil.FOUNTAIN_ADMIN_SERVICE_EXCEPTION, "getPermissionsForUser", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.FOUNTAIN_ADMIN_SERVICE_EXCEPTION, "getPermissionsForUser", ExceptionUtils.getFullStackTrace(e));			
		}
		return new GetUserPermissionsTaskResponse();
	}
	
}
