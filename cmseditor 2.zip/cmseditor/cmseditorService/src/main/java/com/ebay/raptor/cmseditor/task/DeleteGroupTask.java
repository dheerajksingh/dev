package com.ebay.raptor.cmseditor.task;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.DeleteGroupRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.DeleteGroupTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class DeleteGroupTask extends CmsEditorTask{
	
	@Inject ContentDraftDao contentDraftDao;
	
	private static final Logger LOGGER = Logger.getInstance(DeleteGroupTask.class);

	public DeleteGroupTask(CmsEditorRequest request, List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
	}
	
	public DeleteGroupTask(CmsEditorRequest request, List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao){
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		DeleteGroupRequest req = request.getDeleteGroupRequest();
		if(req==null){
			return createFailureResponse();
		}
		
		List<CmsEditorTaskResponse> taskResponses = getTaskResponses();
		if(CollectionUtils.isEmpty(taskResponses)){
			return createFailureResponse();
		}
		boolean isAdmin=false;
		boolean hasAccess=false;
		DeleteGroupTaskResponse response = new DeleteGroupTaskResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses){
			if(taskResponse instanceof GetUserPermissionsTaskResponse){
				Set<String> permissions = ((GetUserPermissionsTaskResponse) taskResponse).getPermissions();
				if(!CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.DELETE_OTHER_CONTENT.name())){
					isAdmin=true;
				}
			} else if(taskResponse instanceof GetAccessControlListTaskResponse) {
				if(taskResponse.getTaskStatus()==CmsEditorTaskStatus.FAILURE){
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					response.setError(taskResponse.getError());
					return response;
				}
				Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) taskResponse)
						.getContentEntityMap();
				if(contentEntityMap != null && contentEntityMap.get(req.getContentId()) != null && !CollectionUtils.isEmpty(contentEntityMap.get(req.getContentId()).getAccessControlList())) {
					hasAccess = contentEntityMap.get(req.getContentId())
							.getAccessControlList()
							.contains(String.valueOf(request.getUserId()));
				}		
				
			}
		}
		if(!isAdmin && !hasAccess){
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
			return response;
		}
		
		try{
			deleteContentGroup(req.getContentId(), req.getGroupId());
		}catch(CmsEditorException c){
	 		LOGGER.log(LogLevel.ERROR,c);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
 			response.setError(c.getError());
 			return response;
		}
		catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

	private void deleteContentGroup(String contentId, String groupId) throws Exception {
		//Retrive the draft content from the database
		DraftContentEntity draftContent=null;
		try{
			draftContent = contentDraftDao.findContentById(contentId);
		}catch(IllegalArgumentException i){
			throw new CmsEditorException(CmsEditorStatus.INVALID_CONTENT_ID);
		}
		if(draftContent == null) {
			throw new CmsEditorException(CmsEditorStatus.CONTENT_NOT_FOUND);
		}
		List<GroupEntity> groups = draftContent.getUserGeneratedContent().getGroups();
		boolean foundGroup=false;
				if(!CollectionUtils.isEmpty(groups)) {
			Iterator<GroupEntity> iter = groups.listIterator();
			while(iter.hasNext()) {
			    GroupEntity group = iter.next();
			    if (group.getGroupId().equals(groupId)) {
			    	foundGroup=true;
			        iter.remove();
			    }
			}
		}
		if(!foundGroup) {
			throw new CmsEditorException(CmsEditorStatus.GROUP_NOT_FOUND);
		}
		contentDraftDao.save(draftContent);
	}
}
