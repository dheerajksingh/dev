package com.ebay.raptor.cmseditor.task.response;

public class UpdateContentTaskResponse extends CmsEditorTaskResponse{

}
