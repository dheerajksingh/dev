package com.ebay.raptor.cmseditor.resource;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import com.ebay.cos.raptor.service.annotations.ApiDescription;
import com.ebay.cos.raptor.service.annotations.ApiMethod;
import com.ebay.cos.raptor.service.annotations.ApiMultivalueParam;
import com.ebay.cos.raptor.service.annotations.ApiRef;
import com.ebay.cos.raptor.service.annotations.ApiSchema;
import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.kernel.cal.helper.RLogId;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.MigrationLogDao;
import com.ebay.raptor.cmseditor.dao.entities.MigrationLog;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.error.ErrorBuilder;
import com.ebay.raptor.cmseditor.field.validator.ContentFieldValidator;
import com.ebay.raptor.cmseditor.manager.CmsEditorManager;
import com.ebay.raptor.cmseditor.moderation.validator.ModerationValidator;
import com.ebay.raptor.cmseditor.request.AkismetCommentBuilder;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ArticleUpdateFieldRequest;
import com.ebay.raptor.cmseditor.request.BulkContentDeleteRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentPublishRequest;
import com.ebay.raptor.cmseditor.request.ContentReadAllRequest;
import com.ebay.raptor.cmseditor.request.ContentReadRequest;
import com.ebay.raptor.cmseditor.request.ContentUpdateRequest;
import com.ebay.raptor.cmseditor.request.CreateDraftRequest;
import com.ebay.raptor.cmseditor.request.DeleteContentRequest;
import com.ebay.raptor.cmseditor.request.DeleteGroupRequest;
import com.ebay.raptor.cmseditor.request.DeleteSectionRequest;
import com.ebay.raptor.cmseditor.request.GetForEditRequest;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.request.SortOrder;
import com.ebay.raptor.cmseditor.request.UpdateGroupRequest;
import com.ebay.raptor.cmseditor.request.UpdateModerationStatusRequest;
import com.ebay.raptor.cmseditor.request.UpdateSectionRequest;
import com.ebay.raptor.cmseditor.response.BulkArticleResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.cmseditor.response.CreateSectionResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.UpdateGroupResponse;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadAllResponse;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadResponse;
import com.ebay.raptor.cmseditor.response.content.model.BaseArticle;
import com.ebay.raptor.cmseditor.util.UserInfoUtil;
import com.ebay.raptor.kernel.context.RaptorContextFactory;
import com.google.common.base.Splitter;

@Component
@Scope("request")
@ApiRef(api = "user_content")
@Path("/v1")
public class CmsEditorResource {
	
	@Inject ContentFieldValidator contentFieldValidator;

	private static final Logger LOGGER = Logger
			.getInstance(CmsEditorResource.class);

	@Autowired
	ApplicationContext applicationContext;
	
	@Inject AkismetCommentBuilder akismetCommentBuilder;
	
	CmsEditorManager manager;
	
	@Inject UserInfoUtil userInfo;
	
	private HttpServletRequest httpRequest;
	private static int counter=1;
	
	@Inject ModerationValidator moderationValidator;

//	@POST
//	@Path("/content/search")
//	@Produces({ MediaType.APPLICATION_JSON })
//	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/@public')")
//	@ApiMethod(resource = "/content/search")
//	@ApiDescription("Retrieve search results for content")
//	@ApiSchema(schemaClass = ContentSearchResponse.class)
//	public ContentSearchResponse searchContent(
//			@QueryParam("keyword") String keyword) {
//		return null;
//	}
	
	public CmsEditorResource(){
		this.manager=new CmsEditorManager();
		this.httpRequest=RaptorContextFactory.getCtx().getHttpServletRequest();
	}
	
	public CmsEditorResource(CmsEditorManager manager,ApplicationContext applicationContext){
		this.manager=manager;
		this.applicationContext=applicationContext;
	}
	
	public CmsEditorResource(CmsEditorManager manager,ApplicationContext applicationContext,UserInfoUtil userInfo,AkismetCommentBuilder builder,HttpServletRequest request){
		this.manager=manager;
		this.applicationContext=applicationContext;
		this.akismetCommentBuilder=builder;
		this.userInfo=userInfo;
	}
	
	public CmsEditorResource(CmsEditorManager manager,ApplicationContext applicationContext,ContentFieldValidator validator,UserInfoUtil userInfo){
		this.manager=manager;
		this.applicationContext=applicationContext;
		this.contentFieldValidator=validator;
		this.userInfo=userInfo;
	}


	@GET
	@Path("/user/@self/article")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Retrieve a paginated list of articles for a given user. This method returns ArticleReadAllResponse")
	@ApiSchema(schemaClass = ArticleReadAllResponse.class)
	public Response getUserArticles(
			@ApiDescription("The number of article resources which will be returned") @DefaultValue("10") @QueryParam("limit") int limit,
			@ApiDescription("The offset for the request") @DefaultValue("0") @QueryParam("offset") int offset,
			@ApiDescription("The sort criteria for this result") @ApiMultivalueParam(value = "-dateModified,dateModified") @DefaultValue("-dateModified") @QueryParam("sort") String sort,
			@ApiDescription("Represents the article status - DRAFT/SUBMITTED") @DefaultValue("SUBMITTED") @QueryParam("filter") String filter) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setSelector(Selector.READ_ALL_CONTENT);
			ContentReadAllRequest req = new ContentReadAllRequest();
			long userId = validateAndGetUserId();
			if(userId>0){
				request.setUserId(userId);
				req.setUserId(String.valueOf(userId));
			}
			request.setApplicationContext(applicationContext);
			req.setSort(SortOrder.getSortByName(sort));
			if (limit > 0) {
				req.setLimit(limit);
			}
			if(offset>=0){
				req.setOffset(offset);
			}
			req.setContentStatuses(filter);
			request.setContentReadAllRequest(req);

			ArticleReadAllResponse response = (ArticleReadAllResponse) manager
					.manage(request);
			return Response.ok().entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GET
	@Path("/article/{articleId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/@public')")
	@ApiMethod(resource = "article")
	@ApiDescription("Retrieves a article specified by the article Id")
	@ApiSchema(schemaClass = ArticleReadResponse.class)
	public Response getArticleById(
			@ApiDescription("The unique article identifier") @PathParam("articleId") String articleId,
			@ApiDescription("Represents the article status - DRAFT/SUBMITTED") @DefaultValue("SUBMITTED") @QueryParam("mode") String mode) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setSelector(Selector.READ_CONTENT);
			ContentReadRequest req = new ContentReadRequest();
			if(StringUtils.isEmpty(articleId)){
				return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID));
			}
			req.setAuthorizedApplication(userInfo.isAuthorizedApplication());
			req.setContentId(articleId);
			request.setApplicationContext(applicationContext);
			long userId=userInfo.getSignedInUserId();
			if(userId>0){
				request.setUserId(userId);
				req.setUserId(String.valueOf(userId));
			}
			if(StringUtils.isEmpty(mode)){
				mode = ArticleStatusEnum.SUBMITTED.name();
			}
			try{
				req.setStatus(ArticleStatusEnum.valueOf(mode));
			}catch(IllegalArgumentException i){
				return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.INVALID_STATUS));
			}
			request.setContentReadRequest(req);
			ArticleReadResponse readResponse = (ArticleReadResponse) manager
					.manage(request);
			return Response.ok().entity(readResponse).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}

	}

	/**
	 * Publishes the given content
	 * 
	 * @param contentId
	 * @param content
	 * @return
	 */

	@POST
	@Path("/article/{articleId}/publish")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Publishes a draft")
	@ApiSchema(schemaClass = PublishArticleResponse.class)
	public Response publish(
			@ApiDescription("The unique article identifier") @PathParam("articleId") String articleId) {
		try {
			if(StringUtils.isEmpty(articleId)) {
				throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID);
			}
			CmsEditorRequest request = new CmsEditorRequest();
			
			request.setUserId(validateAndGetUserId());
			request.setSelector(Selector.PUBLISH_CONTENT);
			request.setApplicationContext(applicationContext);
			ContentPublishRequest publishRequest = new ContentPublishRequest();
			publishRequest.setDraftContentId(articleId);
			publishRequest.setAkismetComment(akismetCommentBuilder.buildAkismetComment(httpRequest));
			request.setContentPublishRequest(publishRequest);
			
			PublishArticleResponse response = (PublishArticleResponse) manager.manage(request);
			return Response.ok().entity(response).build();
		}  catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Updates fields for the given content.
	 * 
	 * @param contentId
	 * @param content
	 * @return
	 */
	@POST
	@Path("/article/{articleId}/update_attribute")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates a specific attribute in the article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response updateAttribute(
			@ApiDescription("The unique article identifier") @PathParam("articleId") String articleId,
			@ApiDescription("The update request with list of key value attribute pairs to be updated") ArticleUpdateFieldRequest updateRequest) {
		try {
			if(StringUtils.isEmpty(articleId)) {
				throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID);
			}
			
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			request.setSelector(Selector.UPDATE_CONTENT_ATTRIBUTE);
			request.setApplicationContext(applicationContext);
			updateRequest.setArticleId(articleId);
			contentFieldValidator.validateFields(updateRequest.getKeyValues());
			request.setContentUpdateFieldRequest(updateRequest);
			
			CmsEditorResponse response = manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PUT
	@Path("/article/{articleId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates a article resource specified by the article Id")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response updateArticle(
			@ApiDescription("The unique article identifier") @PathParam("articleId") String articleId,
			@ApiDescription("The article to be updated") Article article) {
		try {
			
			if(StringUtils.isEmpty(articleId)){
				throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID);
			}
			if(article==null){
				throw new CmsEditorException(CmsEditorStatus.MISSING_OR_BAD_CONTENT);
			}
			
			
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			request.setSelector(Selector.UPDATE_CONTENT);
			request.setApplicationContext(applicationContext);
			ContentUpdateRequest updateRequest = new ContentUpdateRequest();
			updateRequest.setContentId(articleId);
			updateRequest.setContentEntity(article);
			updateRequest.setStatus(ArticleStatusEnum.DRAFT);
			request.setContentUpdateRequest(updateRequest);
			
			CmsEditorResponse response = manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Creates a draft
	 * 
	 * @param contents
	 * @return
	 */

	@POST
	@Path("/article")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Creates a draft article")
	@ApiSchema(schemaClass = CreateDraftResponse.class)
	public Response createArticle(
			@ApiDescription("The article to be created") BaseArticle baseArticle) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			if (baseArticle == null) {
				throw new CmsEditorException(CmsEditorStatus.MISSING_OR_BAD_CONTENT);
			}
			CreateDraftRequest createContentRequest = new CreateDraftRequest();
			Article article = new Article(baseArticle);
			article.setDateCreated(new DateTime(new Date()));
			article.setArticleStatus(ArticleStatusEnum.DRAFT);
			article.setMarketplaceId(UserInfoUtil.getMarketPlaceId());
			createContentRequest.setContent(article);
			long userId = validateAndGetUserId();
			createContentRequest.setUserId(String.valueOf(userId));
			request.setUserId(userId);
			request.setSelector(Selector.CREATE_DRAFT);
			request.setApplicationContext(applicationContext);
			request.setCreateContentRequest(createContentRequest);
				CreateDraftResponse response = (CreateDraftResponse) manager
						.manage(request);
				System.out.println("Resonse from create Article --- %%%%%%% -  contentid  "+response.getContentId()+"  status - "+response.getStatus()+"   counter "+counter++);
				return Response.status(Status.CREATED).entity(response).build();
			} catch (CmsEditorException c) {
				return buildCmsEditorResponse(c);
			} catch (Exception e) {
				return buildGenericErrorResponse(e,
						CmsEditorStatus.INTERNAL_SERVER_ERROR);
			}
	}

	/**
	 * Deletes all contents specified in the request
	 * 
	 * @param contentId
	 * @return
	 */

	@POST
	@Path("/article/bulk_delete")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Deletes articles for the specified article Ids in the request")
	@ApiSchema(schemaClass = BulkArticleResponse.class)
	public Response deleteArticles(
			@ApiDescription("List of comma separated article Ids to be deleted") @QueryParam("articleIds") String articleIds,
			@ApiDescription("Represents the article status - DRAFT/SUBMITTED") @QueryParam("mode") String mode) {

		try {
			if(StringUtils.isEmpty(articleIds)) {
				throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_IDS);
			}
			if(StringUtils.isEmpty(mode)){
				throw new CmsEditorException(CmsEditorStatus.MISSING_STATUS);
			}
			
			try{
			if(ArticleStatusEnum.valueOf(mode)!=ArticleStatusEnum.DRAFT && ArticleStatusEnum.valueOf(mode)!=ArticleStatusEnum.PUBLISHED){
				throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
			}
			}catch(IllegalArgumentException i){
				throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS,i);
			}
			
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			BulkContentDeleteRequest deleteRequest = new BulkContentDeleteRequest();
			deleteRequest.populateContentIds(articleIds);
			deleteRequest.setStatus(ArticleStatusEnum.valueOf(mode));
			request.setSelector(Selector.BULK_DELETE_CONTENT);
			request.setApplicationContext(applicationContext);
			request.setBulkContentDeleteRequest(deleteRequest);
			
			BulkArticleResponse response = (BulkArticleResponse) manager.manage(request);
			return Response.status(response.getStatusCode()).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Deletes a single content
	 * 
	 * @param contentId
	 * @return
	 */

	@DELETE
	@Path("/article/{articleId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Deletes article for the specified article Id in the request")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response deleteArticle(
			@ApiDescription("Identifier of the article to be deleted") @PathParam("articleId") String articleId,
			@ApiDescription("Represents the article status - DRAFT/SUBMITTED") @QueryParam("mode") String mode) {

		try {
			if(StringUtils.isEmpty(articleId)) {
				throw new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID);
			}
			if(StringUtils.isEmpty(mode)){
				throw new CmsEditorException(CmsEditorStatus.MISSING_STATUS);
			}
			try{
			if(ArticleStatusEnum.valueOf(mode)==null){
				throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
			}
			}catch(IllegalArgumentException i){
				throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
			}
			if(ArticleStatusEnum.valueOf(mode)!=ArticleStatusEnum.DRAFT && ArticleStatusEnum.valueOf(mode)!=ArticleStatusEnum.SUBMITTED){
				throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
			}
			
			CmsEditorRequest request = new CmsEditorRequest();
			DeleteContentRequest deleteRequest = new DeleteContentRequest();
			deleteRequest.setContentId(articleId);
			deleteRequest.setStatus(ArticleStatusEnum.valueOf(mode));
			request.setUserId(validateAndGetUserId());
			request.setSelector(Selector.DELETE_CONTENT);
			request.setApplicationContext(applicationContext);
			request.setDeleteContentRequest(deleteRequest);
			
			CmsEditorResponse response = manager.manage(request);
			return Response.status(Status.OK).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/** Create group
	 * 
	 * @param articleId
	 * @param createGroupRequest
	 * @return
	 */
	
	@POST
	@Path("/article/{articleId}/group")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates a specific group in the article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response createGroup(
			@ApiDescription("Identifier of the article whose group has to be updated") @PathParam("articleId") String articleId,
			@ApiDescription("The group create request") UpdateGroupRequest createGroupRequest) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			if (StringUtils.isEmpty(articleId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_CONTENT_ID));
			}
			createGroupRequest.setArticleId(articleId);
			if (createGroupRequest.getGroupType() == null) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_GROUP_TYPE));
			}
			request.setSelector(Selector.UPDATE_GROUP);
			request.setApplicationContext(applicationContext);
			request.setUpdateGroupRequest(createGroupRequest);

			CmsEditorManager manager = new CmsEditorManager();
			CmsEditorResponse response = manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity((UpdateGroupResponse)response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	/**
	 * Saves the group to the contents specified by the content id. The group is
	 * identified by the group Id inside the module.
	 * 
	 * @param contentId
	 * @param UpdateGroupRequest
	 * @return
	 */
	@PUT
	@Path("/article/{articleId}/group/{groupId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates a specific group in the article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response updateGroup(
			@ApiDescription("Identifier of the article whose group has to be updated") @PathParam("articleId") String articleId,
			@ApiDescription("The group Id") @PathParam("groupId") String groupId,
			@ApiDescription("The group update request") UpdateGroupRequest updateGroupRequest) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			if (StringUtils.isEmpty(articleId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_CONTENT_ID));
			}
			if(StringUtils.isEmpty(groupId)){
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_GROUP_ID));
			}
			updateGroupRequest.setArticleId(articleId);
			updateGroupRequest.setGroupId(groupId);
			if (updateGroupRequest.getGroupType() == null) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_GROUP_TYPE));
			}
			request.setSelector(Selector.UPDATE_GROUP);
			request.setApplicationContext(applicationContext);
			request.setUpdateGroupRequest(updateGroupRequest);

			CmsEditorManager manager = new CmsEditorManager();
			CmsEditorResponse response = manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity((UpdateGroupResponse)response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Create a section
	 * @param articleId
	 * @param createSectionRequest
	 * @return
	 */
	@POST
	@Path("/article/{articleId}/group/{groupId}/section")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Creates a new section")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response createSection(
			@ApiDescription("Identifier of the article whose section has to be updated") @PathParam("articleId") String articleId,
			@ApiDescription("The group Id") @PathParam("groupId") String groupId,
			@ApiDescription("The create section request") UpdateSectionRequest updateSectionRequest) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			if (StringUtils.isEmpty(articleId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_CONTENT_ID));
			}
			updateSectionRequest.setArticleId(articleId);
			if (groupId == null) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_GROUP_ID));
			}
			updateSectionRequest.setGroupId(groupId);
			if (updateSectionRequest.getSection() == null) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_MODULE));
			}
			updateSectionRequest.setSection(updateSectionRequest.getSection());
			request.setSelector(Selector.CREATE_MODULE);
			request.setApplicationContext(applicationContext);
			request.setUpdateSectionRequest(updateSectionRequest);

			CmsEditorManager manager = new CmsEditorManager();
			CreateSectionResponse response = (CreateSectionResponse) manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Updates the section
	 * 
	 * @param articleId
	 * @param updateSectionRequest
	 * @return
	 */
	@PUT
	@Path("/article/{articleId}/group/{groupId}/section/{sectionId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates a specific section in the article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response updateSection(
			@ApiDescription("Identifier of the article whose section has to be updated") @PathParam("articleId") String articleId,
			@ApiDescription("The group Id") @PathParam("groupId") String groupId,
			@ApiDescription("The section Id") @PathParam("sectionId") String sectionId,
			@ApiDescription("The section update request") UpdateSectionRequest updateSectionRequest) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			if (StringUtils.isEmpty(articleId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_CONTENT_ID));
			}
			updateSectionRequest.setArticleId(articleId);
			if (StringUtils.isEmpty(groupId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_GROUP_ID));
			}
			if (updateSectionRequest.getSection() == null) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_MODULE));
			}
			updateSectionRequest.setGroupId(groupId);
			updateSectionRequest.getSection().setSectionId(sectionId);
			request.setSelector(Selector.UPDATE_MODULE);
			request.setApplicationContext(applicationContext);
			request.setUpdateSectionRequest(updateSectionRequest);

			CmsEditorManager manager = new CmsEditorManager();
			CmsEditorResponse response = manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Deletes a group with id specified in the request for the given article Id
	 * 
	 * @param articleId
	 * @param groupId
	 * @return
	 */
	@DELETE
	@Path("/article/{articleId}/group/{groupId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Deletes a specific group in the article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response deleteGroup(
			@ApiDescription("Identifier of the article whose group has to be deleted") @PathParam("articleId") String articleId,
			@ApiDescription("Identifier of the group which has to be deleted") @PathParam("groupId") String groupId) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setUserId(validateAndGetUserId());
			request.setSelector(Selector.DELETE_GROUP);
			request.setApplicationContext(applicationContext);
			DeleteGroupRequest groupRequest = new DeleteGroupRequest();
			if(StringUtils.isEmpty(articleId)){
				return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID));
			}
			groupRequest.setContentId(articleId);
			if(groupId.equals("0")){
				return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_GROUP_ID));
			}
			groupRequest.setGroupId(groupId);
			request.setDeleteGroupRequest(groupRequest);
	
			CmsEditorManager manager = new CmsEditorManager();
			CmsEditorResponse response=manager.manage(request);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Deletes a section with id specified in the request for the given article
	 * Id
	 * 
	 * @param articleId
	 * @param groupId
	 * @param sectionid
	 * @return
	 */
	@DELETE
	@Path("/article/{articleId}/group/{groupId}/section/{sectionId}")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Deletes a specific section in the article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response deleteSection(
			@ApiDescription("Identifier of the article whose section has to be deleted") @PathParam("articleId") String articleId,
			@ApiDescription("Identifier of the group whose section has to be deleted") @PathParam("groupId") String groupId,
			@ApiDescription("Identifier of the section which has to be deleted") @PathParam("sectionId") String sectionId) {
		try {
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(validateAndGetUserId());
		request.setSelector(Selector.DELETE_MODULE);
		request.setApplicationContext(applicationContext);
		DeleteSectionRequest groupRequest = new DeleteSectionRequest();
		if(StringUtils.isEmpty(articleId)){
			return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID));
		}
		groupRequest.setContentId(articleId);
		if(StringUtils.isEmpty(groupId)){
			return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_GROUP_ID));
		}
		groupRequest.setGroupId(groupId);
		if(StringUtils.isEmpty(sectionId)){
			return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_MODULE_ID));
		}
		groupRequest.setSectionId(sectionId);
		request.setDeleteModuleRequest(groupRequest);

			CmsEditorResponse response = manager.manage(request);
			return Response.ok().entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@POST
	@Path("/article/{articleId}/edit_published")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Retrieves the draft corresponding to this article for editing.")
	@ApiSchema(schemaClass = ArticleReadResponse.class)
	public Response editPublished(
			@ApiDescription("Unique identifier for the article") @PathParam("articleId") String articleId) {
		try {
		if (StringUtils.isEmpty(articleId)) {
			return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID));
		}

		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(validateAndGetUserId());
		//request.setUserId(1304319609l);
		GetForEditRequest editRequest = new GetForEditRequest();
		editRequest.setContentId(articleId);
		request.setGetForEditRequest(editRequest);
		request.setApplicationContext(applicationContext);
		request.setSelector(Selector.GET_FOR_EDIT);

		ArticleReadResponse readResponse = (ArticleReadResponse) manager
					.manage(request);
			return Response.ok().entity(readResponse).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@POST
	@Path("/article/{articleId}/moderate")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/core@application')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates moderation status by moderator")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response moderate(
			@ApiDescription("Unique identifier for the article") @PathParam("articleId") String articleId,
			UpdateModerationStatusRequest updateRequest) {
		try {
		if (StringUtils.isEmpty(articleId)) {
			return buildCmsEditorResponse(new CmsEditorException(CmsEditorStatus.MISSING_CONTENT_ID));
		}
		//CmsEditorResponse response = handleUpdateModerationStatus(updateRequest, articleId,Selector.MODERATE);
		CmsEditorResponse response = moderationValidator.handleUpdateModerationStatus(updateRequest, articleId,Selector.MODERATE,httpRequest,manager);
		return Response.status(Status.NO_CONTENT).entity(response).build();
		}catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@POST
	@Path("/article/{articleId}/viewer_report_spam")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/core@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates moderation status when a viewer reports an article")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response viewerReportSpam(
			@ApiDescription("Unique identifier for the article") @PathParam("articleId") String articleId) {
		try {
			if (StringUtils.isEmpty(articleId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_CONTENT_ID));
			}
			UpdateModerationStatusRequest updateRequest = new UpdateModerationStatusRequest();
			updateRequest.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
			//CmsEditorResponse response = handleUpdateModerationStatusForUser(updateRequest, articleId,Selector.UPDATE_STATUS_FOR_MODERATION);
			CmsEditorResponse response = moderationValidator.handleUpdateModerationStatusForUser(updateRequest, articleId,Selector.UPDATE_STATUS_FOR_MODERATION,httpRequest,manager);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@POST
	@Path("/article/{articleId}/update_status")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/core@application')")
	@ApiMethod(resource = "article")
	@ApiDescription("Updates moderation status when the system reports a spam")
	@ApiSchema(schemaClass = CmsEditorResponse.class)
	public Response updateStatus(
			@ApiDescription("Unique identifier for the article") @PathParam("articleId") String articleId,
			UpdateModerationStatusRequest updateRequest) {
		try {
			if (StringUtils.isEmpty(articleId)) {
				return buildCmsEditorResponse(new CmsEditorException(
						CmsEditorStatus.MISSING_CONTENT_ID));
			}
			//CmsEditorResponse response = handleUpdateModerationStatusForSystem(updateRequest, articleId,Selector.UPDATE_STATUS_FOR_MODERATION);
			CmsEditorResponse response = moderationValidator.handleUpdateModerationStatusForSystem(updateRequest, articleId,Selector.UPDATE_STATUS_FOR_MODERATION,httpRequest,manager);
			return Response.status(Status.NO_CONTENT).entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
	
	
	@GET
	@Path("/article/get_for_moderation")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/core@user')")
	@ApiMethod(resource = "article")
	@ApiDescription("Retrieve a list of articles for moderation review")
	@ApiSchema(schemaClass = ArticleReadAllResponse.class)
	public Response getArticlesForModeration(
			@ApiDescription("The number of article resources which will be returned") @DefaultValue("10") @QueryParam("limit") int limit,
			@ApiDescription("The offset for the request") @DefaultValue("0") @QueryParam("offset") int offset,
			@ApiDescription("The sort criteria for this result") @ApiMultivalueParam(value = "-dateModified,dateModified") @DefaultValue("-dateModified") @QueryParam("sort") String sort,
			@ApiDescription("Represents the article status") @DefaultValue("SPAM") @QueryParam("filter") String filter,
			@ApiDescription("Represents the moderation status.Possible values-MODERATED,NEEDS_MODERATION,NOT_MODERATED") @DefaultValue("NOT_MODERATED") @QueryParam("moderationStatus") String moderationStatus) {
		try {
			CmsEditorRequest request = new CmsEditorRequest();
			request.setSelector(Selector.GET_FOR_MODERATION);
			ContentReadAllRequest req = new ContentReadAllRequest();
			long userId=validateAndGetUserId();
			String userIdString = String.valueOf(userId);
			req.setUserId(userIdString);
			request.setUserId(userId);
			request.setApplicationContext(applicationContext);
			req.setSort(SortOrder.getSortByName(sort));
			if (limit > 0) {
				req.setLimit(limit);
			}
			if(offset>=0){
				req.setOffset(offset);
			}
			req.setContentStatuses(filter);
			req.setModerationStatuses(moderationStatus);
			request.setContentReadAllRequest(req);

			ArticleReadAllResponse response = (ArticleReadAllResponse) manager
					.manage(request);
			return Response.ok().entity(response).build();
		} catch (CmsEditorException c) {
			return buildCmsEditorResponse(c);
		} catch (Exception e) {
			return buildGenericErrorResponse(e,
					CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GET
	@Path("/article/migrate/oracle/log")
	@Produces({ MediaType.APPLICATION_JSON })
	@PreAuthorize("hasRole('https://api.ebay.com/oauth/scope/social@user')")
	public Response getMigrationLogsByOracle(@QueryParam("oracleId") String oracleId) {
		MigrationLogDao dao = applicationContext.getBean(MigrationLogDao.class);
		MigrationLog log = dao.findMigrationLogByOracleContentId(oracleId);
		if(log==null){
			return Response.ok().status(Status.NOT_FOUND.getStatusCode()).build();
		}
		return Response.ok().entity(log).build();

	}
	

	private Response buildGenericErrorResponse(Exception e, CmsEditorStatus error) {
		LOGGER.log(LogLevel.ERROR, e);
		List<CmsEditorStatus> errors = new ArrayList<>();
		errors.add(error);
		CmsEditorResponse response = new CmsEditorResponse();
		new ErrorBuilder().buildErrorMessage(response, errors);
		return Response.status(error.getStatus()).entity(response)
				.header("rlogid", RLogId.getRLogId(true)).build();
	}

	private Response buildCmsEditorResponse(CmsEditorException e) {
		CmsEditorStatus error = e.getError();
		if(e.getCause()!=null){
			LOGGER.log(LogLevel.ERROR,e.getCause());
		}
		List<CmsEditorStatus> errors = new ArrayList<>();
		errors.add(error);
		CmsEditorResponse response = new CmsEditorResponse();
		new ErrorBuilder().buildErrorMessage(response, errors);

		return Response.status(error.getStatus()).entity(response)
				.header("rlogid", RLogId.getRLogId(true)).build();
	}
	
	private long validateAndGetUserId() throws CmsEditorException {
//		long userId = userInfo.getSignedInUserId();
//		if(userId == UserInfoUtil.INVALID_USER_ID) {
//			throw new CmsEditorException(CmsEditorStatus.USER_NOT_SIGNED_IN_ERROR);
//		}
//		return userId;
		return 1304319609l;
	}

	public void setModerationValidator(ModerationValidator moderationValidator) {
		this.moderationValidator = moderationValidator;
	}
	
	
}
