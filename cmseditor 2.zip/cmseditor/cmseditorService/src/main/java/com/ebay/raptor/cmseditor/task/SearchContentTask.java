package com.ebay.raptor.cmseditor.task;

import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;


/**
 * Search for content by title,author or date
 * SELECTOR:SEARCH_CONTENT
 * @author kravikumar
 *
 */
public class SearchContentTask extends CmsEditorTask{

	public SearchContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		return null;
	}

}
