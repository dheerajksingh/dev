package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentsResponse;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentsResponse;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentReadAllRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadAllTaskResponse;

/**
 * Reads all content for a given user
 * SELECTOR: READ_ALL_CONTENT
 * @author kravikumar
 *
 */
public class ContentReadAllTask extends CmsEditorTask{
	
	private ContentDraftDao contentDraftDao;
	private ContentPublishDao contentPublishDao;
	private static final Logger LOGGER = Logger.getInstance(ContentReadAllTask.class);

	public ContentReadAllTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
		contentPublishDao=request.getApplicationContext().getBean(ContentPublishDao.class);
	}
	
	public ContentReadAllTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao,ContentPublishDao contentPublishDao) {
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
		this.contentPublishDao=contentPublishDao;
	} 

	@Override
	protected CmsEditorTaskResponse createResponse() {
		ContentReadAllRequest req = request.getContentReadAllRequest();
		if(req==null || CollectionUtils.isEmpty(req.getStatuses())){
			return createFailureResponse();
		}
		ContentReadAllTaskResponse response = new ContentReadAllTaskResponse();
		try{
		List<String> contentStatuses = convertContentStatusToString(req.getStatuses());
		List<String> moderationStatuses = convertModerationStatusToString(req.getModerationStatuses());
		if(ArticleStatusEnum.hasDraftContent(req.getStatuses())){
			List<DraftContentEntity> contents=null;
			DraftContentsResponse draftResponse = contentDraftDao.findContentByUserId(req.getUserId(),req.getLimit(),req.getOffset(),req.getSort().getSort(),contentStatuses,moderationStatuses);
			contents=draftResponse.getDrafts();
			response.setDraftArticlesCount(draftResponse.getCount());
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setDrafts(contents);
		}
		if(ArticleStatusEnum.hasPublishedContent(req.getStatuses())){
			List<PublishedContentEntity> contents = null;
			PublishedContentsResponse publishedResponse=contentPublishDao.findContentByUserId(req.getUserId(),req.getLimit(),req.getOffset(),req.getSort().getSort(),contentStatuses,moderationStatuses);
			contents=publishedResponse.getPublishedContents();
			response.setPublishedArticlesCount(publishedResponse.getCount());
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setPublished(contents);
			}
		return response;
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
		}
		return createFailureResponse();
	}
	
	

	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		ContentReadAllTaskResponse response = new ContentReadAllTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
	
	private List<String> convertContentStatusToString(List<ArticleStatusEnum> contentStatuses){
		List<String> statuses = new ArrayList<String>();
		if(CollectionUtils.isEmpty(contentStatuses)){
			return statuses;
		}
		for(ArticleStatusEnum status:contentStatuses){
			statuses.add(status.name());
		}
		return statuses;
		
	}
	
	private List<String> convertModerationStatusToString(List<ModerationStatusEnum> moderationStatuses){
		List<String> statuses = new ArrayList<String>();
		if(CollectionUtils.isEmpty(moderationStatuses)){
			return statuses;
		}
		for(ModerationStatusEnum status:moderationStatuses){
			statuses.add(status.name());
		}
		return statuses;
		
	}

}
