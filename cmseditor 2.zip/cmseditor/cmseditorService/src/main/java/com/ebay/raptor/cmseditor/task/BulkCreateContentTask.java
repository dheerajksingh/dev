package com.ebay.raptor.cmseditor.task;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.BulkCreateArticleRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.task.response.BulkContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserIdsByUsernamesTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserNameByIdTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

/**
 * Creates a content
 * SELECTOR:CREATE_CONTENT
 * @author kravikumar
 *
 */
public class BulkCreateContentTask extends CmsEditorTask{
	
	private ContentDraftDao contentDraftDao;
	private ContentPublishDao contentPublishDao;
	private ContentEntityAdaptor adaptor;
	private Map<String, ContentEntity> contentEntityMap;
	private Set<String> userPermissions;
	private String loggedInUserName;
	private Map<String, Long> userNamesToUserIdsMap;
	
	public BulkCreateContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		if(request != null) {
			contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
			contentPublishDao=request.getApplicationContext().getBean(ContentPublishDao.class);
		}
		adaptor = new ContentEntityAdaptor();
		contentEntityMap = new HashMap<String, ContentEntity>();
		userPermissions = new HashSet<String>();
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		if(request==null || request.getCreateBulkContentRequest() == null){
			return createFailureResponse();
		}
		BulkCreateArticleRequest req = request.getCreateBulkContentRequest();
		
		if(CollectionUtils.isEmpty(req.getArticles())){
			return createFailureResponse();
		}
		processSubtaskResults();
		BulkContentTaskResponse response = new BulkContentTaskResponse();
		//TODO: Change to batch update
		if(req.getMode()!=null && ArticleStatusEnum.valueOf(req.getMode())==ArticleStatusEnum.DRAFT){
			return createDraftContent(req, response);
		}
		else {
			return createPublishedContent(req, response);
		}
	}

	private CmsEditorTaskResponse createPublishedContent(
			BulkCreateArticleRequest req, BulkContentTaskResponse response) {
		List<BulkAdaptorResponse> bulkResponses=null;
		try{
			bulkResponses = adaptor.adaptToPublishedWithStatus(req.getArticles(), req.getUserId());
			populateAuthorAndACLFields(bulkResponses);
			if(CollectionUtils.isEmpty(bulkResponses)){
				response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
				return response;
			}
			contentPublishDao.createBulkContents(bulkResponses);
			response.setResponses(bulkResponses);
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			return response;
		}catch(Exception e){
			response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
	}
	
	private void populateAuthorAndACLFields(List<BulkAdaptorResponse> bulkResponses) {
		
		boolean isAdmin = userPermissions != null && userPermissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name());
		for(BulkAdaptorResponse response:bulkResponses) {
			ContentEntity content = response.getEntity();
			ContentEntity contentWithACL = contentEntityMap.get(String.valueOf(content.getContentId()));
			if(content.getContentId() == null) {
				if(isAdmin && content.getAuthorName() != null) {
					content.setAuthorId(userNamesToUserIdsMap.get(content.getAuthorName()));
				} else {
					response.setAuthor(loggedInUserName);
					content.setAuthorName(loggedInUserName);
					content.setAuthorId(request.getUserId());
				}
			} else if(isAdmin || contentWithACL.getAccessControlList().contains(String.valueOf(request.getUserId()))) {
					response.setAuthor(contentWithACL.getAuthorName());
					content.setAuthorId(contentWithACL.getAuthorId());
					content.setAuthorName(contentWithACL.getAuthorName());
			} else {
				response.setStatus(CmsEditorStatus.USER_ACCESS_ERROR);
			}
		}
	}

	private CmsEditorTaskResponse createDraftContent(
			BulkCreateArticleRequest req, BulkContentTaskResponse response) {
		List<BulkAdaptorResponse> bulkResponses=null;
		try{
			bulkResponses = adaptor.adaptToDraftWithStatus(req.getArticles(), req.getUserId());
		}catch(Exception e){
			response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
		if(CollectionUtils.isEmpty(bulkResponses)){
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			return response;
		}
		try{
			contentDraftDao.createBulkContents(bulkResponses);
		}catch(Exception e){
			response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
		
		response.setResponses(bulkResponses);
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}
	
	private void processSubtaskResults() {
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse) ((GetUserPermissionsTask) task)
						.getTaskResponse());
				this.userPermissions = permissionsResponse.getPermissions();
			} else if(task instanceof GetAccessControlListTask) {
				GetAccessControlListTaskResponse aclTaskResponse = ((GetAccessControlListTaskResponse) ((GetAccessControlListTask) task)
						.getTaskResponse());
				this.contentEntityMap = ((GetAccessControlListTaskResponse) aclTaskResponse).getContentEntityMap();
				
			} else if (task instanceof GetUserNameByIdTask) {
				GetUserNameByIdTaskResponse usernameTaskResponse = ((GetUserNameByIdTaskResponse) ((GetUserNameByIdTask) task)
						.getTaskResponse());
				this.loggedInUserName = usernameTaskResponse.getUserName();
			} else if (task instanceof GetUserIdsByUsernamesTask) {
				GetUserIdsByUsernamesTaskResponse userIdsResponse = ((GetUserIdsByUsernamesTaskResponse) ((GetUserIdsByUsernamesTask) task).getTaskResponse());
				this.userNamesToUserIdsMap = userIdsResponse.getUserNamesToUserIdsMap();
			}
		}
	}
	
}
