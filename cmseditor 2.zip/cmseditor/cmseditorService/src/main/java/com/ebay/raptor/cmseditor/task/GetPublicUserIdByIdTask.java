package com.ebay.raptor.cmseditor.task;

import java.util.List;

import javax.ws.rs.core.Response.Status;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetPublicUserIdByIdTaskResponse;
import com.ebay.raptor.cmseditor.util.UserInfoUtil;
import com.ebay.userlookup.UserLookup;
import com.ebay.userlookup.common.ClientException;

public class GetPublicUserIdByIdTask extends CmsEditorTask{
	
	private UserLookup userLookup;
	
	private static final Logger LOGGER = Logger.getInstance(GetPublicUserIdByIdTask.class);

	public GetPublicUserIdByIdTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		this.userLookup=new UserLookup();
	}
	
	public GetPublicUserIdByIdTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,UserLookup userLookup) {
		super(request, providerTasks);
		this.userLookup=userLookup;
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		Long userId= request.getUserId();
		if(userId==null || userId==UserInfoUtil.INVALID_USER_ID){
			return new GetPublicUserIdByIdTaskResponse();
		}
		GetPublicUserIdByIdTaskResponse response = new GetPublicUserIdByIdTaskResponse();
		try{
		String publicUserId = getPublicUserId(userId);
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		response.setPublicUserId(publicUserId);
		return response;
		}catch(CmsEditorException c){
			response.setError(c.getError());
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
	}
	
	private String getPublicUserId(long internalId) throws CmsEditorException{
		try {
			String publicUserId= userLookup.getPublicUserId(internalId);	
			return publicUserId;
		} catch (ClientException e) {
			LOGGER.log(LogLevel.ERROR,e);
			if(e.getStatusCode()==Status.NOT_FOUND.getStatusCode()){
				throw new CmsEditorException(CmsEditorStatus.USER_DOES_NOT_EXIST, e);
			}
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR, e);
		}
	}
	
}
