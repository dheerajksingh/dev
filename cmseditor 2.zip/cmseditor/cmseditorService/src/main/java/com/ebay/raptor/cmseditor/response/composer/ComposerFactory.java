package com.ebay.raptor.cmseditor.response.composer;

import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;

public class ComposerFactory {
	
	public IResponseComposer getComposer(List<CmsEditorTaskResponse> taskResponses,CmsEditorRequest request){
		if(request==null || request.getSelector()==null){
			return null;
		}
		switch (request.getSelector()) {
//		case BLACKLIST_CONTENT:
//			return new BlacklistContentResponseComposer(taskResponses)
//					.compose();
		case BULK_CREATE_CONTENT: return new BulkContentResponseComposer(taskResponses);
		case READ_ALL_CONTENT:
			return new ContentReadAllResponseComposer(taskResponses);
		case READ_CONTENT:
			return new ContentReadResponseComposer(taskResponses);
		case UPDATE_MODULE:
			return new UpdateModuleResponseComposer(taskResponses);
		case DELETE_MODULE:
			return new DeleteModuleResponseComposer(taskResponses);
		case UPDATE_CONTENT_ATTRIBUTE:
			return new UpdateContentFieldResponseComposer(taskResponses);
		case UPDATE_CONTENT:
			return new UpdateContentResponseComposer(taskResponses);
		case UPDATE_GROUP:
			return new UpdateGroupResponseComposer(taskResponses);
		case DELETE_GROUP:
			return new DeleteGroupResponseComposer(taskResponses);
		case BULK_DELETE_CONTENT:
			return new BulkContentResponseComposer(taskResponses);
		case PUBLISH_CONTENT:
			return new PublishContentResponseComposer(taskResponses);
		case GET_FOR_EDIT:
			return new ContentReadResponseComposer(taskResponses);
		case CREATE_DRAFT:
			return new CreateDraftResponseComposer(taskResponses);
		case DELETE_CONTENT:
			return new UpdateContentResponseComposer(taskResponses);
		case UPDATE_STATUS_FOR_MODERATION:
			return new CmsEditorResponseComposer(taskResponses);
		case MODERATE:
			return new CmsEditorResponseComposer(taskResponses);
		case GET_FOR_MODERATION:
			return new ContentReadAllResponseComposer(taskResponses);
		case CREATE_MODULE:
			return new CreateSectionResponseComposer(taskResponses);
		default: return null;
		}
	}

}
