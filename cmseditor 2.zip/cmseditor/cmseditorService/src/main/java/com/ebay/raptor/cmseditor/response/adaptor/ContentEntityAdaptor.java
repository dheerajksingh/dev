package com.ebay.raptor.cmseditor.response.adaptor;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;

import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.Video;
import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.MarketingAssetsEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.exception.IllegalContentIdException;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.EntityComponent;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.TemplateType;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;

public class ContentEntityAdaptor {
	
	private static final Logger LOGGER = Logger.getInstance(ContentEntityAdaptor.class);
	
	public List<DraftContentEntity> adaptToDrafts(List<Article> models,String userId) throws IllegalContentIdException, CmsEditorException{
		List<DraftContentEntity> drafts = new ArrayList<DraftContentEntity>();
		if(CollectionUtils.isEmpty(models)){
			return drafts;
		}
		for(Article model:models){
			DraftContentEntity entity=(DraftContentEntity) adaptToDraft(model,userId);
			entity.setContentStatus(ArticleStatusEnum.DRAFT.name());
			drafts.add(entity);
		}
		return drafts;
	}
	
	public List<PublishedContentEntity> adaptToPublished(List<Article> models,String userId) throws IllegalContentIdException, CmsEditorException{
		List<PublishedContentEntity> publishedContents = new ArrayList<PublishedContentEntity>();
		if(CollectionUtils.isEmpty(models)){
			return publishedContents;
		}
		for(Article model:models){
			publishedContents.add((PublishedContentEntity) adaptToPublished(model,userId));
		}
		return publishedContents;
	}
	
	public List<BulkAdaptorResponse> adaptToPublishedWithStatus(List<Article> models,String userId) throws CmsEditorException {
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		for(Article model:models){
			BulkAdaptorResponse adaptorResponse = new BulkAdaptorResponse();
			if(model.getAuthor() != null) {
				adaptorResponse.setAuthor(model.getAuthor().getUsername());
			}
			adaptorResponse.setTitle(model.getUserGeneratedContent().getTitle().getContent());
			try{
				PublishedContentEntity entity=adaptToPublished(model,userId);
				adaptorResponse.setEntity(entity);
				adaptorResponse.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
				responses.add(adaptorResponse);
			}catch(IllegalContentIdException i){
				LOGGER.log(LogLevel.ERROR,i);
				adaptorResponse.setStatus(CmsEditorStatus.INVALID_CONTENT_ID);
				responses.add(adaptorResponse);
			}
		}
		return responses;
	}
	
	public List<BulkAdaptorResponse> adaptToDraftWithStatus(List<Article> models,String userId) throws CmsEditorException {
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		for(Article model:models){
			BulkAdaptorResponse adaptorResponse = new BulkAdaptorResponse();
			adaptorResponse.setAuthor(model.getAuthor().getUsername());
			adaptorResponse.setTitle(model.getUserGeneratedContent().getTitle().getContent());
			try{
				DraftContentEntity entity=adaptToDraft(model,userId);
				adaptorResponse.setEntity(entity);
				adaptorResponse.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
				responses.add(adaptorResponse);
			}catch(IllegalContentIdException i){
				LOGGER.log(LogLevel.ERROR,i);
				adaptorResponse.setStatus(CmsEditorStatus.INVALID_CONTENT_ID);
				responses.add(adaptorResponse);
			}
		}
		return responses;
	}

	public DraftContentEntity adaptToDraft(Article model,String userId)
			throws IllegalContentIdException, CmsEditorException {
		DraftContentEntity entity = new DraftContentEntity();
		if(model==null){
			return entity;
		}
		adaptToEntity(model, entity,userId);
		entity.setContentStatus(ArticleStatusEnum.DRAFT.name());
		return entity;
	}

	public PublishedContentEntity adaptToPublished(Article model,String userId)
			throws IllegalContentIdException, CmsEditorException {

		PublishedContentEntity entity = new PublishedContentEntity();
		if(model==null){
			return entity;
		}
		adaptToEntity(model, entity,userId);
		return entity;
	}

	private void adaptToEntity(Article model, ContentEntity entity, String userId)
			throws IllegalContentIdException, CmsEditorException {
		List<String> accessControlList = new ArrayList<String>();
		accessControlList.add(userId);
		entity.setAccessControlList(accessControlList);
		entity.setAuthorId(Long.parseLong(userId));
		if (model.getAuthor() != null) {
			entity.setAuthorName(model.getAuthor().getUsername());
			entity.setPublicAuthorId(model.getAuthor().getUserId());
		}
		
		if(!StringUtils.isEmpty(model.getArticleId())){
		try {
			entity.setContentId(new ObjectId(model.getArticleId()));
		} catch (IllegalArgumentException i) {
			throw new IllegalContentIdException(i.getMessage(), i.getCause());
		}
		}
		if(model.getArticleStatus() == null){
			throw new CmsEditorException(CmsEditorStatus.MISSING_STATUS);
		}
		try{
			entity.setContentStatus(model.getArticleStatus().name());
		}catch(IllegalArgumentException i){
			throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
		}
		if(model.getDateCreated()==null){
			entity.setDateCreated(new Date());
		}else{
			entity.setDateCreated(model.getDateCreated().getValue());
		}
			entity.setDateModified(new Date());
		if(StringUtils.isEmpty(model.getTemplateType())){
			throw new CmsEditorException(CmsEditorStatus.BAD_TEMPLATE_TYPE);
		}
		try{
			entity.setTemplateType(TemplateType.valueOf(model.getTemplateType()).name());
		}catch(IllegalArgumentException i){
			throw new CmsEditorException(CmsEditorStatus.BAD_TEMPLATE_TYPE);
		}
		if(model.getUserGeneratedContent()!=null){
			entity.setUserGeneratedContent(convertUserGenContent(model
				.getUserGeneratedContent()));
		} 
		if(model.getModerationStatus() != null) {
			entity.setModerationStatus(model.getModerationStatus().name());
		}
		entity.setMarketPlaceId(model.getMarketplaceId());
	}

	private UserGeneratedContentEntity convertUserGenContent(
			UserGeneratedContent model) {
		UserGeneratedContentEntity content = null;
		if (model != null) {
			content= new UserGeneratedContentEntity();
			if (model.getCoverImage() != null) {
				content.setCoverImage(model.getCoverImage().getImageURL());
			}
			if (model.getSynopsis() != null) {
				content.setSynopsis(model.getSynopsis().getContent());
			}
			content.setTags(model.getTags());
			if (model.getTitle() != null) {
				content.setTitle(model.getTitle().getContent());
			}
			if (model.getConclusionTitle() != null) {
				content.setConclusionTitle(model.getConclusionTitle().getContent());
			}
			if (model.getConclusionDescription() != null) {
				content.setConclusionDescription(model.getConclusionDescription().getContent());
			}
			if(model.getCostRange() != null) {
				content.setCostRange(model.getCostRange());
			}
			if(model.getDifficultyLevel() != null) {
				content.setDifficultyLevel(model.getDifficultyLevel());
			}
			if(model.getEstimatedTime() != null) {
				content.setEstimatedTime(model.getEstimatedTime());
			}
			if(model.getMaterialsNeeded() != null) {
				content.setMaterialsNeeded(model.getMaterialsNeeded());
			}
			if(model.getToolsNeeded() != null) {
				content.setToolsNeeded(model.getToolsNeeded());
			}
			content.setTags(model.getTags());
			if (model.getTitle() != null) {
				content.setTitle(model.getTitle().getContent());
			}
			if (!CollectionUtils.isEmpty(model.getGroups())) {
				content.setGroups(convertGroups(model.getGroups()));
			}			
			if(model.getMarketingAssets()!=null && model.getMarketingAssets().getAssets()!=null){
				Map<String, String> assets = new HashMap<String, String>();
				for(Entry<String, Image> assetMap:model.getMarketingAssets().getAssets().entrySet()){
					Image image =  assetMap.getValue();
					assets.put(assetMap.getKey(), image.getImageURL());
				}
				MarketingAssetsEntity mAEntity = new MarketingAssetsEntity();
				mAEntity.setMarketingAssetImages(assets);
				mAEntity.setMarketingContent(model.getMarketingAssets().getMarketingContent());
				content.setMarketingAssets(mAEntity);
			}
			if(model.getCategories()!=null){
				content.setCategories(model.getCategories());
			}
		}
		return content;
	}

	private List<GroupEntity> convertGroups(List<Group> models) {

		List<GroupEntity> groups = new ArrayList<GroupEntity>();
		for (Group model : models) {
			GroupEntity g = new GroupEntity();
			g.setGroupId(model.getGroupId());
			g.setGroupType(model.getGroupType());
			if(model.getTitle()!=null){
				g.setTitle(model.getTitle());
			}
			if (!CollectionUtils.isEmpty(model.getSections())) {
				g.setModuleMap(constructModuleMap(model.getSections()));
			}
			groups.add(g);
		}
		return groups;
	}

	private Map<String, ModuleEntity> constructModuleMap(List<Section> modules) {
		Map<String, ModuleEntity> moduleMap = new LinkedHashMap<String, ModuleEntity>();
        int count=1;
		for (Section module : modules) {
			if(module.getSectionId()!=null){
				count=Math.max(count,Integer.parseInt(module.getSectionId()));
			}
            module.setSectionId(String.valueOf(count++));
			ModuleEntity entity = adaptToModuleEntity(module);
			moduleMap.put(module.getSectionId(), entity);
		}
		return moduleMap;
	}

	public ModuleEntity adaptToModuleEntity(Section module) {
		ModuleEntity entity = new ModuleEntity();
		entity.setAlignment(module.getAlignment());
		entity.setModuleId(module.getSectionId());
		entity.setSortOrder(module.getSequence());
		if (!CollectionUtils.isEmpty(module.getComponents())) {
			entity.setData(constructSingleModuleEntity(module.getComponents()));
		}
		return entity;
	}

	private List<SingleModuleEntity> constructSingleModuleEntity(
			List<Component> data) {
		List<SingleModuleEntity> singleModuleEntities = new ArrayList<SingleModuleEntity>();
		for (Component module : data) {
			SingleModuleEntity entity = new SingleModuleEntity();
			if (module.getCaption() != null) {
				entity.setCaption(module.getCaption());
			}
			if (module.getComponentType() != null) {
				entity.setType(module.getComponentType());
			}
			if (module instanceof StandardComponent) {
				if (!StringUtils.isEmpty(((StandardComponent) module)
						.getData())) {
					entity.setData(((StandardComponent) module).getData());
				}
			}
			else if (module instanceof MediaComponent) {
				if (((MediaComponent) module).getMedia() != null) {
					if(((MediaComponent) module).getMedia() instanceof Image){
						entity.setResourceUrl(((Image)((MediaComponent) module).getMedia()).getImageURL());
						entity.setCategoryLevel(((MediaComponent) module).getCategoryLevel());
						entity.setCategoryIds(((MediaComponent) module).getCategoryIds());
					}else if(((MediaComponent) module).getMedia() instanceof Video){
						entity.setResourceUrl(((Video)((MediaComponent) module).getMedia()).getVideoURL());
					}
				}
			}else if(module instanceof EntityComponent){
				if(!CollectionUtils.isEmpty(((EntityComponent) module).getEntityIds())){
					entity.setEntityIds(((EntityComponent) module).getEntityIds());
					entity.setEntityType(((EntityComponent) module).getEntityType());
				}
			}
			singleModuleEntities.add(entity);
		}
		return singleModuleEntities;

	}


}
