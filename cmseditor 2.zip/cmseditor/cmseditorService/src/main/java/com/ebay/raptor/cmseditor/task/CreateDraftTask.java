package com.ebay.raptor.cmseditor.task;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;

import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.exception.IllegalContentIdException;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CreateDraftRequest;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetPublicUserIdByIdTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserNameByIdTaskResponse;

public class CreateDraftTask extends CmsEditorTask{
	
	private ContentDraftDao contentDraftDao;
	private ContentEntityAdaptor adaptor;

	public CreateDraftTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
		adaptor=new ContentEntityAdaptor();
	}
	
	public CreateDraftTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao) {
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
		adaptor=new ContentEntityAdaptor();
	} 

	@Override
	protected CmsEditorTaskResponse createResponse() {
		CreateDraftRequest req = request.getCreateContentRequest();
		if(req==null){
			return createFailureResponse();
		}
		
		if(req.getContent()==null){
			return createFailureResponse();
		}
		return createDraftContent(req);
		
	}
	
	private CreateDraftTaskResponse createDraftContent(CreateDraftRequest req) {
		CreateDraftTaskResponse response=new CreateDraftTaskResponse();
		DraftContentEntity entity=null;
		try{
			//Set author name from user id in token. Ignore author field in incoming request while creating draft
			Article model =req.getContent();
			UserIdentifier author = new UserIdentifier();
			populateAuthorFields(author);
			model.setAuthor(author);
			entity = adaptor.adaptToDraft(model, req.getUserId());
			entity.setContentStatus(ArticleStatusEnum.DRAFT.name());
			if(entity.getUserGeneratedContent() == null) {
				UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
				ugc.setTitle("");
				entity.setUserGeneratedContent(ugc);
			}
		}catch(IllegalContentIdException i){
			response.setError(CmsEditorStatus.INVALID_CONTENT_ID);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}catch(CmsEditorException c){
			response.setError(c.getError());
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
		try{
		ObjectId contentId = new ObjectId();
		entity.setContentId(contentId);
		UserGeneratedContentEntity uCOntent=entity.getUserGeneratedContent();
		List<GroupEntity> lsit = uCOntent.getGroups();
		String id = contentDraftDao.createContent(entity);
		
		if(StringUtils.isEmpty(id)){
			response.setError(CmsEditorStatus.CREATE_ERROR);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
		response.setContentId(contentId.toString());
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
		}catch(Exception e){
			response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
	}
	
	private void populateAuthorFields(UserIdentifier author) {
		if(CollectionUtils.isEmpty(providerTasks)){
			return;
		}
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetUserNameByIdTask) {
				GetUserNameByIdTaskResponse response = ((GetUserNameByIdTaskResponse) ((GetUserNameByIdTask) task)
						.getTaskResponse());
				author.setUsername(response.getUserName());
			} else if (task instanceof GetPublicUserIdByIdTask) {
				GetPublicUserIdByIdTaskResponse response = ((GetPublicUserIdByIdTaskResponse) ((GetPublicUserIdByIdTask) task)
						.getTaskResponse());
				author.setUserId(response.getPublicUserId());
			}
		}
	}


}
