package com.ebay.raptor.cmseditor.task;

import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;

public class CreateDraftTaskResponse extends CmsEditorTaskResponse{
	
	private String contentId;

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	
	

}
