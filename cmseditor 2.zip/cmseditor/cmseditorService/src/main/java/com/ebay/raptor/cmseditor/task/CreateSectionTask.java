package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.request.UpdateSectionRequest;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.CreateSectionTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateModuleTaskResponse;

import edu.emory.mathcs.backport.java.util.Collections;


public class CreateSectionTask extends CmsEditorTask{
	
	private ContentEntityAdaptor adaptor;
	private ContentDraftDao contentDraftDao;
	
	private static final Logger LOGGER = Logger.getInstance(CreateSectionTask.class);

	public CreateSectionTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
		adaptor =new ContentEntityAdaptor();
	}
	
	public CreateSectionTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao) {
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
		adaptor =new ContentEntityAdaptor();
	}
	
	@Override
	protected CmsEditorTaskResponse createResponse() {
		List<CmsEditorTaskResponse> taskResponses = getTaskResponses();
		if(CollectionUtils.isEmpty(taskResponses)){
			return createFailureResponse();
		}
		UpdateSectionRequest req = request.getUpdateSectionRequest();
		if(req==null){
			return createFailureResponse();
		}
		boolean isAdmin=false;
		boolean hasAccess=false;
		CreateSectionTaskResponse response = new CreateSectionTaskResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses){
			if(taskResponse instanceof GetUserPermissionsTaskResponse){
				Set<String> permissions = ((GetUserPermissionsTaskResponse) taskResponse).getPermissions();
				if(!CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name())){
					isAdmin=true;
				}
			} else if(taskResponse instanceof GetAccessControlListTaskResponse) {
				Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) taskResponse)
						.getContentEntityMap();
				if(contentEntityMap != null && contentEntityMap.get(req.getArticleId()) != null &&  !CollectionUtils.isEmpty(contentEntityMap.get(req.getArticleId()).getAccessControlList())) {
					hasAccess = contentEntityMap.get(req.getArticleId())
							.getAccessControlList()
							.contains(String.valueOf(request.getUserId()));
				}		
				
			}
		}
		if(!isAdmin && !hasAccess){
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
			return response;
		}
		
		try{
			createModule(req.getArticleId(), req.getGroupId(), req.getSection()); 
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setSection(req.getSection());
			return response;
			
		}catch(CmsEditorException c){
			LOGGER.log(LogLevel.ERROR,c);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(c.getError());
			return response;
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
	}

	protected CmsEditorTaskResponse getSuccessResponse(
			Section section) {
		UpdateModuleTaskResponse response = new UpdateModuleTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

	

	protected void createModule(String contentId, String groupId, Section section)
			throws Exception {
			DraftContentEntity draftContent = contentDraftDao.findContentById(contentId);
			if(draftContent == null) {
				throw new CmsEditorException(CmsEditorStatus.CONTENT_NOT_FOUND);
			}
			long maxModuleId = 0l;
			boolean groupFound=false;
			int sortOrder= section.getSequence();
			GroupEntity grp=null;
			if(!CollectionUtils.isEmpty(draftContent.getUserGeneratedContent().getGroups())) {
				for(GroupEntity group:draftContent.getUserGeneratedContent().getGroups()) {
					if(groupId.equals(group.getGroupId())) {
						grp=group;
						List<ModuleEntity> moduleEntities=null;
						if(group.getModuleMap()==null){
							moduleEntities=new ArrayList<ModuleEntity>();
							grp.setModuleMap(new HashMap<String, ModuleEntity>());
						}else{
							moduleEntities=new ArrayList<ModuleEntity>(group.getModuleMap().values());
							//Sort modules so the sort order can be incremented correctly if needed
							Collections.sort(moduleEntities);
						}
						int index=0;
		 				for(ModuleEntity moduleEntity:moduleEntities) {
		 					String moduleId = moduleEntity.getModuleId();
		 					maxModuleId = Math.max(maxModuleId, Long.valueOf(moduleId));
		 					if(index==sortOrder){
		 						index++;
		 					}
		 					moduleEntity.setSortOrder(index);
		 					index++;
		 				}
		 				groupFound=true;
		 				break;
					}
				}
			}
			if(!groupFound){
				throw new CmsEditorException(CmsEditorStatus.INVALID_GROUP_ID);
			}
			section.setSectionId(String.valueOf(maxModuleId + 1));
			if(grp!=null && grp.getModuleMap()!=null){
				grp.getModuleMap().put(section.getSectionId(), adaptor.adaptToModuleEntity(section));
			}
			
			contentDraftDao.save(draftContent);
	}
	

}