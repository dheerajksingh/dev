package com.ebay.raptor.cmseditor.field.validator;

import org.apache.commons.lang.StringUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;

public class ModerationStatusValidator implements IFieldValidator {

	public void validate(KeyValueImpl keyValue) throws CmsEditorException {
		if (StringUtils.isEmpty(keyValue.getKey())) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		if (!AllowedFields.getAllowedFields().contains(keyValue.getKey())) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		String value = (String) keyValue.getValue();
		try {
			if (StringUtils.isEmpty(value)) {
				throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
			}
			keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
			keyValue.setValue(ModerationStatusEnum.valueOf(value));
		} catch(Exception e) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
	}
}
