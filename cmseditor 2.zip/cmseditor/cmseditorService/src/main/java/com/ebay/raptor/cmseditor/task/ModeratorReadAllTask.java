package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentReadAllRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadAllTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class ModeratorReadAllTask extends CmsEditorTask{
	
	private ContentPublishDao contentPublishDao;
	private static final Logger LOGGER = Logger.getInstance(ModeratorReadAllTask.class);

	public ModeratorReadAllTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentPublishDao=request.getApplicationContext().getBean(ContentPublishDao.class);
	}

	public ModeratorReadAllTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentPublishDao contentPublishDao) {
		super(request, providerTasks);
		this.contentPublishDao=contentPublishDao;
	}
	@Override
	protected CmsEditorTaskResponse createResponse() {
		ContentReadAllRequest req = request.getContentReadAllRequest();
		if(req==null || CollectionUtils.isEmpty(req.getStatuses())){
			return createFailureResponse();
		}
		ContentReadAllTaskResponse response = new ContentReadAllTaskResponse();
		try{
		List<String> contentStatuses = convertContentStatusToString(req.getStatuses());
		List<String> moderationStatuses = convertModerationStatusToString(req.getModerationStatuses());
		if(ArticleStatusEnum.hasPublishedContent(req.getStatuses())){
			Set<String> permissions = findPermissions();
			if(CollectionUtils.isEmpty(permissions) || !permissions.contains(PermissionEnum.BLACKLIST_CONTENT.name())){
				response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				return response;
			}
			List<PublishedContentEntity> contents = contentPublishDao.findContents(req.getLimit(),req.getOffset(),req.getSort().getSort(),contentStatuses,moderationStatuses);
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setPublished(contents);
		}
		return response;
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
	}
	
	
	private Set<String> findPermissions() {
		if(CollectionUtils.isEmpty(providerTasks)){
			return new HashSet<String>();
		}
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse) ((GetUserPermissionsTask) task)
						.getTaskResponse());
				Set<String> permissions = permissionsResponse.getPermissions();
				return permissions;
			}
		}
		return new HashSet<String>();
	}
	

	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		ContentReadAllTaskResponse response = new ContentReadAllTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
	
	private List<String> convertContentStatusToString(List<ArticleStatusEnum> contentStatuses){
		List<String> statuses = new ArrayList<String>();
		if(CollectionUtils.isEmpty(contentStatuses)){
			return statuses;
		}
		for(ArticleStatusEnum status:contentStatuses){
			statuses.add(status.name());
		}
		return statuses;
		
	}
	
	private List<String> convertModerationStatusToString(List<ModerationStatusEnum> moderationStatuses){
		List<String> statuses = new ArrayList<String>();
		if(CollectionUtils.isEmpty(moderationStatuses)){
			return statuses;
		}
		for(ModerationStatusEnum status:moderationStatuses){
			statuses.add(status.name());
		}
		return statuses;
		
	}

}
