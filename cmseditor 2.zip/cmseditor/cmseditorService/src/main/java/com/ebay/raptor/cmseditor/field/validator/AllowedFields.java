package com.ebay.raptor.cmseditor.field.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AllowedFields {

//	public static final String MODERATION_STATUS = "moderationStatus";
//	public static final String CONTENT_STATUS = "contentStatus";
	public static final String TITLE="userGeneratedContent.title";
	public static final String SYNOPSIS="userGeneratedContent.synopsis";
	public static final String COVER_IMAGE="userGeneratedContent.coverImage";
	public static final String ACCESS_CONTROL_LIST="accessControlList";
	public static final String TAGS="userGeneratedContent.tags";
	public static final String MATERIALS_NEEDED="userGeneratedContent.materialsNeeded";
	public static final String TOOLS_NEEDED="userGeneratedContent.toolsNeeded";
	public static final String ESTIMATED_TIME = "userGeneratedContent.estimatedTime";
	public static final String DIFFICULTY_LEVEL = "userGeneratedContent.difficultyLevel";
	public static final String COST_RANGE = "userGeneratedContent.costRange";
	//public static final String CATEGORY1="userGeneratedContent.category1";
	//public static final String CATEGORY2="userGeneratedContent.category2";
	//public static final String CATEGORY3 = "userGeneratedContent.category3";
	public static final String CONCLUSION_TITLE = "userGeneratedContent.conclusionTitle";
	public static final String CONCLUSION_DESCRIPTION = "userGeneratedContent.conclusionDescription";
	public static final String MARKETING_ASSETS="userGeneratedContent.marketingAssets";
	public static final String SCHEDULED_START_DATE="scheduledStartDate";
	public static final String SCHEDULED_END_DATE="scheduledEndDate";
	public static final String CATEGORIES="userGeneratedContent.categories";
	
	
	
	public static final String AUTHOR="author";
	
	
	private static List<String> fields = new ArrayList<String>();
	private static Map<String, IFieldValidator> validatorMap = new HashMap<String, IFieldValidator>();
	private static Map<String, String> modelToEntityFieldMap = new HashMap<String, String>();
	
	static{
//		fields.add(MODERATION_STATUS);
//		fields.add(CONTENT_STATUS);
		fields.add(TITLE);
		fields.add(SYNOPSIS);
		fields.add(COVER_IMAGE);
		fields.add(ACCESS_CONTROL_LIST);
		fields.add(TAGS);
		fields.add(AUTHOR);
		fields.add(MATERIALS_NEEDED);
		fields.add(TOOLS_NEEDED);
		fields.add(ESTIMATED_TIME);
		fields.add(DIFFICULTY_LEVEL);
		fields.add(COST_RANGE);
		//fields.add(CATEGORY1);
		//fields.add(CATEGORY2);
		//fields.add(CATEGORY3);
		fields.add(CONCLUSION_TITLE);
		fields.add(CONCLUSION_DESCRIPTION);
		fields.add(MARKETING_ASSETS);
		fields.add(SCHEDULED_START_DATE);
		fields.add(SCHEDULED_END_DATE);
		fields.add(CATEGORIES);
		
		validatorMap.put(TITLE, new CosTextFieldValidator());
		validatorMap.put(SYNOPSIS, new CosTextFieldValidator());
		validatorMap.put(CONCLUSION_TITLE, new CosTextFieldValidator());
		validatorMap.put(CONCLUSION_DESCRIPTION, new CosTextFieldValidator());
		validatorMap.put(COVER_IMAGE, new CosImageFieldValidator());
		validatorMap.put(TAGS,new TagsFieldValidator());
		validatorMap.put(ACCESS_CONTROL_LIST,new AcessControlFieldValidator());
		validatorMap.put(MATERIALS_NEEDED, new ListCosTextFieldValidator());
		validatorMap.put(TOOLS_NEEDED, new ListCosTextFieldValidator());
		validatorMap.put(ESTIMATED_TIME, new CosTimeDurationValidator());
		validatorMap.put(MARKETING_ASSETS, new MarketingAssetsValidator());
		validatorMap.put(SCHEDULED_END_DATE,new CosDateTimeValidator());
		validatorMap.put(SCHEDULED_START_DATE,new CosDateTimeValidator());
		validatorMap.put(CATEGORIES,new MapValidator());
		
//		validatorMap.put(MODERATION_STATUS,new ModerationStatusValidator());
//		validatorMap.put(CONTENT_STATUS,new ContentStatusValidator());
		
//		modelToEntityFieldMap.put(MODERATION_STATUS, "moderationStatus");
//		modelToEntityFieldMap.put(CONTENT_STATUS, "contentStatus");
		modelToEntityFieldMap.put(AUTHOR, "authorName");
		modelToEntityFieldMap.put(TITLE,"userGeneratedContent.title");
		modelToEntityFieldMap.put(SYNOPSIS,"userGeneratedContent.synopsis");
		modelToEntityFieldMap.put(CONCLUSION_TITLE,"userGeneratedContent.conclusionTitle");
		modelToEntityFieldMap.put(CONCLUSION_DESCRIPTION,"userGeneratedContent.conclusionDescription");
		modelToEntityFieldMap.put(COVER_IMAGE, "userGeneratedContent.coverImage");
		modelToEntityFieldMap.put(ACCESS_CONTROL_LIST, "accessControlList");
		modelToEntityFieldMap.put(TAGS, "userGeneratedContent.tags");
		modelToEntityFieldMap.put(MATERIALS_NEEDED, "userGeneratedContent.materialsNeeded");
		modelToEntityFieldMap.put(TOOLS_NEEDED, "userGeneratedContent.toolsNeeded");
		modelToEntityFieldMap.put(ESTIMATED_TIME, "userGeneratedContent.estimatedTime");
		modelToEntityFieldMap.put(DIFFICULTY_LEVEL, "userGeneratedContent.difficultyLevel");
		modelToEntityFieldMap.put(COST_RANGE, "userGeneratedContent.costRange");
		modelToEntityFieldMap.put(MARKETING_ASSETS, "userGeneratedContent.marketingAssets");
		modelToEntityFieldMap.put(SCHEDULED_START_DATE, "scheduledStartDate");
		modelToEntityFieldMap.put(SCHEDULED_END_DATE, "scheduledEndDate");
		modelToEntityFieldMap.put(CATEGORIES, "userGeneratedContent.categories");
	}
	
	public static List<String> getAllowedFields(){
		return fields;
	}
	
	public static IFieldValidator getValidator(String fieldPath){
		return validatorMap.get(fieldPath);
	}
	
	public static String getEntityField(String modelFieldPath){
		return modelToEntityFieldMap.get(modelFieldPath);
	}

}
