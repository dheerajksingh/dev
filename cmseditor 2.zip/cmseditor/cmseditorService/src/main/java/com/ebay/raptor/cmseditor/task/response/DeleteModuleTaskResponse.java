package com.ebay.raptor.cmseditor.task.response;

public class DeleteModuleTaskResponse extends CmsEditorTaskResponse{
	
}
