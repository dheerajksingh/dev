package com.ebay.raptor.cmseditor.response.adaptor;

import java.util.HashMap;
import java.util.Map;

public class ContentFieldMapper {
	
	
	private static Map<String, String> modelToEntityFieldMap = new HashMap<String, String>();
	
	static{
		modelToEntityFieldMap.put("author", "authorName");
		modelToEntityFieldMap.put("userGeneratedContent.title.content","userGeneratedContent.title");
		modelToEntityFieldMap.put("userGeneratedContent.synopsis.content","userGeneratedContent.synopsis");
		modelToEntityFieldMap.put("userGeneratedContent.coverImage.imageURL", "userGeneratedContent.imageURL");
		
	}
	
	public static String getEntityField(String modelFieldPath){
		return modelToEntityFieldMap.get(modelFieldPath);
	}

}
