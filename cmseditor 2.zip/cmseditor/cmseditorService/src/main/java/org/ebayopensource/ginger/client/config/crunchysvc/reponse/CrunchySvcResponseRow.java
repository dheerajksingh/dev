package org.ebayopensource.ginger.client.config.crunchysvc.reponse;

public class CrunchySvcResponseRow {
	
	private CrunchySvcData data;

	public CrunchySvcData getData() {
		return data;
	}

	public void setData(CrunchySvcData data) {
		this.data = data;
	}
	
}
