package org.ebayopensource.ginger.client.config.crunchysvc.reponse;

import java.util.List;

public class CrunchySvcResponse {

	private List<CrunchySvcResponseRow> rows;

	public List<CrunchySvcResponseRow> getRows() {
		return rows;
	}

	public void setRows(List<CrunchySvcResponseRow> rows) {
		this.rows = rows;
	}
	
}
