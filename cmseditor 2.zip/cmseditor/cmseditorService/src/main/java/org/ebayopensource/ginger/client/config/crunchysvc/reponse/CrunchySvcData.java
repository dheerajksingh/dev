package org.ebayopensource.ginger.client.config.crunchysvc.reponse;

public class CrunchySvcData {

	private String __cbcontent;
	private String __cbkey;
	
	public String get__cbcontent() {
		return __cbcontent;
	}
	public void set__cbcontent(String __cbcontent) {
		this.__cbcontent = __cbcontent;
	}
	public String get__cbkey() {
		return __cbkey;
	}
	public void set__cbkey(String __cbkey) {
		this.__cbkey = __cbkey;
	}
	
}
