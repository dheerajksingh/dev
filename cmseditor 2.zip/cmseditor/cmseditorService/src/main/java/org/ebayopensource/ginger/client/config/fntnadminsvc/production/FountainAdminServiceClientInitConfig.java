package org.ebayopensource.ginger.client.config.fntnadminsvc.production;

import org.ebayopensource.ginger.client.config.fntnadminsvc.BaseFountainAdminServiceClientInitConfig;

import com.ebay.raptor.cmseditor.config.ConfigParam;

public class FountainAdminServiceClientInitConfig extends BaseFountainAdminServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.FOUNTAIN_ADMIN_SERVICE_ENDPOINT.getStringValue();
	}
	
}
