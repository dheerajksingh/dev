package com.ebay.raptor.cmseditor.resource;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.manager.CmsEditorManager;
import com.ebay.raptor.cmseditor.moderation.validator.ModerationValidator;
import com.ebay.raptor.cmseditor.request.AkismetCommentBuilder;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ArticleUpdateFieldRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.SortOrder;
import com.ebay.raptor.cmseditor.request.UpdateModerationStatusRequest;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadAllResponse;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadResponse;
import com.ebay.raptor.cmseditor.util.UserInfoUtil;
import com.ebay.spam.akismet.AkismetComment;

public class CmsEditorResourceTest {
	
	
	private static AkismetCommentBuilder builder;
	private static AkismetComment comment;
	private static HttpServletRequest httpRequest;
	
	static{
		comment=mock(AkismetComment.class);
		builder = mock(AkismetCommentBuilder.class);
		httpRequest=mock(HttpServletRequest.class);
		when(builder.buildAkismetComment(any(HttpServletRequest.class))).thenReturn(comment);
	}
	
	@Test
	public void testGetContents() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name());
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentsWithMultipleStatuses() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name()+","+ArticleStatusEnum.DRAFT.name());
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentsWithBadDelimiter() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name()+"!"+ArticleStatusEnum.DRAFT.name());
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INVALID_STATUSES.getMessage()));
		
	}
	
	@Test
	public void testGetContentsWithBadUserId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(-100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name());
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentsWithNullSort() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, null, ArticleStatusEnum.PUBLISHED.name());
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentsWithBadSort() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, "SORT", ArticleStatusEnum.PUBLISHED.name());
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
	}
	
	@Test
	public void testGetContentsWithNullFilter() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), null);
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentsWithBadFilter() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), "FILTER");
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INVALID_STATUSES.getMessage()));
		
	}
	
	
	@Test
	public void testGetContentsWithBadLimit() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(-1, 0, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name());
		assertNotNull(resp);
		ArticleReadAllResponse cmsResp = (ArticleReadAllResponse) resp.getEntity();
		assertNotNull(cmsResp);
		
	}
	
	@Test
	public void testGetContentsWithBadOffset() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, -1, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name());
		assertNotNull(resp);
		ArticleReadAllResponse cmsResp = (ArticleReadAllResponse) resp.getEntity();
		assertNotNull(cmsResp);
		
	}
	
	@Test
	public void testGetContentsWithException() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new NullPointerException());
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getUserArticles(10, 0, SortOrder.DATE_MODIFIED_ASC.name(), ArticleStatusEnum.PUBLISHED.name());
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR.getMessage()));
		
	}
	
	@Test
	public void testGetContent() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadResponse response = new ArticleReadResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getArticleById("1000",ArticleStatusEnum.DRAFT.name());
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentWithEmptyContentId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadResponse response = new ArticleReadResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getArticleById("",ArticleStatusEnum.DRAFT.name());
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.MISSING_CONTENT_ID.getMessage()));
		
	}
	
	@Test
	public void testGetContentWithNullContentId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadResponse response = new ArticleReadResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getArticleById(null,ArticleStatusEnum.DRAFT.name());
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.MISSING_CONTENT_ID.getMessage()));
		
	}
	
	@Test
	public void testGetContentWithEmptyStatus() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadResponse response = new ArticleReadResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getArticleById("1000",null);
		assertNotNull(resp);
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentWithBadStatus() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadResponse response = new ArticleReadResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getArticleById("1000","BAD");
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INVALID_STATUS.getMessage()));
		
	}
	
	@Test
	public void testGetContentWithException() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new NullPointerException());
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		Response resp=resource.getArticleById("1000",ArticleStatusEnum.DRAFT.name());
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR.getMessage()));
		
	}
	
	@Test
	public void testPublishContent() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		PublishArticleResponse response = new PublishArticleResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		Response resp=resource.publish("100");
		assertThat(resp.getEntity().getClass().getName(),is(PublishArticleResponse.class.getName()));
		
	}
	
	@Test
	public void testPublishContentWithNullDraftId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		PublishArticleResponse response = new PublishArticleResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		Response resp=resource.publish(null);
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.MISSING_CONTENT_ID.getMessage()));
		
	}
	
	@Test
	public void testPublishContentWithEmptyDraftId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		PublishArticleResponse response = new PublishArticleResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		Response resp=resource.publish("");
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.MISSING_CONTENT_ID.getMessage()));
		
	}
	
	@Test
	public void testPublishContentWithException() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new NullPointerException());
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		Response resp=resource.publish("100");
		assertNotNull(resp);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR.getMessage()));
		
	}
	
	@Test
	public void testUpdateAttribute() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		ArticleUpdateFieldRequest req = new ArticleUpdateFieldRequest();
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		req.setKeyValues(keyValues);
		Response resp=resource.updateAttribute("100", req);
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
	}
	
	@Test
	public void testUpdateAttributeWithNullContentId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		ArticleUpdateFieldRequest req = new ArticleUpdateFieldRequest();
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		req.setKeyValues(keyValues);
		Response resp=resource.updateAttribute(null, req);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.MISSING_CONTENT_ID.getMessage()));
	}
	
	@Test
	public void testFlagContentWithNullContentId() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		
		
		Response resp=resource.moderate(null, null);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.MISSING_CONTENT_ID.getMessage()));
	}
	
	@Test
	public void testFlagContentWithNoUserAndNoSystem() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(-1L);
		when(userInfo.isAuthorizedApplication()).thenReturn(false);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		UpdateModerationStatusRequest req= new UpdateModerationStatusRequest();
		req.setStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		Response resp=resource.moderate("100",req);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.USER_ACCESS_ERROR.getMessage()));
	}
	
	@Test
	public void testFlagContentWithNoUser() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(-1L);
		when(userInfo.isAuthorizedApplication()).thenReturn(false);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		
		UpdateModerationStatusRequest req= new UpdateModerationStatusRequest();
		req.setStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		Response resp=resource.moderate("100",req);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.USER_ACCESS_ERROR.getMessage()));
	}
	
	@Test
	public void testFlagContentWithNoUserWithSystem() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(-1L);
		when(userInfo.isAuthorizedApplication()).thenReturn(true);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		
		UpdateModerationStatusRequest req= new UpdateModerationStatusRequest();
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		Response resp=resource.updateStatus("100",req);
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(resp.getStatus(),is(204));
	}
	
	@Test
	public void testFlagContentWithUser() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(userInfo.isAuthorizedApplication()).thenReturn(true);
		CmsEditorResponse response = new CmsEditorResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo, builder, context);
		resource.setModerationValidator(validator);
		
		UpdateModerationStatusRequest req= new UpdateModerationStatusRequest();
		req.setStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		Response resp=resource.viewerReportSpam("100");
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(resp.getStatus(),is(204));
	}
	@Test
	public void testFlagContentWithUserAndCmsEditorException() throws CmsEditorException{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(userInfo.isAuthorizedApplication()).thenReturn(true);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new CmsEditorException(CmsEditorStatus.CONTENT_NOT_FOUND));
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		
		UpdateModerationStatusRequest req= new UpdateModerationStatusRequest();
		req.setStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		Response resp=resource.moderate("100",req);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.CONTENT_NOT_FOUND.getMessage()));
	}
	
	@Test
	public void testFlagContentWithUserAndException() throws Throwable{
		
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(userInfo.isAuthorizedApplication()).thenReturn(true);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new NullPointerException());
		CmsEditorResource resource = new CmsEditorResource(manager,context,userInfo,builder,httpRequest);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		
		UpdateModerationStatusRequest req= new UpdateModerationStatusRequest();
		req.setStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		Response resp=resource.moderate("100",req);
		CmsEditorResponse cmsResp = (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(cmsResp.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR.getMessage()));
	}
	
	

	@Test
	public void testGetContentsForModeration() throws CmsEditorException{
		 
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		when(manager.manage(any(CmsEditorRequest.class))).thenReturn(response);
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		Response resp=resource.getArticlesForModeration(0,0,"-dateModfied","SPAM_CONFIRMED", "MODERATED");
		assertThat(resp.getEntity().getClass().getName(),is(ArticleReadAllResponse.class.getName()));
		
	}
	
	@Test
	public void testGetContentsForModerationWithCmsEditorException() throws CmsEditorException{
		 
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new CmsEditorException(CmsEditorStatus.INVALID_MODERATION_STATUS));
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		Response resp=resource.getArticlesForModeration(0,0,"-dateModfied","SPAM_CONFIRMED", "MODERATED");
		CmsEditorResponse response =  (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(response.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INVALID_MODERATION_STATUS.getMessage()));
		
	}
	
	@Test
	public void testGetContentsForModerationWithException() throws Throwable{
		 
		CmsEditorManager manager = mock(CmsEditorManager.class);
		ApplicationContext context = mock(ApplicationContext.class);
		UserInfoUtil userInfo = mock(UserInfoUtil.class);
		when(userInfo.getSignedInUserId()).thenReturn(100L);
		when(manager.manage(any(CmsEditorRequest.class))).thenThrow(new NullPointerException());
		CmsEditorResource resource = new CmsEditorResource(manager,context,null,userInfo);
		ModerationValidator validator = new ModerationValidator(userInfo,  builder, context);
		resource.setModerationValidator(validator);
		Response resp=resource.getArticlesForModeration(0,0,"-dateModfied","SPAM_CONFIRMED", "MODERATED");
		CmsEditorResponse response =  (CmsEditorResponse) resp.getEntity();
		assertThat(resp.getEntity().getClass().getName(),is(CmsEditorResponse.class.getName()));
		assertThat(response.getErrorMessage().getError().get(0).getMessage(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR.getMessage()));
		
	}
}