package com.ebay.raptor.cmseditor.manager;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.response.composer.BulkContentResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.CmsEditorResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.ComposerFactory;
import com.ebay.raptor.cmseditor.response.composer.ContentReadAllResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.ContentReadResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.CreateDraftResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.DeleteModuleResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.IResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.PublishContentResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.UpdateContentFieldResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.UpdateContentResponseComposer;
import com.ebay.raptor.cmseditor.response.composer.UpdateModuleResponseComposer;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;

public class ComposerFactoryTest {
	
	@Test
	public void testComposeWithNullRequest(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadTaskResponse taskResponse = new ContentReadTaskResponse();
		taskResponses.add(taskResponse);
		IResponseComposer composer=factory.getComposer(taskResponses, null);
		assertEquals(composer,null);
		
	}
	
	
	@Test
	public void testComposeWithNoSelector(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadTaskResponse taskResponse = new ContentReadTaskResponse();
		taskResponses.add(taskResponse);
		CmsEditorRequest request = new CmsEditorRequest();
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertEquals(composer,null);
		
	}
	
	@Test
	public void testCompose1(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.BULK_CREATE_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(BulkContentResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose2(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.BULK_DELETE_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(BulkContentResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose3(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.CREATE_DRAFT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(CreateDraftResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose4(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.DELETE_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(UpdateContentResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose5(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.DELETE_MODULE);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(DeleteModuleResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose6(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.GET_FOR_EDIT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(ContentReadResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose7(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.PUBLISH_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(PublishContentResponseComposer.class.getClass()));
		
	}
	

	@Test
	public void testCompose8(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.READ_ALL_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(ContentReadAllResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose9(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.READ_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(ContentReadResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose10(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(UpdateContentResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose11(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_CONTENT_ATTRIBUTE);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(UpdateContentFieldResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose12(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_MODULE);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(UpdateModuleResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose13(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_STATUS_FOR_MODERATION);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(CmsEditorResponseComposer.class.getClass()));
		
	}
	
	@Test
	public void testCompose15(){
		
		ComposerFactory factory = new ComposerFactory();
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.GET_FOR_MODERATION);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		IResponseComposer composer=factory.getComposer(taskResponses, request);
		assertThat(composer.getClass(),is(ContentReadAllResponseComposer.class.getClass()));
		
	}

}
