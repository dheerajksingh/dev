package com.ebay.raptor.cmseditor.task;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.DeleteGroupRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.DeleteGroupTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class DeleteGroupTaskTest {
	
	@Test
	public void testDeleteGroup() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		DeleteGroupTaskResponse delTaskRespons=(DeleteGroupTaskResponse) task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(entity.getUserGeneratedContent().getGroups().size(),is(0));
	}
	

	@Test
	public void testDeleteGroupNullRequest() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse delTaskRespons=task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testDeleteGroupNoAdminNoAccess() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		DeleteGroupTaskResponse delTaskRespons=(DeleteGroupTaskResponse) task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
	}

	@Test
	public void testDeleteGroupNoAdmin() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.DELETE_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		DeleteGroupTaskResponse delTaskRespons=(DeleteGroupTaskResponse) task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(entity.getUserGeneratedContent().getGroups().size(),is(0));
	}
	
	

	@Test
	public void testDeleteGroupNotFound() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("2");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		DeleteGroupTaskResponse delTaskRespons=(DeleteGroupTaskResponse) task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.GROUP_NOT_FOUND));
		assertThat(entity.getUserGeneratedContent().getGroups().size(),is(1));
	}
	
	@Test
	public void testDeleteGroupContentNotFound() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(null);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse delTaskRespons=task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
	}
	
	@Test
	public void testDeleteGroupBadContentId() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9fa4")).thenThrow(new IllegalArgumentException());
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse delTaskRespons=task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
	}
	
	
	@Test
	public void testDeleteGroupError() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse delTaskRespons=task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testDeleteGroupGenericError() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		DeleteGroupRequest deleteGrpRequest = new DeleteGroupRequest();
		deleteGrpRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteGrpRequest.setGroupId("1");
		request.setDeleteGroupRequest(deleteGrpRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new Exception());
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteGroupTask task = new DeleteGroupTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse delTaskRespons=task.createResponse();
		assertThat(delTaskRespons.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(delTaskRespons.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
}
