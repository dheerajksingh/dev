package com.ebay.raptor.cmseditor.dao;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mongodb.morphia.AdvancedDatastore;


import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;

public class ContentDraftDaoTest {
	
	
	@Test
	public void testFindContentById() throws Exception{
		
//		DatastoreImpl ds = mock(DatastoreImpl.class);
//		Mapper mapper = mock(Mapper.class);
//		MappedClass mappedClass = mock(MappedClass.class);
//		when(ds.getMapper()).thenReturn(mapper);
//		when(mapper.addMappedClass(DraftContentEntity.class)).thenReturn(mappedClass);
//		
//		ContentDraftDaoEx dao = new ContentDraftDaoEx(ds);
//		DraftContentEntity entity1 = new DraftContentEntity();
//		dao.setEntity(entity1);
//		assertThat(dao.findContentById("100"),is(entity1));
	}
	
	
	public class ContentDraftDaoEx extends ContentDraftDao{
		
		private DraftContentEntity entity;

		public ContentDraftDaoEx(AdvancedDatastore ds) {
			super(ds);
		}

		@Override
		public DraftContentEntity get(ObjectId id) {
			return entity;
		}

		public void setEntity(DraftContentEntity entity) {
			this.entity = entity;
		}
		
		
		
		
	}

}
