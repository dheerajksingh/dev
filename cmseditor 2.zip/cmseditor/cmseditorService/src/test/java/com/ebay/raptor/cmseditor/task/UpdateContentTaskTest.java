package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mockito.Mockito;
import org.mongodb.morphia.Key;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentUpdateRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.TemplateType;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateContentTaskResponse;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UpdateContentTaskTest {
	
	
	@Test
	public void testUpdateContentTask() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		Article article = new Article();
		article.setArticleId("57fff8ec399d3167c9e53fa4");
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType(TemplateType.HOW_TO.name());
		updateRequest.setContentEntity(article);
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		when(contentDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		Key<DraftContentEntity> key = mock(Key.class);
		when(contentDao.save(entity)).thenReturn(key);
		
		UpdateContentTask updateContentTask = new UpdateContentTask(request, providers,contentDao);
		UpdateContentTaskResponse response=(UpdateContentTaskResponse) updateContentTask.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testUpdateContentTaskNoPermission() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		Article article = new Article();
		article.setArticleId("57fff8ec399d3167c9e53fa4");
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType(TemplateType.HOW_TO.name());
		updateRequest.setContentEntity(article);
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		when(contentDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		Key<DraftContentEntity> key = mock(Key.class);
		when(contentDao.save(entity)).thenReturn(key);
		
		UpdateContentTask updateContentTask = new UpdateContentTask(request, providers,contentDao);
		UpdateContentTaskResponse response=(UpdateContentTaskResponse) updateContentTask.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(response.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
	}
	
	@Test
	public void testUpdateContentTaskAdmin() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		Article article = new Article();
		article.setArticleId("57fff8ec399d3167c9e53fa4");
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType(TemplateType.HOW_TO.name());
		updateRequest.setContentEntity(article);
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		when(contentDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		Key<DraftContentEntity> key = mock(Key.class);
		when(contentDao.save(entity)).thenReturn(key);
		
		UpdateContentTask updateContentTask = new UpdateContentTask(request, providers,contentDao);
		UpdateContentTaskResponse response=(UpdateContentTaskResponse) updateContentTask.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

	@Test
	public void testUpdateContentTaskCmsEditorException() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		Article article = new Article();
		article.setArticleId("57fff8ec399d3167c9e53fa4");
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType(TemplateType.HOW_TO.name());
		updateRequest.setContentEntity(article);
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		when(contentDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		Key<DraftContentEntity> key = mock(Key.class);
		when(contentDao.save(entity)).thenReturn(key);
		
		UpdateContentTask updateContentTask = new UpdateContentTask(request, providers,contentDao);
		UpdateContentTaskResponse response=(UpdateContentTaskResponse) updateContentTask.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(response.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testUpdateContentTaskIllegalArgumentException() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		Article article = new Article();
		article.setArticleId("57fff8ec399d3167c9e53fa4");
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType(TemplateType.HOW_TO.name());
		updateRequest.setContentEntity(article);
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		when(contentDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new IllegalArgumentException());
		Key<DraftContentEntity> key = mock(Key.class);
		when(contentDao.save(entity)).thenReturn(key);
		
		UpdateContentTask updateContentTask = new UpdateContentTask(request, providers,contentDao);
		UpdateContentTaskResponse response=(UpdateContentTaskResponse) updateContentTask.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(response.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
	}
	

	@Test
	public void testUpdateContentTaskGenericException() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		Article article = new Article();
		article.setArticleId("57fff8ec399d3167c9e53fa4");
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType(TemplateType.HOW_TO.name());
		updateRequest.setContentEntity(article);
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		when(contentDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new RuntimeException());
		Key<DraftContentEntity> key = mock(Key.class);
		when(contentDao.save(entity)).thenReturn(key);
		
		UpdateContentTask updateContentTask = new UpdateContentTask(request, providers,contentDao);
		UpdateContentTaskResponse response=(UpdateContentTaskResponse) updateContentTask.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(response.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
}
