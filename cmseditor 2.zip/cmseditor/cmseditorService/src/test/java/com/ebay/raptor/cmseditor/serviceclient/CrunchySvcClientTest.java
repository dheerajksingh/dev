package com.ebay.raptor.cmseditor.serviceclient;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.config.crunchysvc.reponse.CrunchySvcData;
import org.ebayopensource.ginger.client.config.crunchysvc.reponse.CrunchySvcResponse;
import org.ebayopensource.ginger.client.config.crunchysvc.reponse.CrunchySvcResponseRow;
import org.junit.Test;

import edu.emory.mathcs.backport.java.util.Arrays;

public class CrunchySvcClientTest {

	@Test
	public void testGetUserWithValidArticleId() {
		
		
		GingerClient gingerClient = mock(GingerClient.class);
		GingerWebTarget target = mock(GingerWebTarget.class);
		Invocation.Builder builder = mock(Invocation.Builder.class);
		GingerClientResponse gingerResponse = mock(GingerClientResponse.class);
		CrunchySvcResponse response = new CrunchySvcResponse();
		CrunchySvcData data = new CrunchySvcData();
		data.set__cbcontent("12");
		data.set__cbkey("abc");
		CrunchySvcResponseRow row = new CrunchySvcResponseRow();
		row.setData(data);
		List<CrunchySvcResponseRow> rows = new ArrayList<CrunchySvcResponseRow>();
		rows.add(row);
		response.setRows(rows);
		
		when(gingerResponse.getEntity(CrunchySvcResponse.class)).thenReturn(response);
		when(builder.get()).thenReturn(gingerResponse);
		when(target.request(MediaType.APPLICATION_JSON)).thenReturn(builder);
		when(target.queryParam(any(String.class), any())).thenReturn(target);
		when(gingerClient.target(any(String.class))).thenReturn(target);
		
		CrunchyServiceClient client = new CrunchyServiceClient();
		client.client = gingerClient;
		Map<String, Long> clientResponse = client.getArticleViews(Arrays.asList(new String[]{"abc"}));
		assertTrue(clientResponse.get("abc").equals(12l));
		
	}
	
	@Test
	public void testGetUserWithNullArticleIds() {
		
		CrunchyServiceClient client = new CrunchyServiceClient();
		Map<String, Long> response = client.getArticleViews(null);
		assertTrue(response.isEmpty());
		
	}
	
	@Test
	public void testGetUserWithEmptyArticleIds() {
		
		CrunchyServiceClient client = new CrunchyServiceClient();
		Map<String, Long> response = client.getArticleViews(new ArrayList<String>());
		assertTrue(response.isEmpty());
		
	}
	
}
