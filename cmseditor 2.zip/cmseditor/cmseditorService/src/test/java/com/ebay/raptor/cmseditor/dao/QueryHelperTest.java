package com.ebay.raptor.cmseditor.dao;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mongodb.morphia.query.QueryImpl;

import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;
import com.mongodb.DBObject;


public class QueryHelperTest {

	@Test
	public void testQueryAsList(){
		
		QueryImpl<DraftContentEntity> query = mock(QueryImpl.class);
		DBObject dbObject = mock(DBObject.class);
		when(query.getQueryObject()).thenReturn(dbObject);
		when(dbObject.toString()).thenReturn("string");
		List<DraftContentEntity> entities = new ArrayList<DraftContentEntity>();
		when(query.asList()).thenReturn(entities);
		QueryHelper helper = new QueryHelper();
		List<DraftContentEntity> actualEntities =helper.asList(query, "dao", "query");
		assertNotNull(actualEntities);
		assertThat(actualEntities,is(entities));
	}
	
	@Test
	public void testQueryGet(){
		
		QueryImpl<DraftContentEntity> query = mock(QueryImpl.class);
		DBObject dbObject = mock(DBObject.class);
		when(query.getQueryObject()).thenReturn(dbObject);
		when(dbObject.toString()).thenReturn("string");
		DraftContentEntity entity = new DraftContentEntity();
		when(query.get()).thenReturn(entity);
		QueryHelper helper = new QueryHelper();
		DraftContentEntity actualEntity =helper.get(query, "dao", "query");
		assertNotNull(actualEntity);
		assertThat(actualEntity,is(entity));
	}
}