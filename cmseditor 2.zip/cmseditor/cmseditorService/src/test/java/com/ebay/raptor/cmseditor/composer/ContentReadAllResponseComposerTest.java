package com.ebay.raptor.cmseditor.composer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.adaptor.ContentModelAdaptor;
import com.ebay.raptor.cmseditor.response.composer.ContentReadAllResponseComposer;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadAllResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadAllTaskResponse;

public class ContentReadAllResponseComposerTest {
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithTaskStatusNull() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadAllTaskResponse taskResponse = new ContentReadAllTaskResponse();
		taskResponses.add(taskResponse);
		
		ContentReadAllResponseComposer composer = new ContentReadAllResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithNoTaskResponses() throws Throwable{
		ContentReadAllResponseComposer composer = new ContentReadAllResponseComposer(null);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithEmptyTaskResponses() throws Throwable{
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadAllResponseComposer composer = new ContentReadAllResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithFailedStatus() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadAllTaskResponse taskResponse = new ContentReadAllTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		taskResponse.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		taskResponses.add(taskResponse);
		
		ContentReadAllResponseComposer composer = new ContentReadAllResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test
	public void testComposewithNoDraftsAndPublished() throws CmsEditorException{
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadAllTaskResponse taskResponse = new ContentReadAllTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		taskResponses.add(taskResponse);
		ContentReadAllResponseComposer composer = new ContentReadAllResponseComposer(taskResponses);
		
		assertNotNull(composer.compose());
		
	}
	
	@Test
	public void testComposewithDraftsAndPublished() throws CmsEditorException{
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadAllTaskResponse taskResponse = new ContentReadAllTaskResponse();
		List<DraftContentEntity> drafts = new ArrayList<DraftContentEntity>();
		DraftContentEntity draft = new DraftContentEntity();
		drafts.add(draft);
		List<PublishedContentEntity> publishedEntities = new ArrayList<PublishedContentEntity>();
		PublishedContentEntity published = new PublishedContentEntity();
		publishedEntities.add(published);
		taskResponse.setDrafts(drafts);
		taskResponse.setPublished(publishedEntities);
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		

		
		
		taskResponses.add(taskResponse);
		ContentReadAllResponseComposer composer = new ContentReadAllResponseComposer(taskResponses);
		ContentModelAdaptor adaptor = mock(ContentModelAdaptor.class);
		List<Article> models1 = new ArrayList<Article>();
		Article m1 = new Article();
		models1.add(m1);
		when(adaptor.adaptToContentModelsFromDraft(taskResponse.getDrafts())).thenReturn(models1);
		List<Article> models2 = new ArrayList<Article>();
		Article m2 = new Article();
		models2.add(m2);
		when(adaptor.adaptToContentModelsFromPublished(taskResponse.getPublished())).thenReturn(models2);
		composer.setAdaptor(adaptor);
		ArticleReadAllResponse response = (ArticleReadAllResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getArticles().size(),is(2));
		
	}
}