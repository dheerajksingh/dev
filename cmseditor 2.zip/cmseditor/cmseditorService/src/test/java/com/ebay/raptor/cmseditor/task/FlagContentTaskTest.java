package com.ebay.raptor.cmseditor.task;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.mockito.Mockito;

import com.ebay.raptor.besevents.ArticleStatusChangeEvent;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.UpdateModerationStatusRequest;
import com.ebay.raptor.cmseditor.request.ModerationActorEnum;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.UpdateModerationStatusTask.BESHandler;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.spam.akismet.AkismetComment;

public class FlagContentTaskTest {
	
	@Test
	public void testFlagTaskwithNullRequest(){
		
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(null, null,null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testFlagTaskwithNullFlagRequest(){
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, null,null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testFlagTaskwithNullActorAndIdentifier(){
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setStatus("SPAM");
		request.setFlagContentRequest(req);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, new ArrayList<ICmsEditorTask>(),null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testFlagTaskwithInsufficientPermissions2(){
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.PUBLISHED.name());
		request.setFlagContentRequest(req);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, new ArrayList<ICmsEditorTask>(),null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testUnFlagTaskWithModerator() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.MODERATOR);
		req.setStatus(ArticleStatusEnum.PUBLISHED.name());
		AkismetComment comment = new AkismetComment();
		comment.setReferrer("referrer");
		req.setAkismetComment(comment);
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testUnFlagTaskWithSystem() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.SYSTEM);
		req.setStatus(ArticleStatusEnum.PUBLISHED.name());
		AkismetComment comment = new AkismetComment();
		comment.setReferrer("referrer");
		req.setAkismetComment(comment);
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithModerator() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.MODERATOR);
		req.setStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		AkismetComment comment = new AkismetComment();
		comment.setReferrer("referrer");
		req.setAkismetComment(comment);
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleStatusChangeEvent(any(ArticleStatusChangeEvent.class));
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao,besHandler);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskToLiveWithModerator() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.MODERATOR);
		req.setStatus(ArticleStatusEnum.PUBLISHED.name());
		AkismetComment comment = new AkismetComment();
		comment.setReferrer("referrer");
		req.setAkismetComment(comment);
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleStatusChangeEvent(any(ArticleStatusChangeEvent.class));
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao,besHandler);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithNoActor() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActorIdentifier("100");
		AkismetComment comment = new AkismetComment();
		comment.setReferrer("referrer");
		req.setAkismetComment(comment);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleStatusChangeEvent(any(ArticleStatusChangeEvent.class));
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao,besHandler);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithSystem() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.SYSTEM);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndNoContent() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		when(publishDao.findContentById(any(String.class))).thenReturn(null);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndBadContent() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		when(publishDao.findContentById(any(String.class))).thenThrow(new IllegalArgumentException());
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndException() throws Throwable{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		when(publishDao.findContentById(any(String.class))).thenThrow(new NullPointerException());
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndNoSpamUsers() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActorIdentifier("100");
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndSpamUsersLessThanThreshold() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		req.setActorIdentifier("300");
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		Set<String> users = new HashSet<String>();
		users.add("100");
		users.add("200");
		users.add("300");
		users.add("400");
		entity.setUsersMarkedSpam(users);
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndSpamUsersEquaToThreshold() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		req.setActorIdentifier("500");
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(2);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.SPAM_CONFIRMED.name());
		entity.setUsersMarkedSpamCount(4);
		Set<String> users = new HashSet<String>();
		users.add("100");
		users.add("200");
		users.add("300");
		users.add("400");
		entity.setUsersMarkedSpam(users);
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndFailureToUpdate() throws Exception{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		req.setActorIdentifier("500");
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenReturn(0);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		Set<String> users = new HashSet<String>();
		users.add("100");
		users.add("200");
		users.add("300");
		users.add("400");
		entity.setUsersMarkedSpam(users);
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testFlagTaskWithUserAndUpdateException() throws Throwable{
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateModerationStatusRequest req = new UpdateModerationStatusRequest();
		req.setActor(ModerationActorEnum.USER);
		req.setStatus(ArticleStatusEnum.SPAM_SUSPECTED.name());
		req.setActorIdentifier("500");
		request.setFlagContentRequest(req);
		List<ICmsEditorTask> tasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTaskResponse permissionsTaskResponse = mock(GetUserPermissionsTaskResponse.class);
		Set<String> permissions = new HashSet<String>();
		when(permissionsTaskResponse.getPermissions()).thenReturn(permissions);
		GetUserPermissionsTask permissionsTask = mock(GetUserPermissionsTask.class);
		when(permissionsTask.getTaskResponse()).thenReturn(permissionsTaskResponse);
		tasks.add(permissionsTask);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(publishDao.updateContentField(any(String.class), any(List.class))).thenThrow(new NullPointerException());
		when(publishDao.findContentById(any(String.class))).thenReturn(entity);
		UpdateModerationStatusTask task = new UpdateModerationStatusTask(request, tasks,publishDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}



}