package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;

import org.junit.Test;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetPublicUserIdByIdTaskResponse;
import com.ebay.userlookup.UserLookup;
import com.ebay.userlookup.common.ClientException;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;

public class GetPublicUserIdByIdTaskTest {
	
	
	@Test
	public void testGetPublicUserId() throws ClientException{
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getPublicUserId(100L)).thenReturn("abcd");
		GetPublicUserIdByIdTask task = 
				new GetPublicUserIdByIdTask(request, new ArrayList<ICmsEditorTask>(),userLookup);
		
		GetPublicUserIdByIdTaskResponse taskResponse=(GetPublicUserIdByIdTaskResponse) task.createResponse();
		
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(taskResponse.getPublicUserId(),is("abcd"));
		
	}
	
	@Test
	public void testGetPublicUserIdNull() throws ClientException{
		CmsEditorRequest request = new CmsEditorRequest();
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getPublicUserId(100L)).thenReturn("abcd");
		GetPublicUserIdByIdTask task = 
				new GetPublicUserIdByIdTask(request, new ArrayList<ICmsEditorTask>(),userLookup);
		
		GetPublicUserIdByIdTaskResponse taskResponse=(GetPublicUserIdByIdTaskResponse) task.createResponse();
		
		assertNotNull(taskResponse);
		
	}
	
	@Test
	public void testGetPublicUserIdInvalid() throws ClientException{
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(-1L);
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getPublicUserId(100L)).thenReturn("abcd");
		GetPublicUserIdByIdTask task = 
				new GetPublicUserIdByIdTask(request, new ArrayList<ICmsEditorTask>(),userLookup);
		
		GetPublicUserIdByIdTaskResponse taskResponse=(GetPublicUserIdByIdTaskResponse) task.createResponse();
		
		assertNotNull(taskResponse);
		
	}
	
	@Test
	public void testGetPublicUserIdUserNotFound() throws ClientException{
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getPublicUserId(100L)).thenThrow(new ClientException(404, "error"));
		GetPublicUserIdByIdTask task = 
				new GetPublicUserIdByIdTask(request, new ArrayList<ICmsEditorTask>(),userLookup);
		
		GetPublicUserIdByIdTaskResponse taskResponse=(GetPublicUserIdByIdTaskResponse) task.createResponse();
		
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.USER_DOES_NOT_EXIST));
		
	}
	
	@Test
	public void testGetPublicUserIdException() throws ClientException {
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getPublicUserId(100L)).thenThrow(new ClientException(500, "error"));
		GetPublicUserIdByIdTask task = 
				new GetPublicUserIdByIdTask(request, new ArrayList<ICmsEditorTask>(),userLookup);
		
		GetPublicUserIdByIdTaskResponse taskResponse=(GetPublicUserIdByIdTaskResponse) task.createResponse();
		
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}


}
