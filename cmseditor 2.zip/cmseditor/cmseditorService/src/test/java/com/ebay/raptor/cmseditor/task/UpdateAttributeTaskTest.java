package com.ebay.raptor.cmseditor.task;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mockito.Mockito;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleUpdateFieldRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateContentFieldTaskResponse;

public class UpdateAttributeTaskTest {
	
	@Test
	public void testUpdateAttribute(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ArticleUpdateFieldRequest updateReq = new ArticleUpdateFieldRequest();
		updateReq.setArticleId("57fff8ec399d3167c9e53fa4");
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.name());
		kv.setValue(false);
		keyValues.add(kv);
		updateReq.setKeyValues(keyValues);
		
		request.setContentUpdateFieldRequest(updateReq);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		Mockito.doNothing().when(contentDao).updateContentField(updateReq.getArticleId(), keyValues);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		UpdateAttributeTask task = new UpdateAttributeTask(request, providers,contentDao);
		UpdateContentFieldTaskResponse taskResponse=(UpdateContentFieldTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

	@Test
	public void testUpdateAttributeNullRequest(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		UpdateAttributeTask task = new UpdateAttributeTask(request, providers,contentDao);
		CmsEditorTaskResponse taskResponse= task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
	}
	
	@Test
	public void testUpdateAttributeNoUserAccess(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ArticleUpdateFieldRequest updateReq = new ArticleUpdateFieldRequest();
		updateReq.setArticleId("57fff8ec399d3167c9e53fa4");
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.name());
		kv.setValue(false);
		keyValues.add(kv);
		updateReq.setKeyValues(keyValues);
		
		request.setContentUpdateFieldRequest(updateReq);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		Mockito.doNothing().when(contentDao).updateContentField(updateReq.getArticleId(), keyValues);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		UpdateAttributeTask task = new UpdateAttributeTask(request, providers,contentDao);
		UpdateContentFieldTaskResponse taskResponse=(UpdateContentFieldTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
	}
	
	@Test
	public void testUpdateAttributeNoUserAccess2(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ArticleUpdateFieldRequest updateReq = new ArticleUpdateFieldRequest();
		updateReq.setArticleId("57fff8ec399d3167c9e53fa4");
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.name());
		kv.setValue(false);
		keyValues.add(kv);
		updateReq.setKeyValues(keyValues);
		
		request.setContentUpdateFieldRequest(updateReq);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		Mockito.doNothing().when(contentDao).updateContentField(updateReq.getArticleId(), keyValues);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("200");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		UpdateAttributeTask task = new UpdateAttributeTask(request, providers,contentDao);
		UpdateContentFieldTaskResponse taskResponse=(UpdateContentFieldTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
	}
	
	@Test
	public void testUpdateAttributeInternalServerError(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ArticleUpdateFieldRequest updateReq = new ArticleUpdateFieldRequest();
		updateReq.setArticleId("57fff8ec399d3167c9e53fa4");
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.name());
		kv.setValue(false);
		keyValues.add(kv);
		updateReq.setKeyValues(keyValues);
		
		request.setContentUpdateFieldRequest(updateReq);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		Mockito.doThrow(new RuntimeException()).when(contentDao).updateContentField(updateReq.getArticleId(), keyValues);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		UpdateAttributeTask task = new UpdateAttributeTask(request, providers,contentDao);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testUpdateAttributeAdmin(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ArticleUpdateFieldRequest updateReq = new ArticleUpdateFieldRequest();
		updateReq.setArticleId("57fff8ec399d3167c9e53fa4");
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.name());
		kv.setValue(false);
		keyValues.add(kv);
		updateReq.setKeyValues(keyValues);
		
		request.setContentUpdateFieldRequest(updateReq);
		
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		Mockito.doNothing().when(contentDao).updateContentField(updateReq.getArticleId(), keyValues);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		UpdateAttributeTask task = new UpdateAttributeTask(request, providers,contentDao);
		UpdateContentFieldTaskResponse taskResponse=(UpdateContentFieldTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

}
