package com.ebay.raptor.besevents;

import com.ebay.bes.common.BusinessEvent;

public class ArticleEvent extends BusinessEvent {
	
	private String articleId;

	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	
	@Override
	public String toString() {
		return "ArticleEvent - articleId=" + articleId + " ";
	}
}
