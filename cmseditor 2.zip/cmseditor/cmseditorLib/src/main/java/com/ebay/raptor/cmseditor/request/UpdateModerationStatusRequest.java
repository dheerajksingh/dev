package com.ebay.raptor.cmseditor.request;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ebay.spam.akismet.AkismetComment;

public class UpdateModerationStatusRequest {

	@JsonIgnore
	private String articleId;
	@JsonIgnore
	private ModerationActorEnum actor;
	@JsonIgnore
	private String actorIdentifier;
	
	private String status;
	
	@JsonIgnore
	private AkismetComment akismetComment;
	
	public ModerationActorEnum getActor() {
		return actor;
	}
	public void setActor(ModerationActorEnum actor) {
		this.actor = actor;
	}
	public String getActorIdentifier() {
		return actorIdentifier;
	}
	public void setActorIdentifier(String actorIdentifier) {
		this.actorIdentifier = actorIdentifier;
	}
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public AkismetComment getAkismetComment() {
		return akismetComment;
	}
	public void setAkismetComment(AkismetComment akismetComment) {
		this.akismetComment = akismetComment;
	}
	
	
	
}
