package com.ebay.raptor.cmseditor.dao.entities;

import java.util.Map;

import com.ebay.cos.type.v3.base.Text;

public class MarketingAssetsEntity {

	private Text marketingContent;
	private Map<String, String> marketingAssetImages;
	
	public Text getMarketingContent() {
		return marketingContent;
	}
	public void setMarketingContent(Text marketingContent) {
		this.marketingContent = marketingContent;
	}
	public Map<String, String> getMarketingAssetImages() {
		return marketingAssetImages;
	}
	public void setMarketingAssetImages(Map<String, String> marketingAssetImages) {
		this.marketingAssetImages = marketingAssetImages;
	}
	
}
