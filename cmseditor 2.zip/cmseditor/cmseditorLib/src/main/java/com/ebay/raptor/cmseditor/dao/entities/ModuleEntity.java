package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;

public class ModuleEntity implements Comparable<ModuleEntity>{
	
	//IMAGE_TEXT,TEXT_IMAGE,IMAGE_SLIDER
	private String alignment;
	private List<SingleModuleEntity> data;
	private String moduleId;
	private int sortOrder;
	
	public String getAlignment() {
		return alignment;
	}
	
	public void setAlignment(String alignment) {
		this.alignment = alignment;
	}
	
	public List<SingleModuleEntity> getData() {
		return data;
	}
	public void setData(List<SingleModuleEntity> data) {
		this.data = data;
	}
	public String getModuleId() {
		return moduleId;
	}
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}
	
	@Override
	public int compareTo(ModuleEntity module) {
		if(this.sortOrder < module.sortOrder)
			return -1;
		else 
			return this.sortOrder == module.sortOrder ? 0 : 1;
	}
}
