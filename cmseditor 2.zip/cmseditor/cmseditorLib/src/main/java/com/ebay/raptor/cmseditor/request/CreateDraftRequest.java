package com.ebay.raptor.cmseditor.request;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ebay.raptor.cmseditor.response.content.model.Article;

public class CreateDraftRequest {
	
	private Article content;
	
	@JsonIgnore
	private String userId;

	public Article getContent() {
		return content;
	}

	public void setContent(Article content) {
		this.content = content;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	

}
