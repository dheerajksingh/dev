package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;

public class DraftContentsResponse {
	
	private List<DraftContentEntity> drafts;
	private Long count;
	public List<DraftContentEntity> getDrafts() {
		return drafts;
	}
	public void setDrafts(List<DraftContentEntity> drafts) {
		this.drafts = drafts;
	}
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	
	

}
