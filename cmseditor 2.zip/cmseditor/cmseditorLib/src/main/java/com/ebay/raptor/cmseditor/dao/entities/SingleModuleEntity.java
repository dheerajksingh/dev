package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;


/**
 * Represents a module : PARAGRAPH,IMAGE,VIDEO,HEADING,BLOCK_QUOTE,COLLECTION,TABLE,DIVIDER
 * @author kravikumar
 *
 */
public class SingleModuleEntity {
	
	//PARAGRAPH,IMAGE,VIDEO,HEADING,BLOCK_QUOTE,COLLECTION,TABLE,DIVIDER,COLLECTION,ITEMS
	private String type;
	private String caption;
	private String data;
	private String resourceUrl;
	private List<String> entityIds;
	private String entityType;
	private List<String> categoryIds;
	private String categoryLevel;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getResourceUrl() {
		return resourceUrl;
	}
	public void setResourceUrl(String resourceUrl) {
		this.resourceUrl = resourceUrl;
	}
	public List<String> getEntityIds() {
		return entityIds;
	}
	public void setEntityIds(List<String> entityIds) {
		this.entityIds = entityIds;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public List<String> getCategoryIds() {
		return categoryIds;
	}
	public void setCategoryIds(List<String> categoryIds) {
		this.categoryIds = categoryIds;
	}
	public String getCategoryLevel() {
		return categoryLevel;
	}
	public void setCategoryLevel(String categoryLevel) {
		this.categoryLevel = categoryLevel;
	}

}
