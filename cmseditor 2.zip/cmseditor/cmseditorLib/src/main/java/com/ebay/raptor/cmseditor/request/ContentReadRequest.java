package com.ebay.raptor.cmseditor.request;

public class ContentReadRequest {
	
	private String contentId;
	private String userId;
	private ArticleStatusEnum status;
	private ModerationStatusEnum moderationStatus;
	private boolean isAuthorizedApplication;
	
	
	
	
	public ModerationStatusEnum getModerationStatus() {
		return moderationStatus;
	}
	public void setModerationStatus(ModerationStatusEnum moderationStatus) {
		this.moderationStatus = moderationStatus;
	}
	public ArticleStatusEnum getStatus() {
		return status;
	}
	public void setStatus(ArticleStatusEnum status) {
		this.status = status;
	}
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public boolean isAuthorizedApplication() {
		return isAuthorizedApplication;
	}
	public void setAuthorizedApplication(boolean isAuthorizedApplication) {
		this.isAuthorizedApplication = isAuthorizedApplication;
	}
	
	
	

}
