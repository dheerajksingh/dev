package com.ebay.raptor.cmseditor.adapter;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.ebay.globalenv.SiteEnum;
import com.ebay.raptor.cmseditor.dao.entities.ComputedArticleDetailsEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.kernel.util.GlobalIdConverter;

public class ArticleEntityToCassiniModelAdapter {

	public static String convertArticleToJson(PublishedContentEntity entity) {
		
		FlatArticle fArticle = new FlatArticle();
		fArticle.setId(String.valueOf(entity.getContentId()));
		fArticle.setTemplateType(entity.getTemplateType());
		UserGeneratedContentEntity ugc = entity.getUserGeneratedContent();
		
		if(ugc != null) {
			fArticle.setTitle(ugc.getTitle());
			fArticle.setTags(ugc.getTags());
			
			PlainTextBuilder plainTextBuilder = new PlainTextBuilder();
			String content = plainTextBuilder.convertToPlainText(entity);
			if(content != null) {
				fArticle.setContent(content);
				if(!StringUtils.isEmpty(ugc.getSynopsis())) {
					fArticle.setSynopsis(ugc.getSynopsis());
				} else {
					fArticle.setSummary(content.substring(0, Math.min(200, content.length())));
				}
			}
			//fArticle.setAllCats(entity.getCate);
			//fArticle.setAllCatsName(entity.getAlLCates());
			//fArticle.setLeafCat(entity.getLeafCate());
			//fArticle.setLeafCatName(entity.getLeafCatName());
			populateNumPicsAndVideos(fArticle, entity);
		}
		SiteEnum siteEnum = GlobalIdConverter.encode(entity.getMarketPlaceId(), null);
		if(siteEnum != null) {
			fArticle.setSiteId(String.valueOf(siteEnum.getId()));
		}
		fArticle.setLocale(entity.getLocale());
		fArticle.setCreationDate(entity.getDateCreated());
		fArticle.setLastModifiedDate(entity.getDateModified());
		fArticle.setAuthorLoginName(entity.getAuthorName());
		fArticle.setAuthorId(entity.getAuthorId());

		ComputedArticleDetailsEntity cADE = entity.getComputedArticleDetailsEntity();
		if(cADE != null) {
			fArticle.setSystemTags(cADE.getRecommendedTags());
			fArticle.setAuthorImage(cADE.getAuthorImageUrl());
			fArticle.setAuthorRankScore(cADE.getAuthorRankScore());
			fArticle.setAuthorType(cADE.getAuthorType());
			fArticle.setPictureBroken(cADE.isPictureBroken());
			fArticle.setViewCount(cADE.getViewCount());
			fArticle.setCommentCount(cADE.getCommentCount());
			fArticle.setLikeCount(cADE.getLikeCount());
			fArticle.setQualityScore(cADE.getQualityScore());
			fArticle.setSponsored(cADE.isSponsored() ? 1 : 0);
		}
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(fArticle);
		} catch (JsonGenerationException | JsonMappingException e) {
			System.out.println("Error converting article with Id" + entity.getId() + " " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error converting article with Id" + entity.getId() + " " + e.getMessage());
		}
		return null;
	}

	private static void populateNumPicsAndVideos(FlatArticle fArticle,
			PublishedContentEntity entity) {
		
		List<GroupEntity> groups = entity.getUserGeneratedContent().getGroups();
		for(GroupEntity group:groups) {
			if(group.getModuleMap() == null || group.getModuleMap().values() == null) 
				continue;
			int numPics = 0, numVideos = 0;
			Collection<ModuleEntity> modules = group.getModuleMap().values();
			for(ModuleEntity module:modules) {
				if(module.getData() != null) {
					for(SingleModuleEntity sModule:module.getData()) {
						if(sModule.getType() != null) {
							if(sModule.getType().equals("IMAGE") || sModule.getType().equals("SHOP_THE_LOOK")) {
								numPics++;
							} else if(sModule.getType().equals("VIDEO")) {
								numVideos++;
							}
						}
					}
				}
			}
			fArticle.setNumPics(numPics);
			fArticle.setNumVideos(numVideos);
		}
	}
}

