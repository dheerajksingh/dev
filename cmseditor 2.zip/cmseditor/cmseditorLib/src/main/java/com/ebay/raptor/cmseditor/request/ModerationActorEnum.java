package com.ebay.raptor.cmseditor.request;

public enum ModerationActorEnum {
	
	SYSTEM,USER,MODERATOR

}
