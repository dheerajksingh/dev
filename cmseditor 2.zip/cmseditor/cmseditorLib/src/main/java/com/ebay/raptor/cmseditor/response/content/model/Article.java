package com.ebay.raptor.cmseditor.response.content.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class Article extends BaseArticle{
	
	protected String articleId;
	protected DateTime dateCreated;
	protected DateTime dateModified;
	protected ArticleStatusEnum articleStatus;
	protected ModerationStatusEnum moderationStatus;
	private String version;
	private AuthorType authorType;
	protected long viewCount;
	
	public Article(){}
	
	public Article(BaseArticle article){
		this.author=article.author;
		this.templateType=article.templateType;
		this.userGeneratedContent=article.userGeneratedContent;
		this.accessControlList=article.getAccessControlList();
		this.lastModifiedUser=article.getLastModifiedUser();
		this.marketplaceId=article.getMarketplaceId();
		this.scheduledEndDate=article.getScheduledEndDate();
		this.scheduledStartDate=article.getScheduledStartDate();
	}

	public String getArticleId() {
		return articleId;
	}


	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

	public DateTime getDateCreated() {
		return dateCreated;
	}


	public void setDateCreated(DateTime dateCreated) {
		this.dateCreated = dateCreated;
	}


	public DateTime getDateModified() {
		return dateModified;
	}


	public void setDateModified(DateTime dateModified) {
		this.dateModified = dateModified;
	}

	public ArticleStatusEnum getArticleStatus() {
		return articleStatus;
	}

	public void setArticleStatus(ArticleStatusEnum articleStatus) {
		this.articleStatus = articleStatus;
	}

	public ModerationStatusEnum getModerationStatus() {
		return moderationStatus;
	}

	public void setModerationStatus(ModerationStatusEnum moderationStatus) {
		this.moderationStatus = moderationStatus;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public AuthorType getAuthorType() {
		return authorType;
	}

	public void setAuthorType(AuthorType authorType) {
		this.authorType = authorType;
	}
	public long getViewCount() {
		return viewCount;
	}
	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}
}