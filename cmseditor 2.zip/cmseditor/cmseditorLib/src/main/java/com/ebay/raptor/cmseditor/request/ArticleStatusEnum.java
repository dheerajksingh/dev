package com.ebay.raptor.cmseditor.request;

import java.util.ArrayList;
import java.util.List;

public enum ArticleStatusEnum {
	//SUBMITTED IS NOT REALLY A CONTENT STATUS. IT IS ADDED HERE TO SUPPORT CLIENT REQUESTS WHICH PASS IN SUBMITTED AS STATUS.
	DRAFT,PENDING_SPAM_DETECTION,SPAM_CONFIRMED,SPAM_SUSPECTED,VIEWER_MARKED_SPAM,PUBLISHED,SUBMITTED;
	
	public static boolean isDraftContent(ArticleStatusEnum status){
		return status==ArticleStatusEnum.DRAFT;
	}
	
	public static boolean isPublishedContent(ArticleStatusEnum status){
		if(status==ArticleStatusEnum.PENDING_SPAM_DETECTION || status==ArticleStatusEnum.SPAM_CONFIRMED || status==ArticleStatusEnum.SPAM_SUSPECTED || 
				status==ArticleStatusEnum.PUBLISHED || status==ArticleStatusEnum.SUBMITTED || status==ArticleStatusEnum.VIEWER_MARKED_SPAM){
			return true;
		}
		return false;
	}
	
	public static boolean hasDraftContent(List<ArticleStatusEnum> statuses){
		for(ArticleStatusEnum status:statuses){
			if(status==ArticleStatusEnum.DRAFT){
				return true;
			}
		}
		return false;
	}
	
	public static boolean hasPublishedContent(List<ArticleStatusEnum> statuses){
		for(ArticleStatusEnum status:statuses){
			if(status==ArticleStatusEnum.PENDING_SPAM_DETECTION || status==ArticleStatusEnum.SPAM_CONFIRMED || status==ArticleStatusEnum.SPAM_SUSPECTED || 
					status==ArticleStatusEnum.PUBLISHED || status==ArticleStatusEnum.SUBMITTED || status==ArticleStatusEnum.VIEWER_MARKED_SPAM){
				return true;
			}
		}
		return false;
	}
	
	
	public static boolean isSpam(ArticleStatusEnum status){
		return status==ArticleStatusEnum.SPAM_CONFIRMED || status==ArticleStatusEnum.SPAM_SUSPECTED;
	}
	
	public static List<ArticleStatusEnum> getPublishedContentStatuses(){
		List<ArticleStatusEnum> statuses = new ArrayList<ArticleStatusEnum>();
		statuses.add(ArticleStatusEnum.PENDING_SPAM_DETECTION);
		statuses.add(ArticleStatusEnum.SPAM_CONFIRMED);
		statuses.add(ArticleStatusEnum.SPAM_SUSPECTED);
		statuses.add(ArticleStatusEnum.VIEWER_MARKED_SPAM);
		statuses.add(ArticleStatusEnum.PUBLISHED);
		return statuses;
	}

}