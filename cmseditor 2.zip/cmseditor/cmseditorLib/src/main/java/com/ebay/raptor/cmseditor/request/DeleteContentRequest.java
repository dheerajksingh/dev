package com.ebay.raptor.cmseditor.request;

public class DeleteContentRequest {
	
	private String contentId;
	private ArticleStatusEnum status;
	
	

	public ArticleStatusEnum getStatus() {
		return status;
	}

	public void setStatus(ArticleStatusEnum status) {
		this.status = status;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	
	

}
