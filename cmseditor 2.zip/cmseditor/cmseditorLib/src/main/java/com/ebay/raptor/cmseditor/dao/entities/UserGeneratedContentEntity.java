package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;
import java.util.Map;

import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.base.TimeDuration;

public class UserGeneratedContentEntity {
	
	private String title;
	private String synopsis;
	private String conclusionTitle;
	private String conclusionDescription;
	private String coverImage;
	private List<String> tags;
	private List<GroupEntity> groups;
	private TimeDuration estimatedTime;
	private String costRange;
	private String difficultyLevel;
	private List<Text> materialsNeeded;
	private List<Text> toolsNeeded;
	private MarketingAssetsEntity marketingAssets;
	private Map<String,String> categories;
	//TODO: Clean this
	/*private Integer category1;
	private Integer category2;
	private Integer category3;*/
	
	public List<GroupEntity> getGroups() {
		return groups;
	}
	public void setGroups(List<GroupEntity> groups) {
		this.groups = groups;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public String getCoverImage() {
		return coverImage;
	}
	public void setCoverImage(String coverImage) {
		this.coverImage = coverImage;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public TimeDuration getEstimatedTime() {
		return estimatedTime;
	}
	public void setEstimatedTime(TimeDuration estimatedTime) {
		this.estimatedTime = estimatedTime;
	}
	public String getCostRange() {
		return costRange;
	}
	public void setCostRange(String costRange) {
		this.costRange = costRange;
	}
	public String getDifficultyLevel() {
		return difficultyLevel;
	}
	public void setDifficultyLevel(String difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}
	public List<Text> getMaterialsNeeded() {
		return materialsNeeded;
	}
	public void setMaterialsNeeded(List<Text> materialsNeeded) {
		this.materialsNeeded = materialsNeeded;
	}
	public List<Text> getToolsNeeded() {
		return toolsNeeded;
	}
	public void setToolsNeeded(List<Text> toolsNeeded) {
		this.toolsNeeded = toolsNeeded;
	}
	public String getConclusionTitle() {
		return conclusionTitle;
	}
	public void setConclusionTitle(String conclusionTitle) {
		this.conclusionTitle = conclusionTitle;
	}
	public String getConclusionDescription() {
		return conclusionDescription;
	}
	public void setConclusionDescription(String conclusionDescription) {
		this.conclusionDescription = conclusionDescription;
	}
	/*public Integer getCategory1() {
		return category1;
	}
	public void setCategory1(Integer category1) {
		this.category1 = category1;
	}
	public Integer getCategory2() {
		return category2;
	}
	public void setCategory2(Integer category2) {
		this.category2 = category2;
	}
	public Integer getCategory3() {
		return category3;
	}
	public void setCategory3(Integer category3) {
		this.category3 = category3;
	}*/
	public Map<String, String> getCategories() {
		return categories;
	}
	public void setCategories(Map<String, String> categories) {
		this.categories = categories;
	}
	public MarketingAssetsEntity getMarketingAssets() {
		return marketingAssets;
	}
	public void setMarketingAssets(MarketingAssetsEntity marketingAssets) {
		this.marketingAssets = marketingAssets;
	}
	
	
}
