package com.ebay.raptor.cmseditor.response.content.model;

import com.ebay.raptor.cmseditor.response.CmsEditorResponse;

public class ArticleReadResponse extends CmsEditorResponse{
	
	private Article article;

	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}
	
	

}