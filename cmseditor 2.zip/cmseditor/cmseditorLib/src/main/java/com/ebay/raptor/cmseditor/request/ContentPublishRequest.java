package com.ebay.raptor.cmseditor.request;

import com.ebay.spam.akismet.AkismetComment;

public class ContentPublishRequest {

	private String draftContentId;
	
	private AkismetComment akismetComment;

	public String getDraftContentId() {
		return draftContentId;
	}

	public void setDraftContentId(String draftContentId) {
		this.draftContentId = draftContentId;
	}

	public AkismetComment getAkismetComment() {
		return akismetComment;
	}

	public void setAkismetComment(AkismetComment akismetComment) {
		this.akismetComment = akismetComment;
	}
	
	
}
