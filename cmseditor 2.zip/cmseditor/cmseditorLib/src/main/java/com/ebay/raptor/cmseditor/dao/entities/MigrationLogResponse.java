package com.ebay.raptor.cmseditor.dao.entities;

import java.util.List;

import com.ebay.raptor.cmseditor.dao.entities.MigrationLog;

public class MigrationLogResponse {
	
	long count;
	List<MigrationLog> migrationLogs;
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public List<MigrationLog> getMigrationLogs() {
		return migrationLogs;
	}
	public void setMigrationLogs(List<MigrationLog> migrationLogs) {
		this.migrationLogs = migrationLogs;
	}
	
	

}
