package com.ebay.raptor.besevents;

import com.ebay.bes.common.BusinessEventInitializer;

public class ArticleBulkUploadEvent extends ArticleEvent {

	private String userName;
	private String fileName;
	
	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getFileName() {
		return fileName;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	
	public ArticleBulkUploadEvent() {
		m_eventType = BusinessEventInitializer.getInstance().getEventType(ConsumerConstants.ARTICLE_BULK_UPLOAD_EVENT);
	}	
	
	@Override
	public String toString() {
		return "ArticleBulkUploadEvent [userName=" + userName + ", fileName="
				+ fileName + "]";
	}

}