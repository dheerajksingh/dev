package com.ebay.raptor.cmseditor.request;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.ebay.cos.type.v3.base.Text;
import com.ebay.raptor.cmseditor.response.content.model.Section;

public class UpdateGroupRequest {
	@JsonIgnore private String articleId;
	@JsonIgnore private String userId;
	@JsonIgnore private String groupId;
	private Text title;
	private String groupType;
	private List<Section> sections;
	
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<Section> getSections() {
		return sections;
	}
	public void setSections(List<Section> sections) {
		this.sections = sections;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public Text getTitle() {
		return title;
	}
	public void setTitle(Text title) {
		this.title = title;
	}
	public String getGroupType() {
		return groupType;
	}
	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}
}