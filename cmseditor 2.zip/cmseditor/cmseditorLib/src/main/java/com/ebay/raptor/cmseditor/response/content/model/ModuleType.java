package com.ebay.raptor.cmseditor.response.content.model;

public enum ModuleType {
	PARAGRAPH,IMAGE,VIDEO,HEADING,BLOCK_QUOTE,COLLECTION,TABLE,DIVIDER;
}
