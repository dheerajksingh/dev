package com.ebay.raptor.cmseditor.error;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;

@SuppressWarnings("serial")
public class CmsEditorException extends Exception{

	private CmsEditorStatus error;
	
	public CmsEditorException(CmsEditorStatus error){
		this.error = error;
	}
	
	public CmsEditorException(CmsEditorStatus error,Throwable t){
		super(t.getMessage(),t);
		this.error = error;
	}

	public CmsEditorStatus getError() {
		return error;
	}

	public void setError(CmsEditorStatus error) {
		this.error = error;
	}
}
