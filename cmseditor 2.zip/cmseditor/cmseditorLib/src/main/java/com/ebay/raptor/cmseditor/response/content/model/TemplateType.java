package com.ebay.raptor.cmseditor.response.content.model;

public enum TemplateType {
	
	HOW_TO,LONG_FORM,ASCENDING_LIST,DESCENDING_LIST,QUIZ

}
