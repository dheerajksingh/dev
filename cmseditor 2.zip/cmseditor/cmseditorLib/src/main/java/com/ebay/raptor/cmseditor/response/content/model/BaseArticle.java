package com.ebay.raptor.cmseditor.response.content.model;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ebay.cos.raptor.service.annotations.ApiDescription;
import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.core.user.UserIdentifier;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class BaseArticle {
	
	@ApiDescription("Possible values: HOW_TO,LONG_FORM,ASCENDING_LIST,DESCENDING_LIST,QUIZ")
	protected String templateType;
	
	protected UserGeneratedContent userGeneratedContent;
	
	@ApiDescription("List of user names who can edit this article.The user names are "
			+ "persisted as oracle ids in the DB and converted back at fetch time")
	protected List<String> accessControlList;
	
	protected UserIdentifier author;
	protected DateTime scheduledStartDate;
	protected DateTime scheduledEndDate;
	protected String marketplaceId;
	protected UserIdentifier lastModifiedUser;

	public String getTemplateType() {
		return templateType;
	}
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	public UserGeneratedContent getUserGeneratedContent() {
		return userGeneratedContent;
	}
	public void setUserGeneratedContent(UserGeneratedContent userGeneratedContent) {
		this.userGeneratedContent = userGeneratedContent;
	}
	public List<String> getAccessControlList() {
		return accessControlList;
	}
	public void setAccessControlList(List<String> accessControlList) {
		this.accessControlList = accessControlList;
	}
	public UserIdentifier getAuthor() {
		return author;
	}
	public void setAuthor(UserIdentifier author) {
		this.author = author;
	}
	public DateTime getScheduledStartDate() {
		return scheduledStartDate;
	}
	public void setScheduledStartDate(DateTime scheduledStartDate) {
		this.scheduledStartDate = scheduledStartDate;
	}
	public DateTime getScheduledEndDate() {
		return scheduledEndDate;
	}
	public void setScheduledEndDate(DateTime scheduledEndDate) {
		this.scheduledEndDate = scheduledEndDate;
	}
	

	public UserIdentifier getLastModifiedUser() {
		return lastModifiedUser;
	}
	public void setLastModifiedUser(UserIdentifier lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}
	public String getMarketplaceId() {
		return marketplaceId;
	}
	public void setMarketplaceId(String marketplaceId) {
		this.marketplaceId = marketplaceId;
	}

	
	
}