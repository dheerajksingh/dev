package com.ebay.raptor.cmseditor.request;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

public class ArticleUpdateFieldRequest {

	private List<KeyValueImpl> keyValues;
	
	@JsonIgnore
	private String articleId;

	public List<KeyValueImpl> getKeyValues() {
		return keyValues;
	}

	public void setKeyValues(List<KeyValueImpl> keyValues) {
		this.keyValues = keyValues;
	}
	
	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	
	
}
