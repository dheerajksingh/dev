package com.ebay.raptor.cmseditor.response;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.ebayopensource.ginger.common.types.ErrorMessage;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class CmsEditorResponse {
	
	@JsonIgnore 
	public CmsEditorResponseStatus status;
	protected ErrorMessage errorMessage;

	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(ErrorMessage errorMessage) {
		this.errorMessage = errorMessage;
	}

	public CmsEditorResponseStatus getStatus() {
		return status;
	}

	public void setStatus(CmsEditorResponseStatus status) {
		this.status = status;
	}
	
	
}

