package com.ebay.raptor.cmseditor.request;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.kernel.context.impl.RaptorHttpServletRequest;
import com.ebay.spam.akismet.AkismetComment;


@Component
public class AkismetCommentBuilder {
	
	private static final String COMMENT_TYPE="blog-post";
	private static final String REFERER="referer";

	
	private static final Logger LOGGER = Logger.getInstance(AkismetCommentBuilder.class);
	
	public AkismetComment buildAkismetComment(HttpServletRequest request){
		AkismetComment comment = new AkismetComment();
		RaptorHttpServletRequest raptorRequest = (RaptorHttpServletRequest)request;
		try{
		comment.setCommentType(COMMENT_TYPE);
		comment.setUserAgent(raptorRequest.getUserAgent());
		comment.setReferrer(raptorRequest.getHeader(REFERER));
		comment.setCommentAuthorUrl(raptorRequest.getUrl());
		comment.setUserIp(raptorRequest.getRemoteAddr());
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
		}
		
		return comment;
	}

}
