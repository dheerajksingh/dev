package com.ebay.raptor.cmseditor.request;

public class ContentSearchRequest {
	
	

}
