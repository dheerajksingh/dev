package com.ebay.raptor.cmseditor.request;

public class DeleteGroupRequest {
	
	private String groupId;
	private String contentId;
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	
}
