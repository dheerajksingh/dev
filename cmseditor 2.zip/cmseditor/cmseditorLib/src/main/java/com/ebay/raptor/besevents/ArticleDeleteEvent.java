package com.ebay.raptor.besevents;

import com.ebay.bes.common.BusinessEventInitializer;

public class ArticleDeleteEvent extends ArticleEvent {
	
	public ArticleDeleteEvent() {
		m_eventType = BusinessEventInitializer.getInstance().getEventType(ConsumerConstants.ARTICLE_DELETE_EVENT);
	}	
}
