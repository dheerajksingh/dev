package com.ebay.raptor.cmseditor.response.content.model;

import java.util.Map;

import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;

public class MarketingAssets {
	
	private Map<String, Image> assets;
	private Text marketingContent;

	public Map<String, Image> getAssets() {
		return assets;
	}

	public void setAssets(Map<String, Image> assets) {
		this.assets = assets;
	}

	public Text getMarketingContent() {
		return marketingContent;
	}

	public void setMarketingContent(Text marketingContent) {
		this.marketingContent = marketingContent;
	}
	
}
