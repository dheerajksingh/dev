package com.ebay.raptor.cmseditor.request;

public class GetForEditRequest {
	
	private String contentId;
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	
	
	

}
