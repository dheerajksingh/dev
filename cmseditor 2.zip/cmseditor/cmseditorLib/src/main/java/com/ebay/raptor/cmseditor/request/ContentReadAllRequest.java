package com.ebay.raptor.cmseditor.request;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.google.common.base.Splitter;

public class ContentReadAllRequest {
	
	private String userId;
	
	private List<ArticleStatusEnum> statuses=new ArrayList<ArticleStatusEnum>();
	private List<ModerationStatusEnum> moderationStatuses=new ArrayList<ModerationStatusEnum>();
	private SortOrder sort = SortOrder.DATE_MODIFIED_DESC;
	private int limit;
	private int offset;
	
	
	
	public List<ArticleStatusEnum> getStatuses() {
		return statuses;
	}
	public void setStatuses(List<ArticleStatusEnum> statuses) {
		this.statuses = statuses;
	}
	public List<ModerationStatusEnum> getModerationStatuses() {
		return moderationStatuses;
	}
	public void setModerationStatuses(List<ModerationStatusEnum> moderationStatuses) {
		this.moderationStatuses = moderationStatuses;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}
	public SortOrder getSort() {
		return sort;
	}
	public void setSort(SortOrder sort) {
		this.sort = sort;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public void setContentStatuses(String status) throws CmsEditorException{
		if(StringUtils.isEmpty(status)){
			this.statuses.add(ArticleStatusEnum.PUBLISHED);
			this.statuses.add(ArticleStatusEnum.PENDING_SPAM_DETECTION);
			this.statuses.add(ArticleStatusEnum.PUBLISHED);
			this.statuses.add(ArticleStatusEnum.DRAFT);
			this.statuses.add(ArticleStatusEnum.SPAM_CONFIRMED);
			this.statuses.add(ArticleStatusEnum.SPAM_SUSPECTED);
			return;
		}
		try{
		Iterable<String> statuses =Splitter.on(",").split(status);
		for(String s:statuses){
			if(ArticleStatusEnum.valueOf(s)==null){
				throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
			}
			if(ArticleStatusEnum.valueOf(s)==ArticleStatusEnum.SUBMITTED){
				this.statuses.addAll(ArticleStatusEnum.getPublishedContentStatuses());
			}else{
				this.statuses.add(ArticleStatusEnum.valueOf(s));
			}
		}
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_STATUSES,e);
		}
	}
	
	public void setModerationStatuses(String status) throws CmsEditorException{
		if(StringUtils.isEmpty(status)){
			return;
		}
		try{
		Iterable<String> statuses =Splitter.on(",").split(status);
		for(String s:statuses){
			if(ModerationStatusEnum.valueOf(s)==null){
				throw new CmsEditorException(CmsEditorStatus.INVALID_MODERATION_STATUSES);
			}
			this.moderationStatuses.add(ModerationStatusEnum.valueOf(s));
		}
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_MODERATION_STATUSES,e);
		}
	}
	
	

}
