package com.ebay.raptor.cmseditor.response.content.model;

public enum AuthorType {
	
	AUTHOR,PREMIUM_AUTHOR,MODERATOR,ADMINISTRATOR

}
