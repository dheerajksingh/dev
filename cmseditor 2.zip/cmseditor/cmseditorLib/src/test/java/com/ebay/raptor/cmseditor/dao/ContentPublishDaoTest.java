package com.ebay.raptor.cmseditor.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.KeyValue;
import org.bson.types.ObjectId;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.DatastoreImpl;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.mapping.Mapper;
import org.mongodb.morphia.query.FieldEnd;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentsResponse;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentsResponse;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

import edu.emory.mathcs.backport.java.util.Arrays;
import static org.mockito.Mockito.*;

public class ContentPublishDaoTest {
	
	private DatastoreImpl ds;
	
	@Mock
	private QueryHelper queryHelper;
	
	private ContentPublishDao contentPublishDao;
	
	/*@Test
	public void testFindContentById() throws Exception{
		
//		DatastoreImpl ds = mock(DatastoreImpl.class);
//		Mapper mapper = mock(Mapper.class);
//		MappedClass mappedClass = mock(MappedClass.class);
//		when(ds.getMapper()).thenReturn(mapper);
//		when(mapper.addMappedClass(PublishedContentEntity.class)).thenReturn(mappedClass);
//		
//		contentPublishDaoEx dao = new contentPublishDaoEx(ds);
//		PublishedContentEntity entity1 = new PublishedContentEntity();
//		dao.setEntity(entity1);
//		assertThat(dao.findContentById("100"),is(entity1));
	}*/
	
	@Before
	public void setup() {
		
		ds = mock(DatastoreImpl.class);
		Mapper mapper = mock(Mapper.class);
		when(ds.getMapper()).thenReturn(mapper);
		queryHelper = mock(QueryHelper.class);
		contentPublishDao = new ContentPublishDao(ds, queryHelper);
		
	}
	
	
	@Test
	public void testFindContentById() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setId(new ObjectId());
		
		when(queryHelper.get(query, "ContentPublishDao", "findContentById")).thenReturn(entity);
		PublishedContentEntity returnedEntity = contentPublishDao.findContentById(new ObjectId().toString());
		
		Assert.assertTrue(returnedEntity.equals(entity));
		
	}
	
	@Test
	public void testFindContentByContentId() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setId(new ObjectId());
		
		when(query.get()).thenReturn(entity);
		PublishedContentEntity returnedEntity = contentPublishDao.findContentByContentId(new ObjectId().toString());
		
		Assert.assertTrue(returnedEntity.equals(entity));
		
	}
	
	@Test
	public void findContentByIdAndUserId() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setId(new ObjectId());
		
		when(queryHelper.get(query, "ContentPublishDao", "findContentByIdAndUserId")).thenReturn(entity);
		PublishedContentEntity returnedEntity = contentPublishDao.findContentByIdAndUserId(new ObjectId().toString(), "0");
		
		Assert.assertTrue(returnedEntity.equals(entity));

	}
	
	@Test
	public void findContentByUserId() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setId(new ObjectId());
		
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		entities.add(entity);
		
		when(queryHelper.asList(query, "ContentPublishDao", "findContentByUserId")).thenReturn(entities);
		when(queryHelper.count(query, "ContentPublishDao", "findContentByUserId")).thenReturn((long) entities.size());
		
		PublishedContentsResponse response = contentPublishDao.findContentByUserId("userId", 0, 10, "date", Arrays.asList(new String[]{"SUBMITTED"}), Arrays.asList(new String[]{"MODERATED"}));
		
		Assert.assertTrue(response.getCount().longValue() == entities.size());
		Assert.assertTrue(response.getPublishedContents().equals(entities));

	}

	@Test
	public void findContents() {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setId(new ObjectId());
		
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		entities.add(entity);
		
		when(queryHelper.asList(query, "ContentPublishDao", "findContents")).thenReturn(entities);
		
		List<PublishedContentEntity> response = contentPublishDao.findContents(0, 10, "date", Arrays.asList(new String[]{"SUBMITTED"}), Arrays.asList(new String[]{"MODERATED"}));
		
		Assert.assertTrue(response.equals(entities));
		
	}
	
	@Test
	public void findContentAccessControlListByContentId() {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		ObjectId id = new ObjectId();
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setId(id);
		entity.setContentId(id);
		List<String> acl = Arrays.asList(new String[]{"0", "1"});
		entity.setAccessControlList(acl);
		
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		entities.add(entity);
		
		when(queryHelper.asList(query, "ContentPublishDao", "findContentAccessControlListByContentIds")).thenReturn(entities);
		
		List<String> response = contentPublishDao.findContentAccessControlListByContentId(id.toString());
		
		Assert.assertTrue(response.equals(acl));
		
	}
	
	@Test
	public void findContentAccessControlListByEmptyContentId() {
		
		List<String> response = contentPublishDao.findContentAccessControlListByContentId(null);
		
		Assert.assertTrue(response == null);
		
		response = contentPublishDao.findContentAccessControlListByContentId("");
		
		Assert.assertTrue(response == null);
		
	}
	
	@Test
	public void updateContentField() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
        when(query.filter(Matchers.anyString(), any(ObjectId.class))).thenReturn(query);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<PublishedContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
			
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(2);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		contentPublishDao.updateContentField(new ObjectId().toString(), Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		verify(ds, times(1)).update(query, updateOps);
		
	}
	
	@Test
	public void updateContentFieldForContentIds() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
        when(query.filter(Matchers.anyString(), any(ObjectId.class))).thenReturn(query);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<PublishedContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
			
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(2);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		contentPublishDao.updateContentFieldForContentIds(Arrays.asList(new String[]{new ObjectId().toString()}), Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		verify(ds, times(1)).update(query, updateOps);
		
	}
	
	@Test
	public void updateContentFieldForContentIdInResponses() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<PublishedContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
		
		int updateCount = 1;
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(updateCount);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setContentId(new ObjectId().toString());
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setContentId(new ObjectId().toString());
		
		responses.add(response1);
		responses.add(response2);
		
		contentPublishDao.updateContentFieldForContentIdsInResponses(responses, Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		verify(ds, times(1)).update(query, updateOps);
		
	}
	
	@Test
	public void updateContentFieldForInvalidContentIdInResponses() throws Exception {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<PublishedContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
		
		int updateCount = 1;
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(updateCount);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setContentId("0");
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setContentId(new ObjectId().toString());
		
		responses.add(response1);
		responses.add(response2);
		
		contentPublishDao.updateContentFieldForContentIdsInResponses(responses, Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		Assert.assertTrue(response1.getStatus().equals(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
	@Test
	public void createContents() {
		
		List<PublishedContentEntity> contents = new ArrayList<PublishedContentEntity>();
		PublishedContentEntity content1 = new PublishedContentEntity();
		content1.setContentId(new ObjectId());
		
		PublishedContentEntity content2 = new PublishedContentEntity();
		content2.setContentId(new ObjectId());
		
		contents.add(content1);
		contents.add(content2);
		
		Key<PublishedContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		Key<PublishedContentEntity> key2 = mock(Key.class);
		ObjectId id2 = new ObjectId();
		when(key2.getId()).thenReturn(id2);
		
		when(ds.save(content1)).thenReturn(key1);
		when(ds.save(content2)).thenReturn(key2);
		
		List<String> keys = contentPublishDao.createContent(contents);
		Assert.assertTrue(keys.get(0).equals(key1.getId().toString()));
		Assert.assertTrue(keys.get(1).equals(key2.getId().toString()));
		
	}
	
	@Test
	public void updateContent() throws Exception {
		
		PublishedContentEntity content1 = new PublishedContentEntity();
		content1.setContentId(new ObjectId());
		
		Key<PublishedContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		when(ds.save(content1)).thenReturn(key1);
		
		contentPublishDao.updateContent(content1.getContentId().toString(), content1);
		
		verify(ds, times(1)).save(content1);
		
	}
	
	@Test
	public void createBulkContents() {
		
		List<BulkAdaptorResponse> contents = new ArrayList<>();
		BulkAdaptorResponse content = new BulkAdaptorResponse();
		PublishedContentEntity content1 = new PublishedContentEntity();
		content1.setContentId(new ObjectId());
		content.setEntity(content1);
		content.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(content);
		
		BulkAdaptorResponse bulkContent2 = new BulkAdaptorResponse();
		PublishedContentEntity content2 = new PublishedContentEntity();
		content2.setContentId(new ObjectId());
		bulkContent2.setEntity(content2);
		bulkContent2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent2);

		
		Key<PublishedContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		when(ds.save(content1)).thenReturn(key1);
		
		contentPublishDao.createBulkContents(contents);
		
		Assert.assertTrue(content.getContentId().equals(key1.getId().toString()));
		Assert.assertTrue(bulkContent2.getStatus().equals(CmsEditorStatus.CREATE_ERROR));
	}
	
	@Test
	public void deleteByContentIds() {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		List<BulkAdaptorResponse> contents = new ArrayList<>();
		BulkAdaptorResponse bulkContent2 = new BulkAdaptorResponse();
		PublishedContentEntity content2 = new PublishedContentEntity();
		content2.setContentId(new ObjectId());
		bulkContent2.setContentId(content2.getContentId().toString());
		bulkContent2.setEntity(content2);
		bulkContent2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent2);
		
		BulkAdaptorResponse bulkContent3 = new BulkAdaptorResponse();
		PublishedContentEntity content3 = new PublishedContentEntity();
		content3.setContentId(new ObjectId());
		bulkContent3.setEntity(content3);
		bulkContent3.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent3);
		
		contentPublishDao.deleteByContentIds(contents);
		
		verify(ds, times(1)).delete(query);
		
	}
	
	@Test
	public void deleteByContentIdsAndUserId() {
		
		Query<PublishedContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		List<BulkAdaptorResponse> contents = new ArrayList<>();
		
		contentPublishDao.deleteByContentIdsAndUserId(contents, "userId");
		
		BulkAdaptorResponse bulkContent2 = new BulkAdaptorResponse();
		PublishedContentEntity content2 = new PublishedContentEntity();
		content2.setContentId(new ObjectId());
		bulkContent2.setContentId(content2.getContentId().toString());
		bulkContent2.setEntity(content2);
		bulkContent2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent2);
		
		BulkAdaptorResponse bulkContent3 = new BulkAdaptorResponse();
		PublishedContentEntity content3 = new PublishedContentEntity();
		content3.setContentId(new ObjectId());
		bulkContent3.setEntity(content3);
		bulkContent3.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent3);
		
		contentPublishDao.deleteByContentIdsAndUserId(contents, "userId");
		
		verify(ds, times(1)).delete(query);
		
	}

}
