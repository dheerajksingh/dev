package com.ebay.raptor.cmseditor.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.KeyValue;
import org.bson.types.ObjectId;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.DatastoreImpl;
import org.mongodb.morphia.Key;
import org.mongodb.morphia.mapping.Mapper;
import org.mongodb.morphia.query.FieldEnd;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentsResponse;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.util.QueryHelper;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

import edu.emory.mathcs.backport.java.util.Arrays;
import static org.mockito.Mockito.*;

public class ContentDraftDaoTest {
	
	private DatastoreImpl ds;
	
	@Mock
	private QueryHelper queryHelper;
	
	private ContentDraftDao contentDraftDao;
	
	/*@Test
	public void testFindContentById() throws Exception{
		
//		DatastoreImpl ds = mock(DatastoreImpl.class);
//		Mapper mapper = mock(Mapper.class);
//		MappedClass mappedClass = mock(MappedClass.class);
//		when(ds.getMapper()).thenReturn(mapper);
//		when(mapper.addMappedClass(DraftContentEntity.class)).thenReturn(mappedClass);
//		
//		ContentDraftDaoEx dao = new ContentDraftDaoEx(ds);
//		DraftContentEntity entity1 = new DraftContentEntity();
//		dao.setEntity(entity1);
//		assertThat(dao.findContentById("100"),is(entity1));
	}*/
	
	@Before
	public void setup() {
		
		ds = mock(DatastoreImpl.class);
		Mapper mapper = mock(Mapper.class);
		when(ds.getMapper()).thenReturn(mapper);
		queryHelper = mock(QueryHelper.class);
		contentDraftDao = new ContentDraftDao(ds, queryHelper);
		
	}
	
	
	@Test
	public void testFindContentById() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setId(new ObjectId());
		
		when(queryHelper.get(query, "ContentDraftDAO", "findContentById")).thenReturn(entity);
		DraftContentEntity returnedEntity = contentDraftDao.findContentById(new ObjectId().toString());
		
		Assert.assertTrue(returnedEntity.equals(entity));
		
	}
	
	@Test
	public void findLatestDraftById() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setId(new ObjectId());
		
		when(queryHelper.get(query, "ContentDraftDAO", "findLatestDraftById")).thenReturn(entity);
		DraftContentEntity returnedEntity = contentDraftDao.findLatestDraftById(new ObjectId());
		
		Assert.assertTrue(returnedEntity.equals(entity));

	}
	
	@Test
	public void findContentByIdAndUserId() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setId(new ObjectId());
		
		when(queryHelper.get(query, "ContentDraftDAO", "findContentByIdAndUserId")).thenReturn(entity);
		DraftContentEntity returnedEntity = contentDraftDao.findContentByIdAndUserId(new ObjectId().toString(), "0");
		
		Assert.assertTrue(returnedEntity.equals(entity));

	}
	
	@Test
	public void findContentByUserId() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setId(new ObjectId());
		
		List<DraftContentEntity> entities = new ArrayList<DraftContentEntity>();
		entities.add(entity);
		
		when(queryHelper.asList(query, "ContentDraftDAO", "findContentByUserId")).thenReturn(entities);
		when(queryHelper.count(query, "ContentDraftDAO", "findContentByUserId")).thenReturn((long) entities.size());
		
		DraftContentsResponse response = contentDraftDao.findContentByUserId("userId", 0, 10, "date", Arrays.asList(new String[]{"SUBMITTED"}), Arrays.asList(new String[]{"MODERATED"}));
		
		Assert.assertTrue(response.getCount().longValue() == entities.size());
		Assert.assertTrue(response.getDrafts().equals(entities));

	}

	@Test
	public void findContents() {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setId(new ObjectId());
		
		List<DraftContentEntity> entities = new ArrayList<DraftContentEntity>();
		entities.add(entity);
		
		when(queryHelper.asList(query, "ContentDraftDAO", "findContents")).thenReturn(entities);
		
		List<DraftContentEntity> response = contentDraftDao.findContents(0, 10, "date", Arrays.asList(new String[]{"SUBMITTED"}), Arrays.asList(new String[]{"MODERATED"}));
		
		Assert.assertTrue(response.equals(entities));
		
	}
	
	@Test
	public void findContentAccessControlListByContentId() {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		ObjectId id = new ObjectId();
		DraftContentEntity entity = new DraftContentEntity();
		entity.setId(id);
		entity.setContentId(id);
		List<String> acl = Arrays.asList(new String[]{"0", "1"});
		entity.setAccessControlList(acl);
		
		List<DraftContentEntity> entities = new ArrayList<DraftContentEntity>();
		entities.add(entity);
		
		when(queryHelper.asList(query, "ContentDraftDAO", "findContentAccessControlListByContentIds")).thenReturn(entities);
		
		List<String> response = contentDraftDao.findContentAccessControlListByContentId(id.toString());
		
		Assert.assertTrue(response.equals(acl));
		
	}
	
	@Test
	public void findContentAccessControlListByEmptyContentId() {
		
		List<String> response = contentDraftDao.findContentAccessControlListByContentId(null);
		
		Assert.assertTrue(response == null);
		
		response = contentDraftDao.findContentAccessControlListByContentId("");
		
		Assert.assertTrue(response == null);
		
	}
	
	@Test
	public void updateContentModule() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<DraftContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
		
		int updateCount = 1;
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(updateCount);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		int response = contentDraftDao.updateContentModule(new ObjectId().toString(), "1", new ModuleEntity());
		
		Assert.assertTrue(response == updateCount);
		
	}
	
	@Test
	public void deleteContentModule() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<DraftContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.unset(anyString())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
		
		int updateCount = 1;
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(updateCount);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		int response = contentDraftDao.deleteContentModule(new ObjectId().toString(), "1", "1");
		
		Assert.assertTrue(response == updateCount);
		
	}
	
	@Test
	public void updateContentField() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<DraftContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
			
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		contentDraftDao.updateContentField(new ObjectId().toString(), Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		verify(ds, times(1)).update(query, updateOps);
		
	}
	
	@Test
	public void updateContentFieldForContentIdInResponses() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<DraftContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
		
		int updateCount = 1;
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(updateCount);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setContentId(new ObjectId().toString());
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setContentId(new ObjectId().toString());
		
		responses.add(response1);
		responses.add(response2);
		
		contentDraftDao.updateContentFieldForContentIdsInResponses(responses, Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		verify(ds, times(1)).update(query, updateOps);
		
	}
	
	@Test
	public void updateContentFieldForInvalidContentIdInResponses() throws Exception {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		UpdateOperations<DraftContentEntity> updateOps = mock(UpdateOperations.class);
		when(updateOps.set(anyString(), any())).thenReturn(updateOps);
		when(updateOps.disableValidation()).thenReturn(updateOps);
		when(updateOps.enableValidation()).thenReturn(updateOps);
		when(ds.createUpdateOperations(any(Class.class))).thenReturn(updateOps);
		
		int updateCount = 1;
		UpdateResults result = mock(UpdateResults.class);
		when(result.getUpdatedCount()).thenReturn(updateCount);
		when(ds.update(query, updateOps)).thenReturn(result);
		
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey("key");
		kv.setValue("value");
		
		KeyValueImpl kv1 = new KeyValueImpl();
		kv1.setKey("key");
		kv1.setValue(null);
		
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setContentId("0");
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setContentId(new ObjectId().toString());
		
		responses.add(response1);
		responses.add(response2);
		
		contentDraftDao.updateContentFieldForContentIdsInResponses(responses, Arrays.asList(new KeyValue[]{ kv, kv1 }));
		
		Assert.assertTrue(response1.getStatus().equals(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
	@Test
	public void createContents() {
		
		List<DraftContentEntity> contents = new ArrayList<DraftContentEntity>();
		DraftContentEntity content1 = new DraftContentEntity();
		content1.setContentId(new ObjectId());
		
		DraftContentEntity content2 = new DraftContentEntity();
		content2.setContentId(new ObjectId());
		
		contents.add(content1);
		contents.add(content2);
		
		Key<DraftContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		Key<DraftContentEntity> key2 = mock(Key.class);
		ObjectId id2 = new ObjectId();
		when(key2.getId()).thenReturn(id2);
		
		when(ds.save(content1)).thenReturn(key1);
		when(ds.save(content2)).thenReturn(key2);
		
		List<String> keys = contentDraftDao.createContent(contents);
		Assert.assertTrue(keys.get(0).equals(key1.getId().toString()));
		Assert.assertTrue(keys.get(1).equals(key2.getId().toString()));
		
	}
	
	@Test
	public void createContent() throws Exception {
		
		DraftContentEntity content1 = new DraftContentEntity();
		content1.setContentId(new ObjectId());
		
		Key<DraftContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		when(ds.save(content1)).thenReturn(key1);
		
		String key = contentDraftDao.createContent(content1);
		Assert.assertTrue(key.equals(key1.getId().toString()));
		
	}
	
	@Test
	public void updateContent() throws Exception {
		
		DraftContentEntity content1 = new DraftContentEntity();
		content1.setContentId(new ObjectId());
		
		Key<DraftContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		when(ds.save(content1)).thenReturn(key1);
		
		contentDraftDao.updateContent(content1.getContentId().toString(), content1);
		
		verify(ds, times(1)).save(content1);
		
	}
	
	@Test
	public void createBulkContents() {
		
		List<BulkAdaptorResponse> contents = new ArrayList<>();
		BulkAdaptorResponse content = new BulkAdaptorResponse();
		DraftContentEntity content1 = new DraftContentEntity();
		content1.setContentId(new ObjectId());
		content.setEntity(content1);
		content.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(content);
		
		BulkAdaptorResponse bulkContent2 = new BulkAdaptorResponse();
		DraftContentEntity content2 = new DraftContentEntity();
		content2.setContentId(new ObjectId());
		bulkContent2.setEntity(content2);
		bulkContent2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent2);

		
		Key<DraftContentEntity> key1 = mock(Key.class);
		ObjectId id1 = new ObjectId();
		when(key1.getId()).thenReturn(id1);
		
		when(ds.save(content1)).thenReturn(key1);
		
		contentDraftDao.createBulkContents(contents);
		
		Assert.assertTrue(content.getContentId().equals(key1.getId().toString()));
		Assert.assertTrue(bulkContent2.getStatus().equals(CmsEditorStatus.CREATE_ERROR));
	}
	
	@Test
	public void deleteByContentIds() {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		List<BulkAdaptorResponse> contents = new ArrayList<>();
		BulkAdaptorResponse bulkContent2 = new BulkAdaptorResponse();
		DraftContentEntity content2 = new DraftContentEntity();
		content2.setContentId(new ObjectId());
		bulkContent2.setContentId(content2.getContentId().toString());
		bulkContent2.setEntity(content2);
		bulkContent2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent2);
		
		BulkAdaptorResponse bulkContent3 = new BulkAdaptorResponse();
		DraftContentEntity content3 = new DraftContentEntity();
		content3.setContentId(new ObjectId());
		bulkContent3.setEntity(content3);
		bulkContent3.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent3);
		
		contentDraftDao.deleteByContentIds(contents);
		
		verify(ds, times(1)).delete(query);
		
	}
	
	@Test
	public void deleteByContentIdsAndUserId() {
		
		Query<DraftContentEntity> query = mock(Query.class);
        FieldEnd fieldEnd = mock(FieldEnd.class);
        when(query.criteria(Matchers.anyString())).thenReturn(fieldEnd);
		when(ds.createQuery(any(Class.class))).thenReturn(query);
		
		List<BulkAdaptorResponse> contents = new ArrayList<>();
		
		contentDraftDao.deleteByContentIdsAndUserId(contents, "userId");
		
		BulkAdaptorResponse bulkContent2 = new BulkAdaptorResponse();
		DraftContentEntity content2 = new DraftContentEntity();
		content2.setContentId(new ObjectId());
		bulkContent2.setContentId(content2.getContentId().toString());
		bulkContent2.setEntity(content2);
		bulkContent2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent2);
		
		BulkAdaptorResponse bulkContent3 = new BulkAdaptorResponse();
		DraftContentEntity content3 = new DraftContentEntity();
		content3.setContentId(new ObjectId());
		bulkContent3.setEntity(content3);
		bulkContent3.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		contents.add(bulkContent3);
		
		contentDraftDao.deleteByContentIdsAndUserId(contents, "userId");
		
		verify(ds, times(1)).delete(query);
		
	}

}
