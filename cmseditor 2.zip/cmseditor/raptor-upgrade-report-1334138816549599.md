
# Project upgrade report to Raptor 2.0
## Project details
Name | Description
---- | -----------
Path to project POM |	pom.xml
Upgrade job ID | Some(1334138816549599)
Full upgrade log | [link](raptor-upgrade-debug-1334138816549599.log)
Upgrade warnings only log | [link](raptor-upgrade-warn-1334138816549599.log)

     ## Summary

| Operation | Details |
| ---- | ----------- |
|[com.ebay.rtran.maven.MavenExcludeDependenciesRule](#MavenExcludeDependenciesRule) | impacted 0 file(s) |
|[com.ebay.rtran.maven.MavenRemoveDependenciesRule](#MavenRemoveDependenciesRule) | impacted 0 file(s) |
