
# Project upgrade report to Raptor 2.0
## Project details
Name | Description
---- | -----------
Path to project POM |	pom.xml
Upgrade job ID | Some(1334669678857004)
Full upgrade log | [link](raptor-upgrade-debug-1334669678857004.log)
Upgrade warnings only log | [link](raptor-upgrade-warn-1334669678857004.log)

     ## Summary

| Operation | Details |
| ---- | ----------- |
|[com.ebay.rtran.maven.MavenExcludeDependenciesRule](#MavenExcludeDependenciesRule) | impacted 0 file(s) |
|[com.ebay.rtran.maven.MavenRemoveDependenciesRule](#MavenRemoveDependenciesRule) | impacted 0 file(s) |
