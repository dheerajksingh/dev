package com.ebay.raptor.cmseditor.task;

import static org.mockito.Mockito.mock;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.DeleteSectionRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.DeleteModuleTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class DeleteModuleTaskTest {
	
	@Test
	public void testDeleteModule() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteSectionRequest sectionRequest = new DeleteSectionRequest();
		sectionRequest.setContentId("57fff8ec399d3167c9e53fa4");
		sectionRequest.setGroupId("1");
		sectionRequest.setSectionId("1");
		request.setDeleteModuleRequest(sectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.deleteContentModule(sectionRequest.getContentId(), sectionRequest.getGroupId(), sectionRequest.getSectionId())).thenReturn(1);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteModuleTask deleteModuleTask = new DeleteModuleTask(request, providers,contentDraftDao);
		DeleteModuleTaskResponse moduleTaskResponse=(DeleteModuleTaskResponse) deleteModuleTask.createResponse();
		assertThat(moduleTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

	@Test
	public void testDeleteModuleFailure() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteSectionRequest sectionRequest = new DeleteSectionRequest();
		sectionRequest.setContentId("57fff8ec399d3167c9e53fa4");
		sectionRequest.setGroupId("1");
		sectionRequest.setSectionId("1");
		request.setDeleteModuleRequest(sectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.deleteContentModule(sectionRequest.getContentId(), sectionRequest.getGroupId(), sectionRequest.getSectionId())).thenReturn(0);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteModuleTask deleteModuleTask = new DeleteModuleTask(request, providers,contentDraftDao);
		DeleteModuleTaskResponse moduleTaskResponse=(DeleteModuleTaskResponse) deleteModuleTask.createResponse();
		assertThat(moduleTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(moduleTaskResponse.getError(),is(CmsEditorStatus.MODULE_NOT_FOUND));
	}
	
	@Test
	public void testDeleteModuleNullRequest() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteModuleTask deleteModuleTask = new DeleteModuleTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse moduleTaskResponse=deleteModuleTask.createResponse();
		assertThat(moduleTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(moduleTaskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testDeleteModuleNoAdminNoAccess() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteSectionRequest sectionRequest = new DeleteSectionRequest();
		sectionRequest.setContentId("57fff8ec399d3167c9e53fa4");
		sectionRequest.setGroupId("1");
		sectionRequest.setSectionId("1");
		request.setDeleteModuleRequest(sectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
//		List<String> aclList = new ArrayList<String>();
//		aclList.add("100");
//		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.deleteContentModule(sectionRequest.getContentId(), sectionRequest.getGroupId(), sectionRequest.getSectionId())).thenReturn(1);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteModuleTask deleteModuleTask = new DeleteModuleTask(request, providers,contentDraftDao);
		DeleteModuleTaskResponse moduleTaskResponse=(DeleteModuleTaskResponse) deleteModuleTask.createResponse();
		assertThat(moduleTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(moduleTaskResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
	}
	
	@Test
	public void testDeleteModuleAdmin() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteSectionRequest sectionRequest = new DeleteSectionRequest();
		sectionRequest.setContentId("57fff8ec399d3167c9e53fa4");
		sectionRequest.setGroupId("1");
		sectionRequest.setSectionId("1");
		request.setDeleteModuleRequest(sectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
//		List<String> aclList = new ArrayList<String>();
//		aclList.add("100");
//		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.deleteContentModule(sectionRequest.getContentId(), sectionRequest.getGroupId(), sectionRequest.getSectionId())).thenReturn(1);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.DELETE_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteModuleTask deleteModuleTask = new DeleteModuleTask(request, providers,contentDraftDao);
		DeleteModuleTaskResponse moduleTaskResponse=(DeleteModuleTaskResponse) deleteModuleTask.createResponse();
		assertThat(moduleTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testDeleteModuleGenericError() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteSectionRequest sectionRequest = new DeleteSectionRequest();
		sectionRequest.setContentId("57fff8ec399d3167c9e53fa4");
		sectionRequest.setGroupId("1");
		sectionRequest.setSectionId("1");
		request.setDeleteModuleRequest(sectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
//		List<String> aclList = new ArrayList<String>();
//		aclList.add("100");
//		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.deleteContentModule(sectionRequest.getContentId(), sectionRequest.getGroupId(), sectionRequest.getSectionId())).thenThrow(new Exception());
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.DELETE_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		DeleteModuleTask deleteModuleTask = new DeleteModuleTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse moduleTaskResponse=deleteModuleTask.createResponse();
		assertThat(moduleTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
	}
}
