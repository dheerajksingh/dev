package com.ebay.raptor.cmseditor.composer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.PublishArticleResponse;
import com.ebay.raptor.cmseditor.response.composer.PublishContentResponseComposer;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.PublishContentTaskResponse;

public class PublishContentResponseComposerTest {
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithTaskStatusNull() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		PublishContentTaskResponse taskResponse = new PublishContentTaskResponse();
		taskResponses.add(taskResponse);
		
		PublishContentResponseComposer composer = new PublishContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			throw c;
		}
	}

	@Test(expected = CmsEditorException.class)
	public void testComposeWithNoTaskResponses() throws Throwable{
		PublishContentResponseComposer composer = new PublishContentResponseComposer(null);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithFailedStatus() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		PublishContentTaskResponse taskResponse = new PublishContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		taskResponse.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		taskResponses.add(taskResponse);
		
		PublishContentResponseComposer composer = new PublishContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test
	public void testComposeWithSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		PublishContentTaskResponse taskResponse = new PublishContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		String contentId="1";
		taskResponse.setContentId(contentId);
		taskResponses.add(taskResponse);
		
		PublishContentResponseComposer composer = new PublishContentResponseComposer(taskResponses);
		PublishArticleResponse response = (PublishArticleResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getArticleId(),is(contentId));
	}
}