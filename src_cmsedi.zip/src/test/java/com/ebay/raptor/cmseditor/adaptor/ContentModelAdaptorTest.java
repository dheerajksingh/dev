package com.ebay.raptor.cmseditor.adaptor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;

import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.Video;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.adaptor.ContentModelAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.EntityComponent;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.is;

public class ContentModelAdaptorTest {
	
	@Test
	public void testAdaptToContentModelsFromDraft()  {
		
		List<DraftContentEntity> drafts = new ArrayList<DraftContentEntity>();
		DraftContentEntity draft = new DraftContentEntity();
		List<String> acl = new ArrayList<String>();
		acl.add("test");
		draft.setAccessControlList(acl);
		draft.setAuthorId(1L);
		draft.setAuthorName("a1");
		draft.setContentId(new ObjectId("576c6dae68ebeaa00281d324"));
		draft.setContentStatus(ArticleStatusEnum.DRAFT.name());
		Date d1 = new Date();
		draft.setDateCreated(d1);
		draft.setDateModified(d1);
		draft.setDeleted(false);
		draft.setLastModeratedUser(2L);
		draft.setLastModifiedUser(3L);
		draft.setMarkedAsProcessing("false");
		draft.setModerationStatus(ModerationStatusEnum.MODERATED.name());
		draft.setScheduledEndDate(d1);
		draft.setScheduledStartDate(d1);
		draft.setTemplateType("HOW_TO");
		//draft.setVisibilityLevel("private");
		UserGeneratedContentEntity draftContent = new UserGeneratedContentEntity();
		draftContent.setCoverImage("http://img");
		draftContent.setSynopsis("synopsis1");
		draftContent.setTitle("title1");
		List<String> draftTags = new ArrayList<String>();
		draftTags.add("t1");
		draftContent.setTags(draftTags);
		List<GroupEntity> groups = new ArrayList<GroupEntity>();
		GroupEntity grp = new GroupEntity();
		grp.setGroupId("1");
		grp.setGroupType("standard");
		grp.setTitle(new Text("take apart the ipod", LanguageEnum.en));
		Map<String,ModuleEntity> map = new HashMap<String, ModuleEntity>();
		ModuleEntity entity1 = new ModuleEntity();
		entity1.setAlignment("text_image");
		entity1.setModuleId("1");
		List<SingleModuleEntity> singleEntities = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity entity = new SingleModuleEntity();
		entity.setType("STANDARD");
		entity.setCaption("caption");
		entity.setData("data");
		singleEntities.add(entity);
		SingleModuleEntity entity2 = new SingleModuleEntity();
		entity2.setType("IMAGE");
		entity2.setCaption("caption");
		entity2.setResourceUrl("url");
		singleEntities.add(entity2);
		entity1.setData(singleEntities);
		map.put("1", entity1);
		grp.setModuleMap(map);
		groups.add(grp);
		draftContent.setGroups(groups);
		draft.setUserGeneratedContent(draftContent);
		
		drafts.add(draft);
		
		ContentModelAdaptor adaptor = new ContentModelAdaptor();
		List<Article> models = adaptor.adaptToContentModelsFromDraft(drafts);
		assertNotNull(models);
		assertThat(models.size(),is(1));
		Article model = models.get(0);
		assertThat(model.getAccessControlList(),is(draft.getAccessControlList()));
		assertThat(model.getAuthor().getUsername(),is(draft.getAuthorName()));
		assertThat(model.getArticleId(),is(draft.getContentId().toString()));
		assertThat(model.getDateCreated().getValue(),is(draft.getDateCreated()));
		assertThat(model.getDateModified().getValue(),is(draft.getDateModified()));
		assertThat(model.getTemplateType(),is(draft.getTemplateType()));
		assertThat(model.getUserGeneratedContent().getCoverImage().getImageURL(),is(draft.getUserGeneratedContent().getCoverImage()));
		assertThat(model.getUserGeneratedContent().getSynopsis().getContent(),is(draft.getUserGeneratedContent().getSynopsis()));
		assertThat(model.getUserGeneratedContent().getTitle().getContent(),is(draft.getUserGeneratedContent().getTitle()));
		assertThat(model.getUserGeneratedContent().getTags(),is(draft.getUserGeneratedContent().getTags()));
		List<Group> groupModels = model.getUserGeneratedContent().getGroups();
		Group groupModel = groupModels.get(0);
		assertThat(groupModel.getGroupId(),is(grp.getGroupId()));
		assertThat(groupModel.getGroupType(),is(grp.getGroupType()));
		assertThat(groupModel.getTitle().getContent(),is(grp.getTitle().getContent()));
		List<Section> modules = groupModel.getSections();
		Section module = modules.get(0);
		assertThat(module.getAlignment(),is(entity1.getAlignment()));
		assertThat(module.getSectionId(),is(entity1.getModuleId()));
		List<Component> singleModules = module.getComponents();
		StandardComponent s1 = (StandardComponent) singleModules.get(0);
		MediaComponent s2 =(MediaComponent) singleModules.get(1);
		assertThat(s1.getCaption(),is(entity.getCaption()));
		assertThat(s1.getData(),is(entity.getData()));
		assertThat(s1.getComponentType(),is(entity.getType()));
		assertThat(s2.getCaption(),is(entity2.getCaption()));
		assertThat(((Image)s2.getMedia()).getImageURL(),is(entity2.getResourceUrl()));
		assertThat(s2.getComponentType(),is(entity2.getType()));
		
		
	}
	

	@Test
	public void testAdaptToContentModelsFromPublished() throws JsonGenerationException, JsonMappingException, IOException{
		
		List<PublishedContentEntity> publishedContents = new ArrayList<PublishedContentEntity>();
		PublishedContentEntity published = new PublishedContentEntity();
		List<String> acl = new ArrayList<String>();
		acl.add("test");
		published.setAccessControlList(acl);
		published.setAuthorId(1L);
		published.setAuthorName("a1");
		published.setContentId(new ObjectId("576c6dae68ebeaa00281d324"));
		published.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		published.setDraftId("10");
		Date d1 = new Date();
		published.setDateCreated(d1);
		published.setDateModified(d1);
		published.setDeleted(false);
		published.setLastModeratedUser(2L);
		published.setLastModifiedUser(3L);
		published.setMarkedAsProcessing("false");
		published.setModerationStatus(ModerationStatusEnum.MODERATED.name());
		published.setScheduledEndDate(d1);
		published.setScheduledStartDate(d1);
		published.setTemplateType("HOW_TO");
		//published.setVisibilityLevel("private");
		UserGeneratedContentEntity publishedContent = new UserGeneratedContentEntity();
		publishedContent.setCoverImage("http://img");
		publishedContent.setSynopsis("synopsis1");
		publishedContent.setTitle("title1");
		List<String> draftTags = new ArrayList<String>();
		draftTags.add("t1");
		publishedContent.setTags(draftTags);
		List<GroupEntity> groups = new ArrayList<GroupEntity>();
		GroupEntity grp = new GroupEntity();
		grp.setGroupId("1");
		grp.setGroupType("standard");
		grp.setTitle(new Text("take apart the ipod", LanguageEnum.en));
		Map<String,ModuleEntity> map = new LinkedHashMap<String, ModuleEntity>();
		ModuleEntity entity1 = new ModuleEntity();
		entity1.setAlignment("text_image");
		entity1.setModuleId("1");
		List<SingleModuleEntity> singleEntities = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity entity = new SingleModuleEntity();
		entity.setType("STANDARD");
		entity.setCaption("caption");
		entity.setData("data");
		singleEntities.add(entity);
		SingleModuleEntity entity2 = new SingleModuleEntity();
		entity2.setType("IMAGE");
		entity2.setCaption("caption");
		entity2.setResourceUrl("url");
		singleEntities.add(entity2);
		entity1.setData(singleEntities);
		map.put("1", entity1);
		ModuleEntity moduleEntity2 = new ModuleEntity();
		moduleEntity2.setAlignment("standard");
		moduleEntity2.setModuleId("2");
		List<SingleModuleEntity> singleEntities2 = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity singleModuleEntity2 = new SingleModuleEntity();
		singleModuleEntity2.setType("VIDEO");
		singleModuleEntity2.setCaption("caption");
		singleModuleEntity2.setResourceUrl("url");
		singleModuleEntity2.setData("data");
		singleEntities2.add(singleModuleEntity2);
		moduleEntity2.setData(singleEntities2);
		map.put("2", moduleEntity2);
		
		ModuleEntity moduleEntity3 = new ModuleEntity();
		moduleEntity3.setAlignment("standard");
		moduleEntity3.setModuleId("3");
		List<SingleModuleEntity> singleEntities3 = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity singleModuleEntity3 = new SingleModuleEntity();
		singleModuleEntity3.setType("ENTITY");
		singleModuleEntity3.setCaption("caption");
		List<String> entityIds = new ArrayList<String>();
		entityIds.add("100");
		singleModuleEntity3.setEntityIds(entityIds);
		
		singleEntities3.add(singleModuleEntity3);
		moduleEntity3.setData(singleEntities3);
		map.put("3", moduleEntity3);
		
		grp.setModuleMap(map);
		groups.add(grp);
		publishedContent.setGroups(groups);
		published.setUserGeneratedContent(publishedContent);
		
		publishedContents.add(published);
		
		ContentModelAdaptor adaptor = new ContentModelAdaptor();
		List<Article> models = adaptor.adaptToContentModelsFromPublished(publishedContents);
		assertNotNull(models);
		assertThat(models.size(),is(1));
		Article model = models.get(0);
		System.out.println(new ObjectMapper().writeValueAsString(model));
		assertThat(model.getAccessControlList(),is(published.getAccessControlList()));
		assertThat(model.getAuthor().getUsername(),is(published.getAuthorName()));
		assertThat(model.getArticleId(),is(published.getContentId().toString()));
		assertThat(model.getDateCreated().getValue(),is(published.getDateCreated()));
		assertThat(model.getDateModified().getValue(),is(published.getDateModified()));
		assertThat(model.getTemplateType(),is(published.getTemplateType()));
		assertThat(model.getUserGeneratedContent().getCoverImage().getImageURL(),is(published.getUserGeneratedContent().getCoverImage()));
		assertThat(model.getUserGeneratedContent().getSynopsis().getContent(),is(published.getUserGeneratedContent().getSynopsis()));
		assertThat(model.getUserGeneratedContent().getTitle().getContent(),is(published.getUserGeneratedContent().getTitle()));
		assertThat(model.getUserGeneratedContent().getTags(),is(published.getUserGeneratedContent().getTags()));
		List<Group> groupModels = model.getUserGeneratedContent().getGroups();
		Group groupModel = groupModels.get(0);
		assertThat(groupModel.getGroupId(),is(grp.getGroupId()));
		assertThat(groupModel.getGroupType(),is(grp.getGroupType()));
		assertThat(groupModel.getTitle().getContent(),is(grp.getTitle().getContent()));
		List<Section> modules = groupModel.getSections();
		Section module = modules.get(0);
		assertThat(module.getAlignment(),is(entity1.getAlignment()));
		assertThat(module.getSectionId(),is(entity1.getModuleId()));
		List<Component> singleModules = module.getComponents();
		StandardComponent s1 = (StandardComponent) singleModules.get(0);
		MediaComponent s2 =(MediaComponent) singleModules.get(1);
		assertThat(s1.getCaption(),is(entity.getCaption()));
		assertThat(s1.getData(),is(entity.getData()));
		assertThat(s1.getComponentType(),is(entity.getType()));
		assertThat(s2.getCaption(),is(entity2.getCaption()));
		assertThat(((Image)s2.getMedia()).getImageURL(),is(entity2.getResourceUrl()));
		assertThat(s2.getComponentType(),is(entity2.getType()));
		
		Section videoModule = modules.get(1);
		assertThat(videoModule.getAlignment(),is(moduleEntity2.getAlignment()));
		assertThat(videoModule.getSectionId(),is(moduleEntity2.getModuleId()));
		List<Component> singleModules2 = videoModule.getComponents();
		MediaComponent s3=(MediaComponent) singleModules2.get(0);
		assertThat(s3.getCaption(),is(singleModuleEntity2.getCaption()));
		assertThat(((Video)s3.getMedia()).getVideoURL(),is(singleModuleEntity2.getResourceUrl()));
		assertThat(s3.getComponentType(),is(singleModuleEntity2.getType()));
		
		Section entityModule = modules.get(2);
		assertThat(entityModule.getAlignment(),is(moduleEntity3.getAlignment()));
		assertThat(entityModule.getSectionId(),is(moduleEntity3.getModuleId()));
		List<Component> singleModules3 = entityModule.getComponents();
		EntityComponent s4=(EntityComponent) singleModules3.get(0);
		assertThat(s4.getCaption(),is(singleModuleEntity3.getCaption()));
		assertThat(s4.getEntityIds(),is(entityIds));
		assertThat(s4.getComponentType(),is(singleModuleEntity3.getType()));
		
		
	}

}