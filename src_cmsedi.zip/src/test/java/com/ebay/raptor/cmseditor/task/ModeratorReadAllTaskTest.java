package com.ebay.raptor.cmseditor.task;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mockito.Matchers;

import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.eq;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;

import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentReadAllRequest;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.request.SortOrder;
import com.ebay.raptor.cmseditor.task.response.ContentReadAllTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class ModeratorReadAllTaskTest {
	
	
	@Test
	public void testModeratorReadAllTask(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadAllRequest req = new ContentReadAllRequest();
		List<ArticleStatusEnum> statuses = new ArrayList<ArticleStatusEnum>();
		statuses.add(ArticleStatusEnum.PUBLISHED);
		req.setStatuses(statuses);
		List<ModerationStatusEnum> moderationStatuses = new ArrayList<ModerationStatusEnum>();
		moderationStatuses.add(ModerationStatusEnum.MODERATED);
		req.setModerationStatuses(moderationStatuses);
		request.setContentReadAllRequest(req);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentDao = mock(ContentPublishDao.class);
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		PublishedContentEntity e1 = new PublishedContentEntity();
		e1.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		entities.add(e1);
		when(contentDao.findContents(eq(req.getLimit()), eq(req.getOffset()), eq(req.getSort().getSort()), Matchers.anyListOf(String.class), Matchers.anyListOf(String.class))).thenReturn(entities);
		
		ModeratorReadAllTask task = new ModeratorReadAllTask(request, providers,contentDao);
		ContentReadAllTaskResponse response=(ContentReadAllTaskResponse) task.createResponse();
		assertThat(response.getPublished(),is(entities));
	}
	
	@Test
	public void testModeratorReadAllTaskEmptyStatuses(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadAllRequest req = new ContentReadAllRequest();
		List<ArticleStatusEnum> statuses = new ArrayList<ArticleStatusEnum>();
		req.setStatuses(statuses);
		request.setContentReadAllRequest(req);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentDao = mock(ContentPublishDao.class);
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		when(contentDao.findContents(eq(req.getLimit()), eq(req.getOffset()), eq(req.getSort().getSort()), Matchers.anyListOf(String.class), Matchers.anyListOf(String.class))).thenReturn(entities);
		
		ModeratorReadAllTask task = new ModeratorReadAllTask(request, providers,contentDao);
		ContentReadAllTaskResponse response=(ContentReadAllTaskResponse) task.createResponse();
		assertThat(response.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testModeratorReadAllTaskNoPermissions(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadAllRequest req = new ContentReadAllRequest();
		List<ArticleStatusEnum> statuses = new ArrayList<ArticleStatusEnum>();
		statuses.add(ArticleStatusEnum.PUBLISHED);
		req.setStatuses(statuses);
		request.setContentReadAllRequest(req);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
//		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
//		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
//		Set<String> permissions = new HashSet<>();
//		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
//		userPermissionsTaskResponse.setPermissions(permissions);
//		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
//		providers.add(userPermissionsTask);
		
		ContentPublishDao contentDao = mock(ContentPublishDao.class);
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		when(contentDao.findContents(eq(req.getLimit()), eq(req.getOffset()), eq(req.getSort().getSort()), Matchers.anyListOf(String.class), Matchers.anyListOf(String.class))).thenReturn(entities);
		
		ModeratorReadAllTask task = new ModeratorReadAllTask(request, providers,contentDao);
		ContentReadAllTaskResponse response=(ContentReadAllTaskResponse) task.createResponse();
		assertThat(response.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
	}
	
	@Test
	public void testModeratorReadAllTaskInternalServerError(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadAllRequest req = new ContentReadAllRequest();
		List<ArticleStatusEnum> statuses = new ArrayList<ArticleStatusEnum>();
		statuses.add(ArticleStatusEnum.PUBLISHED);
		req.setStatuses(statuses);
		List<ModerationStatusEnum> moderationStatuses = new ArrayList<ModerationStatusEnum>();
		moderationStatuses.add(ModerationStatusEnum.MODERATED);
		req.setModerationStatuses(moderationStatuses);
		req.setLimit(10);
		req.setOffset(0);
		req.setSort(SortOrder.DATE_MODIFIED_DESC);
		request.setContentReadAllRequest(req);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentDao = mock(ContentPublishDao.class);
		when(contentDao.findContents(eq(req.getLimit()), eq(req.getOffset()), eq(req.getSort().getSort()), Matchers.anyListOf(String.class), Matchers.anyListOf(String.class))).
		thenThrow(new RuntimeException());
		
		ModeratorReadAllTask task = new ModeratorReadAllTask(request, providers,contentDao);
		ContentReadAllTaskResponse response=(ContentReadAllTaskResponse) task.createResponse();
		assertThat(response.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
	

}
