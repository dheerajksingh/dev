package com.ebay.raptor.cmseditor.task;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.context.ApplicationContext;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.BulkCreateArticleRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.raptor.cmseditor.task.response.BulkContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserIdsByUsernamesTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class BulkCreateContentTaskTest {
	
	@Test
	public void testBulkCreateContentTaskwithNullRequest(){
		
		//ApplicationContext context = mock(ApplicationContext.class);
		BulkCreateContentTask task = new BulkCreateContentTask(null, null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testBulkCreateContentTaskwithNullBulkCreateRequest(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		ApplicationContext context = mock(ApplicationContext.class);
		request.setApplicationContext(context);
		BulkCreateContentTask task = new BulkCreateContentTask(request, null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testBulkCreateContentTaskwithNoAuthor(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("PUBLISHED");
		
		
		Article c1 = new Article();
		c1.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc1);
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, null);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
	}
	
	@Test
	public void testBulkUpdateContentTaskwithNoAuthor(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("PUBLISHED");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		c1.setTemplateType("HOW_TO");

		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		
		Article c2 = new Article();
		c2.setArticleId("57642e704b75cb914491ddae");
		c2.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		c2.setTemplateType("HOW_TO");
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		upResponse.setPermissions(new HashSet<String>());
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		ContentEntity c2Entity = new ContentEntity();
		c2Entity.setAuthorId(101l);
		c2Entity.setAuthorName("user2");
		List<String> accessControlList2 = new ArrayList<String>();
		accessControlList2.add("102");
		c2Entity.setAccessControlList(accessControlList2);
		contentEntityMap.put("57642e704b75cb914491ddae", c2Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertEquals(bulkResponse.getResponses().get(0).getStatus(),CmsEditorStatus.BULK_CREATE_SUCCESS);
		assertEquals(bulkResponse.getResponses().get(1).getStatus(),CmsEditorStatus.USER_ACCESS_ERROR);
	}
	
	@Test
	public void testBulkUpdateContentTaskAsAdmin(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("PUBLISHED");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		c1.setTemplateType("HOW_TO");
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		UserIdentifier author = new UserIdentifier();
		author.setUsername("user2");
		c2.setAuthor(author);
		c2.setTemplateType("HOW_TO");
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertEquals(bulkResponse.getResponses().get(0).getStatus(),CmsEditorStatus.BULK_CREATE_SUCCESS);
	}
	
	@Test
	public void testBulkUpdateDrafts(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		when(context.getBean(ContentDraftDao.class)).thenReturn(contentDao);
		Mockito.doNothing().when(contentDao).createBulkContents(Matchers.anyListOf(BulkAdaptorResponse.class));
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("DRAFT");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.DRAFT);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		UserIdentifier a1 = new UserIdentifier();
		a1.setUsername("user1");
		c1.setAuthor(a1);
		c1.setTemplateType("HOW_TO");
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.DRAFT);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		UserIdentifier author = new UserIdentifier();
		author.setUsername("user2");
		c2.setAuthor(author);
		c2.setTemplateType("HOW_TO");
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		usernamesToUserIdsMap.put("user1", 100l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertEquals(bulkResponse.getResponses().get(0).getStatus(),CmsEditorStatus.BULK_CREATE_SUCCESS);
	}
	
	@Test
	public void testBulkUpdateDraftsInternalServerError(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		when(context.getBean(ContentDraftDao.class)).thenReturn(contentDao);
		Mockito.doNothing().when(contentDao).createBulkContents(Matchers.anyListOf(BulkAdaptorResponse.class));
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("DRAFT");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.DRAFT);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		c1.setTemplateType("HOW_TO");
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.DRAFT);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		c2.setTemplateType("HOW_TO");
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		usernamesToUserIdsMap.put("user1", 100l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertThat(bulkResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
	}
	
	@Test
	public void testBulkUpdateDraftsInternalServerError2(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao contentDao = mock(ContentDraftDao.class);
		when(context.getBean(ContentDraftDao.class)).thenReturn(contentDao);
		Mockito.doThrow(new RuntimeException()).when(contentDao).createBulkContents(Matchers.anyListOf(BulkAdaptorResponse.class));
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("DRAFT");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.DRAFT);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		UserIdentifier a1 = new UserIdentifier();
		a1.setUsername("user1");
		c1.setAuthor(a1);
		c1.setTemplateType("HOW_TO");
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.DRAFT);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		UserIdentifier author = new UserIdentifier();
		author.setUsername("user2");
		c2.setAuthor(author);
		c2.setTemplateType("HOW_TO");
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		usernamesToUserIdsMap.put("user1", 100l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertThat(bulkResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
	}
	
	@Test
	public void testBulkUpdateContentTaskNoAdmin(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("PUBLISHED");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		c1.setTemplateType("HOW_TO");
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		c2.setTemplateType("HOW_TO");
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertEquals(bulkResponse.getResponses().get(0).getStatus(),CmsEditorStatus.BULK_CREATE_SUCCESS);
	}
	
	@Test
	public void testBulkUpdateContentTaskNoArticles(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("PUBLISHED");
		
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		CmsEditorTaskResponse bulkResponse = taskResponse;
		assertEquals(bulkResponse.getTaskStatus(),CmsEditorTaskStatus.FAILURE);
	}
	
	@Test
	public void testBulkUpdateContentTaskNoBulkResponse(){
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100l);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		request.setApplicationContext(context);
		
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setUserId("100");
		bulkCreateRequest.setMode("PUBLISHED");
		
		Article c1 = new Article();
		c1.setArticleId("57642e704b75cb914491ddac");
		c1.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c1.setDateCreated(new DateTime());
		c1.setDateModified(new DateTime());
		UserGeneratedContent ugc1 = new UserGeneratedContent();
		ugc1.setTitle(new Text("Title1", LanguageEnum.en));
		c1.setUserGeneratedContent(ugc1);
		c1.setTemplateType("HOW_TO");
		
		Article c2 = new Article();
		c2.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		c2.setDateCreated(new DateTime());
		c2.setDateModified(new DateTime());
		UserGeneratedContent ugc2 = new UserGeneratedContent();
		ugc2.setTitle(new Text("Title2", LanguageEnum.en));
		c2.setUserGeneratedContent(ugc2);
		UserIdentifier author = new UserIdentifier();
		author.setUsername("user2");
		c2.setAuthor(author);
		c2.setTemplateType("HOW_TO");
		
		List<Article> contents = new ArrayList<Article>();
		contents.add(c1);
		contents.add(c2);
		bulkCreateRequest.setArticles(contents);
		
		request.setCreateBulkContentRequest(bulkCreateRequest);
		
		//Creating subtasks 
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		
		GetUserPermissionsTask upTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse upResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		upResponse.setPermissions(permissions);
		when(upTask.getTaskResponse()).thenReturn(upResponse);
		providerTasks.add(upTask);
		
		GetUserIdsByUsernamesTask getUserIdsByUsernamesTask = mock(GetUserIdsByUsernamesTask.class);
		GetUserIdsByUsernamesTaskResponse userIdsResponse = new GetUserIdsByUsernamesTaskResponse();
		Map<String, Long> usernamesToUserIdsMap = new HashMap<String, Long>();
		usernamesToUserIdsMap.put("user2", 102l);
		userIdsResponse.setUserNamesToUserIdsMap(usernamesToUserIdsMap);
		when(getUserIdsByUsernamesTask.getTaskResponse()).thenReturn(userIdsResponse);
		providerTasks.add(getUserIdsByUsernamesTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		
		ContentEntity c1Entity = new ContentEntity();
		c1Entity.setAuthorId(100l);
		c1Entity.setAuthorName("user1");
		List<String> accessControlList1 = new ArrayList<String>();
		accessControlList1.add("100");
		c1Entity.setAccessControlList(accessControlList1);
		contentEntityMap.put("57642e704b75cb914491ddac", c1Entity);
		
		aclResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclResponse);
		providerTasks.add(aclTask);
		
		BulkCreateContentTask task = new BulkCreateContentTask(request, providerTasks);
		CmsEditorTaskResponse taskResponse=task.createResponse();
		assertNotNull(taskResponse);
		BulkContentTaskResponse bulkResponse = (BulkContentTaskResponse)taskResponse;
		assertEquals(bulkResponse.getResponses().get(0).getStatus(),CmsEditorStatus.BULK_CREATE_SUCCESS);
	}

}