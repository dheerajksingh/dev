package com.ebay.raptor.cmseditor.composer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.composer.UpdateModuleResponseComposer;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.UpdateModuleTaskResponse;

public class UpdateModuleResponseComposerTest {
	
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithTaskStatusNull() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		UpdateModuleTaskResponse taskResponse = new UpdateModuleTaskResponse();
		taskResponses.add(taskResponse);
		
		UpdateModuleResponseComposer composer = new UpdateModuleResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			throw c;
		}
	}

	@Test(expected = CmsEditorException.class)
	public void testComposeWithNoTaskResponses() throws Throwable{
		UpdateModuleResponseComposer composer = new UpdateModuleResponseComposer(null);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithFailedStatus() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		UpdateModuleTaskResponse taskResponse = new UpdateModuleTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		taskResponse.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		taskResponses.add(taskResponse);
		
		UpdateModuleResponseComposer composer = new UpdateModuleResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test
	public void testComposeWithSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		UpdateModuleTaskResponse taskResponse = new UpdateModuleTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		taskResponses.add(taskResponse);
		
		UpdateModuleResponseComposer composer = new UpdateModuleResponseComposer(taskResponses);
		CmsEditorResponse response =  composer.compose();
		assertNotNull(response);
	}

	

}
