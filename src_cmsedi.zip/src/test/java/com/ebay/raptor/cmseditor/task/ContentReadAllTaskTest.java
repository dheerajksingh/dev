package com.ebay.raptor.cmseditor.task;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mockito.Matchers;

import static org.mockito.Mockito.eq;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentsResponse;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentsResponse;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentReadAllRequest;
import com.ebay.raptor.cmseditor.request.SortOrder;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadAllTaskResponse;

public class ContentReadAllTaskTest {
	
	
	@Test
	public void testReadDrafts() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao=mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentReadAllRequest readAllRequest = new ContentReadAllRequest();
		readAllRequest.setLimit(10);
		readAllRequest.setContentStatuses("DRAFT");
		readAllRequest.setOffset(0);
		readAllRequest.setSort(SortOrder.DATE_MODIFIED_DESC);
		readAllRequest.setUserId("100");
		request.setUserId(100L);
		request.setContentReadAllRequest(readAllRequest);
		
		DraftContentsResponse resp = new DraftContentsResponse();
		resp.setCount(10L);
		List<DraftContentEntity> entities = new ArrayList<DraftContentEntity>();
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		entities.add(entity);
		resp.setDrafts(entities);
		
		when(contentDraftDao.findContentByUserId(eq("100"), eq(10), eq(0), eq(SortOrder.DATE_MODIFIED_DESC.getSort()),Matchers.anyListOf(String.class) ,
				Matchers.anyListOf(String.class))).thenReturn(resp);
		
		ContentReadAllTask task = new ContentReadAllTask(request, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		ContentReadAllTaskResponse taskResponse=(ContentReadAllTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getDraftArticlesCount(),is(10L));
		assertThat(taskResponse.getDrafts().get(0).getContentId(), is(entity.getContentId()));
		
	}

	@Test
	public void testReadPublished() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao=mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentReadAllRequest readAllRequest = new ContentReadAllRequest();
		readAllRequest.setLimit(10);
		readAllRequest.setContentStatuses("SUBMITTED");
		readAllRequest.setOffset(0);
		readAllRequest.setSort(SortOrder.DATE_MODIFIED_DESC);
		readAllRequest.setUserId("100");
		request.setUserId(100L);
		request.setContentReadAllRequest(readAllRequest);
		
		PublishedContentsResponse resp = new PublishedContentsResponse();
		resp.setCount(10L);
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		entities.add(entity);
		resp.setPublishedContents(entities);
		
		when(contentPublishDao.findContentByUserId(eq("100"), eq(10), eq(0), eq(SortOrder.DATE_MODIFIED_DESC.getSort()),Matchers.anyListOf(String.class) ,
				Matchers.anyListOf(String.class))).thenReturn(resp);
		
		ContentReadAllTask task = new ContentReadAllTask(request, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		ContentReadAllTaskResponse taskResponse=(ContentReadAllTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getPublishedArticlesCount(),is(10L));
		assertThat(taskResponse.getPublished().get(0).getContentId(), is(entity.getContentId()));
		
	}
	
	@Test
	public void testWithNullStatuses() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao=mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentReadAllRequest readAllRequest = new ContentReadAllRequest();
		readAllRequest.setLimit(10);
		readAllRequest.setOffset(0);
		readAllRequest.setSort(SortOrder.DATE_MODIFIED_DESC);
		readAllRequest.setUserId("100");
		request.setUserId(100L);
		request.setContentReadAllRequest(readAllRequest);
		
		PublishedContentsResponse resp = new PublishedContentsResponse();
		resp.setCount(10L);
		List<PublishedContentEntity> entities = new ArrayList<PublishedContentEntity>();
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		entities.add(entity);
		resp.setPublishedContents(entities);
		
		when(contentPublishDao.findContentByUserId(eq("100"), eq(10), eq(0), eq(SortOrder.DATE_MODIFIED_DESC.getSort()),Matchers.anyListOf(String.class) ,
				Matchers.anyListOf(String.class))).thenReturn(resp);
		
		ContentReadAllTask task = new ContentReadAllTask(request, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		ContentReadAllTaskResponse taskResponse=(ContentReadAllTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
}
