package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.request.BulkCreateArticleRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.task.factory.CmsEditorTaskFactory;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class CmsEditorTaskFactoryTest {

	@Test
	public void testgetTasks1(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		BulkCreateArticleRequest bulkCreateRequest = new BulkCreateArticleRequest();
		bulkCreateRequest.setMode("DRAFT");
		bulkCreateRequest.setArticles(new ArrayList<Article>());
		when(request.getCreateBulkContentRequest()).thenReturn(bulkCreateRequest);
		when(request.getSelector()).thenReturn(Selector.BULK_CREATE_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetAccessControlListTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(GetUserNameByIdTask.class.getName()));
		assertThat(tasks.get(3).getClass().getName(),is(GetUserIdsByUsernamesTask.class.getName()));
		assertThat(tasks.get(4).getClass().getName(),is(BulkCreateContentTask.class.getName()));
	}
	

	@Test
	public void testgetTasks2(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.BULK_DELETE_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(BulkSoftDeleteContentTask.class.getName()));
	}
	
	@Test
	public void testgetTasks3(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.CREATE_DRAFT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserNameByIdTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetPublicUserIdByIdTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(CreateDraftTask.class.getName()));
	}
	
	@Test
	public void testgetTasks4(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.DELETE_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(SoftDeleteContentTask.class.getName()));
	}
	
	@Test
	public void testgetTasks5(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.DELETE_MODULE);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetAccessControlListTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(DeleteModuleTask.class.getName()));
	}
	
	@Test
	public void testgetTasks6(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.GET_FOR_EDIT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetForEditTask.class.getName()));
	}
	
	@Test
	public void testgetTasks7(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.PUBLISH_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(PublishContentTask.class.getName()));
	}
	
	@Test
	public void testgetTasks8(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.READ_ALL_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(ContentReadAllTask.class.getName()));
	}
	
	@Test
	public void testgetTasks9(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.READ_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetArticleViewsTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(ContentReadTask.class.getName()));
	}
	
	@Test
	public void testgetTasks10(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_CONTENT);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetAccessControlListTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(UpdateContentTask.class.getName()));
	}
	
	@Test
	public void testgetTasks11(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_CONTENT_ATTRIBUTE);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetAccessControlListTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(UpdateAttributeTask.class.getName()));
	}
	
	@Test
	public void testgetTasks12(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_MODULE);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(GetAccessControlListTask.class.getName()));
		assertThat(tasks.get(2).getClass().getName(),is(UpdateModuleTask.class.getName()));
	}
	
	@Test
	public void testgetTasks13(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.UPDATE_STATUS_FOR_MODERATION);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(UpdateModerationStatusTask.class.getName()));
	}
	
	
	@Test
	public void testgetTasks15(){
		
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.GET_FOR_MODERATION);
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
		assertThat(tasks.get(0).getClass().getName(),is(GetUserPermissionsTask.class.getName()));
		assertThat(tasks.get(1).getClass().getName(),is(ModeratorReadAllTask.class.getName()));
	}
	
	@Test
	public void testgetTasksWithNullRequest(){
		List<ICmsEditorTask> tasks=CmsEditorTaskFactory.getTasks(null);
		assertNotNull(tasks);
	}
	
	@Test
	public void testgetTasksWithNullSelector(){
		CmsEditorRequest request = new CmsEditorRequest();
		List<ICmsEditorTask> tasks=CmsEditorTaskFactory.getTasks(request);
		assertNotNull(tasks);
	}
	
	
}