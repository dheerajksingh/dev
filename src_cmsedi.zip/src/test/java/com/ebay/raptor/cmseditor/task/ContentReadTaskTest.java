package com.ebay.raptor.cmseditor.task;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.junit.Test;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentReadRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetArticleViewsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class ContentReadTaskTest {
	
	
	@Test
	public void testContentReadDraft() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.DRAFT);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentStatus("DRAFT");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(contentReadtaskResponse.getContent().getContentId(),is(entity.getContentId()));
		
	}
	
	@Test
	public void testContentReadNullStatus() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentStatus("DRAFT");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
	
	@Test
	public void testContentReadDraftNoUserId() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.DRAFT);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentStatus("DRAFT");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.USER_NOT_SIGNED_IN_ERROR));
		
	}
	
	@Test
	public void testContentReadContentNotFound() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.DRAFT);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(null);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}
	
	@Test
	public void testContentReadDraftNoAcl() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.DRAFT);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentStatus("DRAFT");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
	
	@Test
	public void testContentReadDraftBadAcl() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.DRAFT);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentStatus("DRAFT");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("200");
		entity.setAccessControlList(acl);
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
		
	}
	
	@Test
	public void testContentReadPublished() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(contentReadtaskResponse.getContent().getContentId(),is(entity.getContentId()));
		
	}
	
	@Test
	public void testContentReadPublishedNonSignIn() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SPAM_SUSPECTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}
	
	@Test
	public void testContentReadPublishedBadContentId() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e534");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e534")).thenThrow(new IllegalArgumentException());
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
	@Test
	public void testContentReadPublishedException() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e534");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e534")).thenThrow(new Exception());
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testContentReadPublishedContentNotFound() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(null);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}

	
	@Test
	public void testContentReadPublishedSpamWithAuthorizedApplication() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setAuthorizedApplication(true);
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SPAM_SUSPECTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(contentReadtaskResponse.getContent().getContentId(),is(entity.getContentId()));
		
	}
	
	@Test
	public void testContentReadPublishedSpamWithNonSignIn() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SPAM_SUSPECTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}

	@Test
	public void testContentReadPublishedSpamWithSignIn() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setUserId("100");
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SPAM_SUSPECTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(contentReadtaskResponse.getContent().getContentId(),is(entity.getContentId()));
		
	}
	
	@Test
	public void testContentReadPublishedSpamWithAdmin() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.BLACKLIST_CONTENT.name());
		taskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SPAM_SUSPECTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		//acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(contentReadtaskResponse.getContent().getContentId(),is(entity.getContentId()));
		
	}
	
	@Test
	public void testContentReadPublishedSpamWithSignInAndNoAdmin() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		ContentReadRequest readRequest = new ContentReadRequest();
		readRequest.setContentId("57fff8ec399d3167c9e53fa4");
		readRequest.setStatus(ArticleStatusEnum.SUBMITTED);
		readRequest.setUserId("100");
		request.setContentReadRequest(readRequest);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse taskResponse = new GetUserPermissionsTaskResponse();
		taskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(taskResponse);
		providerTasks.add(userPermissionsTask);
		
		GetArticleViewsTask articlesViewTask = mock(GetArticleViewsTask.class);
		GetArticleViewsTaskResponse articlesViewTaskResponse = new GetArticleViewsTaskResponse();
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("57fff8ec399d3167c9e53fa4", 1000L);
		articlesViewTaskResponse.setArticleViewsMap(map);
		when(articlesViewTask.getTaskResponse()).thenReturn(articlesViewTaskResponse);
		providerTasks.add(articlesViewTask);
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SPAM_SUSPECTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		ContentReadTask task = new ContentReadTask(request, providerTasks,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse contentReadtaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertNotNull(contentReadtaskResponse);
		assertThat(contentReadtaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(contentReadtaskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}

}
