package com.ebay.raptor.cmseditor.composer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.composer.UpdateContentResponseComposer;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.UpdateContentTaskResponse;

public class UpdateContentResponseComposerTest {
	
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithTaskStatusNull() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		UpdateContentTaskResponse taskResponse = new UpdateContentTaskResponse();
		taskResponses.add(taskResponse);
		
		UpdateContentResponseComposer composer = new UpdateContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			throw c;
		}
	}

	@Test(expected = CmsEditorException.class)
	public void testComposeWithNoTaskResponses() throws Throwable{
		UpdateContentResponseComposer composer = new UpdateContentResponseComposer(null);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithFailedStatus() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		UpdateContentTaskResponse taskResponse = new UpdateContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		taskResponse.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		taskResponses.add(taskResponse);
		
		UpdateContentResponseComposer composer = new UpdateContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test
	public void testComposeWithSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		UpdateContentTaskResponse taskResponse = new UpdateContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		taskResponses.add(taskResponse);
		
		UpdateContentResponseComposer composer = new UpdateContentResponseComposer(taskResponses);
		CmsEditorResponse response =  composer.compose();
		assertNotNull(response);
	}

}
