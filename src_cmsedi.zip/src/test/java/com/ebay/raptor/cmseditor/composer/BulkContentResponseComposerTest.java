package com.ebay.raptor.cmseditor.composer;

import java.util.ArrayList;
import java.util.List;

import org.ebayopensource.ginger.common.types.ErrorData;
import org.junit.Test;

import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.BulkArticleResponse;
import com.ebay.raptor.cmseditor.response.BulkPayload;
import com.ebay.raptor.cmseditor.response.BulkResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.composer.BulkContentResponseComposer;
import com.ebay.raptor.cmseditor.task.response.BulkContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.hamcrest.CoreMatchers.is;


public class BulkContentResponseComposerTest {
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithTaskStatusNull() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithNoTaskResponses() throws Throwable{
		BulkContentResponseComposer composer = new BulkContentResponseComposer(null);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithEmptyTaskResponses() throws Throwable{
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithFailedStatus() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		taskResponse.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test
	public void testComposeWithEmptyResponses() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
	}
	
	@Test
	public void testComposeWithBulkCreateAllSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setAuthor("a1");
		response1.setContentId("1");
		response1.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		response1.setTitle("t1");
		responses.add(response1);
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setAuthor("a2");
		response2.setContentId("2");
		response2.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		response2.setTitle("t2");
		responses.add(response2);
		taskResponse.setResponses(responses);
		
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		BulkArticleResponse response = (BulkArticleResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getStatusCode(), is(201));
		assertThat(response.getPayload().size(),is(2));
		List<BulkResponse> payloads = response.getPayload();
		int i=0;
		for(BulkResponse payload:payloads){
			assertThat(payload.getHttpStatus(), is(201));
			assertEquals(payload.getError(),null);
			BulkPayload p = payload.getPayload();
			if(i==0){
				assertThat(p.getAuthor(),is(response1.getAuthor()));
				assertThat(p.getTitle(),is(response1.getTitle()));
				assertThat(p.getContentId(),is(response1.getContentId()));
			}else{
				assertThat(p.getAuthor(),is(response2.getAuthor()));
				assertThat(p.getTitle(),is(response2.getTitle()));
				assertThat(p.getContentId(),is(response2.getContentId()));
			}
			i++;
		}
	}
	
	@Test
	public void testComposeWithBulkCreatePartialSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setAuthor("a1");
		response1.setContentId("1");
		response1.setStatus(CmsEditorStatus.BULK_CREATE_SUCCESS);
		response1.setTitle("t1");
		responses.add(response1);
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setAuthor("a2");
		response2.setContentId("2");
		response2.setStatus(CmsEditorStatus.CREATE_ERROR);
		response2.setTitle("t2");
		responses.add(response2);
		taskResponse.setResponses(responses);
		
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		BulkArticleResponse response = (BulkArticleResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getStatusCode(), is(207));
		assertThat(response.getPayload().size(),is(2));
		List<BulkResponse> payloads = response.getPayload();
		int i=0;
		for(BulkResponse payload:payloads){
			BulkPayload p = payload.getPayload();
			if(i==0){
				assertThat(payload.getHttpStatus(), is(201));
				assertThat(p.getAuthor(),is(response1.getAuthor()));
				assertThat(p.getTitle(),is(response1.getTitle()));
				assertThat(p.getContentId(),is(response1.getContentId()));
			}else{
				assertThat(payload.getHttpStatus(), is(response2.getStatus().getStatus()));
				assertNotNull(payload.getError());
				ErrorData e = payload.getError();
				assertThat(e.getErrorId(),is(response2.getStatus().getId()));
				assertThat(p.getAuthor(),is(response2.getAuthor()));
				assertThat(p.getTitle(),is(response2.getTitle()));
				assertThat(p.getContentId(),is(response2.getContentId()));
			}
			i++;
		}
	}
	
	@Test
	public void testComposeWithBulkDeleteAllSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setAuthor("a1");
		response1.setContentId("1");
		response1.setStatus(CmsEditorStatus.BULK_DELETE_SUCCESS);
		response1.setTitle("t1");
		responses.add(response1);
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setAuthor("a2");
		response2.setContentId("2");
		response2.setStatus(CmsEditorStatus.BULK_DELETE_SUCCESS);
		response2.setTitle("t2");
		responses.add(response2);
		taskResponse.setResponses(responses);
		
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		BulkArticleResponse response = (BulkArticleResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getStatusCode(), is(200));
		assertThat(response.getPayload().size(),is(2));
		List<BulkResponse> payloads = response.getPayload();
		int i=0;
		for(BulkResponse payload:payloads){
			assertThat(payload.getHttpStatus(), is(200));
			assertEquals(payload.getError(),null);
			BulkPayload p = payload.getPayload();
			if(i==0){
				assertThat(p.getAuthor(),is(response1.getAuthor()));
				assertThat(p.getTitle(),is(response1.getTitle()));
				assertThat(p.getContentId(),is(response1.getContentId()));
			}else{
				assertThat(p.getAuthor(),is(response2.getAuthor()));
				assertThat(p.getTitle(),is(response2.getTitle()));
				assertThat(p.getContentId(),is(response2.getContentId()));
			}
			i++;
		}
	}
	
	@Test
	public void testComposeWithBulkDeletePartialSuccess() throws CmsEditorException{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		BulkContentTaskResponse taskResponse = new BulkContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
		BulkAdaptorResponse response1 = new BulkAdaptorResponse();
		response1.setAuthor("a1");
		response1.setContentId("1");
		response1.setStatus(CmsEditorStatus.BULK_DELETE_SUCCESS);
		response1.setTitle("t1");
		responses.add(response1);
		
		BulkAdaptorResponse response2 = new BulkAdaptorResponse();
		response2.setAuthor("a2");
		response2.setContentId("2");
		response2.setStatus(CmsEditorStatus.CONTENT_NOT_FOUND);
		response2.setTitle("t2");
		responses.add(response2);
		taskResponse.setResponses(responses);
		
		taskResponses.add(taskResponse);
		
		BulkContentResponseComposer composer = new BulkContentResponseComposer(taskResponses);
		BulkArticleResponse response = (BulkArticleResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getStatusCode(), is(207));
		assertThat(response.getPayload().size(),is(2));
		List<BulkResponse> payloads = response.getPayload();
		int i=0;
		for(BulkResponse payload:payloads){
			BulkPayload p = payload.getPayload();
			if(i==0){
				assertThat(payload.getHttpStatus(), is(200));
				assertThat(p.getAuthor(),is(response1.getAuthor()));
				assertThat(p.getTitle(),is(response1.getTitle()));
				assertThat(p.getContentId(),is(response1.getContentId()));
			}else{
				assertThat(payload.getHttpStatus(), is(response2.getStatus().getStatus()));
				assertNotNull(payload.getError());
				ErrorData e = payload.getError();
				assertThat(e.getErrorId(),is(response2.getStatus().getId()));
				assertThat(p.getAuthor(),is(response2.getAuthor()));
				assertThat(p.getTitle(),is(response2.getTitle()));
				assertThat(p.getContentId(),is(response2.getContentId()));
			}
			i++;
		}
	}

}