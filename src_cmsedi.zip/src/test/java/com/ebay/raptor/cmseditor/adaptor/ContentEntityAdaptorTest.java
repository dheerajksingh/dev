package com.ebay.raptor.cmseditor.adaptor;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Ignore;
import org.junit.Test;

import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.Video;
import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.exception.IllegalContentIdException;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.EntityComponent;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
public class ContentEntityAdaptorTest {
	
	static ObjectMapper mapper;
	
	static{
		mapper=new ObjectMapper();
	}
	
	@Test
	@Ignore
	public void testAdaptPublished() throws JsonParseException, JsonMappingException, IOException, IllegalContentIdException, CmsEditorException{
		
		
		String modelData="{\r\n  \"type\": \"Article\",\r\n  \"articleId\": \"576c6dae68ebeaa00281d324\",\r\n  \"articleStatus\": \"LIVE\",\r\n  \"templateType\": \"HOW_TO\",\r\n  \"dateCreated\": {\r\n    \"value\": \"2016-07-05T22:32:07.573Z\"\r\n  },\r\n  \"dateModified\": {\r\n    \"value\": \"2016-07-05T22:32:07.573Z\"\r\n  },\r\n  \"userGeneratedContent\": {\r\n    \"title\": {\r\n      \"content\": \"title1\",\r\n      \"language\": \"en\"\r\n    },\r\n    \"synopsis\": {\r\n      \"content\": \"synopsis1\",\r\n      \"language\": \"en\"\r\n    },\r\n    \"coverImage\": {\r\n      \"type\": \"image\",\r\n      \"imageURL\": \"http://img\",\r\n      \"imageURLType\": \"NEW_ZOOM\",\r\n      \"imageURLElements\": {\r\n        \"ZOOM_GUID\": null\r\n      }\r\n    },\r\n    \"tags\": [\r\n      \"t1\"\r\n    ],\r\n    \"groups\": [\r\n      {\r\n        \"title\": {\r\n          \"content\": \"take apart the ipod\",\r\n          \"language\": \"en\"\r\n        },\r\n        \"groupType\": \"standard\",\r\n        \"groupId\": 1,\r\n        \"compositeModules\": [\r\n          {\r\n            \"alignment\": \"text_image\",\r\n            \"modules\": [\r\n              {\r\n                \"type\": \"standard\",\r\n                \"moduleType\": \"STANDARD\",\r\n                \"caption\": \"caption\",\r\n                \"data\": \"data\"\r\n              },\r\n              {\r\n                \"type\": \"media\",\r\n                \"moduleType\": \"IMAGE\",\r\n                \"caption\": \"caption\",\r\n                \"media\": {\r\n                  \"type\": \"image\",\r\n                  \"imageURL\": \"url\",\r\n                  \"imageURLType\": \"NEW_ZOOM\",\r\n                  \"imageURLElements\": {\r\n                    \"ZOOM_GUID\": null\r\n                  }\r\n                }\r\n              }\r\n            ],\r\n            \"compositeModuleId\": 1\r\n          },\r\n          {\r\n            \"alignment\": \"standard\",\r\n            \"modules\": [\r\n              {\r\n                \"type\": \"media\",\r\n                \"moduleType\": \"VIDEO\",\r\n                \"caption\": \"caption\",\r\n                \"media\": {\r\n                  \"type\": \"video\",\r\n                  \"videoURL\": \"url\"\r\n                }\r\n              }\r\n            ],\r\n            \"compositeModuleId\": 2\r\n          },\r\n          {\r\n            \"alignment\": \"standard\",\r\n            \"modules\": [\r\n              {\r\n                \"type\": \"entity\",\r\n                \"moduleType\": \"ENTITY\",\r\n                \"caption\": \"caption\",\r\n                \"entityIds\": [\r\n                  \"100\"\r\n                ]\r\n              }\r\n            ],\r\n            \"compositeModuleId\": 3\r\n          }\r\n        ]\r\n      }\r\n    ]\r\n  },\r\n  \"accessControlList\": [\r\n    \"test\"\r\n  ],\r\n  \"author\": {\r\n    \"username\": \"a1\"\r\n  },\r\n  \"draftId\": \"10\",\r\n  \"moderationStatus\": \"MODERATED\"\r\n}";
		
		Article model = mapper.readValue(modelData, Article.class);
		
		List<Article> models = new ArrayList<Article>();
		models.add(model);
		
		ContentEntityAdaptor adaptor = new ContentEntityAdaptor();
		List<PublishedContentEntity> entities = adaptor.adaptToPublished(models, "100");
		assertNotNull(entities);
		PublishedContentEntity entity = entities.get(0);
		assertTrue(entity.getAccessControlList().contains("100"));
		assertThat(entity.getAuthorId(),is(100L));
		assertThat(entity.getAuthorName(),is("a1"));
		assertThat(entity.getContentId().toString(),is("576c6dae68ebeaa00281d324"));
		assertThat(entity.getContentStatus(),is("PUBLISHED"));
		assertNotNull(entity.getDateCreated());
		assertNotNull(entity.getDateModified());
		assertThat(entity.getDraftId(), is("10"));
		assertThat(entity.getModerationStatus(),is(ModerationStatusEnum.MODERATED.name()));
		assertNotNull(entity.getUserGeneratedContent());
		assertThat(entity.getTemplateType(),is("HOW_TO"));
		
		UserGeneratedContentEntity content = entity.getUserGeneratedContent();
		assertThat(content.getCoverImage(),is(model.getUserGeneratedContent().getCoverImage().getImageURL()));
		assertThat(content.getSynopsis(),is(model.getUserGeneratedContent().getSynopsis().getContent()));
		assertThat(content.getTitle(),is(model.getUserGeneratedContent().getTitle().getContent()));
		assertThat(content.getTags(),is(model.getUserGeneratedContent().getTags()));
		
		
		List<GroupEntity> groups = content.getGroups();
		assertNotNull(groups);
		GroupEntity grp = groups.get(0);
		
		List<Group> groupModels = model.getUserGeneratedContent().getGroups();
		Group grpModel = groupModels.get(0);
		assertThat(grp.getGroupId(),is(grpModel.getGroupId()));
		assertThat(grp.getGroupType(),is(grpModel.getGroupType()));
		assertThat(grp.getTitle().getContent(),is(grpModel.getTitle().getContent()));
		
		Map<String, ModuleEntity> moduleMap = grp.getModuleMap();
		assertNotNull(moduleMap);
		
		List<Section> modules = grpModel.getSections();
		Section module1 = modules.get(0);
		Section module2 = modules.get(1);
		Section module3 = modules.get(2);
		
		assertThat(moduleMap.get("1").getAlignment(),is(module1.getAlignment()));
		assertThat(moduleMap.get("1").getModuleId(),is(module1.getSectionId()));
		
		assertThat(moduleMap.get(2L).getAlignment(),is(module2.getAlignment()));
		assertThat(moduleMap.get(2L).getModuleId(),is(module2.getSectionId()));
		
		assertThat(moduleMap.get(3L).getAlignment(),is(module3.getAlignment()));
		assertThat(moduleMap.get(3L).getModuleId(),is(module3.getSectionId()));
		
		List<SingleModuleEntity> singleEntities1 = moduleMap.get(1L).getData();
		List<SingleModuleEntity> singleEntities2 = moduleMap.get(2L).getData();
		List<SingleModuleEntity> singleEntities3 = moduleMap.get(3L).getData();
		
		List<Component> singleModules1 = module1.getComponents();
		List<Component> singleModules2 =module2.getComponents();
		List<Component> singleModules3 =module3.getComponents();
		
		assertThat(singleEntities1.get(0).getCaption(),is(singleModules1.get(0).getCaption()));
		assertThat(singleEntities1.get(0).getData(),is(((StandardComponent)singleModules1.get(0)).getData()));
		assertThat(singleEntities1.get(0).getType(),is(((StandardComponent)singleModules1.get(0)).getComponentType()));
		
		assertThat(singleEntities1.get(1).getCaption(),is(singleModules1.get(1).getCaption()));
		MediaComponent mediaModule = (MediaComponent) singleModules1.get(1);
		assertThat(singleEntities1.get(1).getResourceUrl(),is(((Image)mediaModule.getMedia()).getImageURL()));
		assertThat(singleEntities1.get(1).getType(),is(((MediaComponent)singleModules1.get(1)).getComponentType()));
		

		assertThat(singleEntities2.get(0).getCaption(),is(singleModules2.get(0).getCaption()));
		MediaComponent mediaModule2 = (MediaComponent) singleModules2.get(0);
		assertThat(singleEntities2.get(0).getResourceUrl(),is(((Video)mediaModule2.getMedia()).getVideoURL()));
		assertThat(singleEntities2.get(0).getType(),is(((MediaComponent)singleModules2.get(0)).getComponentType()));
		
		assertThat(singleEntities3.get(0).getCaption(),is(singleModules3.get(0).getCaption()));
		assertThat(singleEntities3.get(0).getEntityIds().get(0),is("100"));
		assertThat(singleEntities3.get(0).getType(),is(((EntityComponent)singleModules3.get(0)).getComponentType()));
		
		
	}
	
	@Test
	@Ignore
	public void testAdaptDraft() throws JsonParseException, JsonMappingException, IOException, IllegalContentIdException, CmsEditorException{
		
		
		String modelData="{\r\n  \"type\": \"Article\",\r\n  \"articleId\": \"576c6dae68ebeaa00281d324\",\r\n  \"articleStatus\": \"LIVE\",\r\n  \"templateType\": \"HOW_TO\",\r\n  \"dateCreated\": {\r\n    \"value\": \"2016-07-05T22:32:07.573Z\"\r\n  },\r\n  \"dateModified\": {\r\n    \"value\": \"2016-07-05T22:32:07.573Z\"\r\n  },\r\n  \"userGeneratedContent\": {\r\n    \"title\": {\r\n      \"content\": \"title1\",\r\n      \"language\": \"en\"\r\n    },\r\n    \"synopsis\": {\r\n      \"content\": \"synopsis1\",\r\n      \"language\": \"en\"\r\n    },\r\n    \"coverImage\": {\r\n      \"type\": \"image\",\r\n      \"imageURL\": \"http://img\",\r\n      \"imageURLType\": \"NEW_ZOOM\",\r\n      \"imageURLElements\": {\r\n        \"ZOOM_GUID\": null\r\n      }\r\n    },\r\n    \"tags\": [\r\n      \"t1\"\r\n    ],\r\n    \"groups\": [\r\n      {\r\n        \"title\": {\r\n          \"content\": \"take apart the ipod\",\r\n          \"language\": \"en\"\r\n        },\r\n        \"groupType\": \"standard\",\r\n        \"groupId\": 1,\r\n        \"compositeModules\": [\r\n          {\r\n            \"alignment\": \"text_image\",\r\n            \"modules\": [\r\n              {\r\n                \"type\": \"standard\",\r\n                \"moduleType\": \"STANDARD\",\r\n                \"caption\": \"caption\",\r\n                \"data\": \"data\"\r\n              },\r\n              {\r\n                \"type\": \"media\",\r\n                \"moduleType\": \"IMAGE\",\r\n                \"caption\": \"caption\",\r\n                \"media\": {\r\n                  \"type\": \"image\",\r\n                  \"imageURL\": \"url\",\r\n                  \"imageURLType\": \"NEW_ZOOM\",\r\n                  \"imageURLElements\": {\r\n                    \"ZOOM_GUID\": null\r\n                  }\r\n                }\r\n              }\r\n            ],\r\n            \"compositeModuleId\": 1\r\n          },\r\n          {\r\n            \"alignment\": \"standard\",\r\n            \"modules\": [\r\n              {\r\n                \"type\": \"media\",\r\n                \"moduleType\": \"VIDEO\",\r\n                \"caption\": \"caption\",\r\n                \"media\": {\r\n                  \"type\": \"video\",\r\n                  \"videoURL\": \"url\"\r\n                }\r\n              }\r\n            ],\r\n            \"compositeModuleId\": 2\r\n          },\r\n          {\r\n            \"alignment\": \"standard\",\r\n            \"modules\": [\r\n              {\r\n                \"type\": \"entity\",\r\n                \"moduleType\": \"ENTITY\",\r\n                \"caption\": \"caption\",\r\n                \"entityIds\": [\r\n                  \"100\"\r\n                ]\r\n              }\r\n            ],\r\n            \"compositeModuleId\": 3\r\n          }\r\n        ]\r\n      }\r\n    ]\r\n  },\r\n  \"accessControlList\": [\r\n    \"test\"\r\n  ],\r\n  \"author\": {\r\n    \"username\": \"a1\"\r\n  },\r\n  \"draftId\": \"10\",\r\n  \"moderationStatus\": \"MODERATED\"\r\n}";
		
		Article model = mapper.readValue(modelData, Article.class);
		
		List<Article> models = new ArrayList<Article>();
		models.add(model);
		
		ContentEntityAdaptor adaptor = new ContentEntityAdaptor();
		List<DraftContentEntity> entities = adaptor.adaptToDrafts(models, "100");
		assertNotNull(entities);
		DraftContentEntity entity = entities.get(0);
		assertTrue(entity.getAccessControlList().contains("100"));
		assertThat(entity.getAuthorId(),is(100L));
		assertThat(entity.getAuthorName(),is("a1"));
		assertThat(entity.getContentId().toString(),is("576c6dae68ebeaa00281d324"));
		assertThat(entity.getContentStatus(),is("DRAFT"));
		assertNotNull(entity.getDateCreated());
		assertNotNull(entity.getDateModified());
		assertThat(entity.getModerationStatus(),is(ModerationStatusEnum.MODERATED.name()));
		assertNotNull(entity.getUserGeneratedContent());
		assertThat(entity.getTemplateType(),is("HOW_TO"));
		
		UserGeneratedContentEntity content = entity.getUserGeneratedContent();
		assertThat(content.getCoverImage(),is(model.getUserGeneratedContent().getCoverImage().getImageURL()));
		assertThat(content.getSynopsis(),is(model.getUserGeneratedContent().getSynopsis().getContent()));
		assertThat(content.getTitle(),is(model.getUserGeneratedContent().getTitle().getContent()));
		assertThat(content.getTags(),is(model.getUserGeneratedContent().getTags()));
		
		
		List<GroupEntity> groups = content.getGroups();
		assertNotNull(groups);
		GroupEntity grp = groups.get(0);
		
		List<Group> groupModels = model.getUserGeneratedContent().getGroups();
		Group grpModel = groupModels.get(0);
		assertThat(grp.getGroupId(),is(grpModel.getGroupId()));
		assertThat(grp.getGroupType(),is(grpModel.getGroupType()));
		assertThat(grp.getTitle().getContent(),is(grpModel.getTitle().getContent()));
		
		Map<String, ModuleEntity> moduleMap = grp.getModuleMap();
		assertNotNull(moduleMap);
		
		List<Section> modules = grpModel.getSections();
		Section module1 = modules.get(0);
		Section module2 = modules.get(1);
		
		assertThat(moduleMap.get(1L).getAlignment(),is(module1.getAlignment()));
		assertThat(moduleMap.get(1L).getModuleId(),is(module1.getSectionId()));
		
		assertThat(moduleMap.get(2L).getAlignment(),is(module2.getAlignment()));
		assertThat(moduleMap.get(2L).getModuleId(),is(module2.getSectionId()));
		
		List<SingleModuleEntity> singleEntities1 = moduleMap.get(1L).getData();
		List<SingleModuleEntity> singleEntities2 = moduleMap.get(2L).getData();
		
		List<Component> singleModules1 = module1.getComponents();
		List<Component> singleModules2 =module2.getComponents();
		
		assertThat(singleEntities1.get(0).getCaption(),is(singleModules1.get(0).getCaption()));
		assertThat(singleEntities1.get(0).getData(),is(((StandardComponent)singleModules1.get(0)).getData()));
		assertThat(singleEntities1.get(0).getType(),is(((StandardComponent)singleModules1.get(0)).getComponentType()));
		
		assertThat(singleEntities1.get(1).getCaption(),is(singleModules1.get(1).getCaption()));
		MediaComponent mediaModule = (MediaComponent) singleModules1.get(1);
		assertThat(singleEntities1.get(1).getResourceUrl(),is(((Image)mediaModule.getMedia()).getImageURL()));
		assertThat(singleEntities1.get(1).getType(),is(((MediaComponent)singleModules1.get(1)).getComponentType()));
		

		assertThat(singleEntities2.get(0).getCaption(),is(singleModules2.get(0).getCaption()));
		MediaComponent mediaModule2 = (MediaComponent) singleModules2.get(0);
		assertThat(singleEntities2.get(0).getResourceUrl(),is(((Video)mediaModule2.getMedia()).getVideoURL()));
		assertThat(singleEntities2.get(0).getType(),is(((MediaComponent)singleModules2.get(0)).getComponentType()));
		
		
	}
	
	@Test
	public void testAdaptToDraftsWithNullModels() throws IllegalContentIdException, CmsEditorException{
		
		ContentEntityAdaptor adaptor = new ContentEntityAdaptor();
		List<DraftContentEntity> entities = adaptor.adaptToDrafts(null, "10");
		assertNotNull(entities);
	}
	
	@Test
	public void testAdaptToPublishedWithNullModels() throws IllegalContentIdException, CmsEditorException{
		
		ContentEntityAdaptor adaptor = new ContentEntityAdaptor();
		List<PublishedContentEntity> entities = adaptor.adaptToPublished(new ArrayList<Article>(), "10");
		assertNotNull(entities);
	}
	
	@Test
	public void testAdaptToDraftWithNullModel() throws IllegalContentIdException, CmsEditorException{
		
		ContentEntityAdaptor adaptor = new ContentEntityAdaptor();
		DraftContentEntity entities = adaptor.adaptToDraft(null, "10");
		assertNotNull(entities);
	}
	
	
	@Test
	public void testAdaptToPublishedWithStatus() throws CmsEditorException{
		
		List<Article> models = new ArrayList<Article>();
		Article model1 = new Article();
		model1.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		UserIdentifier u1 = new UserIdentifier();
		u1.setUsername("a1");
		model1.setAuthor(u1);
		model1.setArticleId("576c6dae68ebeaa00281d324");
		UserGeneratedContent c1 = new UserGeneratedContent();
		c1.setTitle(new Text("t1", LanguageEnum.en));
		model1.setUserGeneratedContent(c1);
		model1.setTemplateType("HOW_TO");
		models.add(model1);
		
		Article model2 = new Article();
		model2.setArticleStatus(ArticleStatusEnum.PUBLISHED);
		UserIdentifier u2 = new UserIdentifier();
		u2.setUsername("a1");
		model2.setAuthor(u2);
		model2.setArticleId("100");
		UserGeneratedContent c2 = new UserGeneratedContent();
		c2.setTitle(new Text("t2", LanguageEnum.en));
		model2.setUserGeneratedContent(c2);
		model2.setTemplateType("HOW_TO");
		models.add(model2);
		
		List<BulkAdaptorResponse> responses = new ContentEntityAdaptor().adaptToPublishedWithStatus(models, "100");
		assertNotNull(responses);
		
		BulkAdaptorResponse response1 = responses.get(0);
		assertThat(response1.getAuthor(),is(u1.getUsername()));
		assertThat(response1.getTitle(),is(c1.getTitle().getContent()));
		assertNotNull(response1.getEntity());
		assertThat(response1.getStatus(),is(CmsEditorStatus.BULK_CREATE_SUCCESS));
		BulkAdaptorResponse response2 = responses.get(1);
		assertThat(response2.getAuthor(),is(u2.getUsername()));
		assertThat(response2.getTitle(),is(c2.getTitle().getContent()));
		assertThat(response2.getStatus(),is(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
	

}