package com.ebay.raptor.cmseditor.manager;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.manager.CmsEditorManager.OrchestratorFactory;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.CreateDraftResponse;
import com.ebay.raptor.cmseditor.task.ContentReadTask;
import com.ebay.raptor.cmseditor.task.CreateDraftTaskResponse;
import com.ebay.raptor.cmseditor.task.SoftDeleteContentTask;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.UpdateContentTaskResponse;
import com.ebay.raptor.orchestration.ITaskOrchestrator;
import com.ebay.raptor.orchestration.ITaskResult;
import com.ebay.raptor.orchestration.TaskConfiguration;
import com.ebay.raptor.orchestration.TaskExecutionException;

public class CmsEditorManagerTest {
	
	@Test(expected = CmsEditorException.class)
	public void testManageWithNullRequest() throws Throwable{
		
		OrchestratorFactory factory = mock(OrchestratorFactory.class);
		CmsEditorManager manager = new CmsEditorManager(factory);
		try{
		manager.manage(null);
		}catch(CmsEditorException exception){
			assertThat(exception.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw exception;
		}
		
	}
	
	@Test
	public void testManageWithNoTasks() throws CmsEditorException{
		
		OrchestratorFactory factory = mock(OrchestratorFactory.class);
		CmsEditorManager manager = new CmsEditorManager(factory);
		CmsEditorRequest request = new CmsEditorRequest();
		CmsEditorResponse response=manager.manage(request);
		assertNotNull(response);
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testManage() throws CmsEditorException, TaskExecutionException{
		
		
		OrchestratorFactory factory = mock(OrchestratorFactory.class);
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.CREATE_DRAFT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		ITaskOrchestrator orchestrator = mock(ITaskOrchestrator.class);
		ITaskResult<Object> taskResult = mock(ITaskResult.class);
		CreateDraftTaskResponse taskResponse =new CreateDraftTaskResponse();
		taskResponse.setContentId("576c6dae68ebeaa00281d324");
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		when(taskResult.getResult()).thenReturn(taskResponse);
		List<ITaskResult<Object>> results = new ArrayList<ITaskResult<Object>>();
		results.add(taskResult);
		when(orchestrator.execute(any(CreateDraftTaskResponse.class), any(TaskConfiguration.class))).thenReturn(taskResult);
		when(factory.create()).thenReturn(orchestrator);
		CmsEditorManager manager = new CmsEditorManager(factory);
		CreateDraftResponse response=(CreateDraftResponse) manager.manage(request);
		assertNotNull(response);
		assertThat(response.getContentId(),is("576c6dae68ebeaa00281d324"));
		
	}
	
	@Test
	public void testManage2() throws CmsEditorException, TaskExecutionException{
		
		
		OrchestratorFactory factory = mock(OrchestratorFactory.class);
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.DELETE_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		ITaskOrchestrator orchestrator = mock(ITaskOrchestrator.class);
		ITaskResult<Object> taskResult = mock(ITaskResult.class);
		UpdateContentTaskResponse taskResponse =new UpdateContentTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		when(taskResult.getResult()).thenReturn(taskResponse);
		List<ITaskResult<Object>> results = new ArrayList<ITaskResult<Object>>();
		results.add(taskResult);
		when(orchestrator.execute(any(SoftDeleteContentTask.class), any(TaskConfiguration.class))).thenReturn(taskResult);
		when(factory.create()).thenReturn(orchestrator);
		CmsEditorManager manager = new CmsEditorManager(factory);
		CmsEditorResponse response= manager.manage(request);
		assertNotNull(response);
		assertThat(response.getStatus(),is(CmsEditorResponseStatus.SUCCESS));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testTaskExecutionException() throws Throwable{
		OrchestratorFactory factory = mock(OrchestratorFactory.class);
		CmsEditorRequest request = mock(CmsEditorRequest.class);
		when(request.getSelector()).thenReturn(Selector.READ_CONTENT);
		
		ApplicationContext context = mock(ApplicationContext.class);
		ContentDraftDao draftDao = mock(ContentDraftDao.class);
		ContentPublishDao publishDao = mock(ContentPublishDao.class);
		when(request.getApplicationContext()).thenReturn(context);
		when(context.getBean(ContentDraftDao.class)).thenReturn(draftDao);
		when(context.getBean(ContentPublishDao.class)).thenReturn(publishDao);
		
		ITaskOrchestrator orchestrator = mock(ITaskOrchestrator.class);
		when(orchestrator.execute(any(ContentReadTask.class), any(TaskConfiguration.class))).thenThrow(new TaskExecutionException("error"));
		when(factory.create()).thenReturn(orchestrator);
		CmsEditorManager manager = new CmsEditorManager(factory);
		try{
			manager.manage(request);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw e;
		}
	}
	

}
