package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.Matchers;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.GetUserIdsByUsernamesTaskResponse;
import com.ebay.userlookup.UserLookup;
import com.ebay.userlookup.common.ClientException;
import com.ebay.userlookup.common.PublicUserIdUsernameMap;
import com.ebay.userlookup.common.UserIdLookupResult;
import com.ebay.userlookup.common.UserIdMap;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;

public class GetUserIdsByUsernamesTaskTest {
	
	
	@Test
	public void testGetUserIdsByUserNames() throws ClientException{
		List<String> userNames = new ArrayList<String>();
		userNames.add("testuser");
		UserLookup userLookup = mock(UserLookup.class);
		UserIdLookupResult publicUserIdsResult = new UserIdLookupResult();
		List<PublicUserIdUsernameMap> users = new ArrayList<PublicUserIdUsernameMap>();
		PublicUserIdUsernameMap map = new PublicUserIdUsernameMap();
		map.setPublic_user_id("publicuserid");
		map.setUsername("testuser");
		users.add(map);
		List<UserIdMap> userIdsMap = new ArrayList<UserIdMap>();
		UserIdMap u1 = new UserIdMap();
		u1.setInternal_id(100L);
		u1.setPublic_user_id("publicuserid");
		userIdsMap.add(u1);
		publicUserIdsResult.setUserid_list(userIdsMap);
		publicUserIdsResult.setPuuidUsernameList(users);
		when(userLookup.getAll_PublicUserIdByUsername(userNames, 500)).thenReturn(publicUserIdsResult);
		when(userLookup.getAll_InternalId(Matchers.anyListOf(String.class), eq(500))).thenReturn(publicUserIdsResult);
		GetUserIdsByUsernamesTask task = new GetUserIdsByUsernamesTask(new CmsEditorRequest(), userNames, new ArrayList<ICmsEditorTask>(), userLookup);
		
		GetUserIdsByUsernamesTaskResponse response=(GetUserIdsByUsernamesTaskResponse) task.createResponse();
		Map<String,Long> userNamesToId=response.getUserNamesToUserIdsMap();
		assertThat(userNamesToId.get("testuser"),is(100L));
	}
	
	@Test
	public void testGetUserIdsByUserNamesEmptyUserNameList() throws ClientException{
		List<String> userNames = new ArrayList<String>();
		UserLookup userLookup = mock(UserLookup.class);
		UserIdLookupResult publicUserIdsResult = new UserIdLookupResult();
		List<PublicUserIdUsernameMap> users = new ArrayList<PublicUserIdUsernameMap>();
		PublicUserIdUsernameMap map = new PublicUserIdUsernameMap();
		map.setPublic_user_id("publicuserid");
		map.setUsername("testuser");
		users.add(map);
		List<UserIdMap> userIdsMap = new ArrayList<UserIdMap>();
		UserIdMap u1 = new UserIdMap();
		u1.setInternal_id(100L);
		u1.setPublic_user_id("publicuserid");
		userIdsMap.add(u1);
		publicUserIdsResult.setUserid_list(userIdsMap);
		publicUserIdsResult.setPuuidUsernameList(users);
		when(userLookup.getAll_PublicUserIdByUsername(userNames, 500)).thenReturn(publicUserIdsResult);
		when(userLookup.getAll_InternalId(Matchers.anyListOf(String.class), eq(500))).thenReturn(publicUserIdsResult);
		GetUserIdsByUsernamesTask task = new GetUserIdsByUsernamesTask(new CmsEditorRequest(), userNames, new ArrayList<ICmsEditorTask>(), userLookup);
		
		GetUserIdsByUsernamesTaskResponse response=(GetUserIdsByUsernamesTaskResponse) task.createResponse();
		assertNotNull(response);
	}

	@Test
	public void testGetUserIdsByUserNamesUserNotFound() throws ClientException{
		List<String> userNames = new ArrayList<String>();
		userNames.add("testuser");
		UserLookup userLookup = mock(UserLookup.class);
		UserIdLookupResult publicUserIdsResult = new UserIdLookupResult();
		List<PublicUserIdUsernameMap> users = new ArrayList<PublicUserIdUsernameMap>();
		PublicUserIdUsernameMap map = new PublicUserIdUsernameMap();
		map.setPublic_user_id("publicuserid");
		map.setUsername("testuser");
		users.add(map);
		List<UserIdMap> userIdsMap = new ArrayList<UserIdMap>();
		UserIdMap u1 = new UserIdMap();
		u1.setInternal_id(100L);
		u1.setPublic_user_id("publicuserid");
		userIdsMap.add(u1);
		publicUserIdsResult.setUserid_list(userIdsMap);
		publicUserIdsResult.setPuuidUsernameList(users);
		when(userLookup.getAll_PublicUserIdByUsername(userNames, 500)).thenThrow(new ClientException(404, "error"));
		when(userLookup.getAll_InternalId(Matchers.anyListOf(String.class), eq(500))).thenThrow(new ClientException(404, "error"));
		GetUserIdsByUsernamesTask task = new GetUserIdsByUsernamesTask(new CmsEditorRequest(), userNames, new ArrayList<ICmsEditorTask>(), userLookup);
		
		GetUserIdsByUsernamesTaskResponse response=(GetUserIdsByUsernamesTaskResponse) task.createResponse();
		assertThat(response.getError(),is(CmsEditorStatus.USER_DOES_NOT_EXIST));
	}
	
	@Test
	public void testGetUserIdsByUserNamesUserInternalServerError() throws ClientException{
		List<String> userNames = new ArrayList<String>();
		userNames.add("testuser");
		UserLookup userLookup = mock(UserLookup.class);
		UserIdLookupResult publicUserIdsResult = new UserIdLookupResult();
		List<PublicUserIdUsernameMap> users = new ArrayList<PublicUserIdUsernameMap>();
		PublicUserIdUsernameMap map = new PublicUserIdUsernameMap();
		map.setPublic_user_id("publicuserid");
		map.setUsername("testuser");
		users.add(map);
		List<UserIdMap> userIdsMap = new ArrayList<UserIdMap>();
		UserIdMap u1 = new UserIdMap();
		u1.setInternal_id(100L);
		u1.setPublic_user_id("publicuserid");
		userIdsMap.add(u1);
		publicUserIdsResult.setUserid_list(userIdsMap);
		publicUserIdsResult.setPuuidUsernameList(users);
		when(userLookup.getAll_PublicUserIdByUsername(userNames, 500)).thenThrow(new ClientException(500, "error"));
		when(userLookup.getAll_InternalId(Matchers.anyListOf(String.class), eq(500))).thenThrow(new ClientException(500, "error"));
		GetUserIdsByUsernamesTask task = new GetUserIdsByUsernamesTask(new CmsEditorRequest(), userNames, new ArrayList<ICmsEditorTask>(), userLookup);
		
		GetUserIdsByUsernamesTaskResponse response=(GetUserIdsByUsernamesTaskResponse) task.createResponse();
		assertThat(response.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
	}
}
