package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.Matchers;
import org.opensaml.ws.wssecurity.impl.CreatedBuilder;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ArticleUpdateFieldRequest;
import com.ebay.raptor.cmseditor.request.BulkCreateArticleRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentPublishRequest;
import com.ebay.raptor.cmseditor.request.ContentUpdateRequest;
import com.ebay.raptor.cmseditor.request.DeleteGroupRequest;
import com.ebay.raptor.cmseditor.request.DeleteSectionRequest;
import com.ebay.raptor.cmseditor.request.UpdateGroupRequest;
import com.ebay.raptor.cmseditor.request.UpdateSectionRequest;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;

import static org.mockito.Mockito.mock;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetAccessControlListTaskTest {
	
	
	@Test
	public void testGetAccessControlListTask(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentPublishRequest publishRequest = new ContentPublishRequest();
		publishRequest.setDraftContentId("57fff8ec399d3167c9e53fa4");
		request.setContentPublishRequest(publishRequest);
		
		PublishedContentEntity c = new PublishedContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentPublishDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.SUBMITTED, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testGetAccessControlListTask2(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ArticleUpdateFieldRequest updateRequest = new ArticleUpdateFieldRequest();
		updateRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateFieldRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testGetAccessControlListTask3(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentUpdateRequest updateRequest = new ContentUpdateRequest();
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setContentUpdateRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testGetAccessControlListTask4(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		DeleteSectionRequest updateRequest = new DeleteSectionRequest();
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setDeleteModuleRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

	@Test
	public void testGetAccessControlListTask5(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateGroupRequest updateRequest = new UpdateGroupRequest();
		updateRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		request.setUpdateGroupRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testGetAccessControlListTask6(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		DeleteGroupRequest updateRequest = new DeleteGroupRequest();
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setDeleteGroupRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

	@Test
	public void testGetAccessControlListTask7(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		UpdateSectionRequest updateRequest = new UpdateSectionRequest();
		updateRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		request.setUpdateSectionRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}

	@Test
	public void testGetAccessControlListTask8(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		DeleteSectionRequest updateRequest = new DeleteSectionRequest();
		updateRequest.setContentId("57fff8ec399d3167c9e53fa4");
		request.setDeleteModuleRequest(updateRequest);
		
		DraftContentEntity c = new DraftContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testGetAccessControlListTask9(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		BulkCreateArticleRequest createRequest = new BulkCreateArticleRequest();
		List<Article> articles = new ArrayList<Article>();
		Article a1 = new Article();
		a1.setArticleId("57fff8ec399d3167c9e53fa4");
		articles.add(a1);
		Article a2 = new Article();
		a2.setArticleId("57fff8ec399d3167c9e53ga4");
		articles.add(a2);
		createRequest.setArticles(articles);
		
	
		request.setCreateBulkContentRequest(createRequest);
		
		DraftContentEntity c1 = new DraftContentEntity();
		c1.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c1.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa4", c1);
		DraftContentEntity c2 = new DraftContentEntity();
		c2.setContentStatus("DRAFT");
		List<String> acl2 = new ArrayList<String>();
		acl2.add("200");
		c2.setAccessControlList(acl2);
		map.put("57fff8ec399d3167c9e53ga4", c2);
		when(contentDraftDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(map);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.DRAFT, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getContentEntityMap(),is(map));
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
	}
	
	@Test
	public void testGetAccessControlListTask10(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentPublishRequest publishRequest = new ContentPublishRequest();
		publishRequest.setDraftContentId("57fff8ec399d3167c9e53fa");
		request.setContentPublishRequest(publishRequest);
		
		PublishedContentEntity c = new PublishedContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa", c);
		when(contentPublishDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenThrow(new IllegalArgumentException());
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.SUBMITTED, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(response.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
	}
	
	@Test
	public void testGetAccessControlListTask11(){
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		ContentPublishRequest publishRequest = new ContentPublishRequest();
		publishRequest.setDraftContentId("57fff8ec399d3167c9e53fa");
		request.setContentPublishRequest(publishRequest);
		
		PublishedContentEntity c = new PublishedContentEntity();
		c.setContentStatus("DRAFT");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		c.setAccessControlList(acl);
		Map<String, ContentEntity> map = new HashMap<String, ContentEntity>();
		map.put("57fff8ec399d3167c9e53fa", c);
		when(contentPublishDao.findContentAccessControlListByContentIds(Matchers.anyListOf(String.class))).thenReturn(null);
		
		GetAccessControlListTask task = new GetAccessControlListTask(request, ArticleStatusEnum.SUBMITTED, new ArrayList<ICmsEditorTask>(),contentDraftDao,contentPublishDao);
		GetAccessControlListTaskResponse response=(GetAccessControlListTaskResponse) task.createResponse();
		assertThat(response.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(response.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
	}
}
