package com.ebay.raptor.cmseditor.adapter;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;

import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.exception.IllegalContentIdException;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Article;

public class ArticleEntityToCassiniModelAdapterTest {

	static ObjectMapper mapper;
	
	static{
		mapper = new ObjectMapper();
	}
	
	@Test
	public void testAdapter() throws JsonParseException, JsonMappingException, IOException, IllegalContentIdException, CmsEditorException {
		
		
		PublishedContentEntity published = new PublishedContentEntity();
		List<String> acl = new ArrayList<String>();
		acl.add("test");
		published.setAccessControlList(acl);
		published.setAuthorId(1L);
		published.setAuthorName("a1");
		published.setContentId(new ObjectId("576c6dae68ebeaa00281d324"));
		published.setContentStatus(ArticleStatusEnum.PUBLISHED.name());
		published.setDraftId("10");
		Date d1 = new Date();
		published.setDateCreated(d1);
		published.setDateModified(d1);
		published.setDeleted(false);
		published.setLastModeratedUser(2L);
		published.setLastModifiedUser(3L);
		published.setMarkedAsProcessing("false");
		published.setModerationStatus(ModerationStatusEnum.MODERATED.name());
		published.setScheduledEndDate(d1);
		published.setScheduledStartDate(d1);
		published.setTemplateType("HOW_TO");
		//published.setVisibilityLevel("private");
		UserGeneratedContentEntity publishedContent = new UserGeneratedContentEntity();
		publishedContent.setCoverImage("http://img");
		publishedContent.setSynopsis("synopsis1");
		publishedContent.setTitle("title1");
		List<String> draftTags = new ArrayList<String>();
		draftTags.add("t1");
		publishedContent.setTags(draftTags);
		List<GroupEntity> groups = new ArrayList<GroupEntity>();
		GroupEntity grp = new GroupEntity();
		grp.setGroupId("1");
		grp.setGroupType("standard");
		grp.setTitle(new Text("take apart the ipod", LanguageEnum.en));
		Map<String,ModuleEntity> map = new LinkedHashMap<String, ModuleEntity>();
		ModuleEntity entity1 = new ModuleEntity();
		entity1.setAlignment("text_image");
		entity1.setModuleId("1");
		List<SingleModuleEntity> singleEntities = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity entity = new SingleModuleEntity();
		entity.setType("STANDARD");
		entity.setCaption("caption");
		entity.setData("data");
		singleEntities.add(entity);
		SingleModuleEntity entity2 = new SingleModuleEntity();
		entity2.setType("IMAGE");
		entity2.setCaption("caption");
		entity2.setResourceUrl("url");
		singleEntities.add(entity2);
		entity1.setData(singleEntities);
		map.put("1", entity1);
		ModuleEntity moduleEntity2 = new ModuleEntity();
		moduleEntity2.setAlignment("standard");
		moduleEntity2.setModuleId("2");
		List<SingleModuleEntity> singleEntities2 = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity singleModuleEntity2 = new SingleModuleEntity();
		singleModuleEntity2.setType("VIDEO");
		singleModuleEntity2.setCaption("caption");
		singleModuleEntity2.setResourceUrl("url");
		singleModuleEntity2.setData("data");
		singleEntities2.add(singleModuleEntity2);
		moduleEntity2.setData(singleEntities2);
		map.put("2", moduleEntity2);
		
		ModuleEntity moduleEntity3 = new ModuleEntity();
		moduleEntity3.setAlignment("standard");
		moduleEntity3.setModuleId("3");
		List<SingleModuleEntity> singleEntities3 = new ArrayList<SingleModuleEntity>();
		SingleModuleEntity singleModuleEntity3 = new SingleModuleEntity();
		singleModuleEntity3.setType("ENTITY");
		singleModuleEntity3.setCaption("caption");
		List<String> entityIds = new ArrayList<String>();
		entityIds.add("100");
		singleModuleEntity3.setEntityIds(entityIds);
		
		singleEntities3.add(singleModuleEntity3);
		moduleEntity3.setData(singleEntities3);
		map.put("3", moduleEntity3);
		
		grp.setModuleMap(map);
		groups.add(grp);
		publishedContent.setGroups(groups);
		published.setUserGeneratedContent(publishedContent);
		
		String s = ArticleEntityToCassiniModelAdapter.convertArticleToJson(published);
		System.out.println(s);
		
		FlatArticle article = mapper.readValue(s, FlatArticle.class);
		
		assertTrue(article.getTemplateType().equals(published.getTemplateType()));
		assertTrue(article.getTitle().equals(published.getUserGeneratedContent().getTitle()));
		assertTrue(article.getSynopsis().equals(published.getUserGeneratedContent().getSynopsis()));
		assertTrue(article.getTags().containsAll(published.getUserGeneratedContent().getTags()));
		assertTrue(article.getNumPics() == 1);
		assertTrue(article.getNumVideos() == 1);
		
	}
	
}
