package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.DeleteContentRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.task.SoftDeleteContentTask.BESHandler;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateContentTaskResponse;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;


public class SoftDeleteContentTaskTest {

	
	@Test
	public void testSoftDeleteDraftTask() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.DRAFT);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		DraftContentEntity entity = new DraftContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentDraftDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenReturn(acl);
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		Mockito.doNothing().when(contentDraftDao).updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class));
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,contentDraftDao,null,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@Test
	public void testSoftDeletePublishedTask() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenReturn(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@Test
	public void testSoftDeletePublishedTaskNoPermissionNoAdmin() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("200");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenReturn(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
		
	}
	
	@Test
	public void testSoftDeletePublishedTaskInternalServerError() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("200");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenThrow(new RuntimeException());
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testSoftDeletePublishedTaskEmptyContentId() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenReturn(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
	
	@Test
	public void testSoftDeletePublishedTaskNoPermission() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenReturn(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}
	
	@Test
	public void testSoftDeletePublishedTaskInvalidContentId() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenThrow(new IllegalArgumentException());
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
	@Test
	public void testSoftDeletePublishedTaskInvalidContentId2() throws Exception{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		DeleteContentRequest deleteContentRequest = new DeleteContentRequest();
		deleteContentRequest.setContentId("57fff8ec399d3167c9e53fa4");
		deleteContentRequest.setStatus(ArticleStatusEnum.PUBLISHED);
		request.setDeleteContentRequest(deleteContentRequest);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentAccessControlListByContentId("57fff8ec399d3167c9e53fa4")).thenReturn(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"),Matchers.anyListOf(KeyValueImpl.class))).thenThrow(new IllegalArgumentException());
		BESHandler besHandler = mock(BESHandler.class);
		Mockito.doNothing().when(besHandler).dropArticleDeleteEvent("57fff8ec399d3167c9e53fa4");
		SoftDeleteContentTask task = new SoftDeleteContentTask(request, providers,null,contentPublishDao,besHandler);
		UpdateContentTaskResponse taskResponse=(UpdateContentTaskResponse) task.createResponse();
		assertThat(taskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INVALID_CONTENT_ID));
		
	}
	
}
