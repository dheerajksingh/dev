package com.ebay.raptor.cmseditor.task;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.request.UpdateSectionRequest;
import com.ebay.raptor.cmseditor.response.content.model.AlignmentEnum;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.ModuleType;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.CreateSectionTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

public class CreateSectionTaskTest {
	
	
	@Test
	public void testCreateSection() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CreateSectionTaskResponse createSectionResponse = (CreateSectionTaskResponse) task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(createSectionResponse.getSection().getSectionId(),is("2"));
		
	}
	
	@Test
	public void testCreateSectionNullRequest() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(null);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse createSectionResponse = task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}

	@Test
	public void testCreateSectionNoAdminNoAccess() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CreateSectionTaskResponse createSectionResponse = (CreateSectionTaskResponse) task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(createSectionResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
		
	}
	
	@Test
	public void testCreateSectionAdmin() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CreateSectionTaskResponse createSectionResponse = (CreateSectionTaskResponse) task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(createSectionResponse.getSection().getSectionId(),is("2"));
		
	}
	
	@Test
	public void testCreateSectionInvalidGroupId() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new CmsEditorException(CmsEditorStatus.INVALID_GROUP_ID));
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CreateSectionTaskResponse createSectionResponse = (CreateSectionTaskResponse) task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(createSectionResponse.getError(),is(CmsEditorStatus.INVALID_GROUP_ID));
		
	}
	
	@Test
	public void testCreateSectionError() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new Exception());
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse createSectionResponse = task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(createSectionResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testCreateSectionGroupNotFound() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("2");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new CmsEditorException(CmsEditorStatus.INVALID_GROUP_ID));
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CreateSectionTaskResponse createSectionResponse = (CreateSectionTaskResponse) task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(createSectionResponse.getError(),is(CmsEditorStatus.INVALID_GROUP_ID));
		
	}
	
	@Test
	public void testCreateSectionContentNotFound() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		ModuleEntity m = new ModuleEntity();
		m.setModuleId("1");
		Map<String, ModuleEntity> map = new HashMap<String, ModuleEntity>();
		map.put("1", m);
		g.setModuleMap(map);
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(null);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CmsEditorTaskResponse createSectionResponse = task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(createSectionResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}
	
	@Test
	public void testCreateSectionModuleMapNull() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		UpdateSectionRequest updateSectionRequest = new UpdateSectionRequest();
		Section section = new Section();
		section.setAlignment(AlignmentEnum.IMAGE_TEXT.name());
		section.setSequence(2);
		List<Component> components = new ArrayList<Component>();
		MediaComponent c = new MediaComponent();
		c.setCaption("caption");
		c.setComponentType(ModuleType.IMAGE.name());
		c.setMedia(new Image());
		components.add(c);
		section.setComponents(components);
		updateSectionRequest.setSection(section);
		updateSectionRequest.setArticleId("57fff8ec399d3167c9e53fa4");
		updateSectionRequest.setGroupId("1");
		updateSectionRequest.setUserId("100");
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		request.setUpdateSectionRequest(updateSectionRequest);
		
		DraftContentEntity entity = new DraftContentEntity();
		UserGeneratedContentEntity ugc = new UserGeneratedContentEntity();
		List<GroupEntity> grps = new ArrayList<GroupEntity>();
		GroupEntity g = new GroupEntity();
		g.setGroupId("1");
		g.setGroupType("IMAGE_TEXT");
		grps.add(g);
		ugc.setGroups(grps);
		List<String> aclList = new ArrayList<String>();
		aclList.add("100");
		entity.setAccessControlList(aclList);
		entity.setUserGeneratedContent(ugc);
		
		when(contentDraftDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		when(contentDraftDao.save(any(DraftContentEntity.class))).thenReturn(null);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetAccessControlListTask aclTask = mock(GetAccessControlListTask.class);
		GetAccessControlListTaskResponse aclTaskResponse = new GetAccessControlListTaskResponse();
		Map<String, ContentEntity> contentEntityMap = new HashMap<String, ContentEntity>();
		contentEntityMap.put("57fff8ec399d3167c9e53fa4", entity);
		aclTaskResponse.setContentEntityMap(contentEntityMap);
		when(aclTask.getTaskResponse()).thenReturn(aclTaskResponse);
		providers.add(aclTask);
		
		CreateSectionTask task = new CreateSectionTask(request, providers,contentDraftDao);
		CreateSectionTaskResponse createSectionResponse = (CreateSectionTaskResponse) task.createResponse();
		assertNotNull(createSectionResponse);
		assertThat(createSectionResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		assertThat(createSectionResponse.getSection().getSectionId(),is("1"));
		
	}
	
}
