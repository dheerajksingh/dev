package com.ebay.raptor.cmseditor.composer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.adaptor.ContentModelAdaptor;
import com.ebay.raptor.cmseditor.response.composer.ContentReadResponseComposer;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;

public class ContentReadResponseComposerTest {
	
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithTaskStatusNull() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadTaskResponse taskResponse = new ContentReadTaskResponse();
		taskResponses.add(taskResponse);
		
		ContentReadResponseComposer composer = new ContentReadResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			throw c;
		}
	}
	

	@Test(expected = CmsEditorException.class)
	public void testComposeWithNoTaskResponses() throws Throwable{
		ContentReadResponseComposer composer = new ContentReadResponseComposer(null);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(), is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test(expected = CmsEditorException.class)
	public void testComposeWithFailedStatus() throws Throwable{
		
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadTaskResponse taskResponse = new ContentReadTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		taskResponse.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		taskResponses.add(taskResponse);
		
		ContentReadResponseComposer composer = new ContentReadResponseComposer(taskResponses);
		try{
		CmsEditorResponse response = composer.compose();
		assertNotNull(response);
		}catch(CmsEditorException c){
			assertThat(c.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
			throw c;
		}
	}
	
	@Test
	public void testComposeSuccess() throws CmsEditorException{
		List<CmsEditorTaskResponse> taskResponses = new ArrayList<CmsEditorTaskResponse>();
		ContentReadTaskResponse taskResponse = new ContentReadTaskResponse();
		taskResponse.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		DraftContentEntity entity = new DraftContentEntity();
		taskResponse.setContent(entity);
		taskResponses.add(taskResponse);
		ContentReadResponseComposer composer = new ContentReadResponseComposer(taskResponses);
		ContentModelAdaptor adaptor = mock(ContentModelAdaptor.class);
		composer.setAdaptor(adaptor);
		Article model = new Article();
		when(adaptor.adaptToContentModel(entity)).thenReturn(model);
		ArticleReadResponse response=(ArticleReadResponse) composer.compose();
		assertNotNull(response);
		assertThat(response.getArticle(),is(model));
	}
}