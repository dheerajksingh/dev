package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.GetUserNameByIdTaskResponse;
import com.ebay.userlookup.UserLookup;
import com.ebay.userlookup.common.ClientException;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;

public class GetUserNameByIdTaskTest {
	
	
	@Test
	public void testGetUserNameById() throws ClientException{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getUsernameByInternalId(100L)).thenReturn("testuser");
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		
		GetUserNameByIdTask task = new GetUserNameByIdTask(request, providers,userLookup);
		GetUserNameByIdTaskResponse taskResponse=(GetUserNameByIdTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getUserName(),is("testuser"));
		
		
	}
	
	@Test
	public void testGetUserNameByIdMissingId() throws ClientException{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getUsernameByInternalId(100L)).thenReturn("testuser");
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		
		GetUserNameByIdTask task = new GetUserNameByIdTask(request, providers,userLookup);
		GetUserNameByIdTaskResponse taskResponse=(GetUserNameByIdTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		
		
	}

	@Test
	public void testGetUserNameByIdMissingUser() throws ClientException{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getUsernameByInternalId(100L)).thenThrow(new ClientException(404, "error"));
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		
		GetUserNameByIdTask task = new GetUserNameByIdTask(request, providers,userLookup);
		GetUserNameByIdTaskResponse taskResponse=(GetUserNameByIdTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.USER_DOES_NOT_EXIST));
		
		
	}
	
	@Test
	public void testGetUserNameByIdInternalServerError() throws ClientException{
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		UserLookup userLookup = mock(UserLookup.class);
		when(userLookup.getUsernameByInternalId(100L)).thenThrow(new ClientException(500, "error"));
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		
		GetUserNameByIdTask task = new GetUserNameByIdTask(request, providers,userLookup);
		GetUserNameByIdTaskResponse taskResponse=(GetUserNameByIdTaskResponse) task.createResponse();
		assertNotNull(taskResponse);
		assertThat(taskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
		
	}
}
