package com.ebay.raptor.cmseditor.task;

import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.CreateDraftRequest;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetPublicUserIdByIdTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserNameByIdTaskResponse;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;
public class CreateDraftTaskTest {

	
	@Test
	public void testCreateDraft() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		CreateDraftRequest req = new CreateDraftRequest();
		req.setUserId("100");
		Article article = new Article();
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType("HOW_TO");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		article.setAccessControlList(acl);
		req.setContent(article);
		request.setCreateContentRequest(req);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserNameByIdTask task1 = mock(GetUserNameByIdTask.class);
		GetUserNameByIdTaskResponse taskResponse1 = new GetUserNameByIdTaskResponse();
		taskResponse1.setUserName("testuser");
		when(task1.getTaskResponse()).thenReturn(taskResponse1);
		providerTasks.add(task1);
		
		GetPublicUserIdByIdTask task2 = mock(GetPublicUserIdByIdTask.class);
		GetPublicUserIdByIdTaskResponse taskResponse2 = new GetPublicUserIdByIdTaskResponse();
		taskResponse2.setPublicUserId("111");
		when(task2.getTaskResponse()).thenReturn(taskResponse2);
		providerTasks.add(task2);
		
		when(contentDraftDao.createContent(any(DraftContentEntity.class))).thenReturn("57fff8ec399d3167c9e53fa4");
		
		CreateDraftTask task = new CreateDraftTask(request, providerTasks,contentDraftDao);
		CreateDraftTaskResponse taskResp=(CreateDraftTaskResponse) task.createResponse();
		assertNotNull(taskResp);
		assertThat(taskResp.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@Test
	public void testCreateDraftNullRequest() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserNameByIdTask task1 = mock(GetUserNameByIdTask.class);
		GetUserNameByIdTaskResponse taskResponse1 = new GetUserNameByIdTaskResponse();
		taskResponse1.setUserName("testuser");
		when(task1.getTaskResponse()).thenReturn(taskResponse1);
		providerTasks.add(task1);
		
		GetPublicUserIdByIdTask task2 = mock(GetPublicUserIdByIdTask.class);
		GetPublicUserIdByIdTaskResponse taskResponse2 = new GetPublicUserIdByIdTaskResponse();
		taskResponse2.setPublicUserId("111");
		when(task2.getTaskResponse()).thenReturn(taskResponse2);
		providerTasks.add(task2);
		
		when(contentDraftDao.createContent(any(DraftContentEntity.class))).thenReturn("57fff8ec399d3167c9e53fa4");
		
		CreateDraftTask task = new CreateDraftTask(request, providerTasks,contentDraftDao);
		CmsEditorTaskResponse taskResp=task.createResponse();
		assertNotNull(taskResp);
		assertThat(taskResp.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
	
	@Test
	public void testCreateDraftNoContent() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		CreateDraftRequest req = new CreateDraftRequest();
		req.setUserId("100");
		request.setCreateContentRequest(req);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserNameByIdTask task1 = mock(GetUserNameByIdTask.class);
		GetUserNameByIdTaskResponse taskResponse1 = new GetUserNameByIdTaskResponse();
		taskResponse1.setUserName("testuser");
		when(task1.getTaskResponse()).thenReturn(taskResponse1);
		providerTasks.add(task1);
		
		GetPublicUserIdByIdTask task2 = mock(GetPublicUserIdByIdTask.class);
		GetPublicUserIdByIdTaskResponse taskResponse2 = new GetPublicUserIdByIdTaskResponse();
		taskResponse2.setPublicUserId("111");
		when(task2.getTaskResponse()).thenReturn(taskResponse2);
		providerTasks.add(task2);
		
		when(contentDraftDao.createContent(any(DraftContentEntity.class))).thenReturn("57fff8ec399d3167c9e53fa4");
		
		CreateDraftTask task = new CreateDraftTask(request, providerTasks,contentDraftDao);
		CmsEditorTaskResponse taskResp=task.createResponse();
		assertNotNull(taskResp);
		assertThat(taskResp.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
	
	@Test
	public void testCreateDraftError() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		CreateDraftRequest req = new CreateDraftRequest();
		req.setUserId("100");
		Article article = new Article();
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType("HOW_TO");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		article.setAccessControlList(acl);
		req.setContent(article);
		request.setCreateContentRequest(req);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserNameByIdTask task1 = mock(GetUserNameByIdTask.class);
		GetUserNameByIdTaskResponse taskResponse1 = new GetUserNameByIdTaskResponse();
		taskResponse1.setUserName("testuser");
		when(task1.getTaskResponse()).thenReturn(taskResponse1);
		providerTasks.add(task1);
		
		GetPublicUserIdByIdTask task2 = mock(GetPublicUserIdByIdTask.class);
		GetPublicUserIdByIdTaskResponse taskResponse2 = new GetPublicUserIdByIdTaskResponse();
		taskResponse2.setPublicUserId("111");
		when(task2.getTaskResponse()).thenReturn(taskResponse2);
		providerTasks.add(task2);
		
		when(contentDraftDao.createContent(any(DraftContentEntity.class))).thenReturn(null);
		
		CreateDraftTask task = new CreateDraftTask(request, providerTasks,contentDraftDao);
		CreateDraftTaskResponse taskResp=(CreateDraftTaskResponse) task.createResponse();
		assertNotNull(taskResp);
		assertThat(taskResp.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResp.getError(),is(CmsEditorStatus.CREATE_ERROR));
		
	}
	
	@Test
	public void testCreateDraftException() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		CreateDraftRequest req = new CreateDraftRequest();
		req.setUserId("100");
		Article article = new Article();
		article.setArticleStatus(ArticleStatusEnum.DRAFT);
		article.setTemplateType("HOW_TO");
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		article.setAccessControlList(acl);
		req.setContent(article);
		request.setCreateContentRequest(req);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		GetUserNameByIdTask task1 = mock(GetUserNameByIdTask.class);
		GetUserNameByIdTaskResponse taskResponse1 = new GetUserNameByIdTaskResponse();
		taskResponse1.setUserName("testuser");
		when(task1.getTaskResponse()).thenReturn(taskResponse1);
		providerTasks.add(task1);
		
		GetPublicUserIdByIdTask task2 = mock(GetPublicUserIdByIdTask.class);
		GetPublicUserIdByIdTaskResponse taskResponse2 = new GetPublicUserIdByIdTaskResponse();
		taskResponse2.setPublicUserId("111");
		when(task2.getTaskResponse()).thenReturn(taskResponse2);
		providerTasks.add(task2);
		
		when(contentDraftDao.createContent(any(DraftContentEntity.class))).thenThrow(new Exception());
		
		CreateDraftTask task = new CreateDraftTask(request, providerTasks,contentDraftDao);
		CreateDraftTaskResponse taskResp=(CreateDraftTaskResponse) task.createResponse();
		assertNotNull(taskResp);
		assertThat(taskResp.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(taskResp.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
}
