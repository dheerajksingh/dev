package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.mockito.Matchers;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.GetForEditRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.eq;
public class GetForEditTaskTest {
	
	@Test
	public void testGetForEditTask() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		GetForEditRequest req = new GetForEditRequest();
		req.setContentId("57fff8ec399d3167c9e53fa4");
		request.setGetForEditRequest(req);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(draftEntity);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse readTaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertThat(readTaskResponse.getContent().getContentId(),is(draftEntity.getContentId()));
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}

	@Test
	public void testGetForEditTaskNoDraft() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		GetForEditRequest req = new GetForEditRequest();
		req.setContentId("57fff8ec399d3167c9e53fa4");
		request.setGetForEditRequest(req);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(null);
		when(contentDraftDao.createContent(draftEntity)).thenReturn("57fff8ec399d3167c9e53fa4");
		when(contentPublishDao.updateContentField(eq("57fff8ec399d3167c9e53fa4"), Matchers.anyListOf(KeyValueImpl.class))).thenReturn(1);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse readTaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertThat(readTaskResponse.getContent().getContentId(),is(draftEntity.getContentId()));
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}
	
	@Test
	public void testGetForEditTaskNullRequest() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(draftEntity);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		CmsEditorTaskResponse readTaskResponse=task.createResponse();
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		
	}
	
	@Test
	public void testGetForEditTaskNoContent() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		GetForEditRequest req = new GetForEditRequest();
		req.setContentId("57fff8ec399d3167c9e53fa4");
		request.setGetForEditRequest(req);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(null);
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(draftEntity);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse readTaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(readTaskResponse.getError(),is(CmsEditorStatus.CONTENT_NOT_FOUND));
		
	}

	@Test
	public void testGetForEditTaskException() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		GetForEditRequest req = new GetForEditRequest();
		req.setContentId("57fff8ec399d3167c9e53fa4");
		request.setGetForEditRequest(req);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		acl.add("100");
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenThrow(new Exception());
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(draftEntity);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		CmsEditorTaskResponse readTaskResponse=task.createResponse();
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(readTaskResponse.getError(),is(CmsEditorStatus.INTERNAL_SERVER_ERROR));
		
	}
	
	@Test
	public void testGetForEditTaskNoAdminNoAccess() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		GetForEditRequest req = new GetForEditRequest();
		req.setContentId("57fff8ec399d3167c9e53fa4");
		request.setGetForEditRequest(req);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(draftEntity);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		userPermissionsTaskResponse.setPermissions(new HashSet<String>());
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse readTaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.FAILURE));
		assertThat(readTaskResponse.getError(),is(CmsEditorStatus.USER_ACCESS_ERROR));
		
	}
	
	@Test
	public void testGetForEditTaskAdmin() throws Exception{
		
		ContentDraftDao contentDraftDao = mock(ContentDraftDao.class);
		ContentPublishDao contentPublishDao = mock(ContentPublishDao.class);
		
		CmsEditorRequest request = new CmsEditorRequest();
		request.setUserId(100L);
		GetForEditRequest req = new GetForEditRequest();
		req.setContentId("57fff8ec399d3167c9e53fa4");
		request.setGetForEditRequest(req);
		
		
		PublishedContentEntity entity = new PublishedContentEntity();
		entity.setContentStatus("SUBMITTED");
		entity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		List<String> acl = new ArrayList<String>();
		entity.setAccessControlList(acl);
		when(contentPublishDao.findContentById("57fff8ec399d3167c9e53fa4")).thenReturn(entity);
		
		DraftContentEntity draftEntity = new DraftContentEntity();
		draftEntity.setContentStatus("DRAFT");
		draftEntity.setContentId(new ObjectId("57fff8ec399d3167c9e53fa4"));
		draftEntity.setAccessControlList(acl);
		when(contentDraftDao.findLatestDraftById(new ObjectId("57fff8ec399d3167c9e53fa4"))).thenReturn(draftEntity);
		
		List<ICmsEditorTask> providers = new ArrayList<ICmsEditorTask>();
		GetUserPermissionsTask userPermissionsTask = mock(GetUserPermissionsTask.class);
		GetUserPermissionsTaskResponse userPermissionsTaskResponse = new GetUserPermissionsTaskResponse();
		Set<String> permissions = new HashSet<String>();
		permissions.add(PermissionEnum.EDIT_OTHER_CONTENT.name());
		userPermissionsTaskResponse.setPermissions(permissions);
		when(userPermissionsTask.getTaskResponse()).thenReturn(userPermissionsTaskResponse);
		providers.add(userPermissionsTask);
		
		GetForEditTask task = new GetForEditTask(request, providers,contentDraftDao,contentPublishDao);
		ContentReadTaskResponse readTaskResponse=(ContentReadTaskResponse) task.createResponse();
		assertThat(readTaskResponse.getContent().getContentId(),is(draftEntity.getContentId()));
		assertThat(readTaskResponse.getTaskStatus(),is(CmsEditorTaskStatus.SUCCESS));
		
	}

}
