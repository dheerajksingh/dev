package com.ebay.raptor.cmseditor.validator;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.base.TimeDuration;
import com.ebay.cos.type.v3.base.TimeDurationUnitEnum;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.raptor.cmseditor.dao.entities.MarketingAssetsEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.field.validator.AllowedFields;
import com.ebay.raptor.cmseditor.field.validator.ContentFieldValidator;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.response.content.model.MarketingAssets;

public class ContentFieldValidatorTest {
	static ObjectMapper mapper;
	
	static{
		mapper=new ObjectMapper();
	}
	
	@Test
	public void testValidationWithNoKeyValues() throws CmsEditorException{
		
		new ContentFieldValidator().validateFields(null);
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithBadKey() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey("Fountain");
		Text text = new Text("title", LanguageEnum.en);
		keyValue.setValue(text);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_PATH));
			throw e;
		}
		
	}
	

	@Test
	public void testValidationWithTitle() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TITLE);
		Text text = new Text("title", LanguageEnum.en);
		keyValue.setValue(text);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.title"));
		assertThat(keyValue.getValue().toString(),is("title"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithTitleBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TITLE);
		keyValue.setValue("title");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithTitleKeyNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		Text text = new Text("title", LanguageEnum.en);
		keyValue.setValue(text);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_PATH));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithTitleValueNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TITLE);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	

	@Test
	public void testValidationWithEmptyTitle() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TITLE);
		Text text = new Text("", LanguageEnum.en);
		keyValue.setValue(text);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.title"));
		assertThat(keyValue.getValue().toString(),is(""));
		
	}
	
	@Test
	public void testValidationWithSynopsis() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.SYNOPSIS);
		Text text = new Text("synopsis", LanguageEnum.en);
		keyValue.setValue(text);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.synopsis"));
		assertThat(keyValue.getValue().toString(),is("synopsis"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithSynopsisBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.SYNOPSIS);
		keyValue.setValue("synopsis");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithSynopsisKeyNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		Text text = new Text("synopsis", LanguageEnum.en);
		keyValue.setValue(text);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_PATH));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithSynopsisValueNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.SYNOPSIS);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test
	public void testValidationWithCoverImage() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.COVER_IMAGE);
		Image image = new Image();
		image.setImageURL("img");
		keyValue.setValue(image);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.coverImage"));
		assertThat(keyValue.getValue().toString(),is("img"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithCoverImageBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.COVER_IMAGE);
		keyValue.setValue("img");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithCoverImageKeyNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		Image image = new Image();
		image.setImageURL("img");
		keyValue.setValue(image);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_PATH));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithCoverImageValueNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.COVER_IMAGE);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test
	public void testValidationWithEmptyCoverImageUrl() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.COVER_IMAGE);
		Image image = new Image();
		image.setImageURL("");
		keyValue.setValue(image);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.coverImage"));
		assertThat(keyValue.getValue().toString(),is(""));
		
	}
	
	@Test
	public void testValidationWithAcl() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.ACCESS_CONTROL_LIST);
		List<String> acls = new ArrayList<String>();
		acls.add("a1");
		keyValue.setValue(acls);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("accessControlList"));
		assertThat(keyValue.getValue().toString(),is("[a1]"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithAclBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.ACCESS_CONTROL_LIST);
		keyValue.setValue("acl");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithAclKeyNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		List<String> acls = new ArrayList<String>();
		acls.add("a1");
		keyValue.setValue(acls);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_PATH));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithAclValueNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.ACCESS_CONTROL_LIST);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test
	public void testValidationWithTags() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TAGS);
		List<String> tags = new ArrayList<String>();
		tags.add("t1");
		keyValue.setValue(tags);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.tags"));
		assertThat(keyValue.getValue().toString(),is("[t1]"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithTagsBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TAGS);
		keyValue.setValue("t1");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithTagsKeyNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		List<String> tags = new ArrayList<String>();
		tags.add("t1");
		keyValue.setValue(tags);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_PATH));
			throw e;
		}
		
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithTagsValueNull() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.TAGS);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
		
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testValidationWithMarketingAssets() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.MARKETING_ASSETS);
		MarketingAssets assets = new MarketingAssets();
		Map<String, Image> assetMap = new HashMap<String, Image>();
		Image img1 = new Image();
		img1.setImageURL("http://fb");
		assetMap.put("FB", img1);
		
		Image img2 = new Image();
		img2.setImageURL("http://instagram");
		assetMap.put("INSTAGRAM", img2);
		
		Text text = new Text();
		text.setContent("Instagram Text");
		
		keyValue.setValue(assetMap);
		assets.setAssets(assetMap);
		assets.setMarketingContent(text);
		keyValue.setValue(assets);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.marketingAssets"));
		Map<String, String> convertedMap = ((MarketingAssetsEntity)keyValue.getValue()).getMarketingAssetImages();
		assertThat(convertedMap.get("FB"),is("http://fb"));
		assertThat(convertedMap.get("INSTAGRAM"),is("http://instagram"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithMarketingAssetsBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.MARKETING_ASSETS);
		Image img1 = new Image();
		img1.setImageURL("http://fb");
		keyValue.setValue(img1);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testValidationWithCategories() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.CATEGORIES);
		Map<String, String> categories = new HashMap<String, String>();
		categories.put("L1", "100");
		categories.put("L2", "200");
		keyValue.setValue(categories);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.categories"));
		Map<String,String> convertedMap = (Map<String, String>) keyValue.getValue();
		assertThat(convertedMap.get("L1"),is("100"));
		assertThat(convertedMap.get("L2"),is("200"));
		
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationWithCategoriesBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.CATEGORIES);
		keyValue.setValue("L1");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
	}
	
	@Test
	public void testValidationForCosDate() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.SCHEDULED_START_DATE);
		DateTime d1 = new DateTime(new Date());
		keyValue.setValue(d1);
		
		KeyValueImpl keyValue2 = new KeyValueImpl();
		keyValue2.setKey(AllowedFields.SCHEDULED_END_DATE);
		DateTime d2 = new DateTime(new Date());
		keyValue2.setValue(d2);
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		String serialized2 = mapper.writeValueAsString(keyValue2);
		keyValue2=mapper.readValue(serialized2, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		keyvalues.add(keyValue2);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("scheduledStartDate"));
		assertThat(keyValue2.getKey(),is("scheduledEndDate"));
		assertThat(keyValue.getValue().toString(),is(d1.getValue().toString()));
		assertThat(keyValue2.getValue().toString(),is(d2.getValue().toString()));
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationForCosDateBadValue() throws Throwable{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.SCHEDULED_START_DATE);
		keyValue.setValue("d1");
		
		KeyValueImpl keyValue2 = new KeyValueImpl();
		keyValue2.setKey(AllowedFields.SCHEDULED_END_DATE);
		keyValue2.setValue("d2");
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		String serialized2 = mapper.writeValueAsString(keyValue2);
		keyValue2=mapper.readValue(serialized2, KeyValueImpl.class);
		
		keyvalues.add(keyValue);
		keyvalues.add(keyValue2);
		
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
	
	}
	
	@Test
	public void testValidationForCosTimeDuration() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.ESTIMATED_TIME);
		TimeDuration t = new TimeDuration();
		t.setUnit(TimeDurationUnitEnum.MINUTE);
		t.setValue(100L);
		keyValue.setValue(t);
		
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		
		keyvalues.add(keyValue);
		validator.validateFields(keyvalues);
		
		assertThat(keyValue.getKey(),is("userGeneratedContent.estimatedTime"));
		TimeDuration td =  (TimeDuration) keyValue.getValue();
		assertThat(td.getValue(),is(100L));
		assertThat(td.getUnit(),is(TimeDurationUnitEnum.MINUTE));
	}
	
	@Test(expected=CmsEditorException.class)
	public void testValidationForCosTimeDurationBadValue() throws CmsEditorException, JsonGenerationException, JsonMappingException, IOException{
		
		ContentFieldValidator validator = new ContentFieldValidator();
		
		List<KeyValueImpl> keyvalues = new ArrayList<KeyValueImpl>();
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(AllowedFields.ESTIMATED_TIME);
		keyValue.setValue("100");
		
		
		
		String serialized = mapper.writeValueAsString(keyValue);
		keyValue=mapper.readValue(serialized, KeyValueImpl.class);
		
		
		keyvalues.add(keyValue);
		try{
			validator.validateFields(keyvalues);
		}catch(CmsEditorException e){
			assertThat(e.getError(),is(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE));
			throw e;
		}
		
	}
	

}
