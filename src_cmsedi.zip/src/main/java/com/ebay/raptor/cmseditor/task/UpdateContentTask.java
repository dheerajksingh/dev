package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ContentUpdateRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateContentTaskResponse;
import com.ebay.raptor.cmseditor.util.CALUtil;

/**
 * Updates(overwrites) the whole content
 * SELECTOR: UPDATE_CONTENT
 * @author kravikumar
 *
 */
public class UpdateContentTask extends CmsEditorTask{

	private ContentEntityAdaptor adaptor;
	ContentDraftDao contentDraftDao;
	
	
	public UpdateContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		adaptor = new ContentEntityAdaptor();
		contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
	}
	
	public UpdateContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao) {
		super(request, providerTasks);
		adaptor = new ContentEntityAdaptor();
		this.contentDraftDao = contentDraftDao;
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		try {
			ContentUpdateRequest updateRequest = (ContentUpdateRequest)request.getContentUpdateRequest();
			
			//1.) Check if user has admin rights to update or blacklist
			boolean hasUpdatePermissions = false;
			List<String> accessControlList = new ArrayList<String>();
			for(ICmsEditorTask task: providerTasks) {
				if(task instanceof GetUserPermissionsTask) {
					GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
					Set<String> permissions = permissionsResponse.getPermissions();
					if(permissions != null && permissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name())) {
						hasUpdatePermissions = true;
					}
				} else if(task instanceof GetAccessControlListTask) {
					Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) task.getTaskResponse())
							.getContentEntityMap();
					if(contentEntityMap != null && contentEntityMap.get(updateRequest.getContentId()) != null) {
						accessControlList.addAll(contentEntityMap.get(updateRequest.getContentId())
								.getAccessControlList());
								
					}
				}
			}
			
			//2.) If user does not have admin rights check if its his own content
			if(!hasUpdatePermissions) {
				hasUpdatePermissions = accessControlList.contains(String.valueOf(request.getUserId()));
			}
			
			//3.) If the user has permissions update the content fields
			UpdateContentTaskResponse response = new UpdateContentTaskResponse();
			if(hasUpdatePermissions) {
				DraftContentEntity existingContent = contentDraftDao.findContentById(updateRequest.getContentId());
				DraftContentEntity entity=adaptor.adaptToDraft(updateRequest.getContentEntity(),String.valueOf(request.getUserId()));
				entity.setId(existingContent.getId());
				entity.setContentId(existingContent.getContentId());
				entity.setDateModified(new Date());
				contentDraftDao.save(entity);
				response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
				return response;
			} else {
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
				return response;
			}
		}catch(CmsEditorException c){
			UpdateContentTaskResponse response = new UpdateContentTaskResponse();
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(c.getError());
			return response;
		}catch(IllegalArgumentException i){
			UpdateContentTaskResponse response = new UpdateContentTaskResponse();
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.INVALID_CONTENT_ID);
			return response;
		}
		catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.UPDATE_CONTENT_TASK_EXCEPTION, "createResponse", ExceptionUtils.getFullStackTrace(e));
			return createFailureResponse();
		}
	}
	
	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		UpdateContentTaskResponse response = new UpdateContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}

}