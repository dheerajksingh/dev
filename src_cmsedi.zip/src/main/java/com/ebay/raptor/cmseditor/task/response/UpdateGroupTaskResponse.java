package com.ebay.raptor.cmseditor.task.response;

import com.ebay.raptor.cmseditor.response.content.model.Group;

public class UpdateGroupTaskResponse extends CmsEditorTaskResponse{
	
	private Group group;

	public Group getGroup() {
		return group;
	}

	public void setGroup(Group group) {
		this.group = group;
	}
	
}
