package com.ebay.raptor.cmseditor.response.composer;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.ArticleReadAllResponse;
import com.ebay.raptor.cmseditor.response.adaptor.ContentModelAdaptor;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadAllTaskResponse;

public class ContentReadAllResponseComposer implements IResponseComposer{
private List<CmsEditorTaskResponse> taskResponses;
private ContentModelAdaptor adaptor;
	
	public ContentReadAllResponseComposer(List<CmsEditorTaskResponse> taskResponses) {
		this.taskResponses = taskResponses;
		adaptor = new ContentModelAdaptor();
	}
	
	@Override
	public CmsEditorResponse compose() throws CmsEditorException{
		ArticleReadAllResponse response = new ArticleReadAllResponse();
		if(CollectionUtils.isEmpty(taskResponses)){
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
		for(CmsEditorTaskResponse taskResponse:taskResponses) {
			if(taskResponse instanceof ContentReadAllTaskResponse) {
				if(taskResponse.getTaskStatus()!=null && taskResponse.getTaskStatus().equals(CmsEditorTaskStatus.SUCCESS)) {
					response.status = CmsEditorResponseStatus.SUCCESS;
					List<Article> contents = new ArrayList<Article>();
					ContentReadAllTaskResponse contentReadAllTaskResponse = (ContentReadAllTaskResponse) taskResponse;
					if(!CollectionUtils.isEmpty(contentReadAllTaskResponse.getDrafts())){
						contents.addAll(adaptor.adaptToContentModelsFromDraft(contentReadAllTaskResponse.getDrafts()));
						response.setDraftArticlesCount(contentReadAllTaskResponse.getDraftArticlesCount());
					}
					if(!CollectionUtils.isEmpty(contentReadAllTaskResponse.getPublished())){
						contents.addAll(adaptor.adaptToContentModelsFromPublished(contentReadAllTaskResponse.getPublished()));
						response.setPublishedArticlesCount(contentReadAllTaskResponse.getPublishedArticlesCount());
					}
					response.setArticles(contents);
				} else {
					throw new CmsEditorException(taskResponse.getError());
				}
				break;
			}
		}
		return response;
	}

	public void setAdaptor(ContentModelAdaptor adaptor) {
		this.adaptor = adaptor;
	}

}
