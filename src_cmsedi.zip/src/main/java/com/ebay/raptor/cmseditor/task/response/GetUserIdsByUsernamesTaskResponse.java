package com.ebay.raptor.cmseditor.task.response;

import java.util.Map;


public class GetUserIdsByUsernamesTaskResponse extends CmsEditorTaskResponse {

	private Map<String, Long> userNamesToUserIdsMap;

	public Map<String, Long> getUserNamesToUserIdsMap() {
		return userNamesToUserIdsMap;
	}

	public void setUserNamesToUserIdsMap(Map<String, Long> userNamesToUserIdsMap) {
		this.userNamesToUserIdsMap = userNamesToUserIdsMap;
	}
	
}
