package com.ebay.raptor.cmseditor.task.factory;

import java.util.ArrayList;
import java.util.List;

import com.ebay.raptor.cmseditor.request.BulkCreateArticleRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.task.BulkCreateContentTask;
import com.ebay.raptor.cmseditor.task.GetAccessControlListTask;
import com.ebay.raptor.cmseditor.task.GetUserIdsByUsernamesTask;
import com.ebay.raptor.cmseditor.task.GetUserNameByIdTask;
import com.ebay.raptor.cmseditor.task.GetUserPermissionsTask;
import com.ebay.raptor.cmseditor.task.ICmsEditorTask;

public class BulkCreateContentTaskFactory implements ICmsEditorTaskFactory{
	
	private List<ICmsEditorTask> tasks = new ArrayList<>();
	
	public  BulkCreateContentTaskFactory(CmsEditorRequest request) {
		

		GetUserPermissionsTask permissionsTask = new GetUserPermissionsTask(request, new ArrayList<ICmsEditorTask>());

		tasks.add(permissionsTask);
		
		GetAccessControlListTask aclTask = new GetAccessControlListTask(
				request, ArticleStatusEnum.valueOf(request.getCreateBulkContentRequest().getMode()), new ArrayList<ICmsEditorTask>());
		tasks.add(aclTask);
		
		GetUserNameByIdTask usernameTask = new GetUserNameByIdTask(
				request, new ArrayList<ICmsEditorTask>());
		tasks.add(usernameTask);
		
		GetUserIdsByUsernamesTask userIdsTask = new GetUserIdsByUsernamesTask(request, getUserNames(request), new ArrayList<ICmsEditorTask>());
		tasks.add(userIdsTask);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		providerTasks.add(permissionsTask);
		providerTasks.add(aclTask);
		providerTasks.add(usernameTask);
		providerTasks.add(userIdsTask);
		
		BulkCreateContentTask createContentTask = new BulkCreateContentTask(request, providerTasks);
		tasks.add(createContentTask);
	}

	private List<String> getUserNames(CmsEditorRequest request) {
		List<String> usernames = new ArrayList<String>();
		
		BulkCreateArticleRequest bulkRequest = request.getCreateBulkContentRequest();
		for(Article content:bulkRequest.getArticles()) {
			usernames.add(content.getAuthor().getUsername());
		}
		return usernames;
	}

	@Override
	public List<ICmsEditorTask> getTasks() {
		return tasks;
	}

}
