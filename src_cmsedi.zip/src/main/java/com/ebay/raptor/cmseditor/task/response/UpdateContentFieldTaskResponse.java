package com.ebay.raptor.cmseditor.task.response;

public class UpdateContentFieldTaskResponse extends CmsEditorTaskResponse{

}
