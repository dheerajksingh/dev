package com.ebay.raptor.cmseditor.field.validator;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

@Component
public class ContentFieldValidator {
	
	public void validateFields(List<KeyValueImpl> keyValues) throws CmsEditorException{
		if(CollectionUtils.isEmpty(keyValues)){
			return;
		}
		
		for(KeyValueImpl keyValue:keyValues){

			if (StringUtils.isEmpty(keyValue.getKey())) {
				throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
			}
			if(!AllowedFields.getAllowedFields().contains(keyValue.getKey())) {
				throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
			} 
			IFieldValidator validator = AllowedFields.getValidator(keyValue.getKey());
			if (validator==null) {
				//This means the field is a primitive and doesn't need a special validator.But we
				//should still reset the path corresponding to the entity field
				if(AllowedFields.getEntityField(keyValue.getKey())==null){
					throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
				}
				keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
				return;
			}
			validator.validate(keyValue);
		}
	}
}
