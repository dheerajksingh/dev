package com.ebay.raptor.cmseditor.response.composer;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;

public interface IResponseComposer {

	public CmsEditorResponse compose() throws CmsEditorException;
	
}
