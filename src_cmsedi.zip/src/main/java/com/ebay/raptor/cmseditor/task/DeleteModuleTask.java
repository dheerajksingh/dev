package com.ebay.raptor.cmseditor.task;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.DeleteSectionRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.DeleteModuleTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;

/**
 * Deletes a module specified by module id
 * SELECTOR:DELETE_MODULE
 * @author kravikumar
 *
 */
public class DeleteModuleTask extends CmsEditorTask{
	
	@Inject ContentDraftDao contentDao;
	
	private static final Logger LOGGER = Logger.getInstance(DeleteModuleTask.class);



	public DeleteModuleTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDao=request.getApplicationContext().getBean(ContentDraftDao.class);

	}
	
	public DeleteModuleTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao) {
		super(request, providerTasks);
		this.contentDao=contentDraftDao;

	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		DeleteSectionRequest req = request.getDeleteSectionRequest();
		if(req==null){
			return createFailureResponse();
		}
		
		List<CmsEditorTaskResponse> taskResponses = getTaskResponses();
		if(CollectionUtils.isEmpty(taskResponses)){
			return createFailureResponse();
		}
		boolean isAdmin=false;
		boolean hasAccess=false;
		DeleteModuleTaskResponse response = new DeleteModuleTaskResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses){
			if(taskResponse instanceof GetUserPermissionsTaskResponse){
				Set<String> permissions = ((GetUserPermissionsTaskResponse) taskResponse).getPermissions();
				if(!CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.DELETE_OTHER_CONTENT.name())){
					isAdmin=true;
				}
			} else if(taskResponse instanceof GetAccessControlListTaskResponse) {
				if(taskResponse.getTaskStatus()==CmsEditorTaskStatus.FAILURE){
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					response.setError(taskResponse.getError());
					return response;
				}
				Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) taskResponse)
						.getContentEntityMap();
				if(contentEntityMap != null && contentEntityMap.get(req.getContentId()) != null && !CollectionUtils.isEmpty(contentEntityMap.get(req.getContentId()).getAccessControlList())) {
					hasAccess = contentEntityMap.get(req.getContentId())
							.getAccessControlList()
							.contains(String.valueOf(request.getUserId()));
				}		
				
			}
		}
		if(!isAdmin && !hasAccess){
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
			return response;
		}
		
		try{
			int updateCount = contentDao.deleteContentModule(req.getContentId(), req.getGroupId(), req.getSectionId());
			if(updateCount<=0){
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.MODULE_NOT_FOUND);
				return response;
			}
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

}
