package com.ebay.raptor.cmseditor.task.response;

public class GetUserNameByIdTaskResponse extends CmsEditorTaskResponse{
	
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	

}
