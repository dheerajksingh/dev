package com.ebay.raptor.cmseditor.response.adaptor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.ebay.cos.type.v3.base.DateTime;
import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.cos.type.v3.core.listing.Image;
import com.ebay.cos.type.v3.core.listing.ImageURLTypeEnum;
import com.ebay.cos.type.v3.core.listing.Video;
import com.ebay.cos.type.v3.core.user.UserIdentifier;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.dao.entities.ModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.SingleModuleEntity;
import com.ebay.raptor.cmseditor.dao.entities.UserGeneratedContentEntity;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.response.content.model.Component;
import com.ebay.raptor.cmseditor.response.content.model.EntityComponent;
import com.ebay.raptor.cmseditor.response.content.model.Group;
import com.ebay.raptor.cmseditor.response.content.model.MarketingAssets;
import com.ebay.raptor.cmseditor.response.content.model.MediaComponent;
import com.ebay.raptor.cmseditor.response.content.model.ModuleType;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.response.content.model.StandardComponent;
import com.ebay.raptor.cmseditor.response.content.model.UserGeneratedContent;
import com.ebay.zoom.imageurlbuilder.core.ZoomImageUrlBuilder;
import com.ebay.zoom.imageurlbuilder.util.ImageOptions;
import com.ebay.zoom.imageurlbuilder.util.UrlBuilderResponse;

import edu.emory.mathcs.backport.java.util.Collections;

public class ContentModelAdaptor {
	
	public List<Article> adaptToContentModelsFromDraft(List<DraftContentEntity> contents){
		List<Article> models = new ArrayList<Article>();
		if(CollectionUtils.isEmpty(contents)){
			return models;
		}
		for(DraftContentEntity content:contents){
			models.add(adaptToContentModelFromDraft(content));
		}
		return models;
	}
	
	public List<Article> adaptToContentModelsFromPublished(List<PublishedContentEntity> contents){
		List<Article> models = new ArrayList<Article>();
		if(CollectionUtils.isEmpty(contents)){
			return models;
		}
		for(PublishedContentEntity content:contents){
			models.add(adaptToContentModelFromPublished(content));
		}
		return models;
	}
	
	
	private Article adaptToContentModelFromDraft(DraftContentEntity content){
		
		return adaptToContentModel(content);
	}
	
	public Article adaptToContentModelFromPublished(PublishedContentEntity content){
		
		return adaptToContentModel(content);
	}

	public Article adaptToContentModel(ContentEntity content) {
		Article model = new Article();
		if(!CollectionUtils.isEmpty(content.getAccessControlList())){
			model.setAccessControlList(content.getAccessControlList());
		}
		UserIdentifier author = new UserIdentifier();
		author.setUserId(content.getPublicAuthorId());
		author.setUsername(content.getAuthorName());
		model.setAuthor(author);
		model.setArticleId(content.getContentId().toString());
		model.setArticleStatus(ArticleStatusEnum.valueOf(content.getContentStatus()));
		if(content.getDateCreated()!=null){
			model.setDateCreated(new DateTime(content.getDateCreated()));
		}
		if(content.getDateModified()!=null){
			model.setDateModified(new DateTime(content.getDateModified()));
		}
		model.setTemplateType(content.getTemplateType());
		if(content.getUserGeneratedContent()!=null){
		model.setUserGeneratedContent(convertUserGenContent(content.getUserGeneratedContent()));
		}
		if(model.getModerationStatus() != null) {
			model.setModerationStatus(ModerationStatusEnum.valueOf(content.getModerationStatus()));
		}
		model.setMarketplaceId(content.getMarketPlaceId());
		model.setScheduledEndDate(new DateTime(content.getScheduledEndDate()));
		model.setScheduledStartDate(new DateTime(content.getScheduledStartDate()));
		return model;
	}
	
	public Group adaptToGroupModel(GroupEntity group) {
		Group groupModel = new Group();
		groupModel.setGroupType(group.getGroupType());
		groupModel.setGroupId(group.getGroupId());
		if(group.getModuleMap()!=null){
			groupModel.setSections(constructModuleList(group.getModuleMap()));
		}
		if(group.getTitle()!=null && !StringUtils.isEmpty(group.getTitle().getContent())){
			groupModel.setTitle(group.getTitle());
		}
		return groupModel;
	}

	private UserGeneratedContent convertUserGenContent(
			UserGeneratedContentEntity userGeneratedContent) {
		UserGeneratedContent model = null;
		if (userGeneratedContent != null ) {
			model = new UserGeneratedContent();
			if(!StringUtils.isEmpty(userGeneratedContent.getCoverImage())){
				model.setCoverImage(convertImage(userGeneratedContent.getCoverImage()));
			}
			if(!StringUtils.isEmpty(userGeneratedContent.getSynopsis())){
				model.setSynopsis(new Text(userGeneratedContent.getSynopsis(),LanguageEnum.en));
			}
			model.setTags(userGeneratedContent.getTags());
			model.setCostRange(userGeneratedContent.getCostRange());
			model.setDifficultyLevel(userGeneratedContent.getDifficultyLevel());
			
			
			if(!StringUtils.isEmpty(userGeneratedContent.getTitle())){
				model.setTitle(new Text(userGeneratedContent.getTitle(),LanguageEnum.en));
			}
			if(!StringUtils.isEmpty(userGeneratedContent.getConclusionTitle())){
				model.setConclusionTitle(new Text(userGeneratedContent.getConclusionTitle(),LanguageEnum.en));
			}
			if(!StringUtils.isEmpty(userGeneratedContent.getConclusionDescription())){
				model.setConclusionDescription(new Text(userGeneratedContent.getConclusionDescription(),LanguageEnum.en));
			}
			if(!CollectionUtils.isEmpty(userGeneratedContent.getGroups())){
				model.setGroups(convertGroupModels(userGeneratedContent.getGroups()));
			}
			if(!CollectionUtils.isEmpty(userGeneratedContent.getMaterialsNeeded())) {
				model.setMaterialsNeeded(userGeneratedContent.getMaterialsNeeded());
			}
			if(!CollectionUtils.isEmpty(userGeneratedContent.getToolsNeeded())) {
				model.setToolsNeeded(userGeneratedContent.getToolsNeeded());
			}
			if(userGeneratedContent.getEstimatedTime() != null) {
				model.setEstimatedTime(userGeneratedContent.getEstimatedTime());
			}
			if(userGeneratedContent.getMarketingAssets()!=null){
				Map<String, Image> assets = new HashMap<String, Image>();
				for(Map.Entry<String, String> assetMap:userGeneratedContent.getMarketingAssets().getMarketingAssetImages().entrySet()){
					assets.put(assetMap.getKey(), convertImage(assetMap.getValue()));
				}
				MarketingAssets marketingAssets = new MarketingAssets();
				marketingAssets.setAssets(assets);
				marketingAssets.setMarketingContent(userGeneratedContent.getMarketingAssets().getMarketingContent());
				model.setMarketingAssets(marketingAssets);
			}
			if(userGeneratedContent.getCategories()!=null){
				model.setCategories(userGeneratedContent.getCategories());
			}
			
		}
		return model;
	}

	private List<Group> convertGroupModels(List<GroupEntity> groups) {
		List<Group> groupModels = new ArrayList<Group>();
		for(GroupEntity group:groups){
			Group model = new Group();
			model.setGroupId(group.getGroupId());
			model.setGroupType(group.getGroupType());
			if(group.getModuleMap()!=null){
				model.setSections(constructModuleList(group.getModuleMap()));
			}
			if(group.getTitle()!=null && !StringUtils.isEmpty(group.getTitle().getContent())){
				model.setTitle(group.getTitle());
			}
			groupModels.add(model);
		}
		return groupModels;
	}

	private List<Section> constructModuleList(Map<String, ModuleEntity> moduleMap) {
		List<Section> modules = new ArrayList<Section>();
		for(Map.Entry<String, ModuleEntity> entry:moduleMap.entrySet()){
			Section module = new Section();
			module.setAlignment(entry.getValue().getAlignment());
			module.setSectionId(entry.getValue().getModuleId());
			module.setSequence(entry.getValue().getSortOrder());
			if(!CollectionUtils.isEmpty(entry.getValue().getData())){
				List<SingleModuleEntity> entities = entry.getValue().getData();
				List<Component> baseModules = new ArrayList<Component>();
				for(SingleModuleEntity singleEntity:entities){
					if(StringUtils.isEmpty(singleEntity.getType())){
						continue;
					}
					baseModules.add(constructModule(singleEntity));
				}
				module.setComponents(baseModules);
			}
			modules.add(module);
		}
		Collections.sort(modules);
		return modules;
	}

	private Component constructModule(SingleModuleEntity singleEntity) {
		switch(singleEntity.getType()){
		case "IMAGE": 
			MediaComponent imagemodule = new MediaComponent();
			imagemodule.setComponentType(ModuleType.IMAGE.name());
			imagemodule.setMedia(convertImage(singleEntity.getResourceUrl()));
			imagemodule.setCaption(singleEntity.getCaption());
			imagemodule.setCategoryIds(singleEntity.getCategoryIds());
			imagemodule.setCategoryLevel(singleEntity.getCategoryLevel());
			return imagemodule;
		case "VIDEO":
			MediaComponent videomodule = new MediaComponent();
			videomodule.setComponentType(ModuleType.VIDEO.name());
			Video video = new Video();
			video.setVideoURL(singleEntity.getResourceUrl());
			videomodule.setCaption(singleEntity.getCaption());
			videomodule.setMedia(video);
			return videomodule;
		case "ENTITY":
			EntityComponent entityModule = new EntityComponent();
			entityModule.setComponentType(singleEntity.getType());
			if(!CollectionUtils.isEmpty(singleEntity.getEntityIds())){
				entityModule.setEntityIds(singleEntity.getEntityIds());
			}
			entityModule.setEntityType(singleEntity.getEntityType());
			entityModule.setCaption(singleEntity.getCaption());
			return entityModule;
		default:
			StandardComponent standardModule = new StandardComponent();
			standardModule.setCaption(singleEntity.getCaption());
			standardModule.setData(singleEntity.getData());
			standardModule.setComponentType(singleEntity.getType());
			return standardModule;
		}
	}

	private Image convertImage(String coverImage) {
		Image image = new Image();
		image.setImageURL(coverImage);
		ZoomImageUrlBuilder builder = ZoomImageUrlBuilder.getInstance();
		ImageOptions options = new ImageOptions(225);
		UrlBuilderResponse response = builder.constructZoomUrl(coverImage, options);
		if(response==null){
			return image;
		}
		image.setImageURLType(ImageURLTypeEnum.NEW_ZOOM);
		Map<String, String> imageURLElements = new HashMap<String, String>();
		imageURLElements.put("ZOOM_GUID", response.getMediaId());
		image.setImageURLElements(imageURLElements);
		return image;
	}

}
