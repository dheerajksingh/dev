package com.ebay.raptor.cmseditor.field.validator;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

public interface IFieldValidator {
	
	public void validate(KeyValueImpl keyValue) throws CmsEditorException;

}
