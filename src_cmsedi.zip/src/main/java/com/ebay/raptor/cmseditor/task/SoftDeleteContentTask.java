package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.DeleteContentRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateContentTaskResponse;
import com.ebay.raptor.cmseditor.util.BESUtil;
import com.ebay.raptor.cmseditor.util.CALUtil;

public class SoftDeleteContentTask extends CmsEditorTask {
	
	ContentDraftDao contentDraftDao;
	ContentPublishDao contentPublishDao;
	BESHandler besHandler;
	
	public SoftDeleteContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
		contentPublishDao = request.getApplicationContext().getBean(ContentPublishDao.class);
	}
	
	public SoftDeleteContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao,ContentPublishDao contentPublishDao,BESHandler besHandler) {
		super(request, providerTasks);
		this.contentDraftDao = contentDraftDao;
		this.contentPublishDao = contentPublishDao;
		this.besHandler=besHandler;
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		
		try {
			
			// 1.) Check if user has admin permissions & can delete a content
			boolean hasAdminDeleteRights = false;
			boolean hasUpdatePermissions = false;
			for(ICmsEditorTask task: providerTasks) {
				if(task instanceof GetUserPermissionsTask) {
					GetUserPermissionsTaskResponse response = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
					Set<String> permissions = response.getPermissions();
					hasAdminDeleteRights = (permissions != null && permissions.contains(PermissionEnum.DELETE_OTHER_CONTENT.name()));
					break;
				}
			}
			// 2a.) If the user has permissions or owns the content then delete the draft or published content
			DeleteContentRequest contentDeleteRequest = request.getDeleteContentRequest();
			String contentId = contentDeleteRequest.getContentId();
			if(StringUtils.isEmpty(contentId)){
				return createFailureResponse();
			}
			ArticleStatusEnum status = contentDeleteRequest.getStatus();

			UpdateContentTaskResponse response = new UpdateContentTaskResponse();
			
			//2b.) If user does not have admin rights check if its his own content
			if(!hasAdminDeleteRights) {
				try{
				List<String> accessControlList = null;
				if(ArticleStatusEnum.isPublishedContent(status)) {
					accessControlList = contentPublishDao.findContentAccessControlListByContentId(contentId);
				}  else {
					accessControlList = contentDraftDao.findContentAccessControlListByContentId(contentId);
				}
				if(CollectionUtils.isEmpty(accessControlList)){
					response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					return response;
				}
				hasUpdatePermissions = accessControlList.contains(String.valueOf(request.getUserId()));
				}catch(IllegalArgumentException i){
					response.setError(CmsEditorStatus.INVALID_CONTENT_ID);
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					return response;
				}
			}

			KeyValueImpl kv = new KeyValueImpl();
			kv.setKey(ContentFields.isDeleted.toString());
			kv.setValue(true);
			List<KeyValue> kvs = new ArrayList<KeyValue>();
			kvs.add(kv);
			//3.) If the user has permissions delete the content
			if(hasAdminDeleteRights || hasUpdatePermissions) {
				try{
				if(ArticleStatusEnum.isPublishedContent(status)) {
					contentPublishDao.updateContentField(contentId, kvs);
					besHandler.dropArticleDeleteEvent(contentId);
				} else {
					contentDraftDao.updateContentField(contentId, kvs);
				}
				}catch(IllegalArgumentException i){
					response.setError(CmsEditorStatus.INVALID_CONTENT_ID);
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					return response;
				}
				response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
				return response;
			} else {
				return createFailureResponse(CmsEditorStatus.USER_ACCESS_ERROR);
			}
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.DELETE_CONTENT_TASK_EXCEPTION, "createResponse", ExceptionUtils.getFullStackTrace(e));
			return createFailureResponse();
		}
	}
	
	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		UpdateContentTaskResponse response = new UpdateContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
	
	protected CmsEditorTaskResponse createFailureResponse(CmsEditorStatus status) {
		UpdateContentTaskResponse response = new UpdateContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(status);
		return response;
	}
	
	static class BESHandler{
		
		public void dropArticleDeleteEvent(String contentId){
			BESUtil.dropArticleDeleteEvent(contentId);
		}
	}

}
