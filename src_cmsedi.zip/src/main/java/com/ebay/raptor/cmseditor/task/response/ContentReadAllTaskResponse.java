package com.ebay.raptor.cmseditor.task.response;

import java.util.List;

import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;

public class ContentReadAllTaskResponse extends CmsEditorTaskResponse{
	
	private List<DraftContentEntity> drafts;
	private List<PublishedContentEntity> published;
	private Long draftArticlesCount;
	private Long publishedArticlesCount;
	
	public List<DraftContentEntity> getDrafts() {
		return drafts;
	}
	public void setDrafts(List<DraftContentEntity> drafts) {
		this.drafts = drafts;
	}
	public List<PublishedContentEntity> getPublished() {
		return published;
	}
	public void setPublished(List<PublishedContentEntity> published) {
		this.published = published;
	}
	public Long getDraftArticlesCount() {
		return draftArticlesCount;
	}
	public void setDraftArticlesCount(Long draftArticlesCount) {
		this.draftArticlesCount = draftArticlesCount;
	}
	public Long getPublishedArticlesCount() {
		return publishedArticlesCount;
	}
	public void setPublishedArticlesCount(Long publishedArticlesCount) {
		this.publishedArticlesCount = publishedArticlesCount;
	}
	
	
	
	
//	private List<DraftContent> draftContents;
//	private List<PublishedContent> publishedContents;
//	public List<DraftContent> getDraftContents() {
//		return draftContents;
//	}
//	public void setDraftContents(List<DraftContent> draftContents) {
//		this.draftContents = draftContents;
//	}
//	public List<PublishedContent> getPublishedContents() {
//		return publishedContents;
//	}
//	public void setPublishedContents(List<PublishedContent> publishedContents) {
//		this.publishedContents = publishedContents;
//	}
	
	

}
