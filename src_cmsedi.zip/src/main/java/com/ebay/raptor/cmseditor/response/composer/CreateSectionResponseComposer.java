package com.ebay.raptor.cmseditor.response.composer;

import java.util.List;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.response.CreateSectionResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.CreateSectionTaskResponse;

public class CreateSectionResponseComposer implements IResponseComposer{

	private List<CmsEditorTaskResponse> taskResponses;
	
	public CreateSectionResponseComposer(List<CmsEditorTaskResponse> taskResponses) {
		this.taskResponses = taskResponses;
	}
	
	@Override
	public CmsEditorResponse compose() throws CmsEditorException{
		CreateSectionResponse response = new CreateSectionResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses) {
			if(taskResponse instanceof CreateSectionTaskResponse) {
				if(taskResponse.getTaskStatus().equals(CmsEditorTaskStatus.SUCCESS)) {
					response.setSection(((CreateSectionTaskResponse) taskResponse).getSection());
					response.status=CmsEditorResponseStatus.SUCCESS;
				} else{
					throw new CmsEditorException(taskResponse.getError());
				}
				break;
			}
		}
		return response;
	}
	
}