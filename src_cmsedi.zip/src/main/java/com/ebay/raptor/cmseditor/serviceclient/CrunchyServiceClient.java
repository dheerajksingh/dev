package com.ebay.raptor.cmseditor.serviceclient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.ebayopensource.ginger.client.GingerClient;
import org.ebayopensource.ginger.client.GingerClientResponse;
import org.ebayopensource.ginger.client.GingerWebTarget;
import org.ebayopensource.ginger.client.config.crunchysvc.reponse.CrunchySvcData;
import org.ebayopensource.ginger.client.config.crunchysvc.reponse.CrunchySvcResponse;
import org.ebayopensource.ginger.client.config.crunchysvc.reponse.CrunchySvcResponseRow;
import org.ebayopensource.ginger.client.internal.GingerClientFactory.ClientCreationException;
import org.ebayopensource.ginger.client.internal.GingerClientManager;
import org.ebayopensource.ginger.client.internal.GingerClientManager.ClientAlreadyRegisteredException;
import org.ebayopensource.ginger.client.internal.InitGingerClientConfigFactory.ConfigCreationException;
import org.springframework.util.CollectionUtils;

import com.ebay.raptor.cmseditor.config.ConfigParam;
import com.ebay.raptor.cmseditor.util.CALUtil;

public class CrunchyServiceClient {

	private static final String ENDPOINT = ConfigParam.TORA_END_POINT.getStringValue();
	private static final String CLIENT_ID = "CrunchyServiceClient";
	private static final String SERVICE_NAME = "crunchysvc";
	private static final String CBKEY_PARAM = "__cbkey";
	
	protected GingerClient client = null;
	
	public Map<String, Long> getArticleViews(List<String> articleIds) {
		Map<String, Long> articleViewsMap = new HashMap<String, Long>();
		if(CollectionUtils.isEmpty(articleIds)) {
			return articleViewsMap;
		}
		try {
			GingerClient client = getGingerClient();
			GingerWebTarget webTarget = client.target(ENDPOINT);
			for(String articleId: articleIds) {
				webTarget = webTarget.queryParam(CBKEY_PARAM, String.format("gd|%s", articleId));
			}
			Invocation.Builder resourceBuilder = webTarget.request(MediaType.APPLICATION_JSON);
			GingerClientResponse response = (GingerClientResponse) resourceBuilder.get();
			if(response == null || response.getStatus() != 200) {
				CALUtil.logFailedCALEvent(CALUtil.CRUNCHY_SERVICE_EXCEPTION, "getArticleViews", "Response is null or request failed. Url: " + webTarget.getUri());
			}
			CrunchySvcResponse crunchyResponse = response.getEntity(CrunchySvcResponse.class);
			if(!CollectionUtils.isEmpty(crunchyResponse.getRows())) {
				for(CrunchySvcResponseRow row: crunchyResponse.getRows()) {
					CrunchySvcData data = row.getData();
					if(data != null) {
						articleViewsMap.put(data.get__cbkey().replace("gd|", ""), 
								Long.valueOf(data.get__cbcontent()));
					}
				}
			}
			
		} catch (ConfigCreationException | ClientCreationException | ClientAlreadyRegisteredException e) {
			CALUtil.logFailedCALEvent(CALUtil.CRUNCHY_SERVICE_EXCEPTION, "getArticleViews", ExceptionUtils.getFullStackTrace(e));
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.CRUNCHY_SERVICE_EXCEPTION, "getArticleViews", ExceptionUtils.getFullStackTrace(e));			
		}
		return articleViewsMap;
	}
	
	
	private GingerClient getGingerClient() throws ConfigCreationException, ClientCreationException, ClientAlreadyRegisteredException {
		
		if(client != null) {
			return client;
		}
		client = GingerClientManager.get().getOrRegisterClient(CLIENT_ID, SERVICE_NAME);
		return client;
		
	}
	
}
