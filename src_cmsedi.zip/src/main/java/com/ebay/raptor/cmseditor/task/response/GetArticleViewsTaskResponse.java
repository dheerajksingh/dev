package com.ebay.raptor.cmseditor.task.response;

import java.util.Map;

public class GetArticleViewsTaskResponse extends CmsEditorTaskResponse {

	private Map<String, Long> articleViewsMap;

	public Map<String, Long> getArticleViewsMap() {
		return articleViewsMap;
	}

	public void setArticleViewsMap(Map<String, Long> articleViewsMap) {
		this.articleViewsMap = articleViewsMap;
	}
	
}
