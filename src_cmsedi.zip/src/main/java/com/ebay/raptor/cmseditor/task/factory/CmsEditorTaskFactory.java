package com.ebay.raptor.cmseditor.task.factory;

import java.util.Collections;
import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.task.ICmsEditorTask;

public class CmsEditorTaskFactory{
	
	

	public static List<ICmsEditorTask> getTasks(CmsEditorRequest request){
		if(request==null){
			return Collections.emptyList();
		}
		Selector selector = request.getSelector();
		if(selector==null){
			return Collections.emptyList();
		}
		switch(selector){
		case BULK_CREATE_CONTENT: return new BulkCreateContentTaskFactory(request).getTasks();
		case READ_ALL_CONTENT:return new ContentReadAllTaskFactory(request).getTasks();
		case READ_CONTENT: return new ContentReadTaskFactory(request).getTasks();
		case DELETE_MODULE: return new DeleteModuleTaskFactory(request).getTasks();
		case DELETE_GROUP: return new DeleteGroupTaskFactory(request).getTasks();
		case BULK_DELETE_CONTENT: return new BulkDeleteContentTaskFactory(request).getTasks();
		case UPDATE_CONTENT: return new UpdateContentTaskFactory(request).getTasks();
		case SEARCH_CONTENT: return new SearchContentTaskFactory(request).getTasks();
		case UPDATE_GROUP: return new UpdateGroupTaskFactory(request).getTasks();
		case UPDATE_MODULE: return new UpdateModuleTaskFactory(request).getTasks();
		case UPDATE_CONTENT_ATTRIBUTE: return new UpdateContentAttributeTaskFactory(request).getTasks();
		case PUBLISH_CONTENT: return new PublishContentTaskFactory(request).getTasks();
		case GET_FOR_EDIT: return new GetForEditTaskFactory(request).getTasks();
		case CREATE_DRAFT: return new CreateDraftTaskFactory(request).getTasks();
		case DELETE_CONTENT: return new DeleteContentTaskFactory(request).getTasks();
		case UPDATE_STATUS_FOR_MODERATION: return new UpdateModerationStatusTaskFactory(request).getTasks();
		case MODERATE: return new UpdateModerationStatusTaskFactory(request).getTasks();
		case GET_FOR_MODERATION: return new ModeratorReadAllTaskFactory(request).getTasks();
		case CREATE_MODULE: return new CreateSectionTaskFactory(request).getTasks();
		default: return Collections.emptyList();
		
		}
	}
}
