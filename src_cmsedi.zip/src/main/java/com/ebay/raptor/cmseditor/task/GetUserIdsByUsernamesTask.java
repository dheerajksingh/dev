package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import org.springframework.util.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserIdsByUsernamesTaskResponse;
import com.ebay.userlookup.UserLookup;
import com.ebay.userlookup.common.ClientException;
import com.ebay.userlookup.common.PublicUserIdUsernameMap;
import com.ebay.userlookup.common.UserIdLookupResult;
import com.ebay.userlookup.common.UserIdMap;

public class GetUserIdsByUsernamesTask extends CmsEditorTask {

	private UserLookup userLookup;
	private List<String> usernames;

	private static final Logger LOGGER = Logger
			.getInstance(GetUserIdsByUsernamesTask.class);

	public GetUserIdsByUsernamesTask(CmsEditorRequest request,
			List<String> usernames, List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		this.userLookup = new UserLookup();
		this.usernames = usernames;
	}
	
	public GetUserIdsByUsernamesTask(CmsEditorRequest request,
			List<String> usernames, List<ICmsEditorTask> providerTasks,UserLookup userLookup) {
		super(request, providerTasks);
		this.userLookup = userLookup;
		this.usernames = usernames;
	}
	
	

	@Override
	protected CmsEditorTaskResponse createResponse() {
		if (CollectionUtils.isEmpty(usernames)) {
			return new GetUserIdsByUsernamesTaskResponse();
		}
		GetUserIdsByUsernamesTaskResponse response = new GetUserIdsByUsernamesTaskResponse();
		try {
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setUserNamesToUserIdsMap(getUserIdsMap());
			return response;
		} catch (CmsEditorException c) {
			response.setError(c.getError());
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
	}

	private Map<String, Long> getUserIdsMap() throws CmsEditorException {
		try {
			UserIdLookupResult publicUserIdsResult = userLookup
					.getAll_PublicUserIdByUsername(usernames, 500); // TODO: Change this to config
			Map<String, String> userNameToPublicUserIdMap = getUserNameToPublicUserIdMap(publicUserIdsResult
					.getPuuidUsernameList());

			List<String> publiUserIds = new ArrayList<String>(
					userNameToPublicUserIdMap.values());
			UserIdLookupResult userIdsResult = userLookup
					.getAll_InternalId(publiUserIds, 500); // TODO: Change this to config
			Map<String, Long> publiUserIdtoInternalIdMap = getPubliUserIdtoInternalIdMap(userIdsResult
					.getUserid_list());

			Map<String, Long> userNameToUserIdMap = new HashMap<String, Long>();
			for (String username : userNameToPublicUserIdMap.keySet()) {
				String publicUserId = userNameToPublicUserIdMap.get(username);
				userNameToUserIdMap.put(username,
						publiUserIdtoInternalIdMap.get(publicUserId));
			}
			return userNameToUserIdMap;
		} catch (ClientException e) {
			LOGGER.log(LogLevel.ERROR, e);
			if (e.getStatusCode() == Status.NOT_FOUND.getStatusCode()) {
				throw new CmsEditorException(
						CmsEditorStatus.USER_DOES_NOT_EXIST, e);
			}
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	private Map<String, Long> getPubliUserIdtoInternalIdMap(
			List<UserIdMap> userid_list) {
		Map<String, Long> publiUserIdtoInternalIdMap = new HashMap<String, Long>();

		for (UserIdMap map : userid_list) {
			publiUserIdtoInternalIdMap.put(map.getPublic_user_id(),
					map.getInternal_id());
		}
		return publiUserIdtoInternalIdMap;
	}

	private Map<String, String> getUserNameToPublicUserIdMap(
			List<PublicUserIdUsernameMap> puuidUsernameList) {
		Map<String, String> userNameToPublicUserIdMap = new HashMap<String, String>();

		for (PublicUserIdUsernameMap map : puuidUsernameList) {
			userNameToPublicUserIdMap.put(map.getUsername(),
					map.getPublic_user_id());
		}
		return userNameToPublicUserIdMap;
	}
}
