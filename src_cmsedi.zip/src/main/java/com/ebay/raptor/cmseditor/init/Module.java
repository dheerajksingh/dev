package com.ebay.raptor.cmseditor.init;

import com.ebay.kernel.initialization.BaseInitializationManager;
import com.ebay.kernel.initialization.BaseModule;
import com.ebay.kernel.initialization.ModuleInterface;
import com.ebay.raptor.kernel.lifecycle.ModuleInitializer;

@ModuleInitializer
public final class Module extends BaseModule {
    private static Module s_Module = new Module();
 
    static class InitializationManager extends BaseInitializationManager {
 
        static final ModuleInterface [] DEPENDENT_MODULES = {
        	com.ebay.bes.common.Module.getInstance()
        };
 
        InitializationManager() {
            super(DEPENDENT_MODULES);
        }
    }
 
    private Module() {
        super(new InitializationManager());
        
    }
 
    public static ModuleInterface getInstance() {
        return s_Module;
    }
}
