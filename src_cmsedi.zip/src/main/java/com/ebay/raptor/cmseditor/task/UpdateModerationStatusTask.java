package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.StringUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.besevents.ArticleStatusChangeEvent;
import com.ebay.raptor.cmseditor.config.ConfigParam;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.ModerationActorEnum;
import com.ebay.raptor.cmseditor.request.ModerationStatusEnum;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.request.UpdateModerationStatusRequest;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.util.BESUtil;
import com.ebay.spam.akismet.AkismetComment;


public class UpdateModerationStatusTask extends CmsEditorTask {

	private ContentPublishDao contentPublishDao;
	private BESHandler besHandler;
	
	private static final String HAM="HAM";
	private static final String SPAM="SPAM";
	
	private static final Logger LOGGER = Logger
			.getInstance(UpdateModerationStatusTask.class);
	
	public UpdateModerationStatusTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentPublishDao contentPublishDao){
		super(request, providerTasks);
		this.contentPublishDao=contentPublishDao;
		
	}
	
	public UpdateModerationStatusTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentPublishDao contentPublishDao,BESHandler besHandler){
		super(request, providerTasks);
		this.contentPublishDao=contentPublishDao;
		this.besHandler=besHandler;
		
	}

	public UpdateModerationStatusTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentPublishDao = request.getApplicationContext().getBean(
				ContentPublishDao.class);
		this.besHandler=new BESHandler();
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		if(request==null){
			return createFailureResponse();
		}
		CmsEditorTaskResponse response = new CmsEditorTaskResponse();
		UpdateModerationStatusRequest flagRequest = request.getFlagContentRequest();
		if (flagRequest == null || flagRequest.getStatus()==null) {
			return createFailureResponse();
		}

		Set<String> permissions = findPermissions();

		ModerationActorEnum actor = flagRequest.getActor();
		if (actor == null
				&& StringUtils.isEmpty(flagRequest.getActorIdentifier())) {
			return createFailureResponse();
		} else if (actor == null) {
			actor = findActorByPermissions(permissions);
		}

		boolean hasPermissions = hasPermissions(actor,
				flagRequest,request.getSelector());
		if (!hasPermissions) {
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
			return response;
		}

		List<KeyValueImpl> keyValues = null;
		PublishedContentEntity content=null;
		try{
		content = contentPublishDao
				.findContentById(flagRequest.getArticleId());
		}catch (IllegalArgumentException i) {
			LOGGER.log(LogLevel.ERROR, i);
			return createFailureResponse(CmsEditorStatus.INVALID_CONTENT_ID);
		}catch (Exception e) {
			LOGGER.log(LogLevel.ERROR, e);
			return createFailureResponse();
		}
		if(content==null){
			return createFailureResponse(CmsEditorStatus.CONTENT_NOT_FOUND);
		}
		ArticleStatusEnum previousStatus = ArticleStatusEnum.valueOf(content.getContentStatus());
		switch (actor) {

		case MODERATOR:
			keyValues = getUpdateRequestForUser(flagRequest,ModerationActorEnum.MODERATOR);
			break;
		case SYSTEM:
			keyValues = getUpdateRequestForSystem(flagRequest);
			break;
		case USER:
				keyValues = getUpdateRequestForUser(flagRequest,content);
			break;
		}
		if (CollectionUtils.isEmpty(keyValues)) {
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			return response;
		}
		try {
			int updatedCount=contentPublishDao.updateContentField(flagRequest.getArticleId(),
					keyValues);
			if(updatedCount<=0){
				return createFailureResponse(CmsEditorStatus.CONTENT_NOT_FOUND);
			}
			if(actor==ModerationActorEnum.MODERATOR){
				ArticleStatusEnum currentStatus = ArticleStatusEnum.valueOf(flagRequest.getStatus());
				AkismetComment akismetComment=flagRequest.getAkismetComment();
				akismetComment.setCommentAuthor(content.getAuthorName());
				if(currentStatus!=previousStatus){
					if(previousStatus==ArticleStatusEnum.SPAM_SUSPECTED || previousStatus==ArticleStatusEnum.SPAM_CONFIRMED){
						//DROP MARK HAM EVENT
						ArticleStatusChangeEvent event=buildStatusChangeEvent(ModerationActorEnum.MODERATOR, flagRequest.getArticleId(), flagRequest.getAkismetComment(), 
								HAM);
						besHandler.dropArticleStatusChangeEvent(event);
 					}else if(previousStatus==ArticleStatusEnum.PUBLISHED){
						//DROP MARK SPAM EVENT
						ArticleStatusChangeEvent event=buildStatusChangeEvent(ModerationActorEnum.MODERATOR, flagRequest.getArticleId(), flagRequest.getAkismetComment(), 
								SPAM);
						besHandler.dropArticleStatusChangeEvent(event);
						if(ArticleStatusEnum.SPAM_CONFIRMED.equals(currentStatus)) {
							softDeleteArticle(flagRequest.getArticleId());
						}
					}
				}
			}
		} catch (Exception e) {
			return createFailureResponse();
		}
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

	private void softDeleteArticle(String articleId) {
		KeyValueImpl kv = new KeyValueImpl();
		kv.setKey(ContentFields.isDeleted.toString());
		kv.setValue(true);
		List<KeyValue> kvs = new ArrayList<KeyValue>();
		kvs.add(kv);
		contentPublishDao.updateContentField(articleId, kvs);
	}

	private Set<String> findPermissions() {
		if(CollectionUtils.isEmpty(providerTasks)){
			return new HashSet<String>();
		}
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse) ((GetUserPermissionsTask) task)
						.getTaskResponse());
				Set<String> permissions = permissionsResponse.getPermissions();
				return permissions;
			}
		}
		return new HashSet<String>();
	}

	private ModerationActorEnum findActorByPermissions(Set<String> permissions) {
		if (CollectionUtils.isEmpty(permissions)) {
			return ModerationActorEnum.USER;
		}
		if (permissions.contains(PermissionEnum.BLACKLIST_CONTENT.name())
				|| permissions.contains(PermissionEnum.UNBLACKLIST_CONTENT
						.name())) {
			return ModerationActorEnum.MODERATOR;
		}
		return ModerationActorEnum.USER;
	}

	private boolean hasPermissions(ModerationActorEnum actor, UpdateModerationStatusRequest request,Selector selector) {
		if (actor == null) {
			return false;
		}
		if(StringUtils.isEmpty(request.getStatus())){
			return false;
		}
		ArticleStatusEnum status=ArticleStatusEnum.valueOf(request.getStatus());
		if(status!=ArticleStatusEnum.SPAM_SUSPECTED && actor==ModerationActorEnum.USER){
			return false;
		}
		if(selector==Selector.MODERATE && actor!=ModerationActorEnum.MODERATOR){
			return false;
		}

		return true;
	}


	private List<KeyValueImpl> getUpdateRequestForUser(
			UpdateModerationStatusRequest flagRequest,PublishedContentEntity content)  {
		ArticleStatusEnum status=ArticleStatusEnum.valueOf(flagRequest.getStatus());
		if(status==ArticleStatusEnum.PUBLISHED){
			return Collections.emptyList();
		}
		Set<String> usersWhoMarkedAsSpam=content.getUsersMarkedSpam();
		if(usersWhoMarkedAsSpam==null){
			usersWhoMarkedAsSpam=new HashSet<String>();
		}
		usersWhoMarkedAsSpam.add(flagRequest.getActorIdentifier());
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		
		KeyValueImpl keyValue = new KeyValueImpl();
		keyValue.setKey(ContentFields.usersMarkedSpam.name());
		keyValue.setValue(usersWhoMarkedAsSpam);
		keyValues.add(keyValue);
		
		int usersMarkedSpamCount=content.getUsersMarkedSpamCount();
		usersMarkedSpamCount++;
		
		KeyValueImpl spamCountKeyValue = new KeyValueImpl();
		spamCountKeyValue.setKey(ContentFields.usersMarkedSpamCount.name());
		spamCountKeyValue.setValue(usersMarkedSpamCount);
		keyValues.add(spamCountKeyValue);
		
		KeyValueImpl moderationStatusKeyValue = new KeyValueImpl();
		moderationStatusKeyValue.setKey(ContentFields.moderationStatus.name());
		moderationStatusKeyValue.setValue(ModerationStatusEnum.NEEDS_MODERATION.name());
		keyValues.add(moderationStatusKeyValue);
		
		
		
		if(usersMarkedSpamCount>=getThresholdCount()){
			keyValues.addAll(getUpdateRequestForNormalUser(flagRequest));
			return keyValues;
		}
		
		return keyValues;
	}
	
	
	private List<KeyValueImpl> getUpdateRequestForNormalUser(
			UpdateModerationStatusRequest flagRequest) {
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl actorKey = new KeyValueImpl();
		actorKey.setKey(ContentFields.lastModerationActor.name());
		actorKey.setValue(ModerationActorEnum.USER.name());
		keyValues.add(actorKey);
		KeyValueImpl contentStatusKey = new KeyValueImpl();
		contentStatusKey.setKey(ContentFields.contentStatus.name());
		contentStatusKey.setValue(ArticleStatusEnum.SPAM_SUSPECTED.name());
		keyValues.add(contentStatusKey);
		KeyValueImpl moderationStatusKey = new KeyValueImpl();
		moderationStatusKey.setKey(ContentFields.moderationStatus.name());
		moderationStatusKey.setValue(ModerationStatusEnum.MODERATED.name());
		keyValues.add(moderationStatusKey);
		KeyValueImpl lastModeratedUserKey = new KeyValueImpl();
		lastModeratedUserKey.setKey(ContentFields.lastModeratedUser.name());
		lastModeratedUserKey.setValue(flagRequest.getActorIdentifier());
		keyValues.add(lastModeratedUserKey);

		return keyValues;
	}

	private List<KeyValueImpl> getUpdateRequestForSystem(
			UpdateModerationStatusRequest flagRequest) {
		ArticleStatusEnum status=ArticleStatusEnum.valueOf(flagRequest.getStatus());
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl actorKey = new KeyValueImpl();
		actorKey.setKey(ContentFields.lastModerationActor.name());
		actorKey.setValue(ModerationActorEnum.SYSTEM.name());
		keyValues.add(actorKey);
		KeyValueImpl contentStatusKey = new KeyValueImpl();
		contentStatusKey.setKey(ContentFields.contentStatus.name());
		if (ArticleStatusEnum.isSpam(status)) {
			contentStatusKey.setValue(ArticleStatusEnum.SPAM_SUSPECTED.name());
		} else {
			contentStatusKey.setValue(ArticleStatusEnum.PUBLISHED.name());
		}
		keyValues.add(contentStatusKey);

		return keyValues;
	}

	private List<KeyValueImpl> getUpdateRequestForUser(
			UpdateModerationStatusRequest flagRequest,ModerationActorEnum actor) {
		ArticleStatusEnum status=ArticleStatusEnum.valueOf(flagRequest.getStatus());
		List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
		KeyValueImpl actorKey = new KeyValueImpl();
		actorKey.setKey(ContentFields.lastModerationActor.name());
		actorKey.setValue(actor.name());
		keyValues.add(actorKey);
		KeyValueImpl contentStatusKey = new KeyValueImpl();
		contentStatusKey.setKey(ContentFields.contentStatus.name());
		if (ArticleStatusEnum.isSpam(status)) {
			contentStatusKey.setValue(ArticleStatusEnum.SPAM_CONFIRMED.name());
		} else {
			contentStatusKey.setValue(ArticleStatusEnum.PUBLISHED.name());
			//RESET USERS WHO MARKED AS SPAM COUNT TO 0
			KeyValueImpl spamCountKeyValue = new KeyValueImpl();
			spamCountKeyValue.setKey(ContentFields.usersMarkedSpamCount.name());
			spamCountKeyValue.setValue(0);
			keyValues.add(spamCountKeyValue);
		}
		keyValues.add(contentStatusKey);
		KeyValueImpl moderationStatusKey = new KeyValueImpl();
		moderationStatusKey.setKey(ContentFields.moderationStatus.name());
		moderationStatusKey.setValue(ModerationStatusEnum.MODERATED.name());
		keyValues.add(moderationStatusKey);
		KeyValueImpl lastModeratedUserKey = new KeyValueImpl();
		lastModeratedUserKey.setKey(ContentFields.lastModeratedUser.name());
		lastModeratedUserKey.setValue(flagRequest.getActorIdentifier());
		keyValues.add(lastModeratedUserKey);

		return keyValues;
	}

	protected CmsEditorTaskResponse createFailureResponse(CmsEditorStatus error) {
		CmsEditorTaskResponse response = new CmsEditorTaskResponse();
		response.setError(error);
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		return response;
	}
	
	private int getThresholdCount(){
		int thresholdCount = ConfigParam.USER_MARKED_AS_SPAM_THRESHOLD.getIntValue();
		return thresholdCount;
	}
	
	private ArticleStatusChangeEvent buildStatusChangeEvent(ModerationActorEnum actor,String contentId,AkismetComment akismetComment,String status){
		
		ArticleStatusChangeEvent event = new ArticleStatusChangeEvent();
		event.setArticleId(contentId);
		event.setActor(actor.name());
		event.setStatus(status);
		event.setCommentAuthor(akismetComment.getCommentAuthor());
		event.setCommentType(akismetComment.getCommentType());
		event.setReferrer(akismetComment.getReferrer());
		event.setUserAgent(akismetComment.getReferrer());
		event.setUserIp(akismetComment.getUserIp());
		
		return event;
	}
	
	static class BESHandler{
		
		public void dropArticleStatusChangeEvent(ArticleStatusChangeEvent event){
			BESUtil.dropArticleStatusChangeEvent(event);
		}
		
		
	}
}
