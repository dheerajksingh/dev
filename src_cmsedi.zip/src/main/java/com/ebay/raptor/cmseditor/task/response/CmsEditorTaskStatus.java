package com.ebay.raptor.cmseditor.task.response;

public enum CmsEditorTaskStatus {
	
	SUCCESS,FAILURE,WARNING

}
