package com.ebay.raptor.cmseditor.task.response;

public class GetPublicUserIdByIdTaskResponse extends CmsEditorTaskResponse{
	
	private String publicUserId;

	public String getPublicUserId() {
		return publicUserId;
	}

	public void setPublicUserId(String publicUserId) {
		this.publicUserId = publicUserId;
	}
	
}
