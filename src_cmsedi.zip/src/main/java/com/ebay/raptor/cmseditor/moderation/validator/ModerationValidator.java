package com.ebay.raptor.cmseditor.moderation.validator;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.manager.CmsEditorManager;
import com.ebay.raptor.cmseditor.request.AkismetCommentBuilder;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ModerationActorEnum;
import com.ebay.raptor.cmseditor.request.Selector;
import com.ebay.raptor.cmseditor.request.UpdateModerationStatusRequest;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.util.UserInfoUtil;

@Component
public class ModerationValidator {
	
	@Inject UserInfoUtil userInfo;
	@Inject AkismetCommentBuilder akismetCommentBuilder;
	@Autowired ApplicationContext applicationContext;
	
	private static final Logger LOGGER = Logger.getInstance(ModerationValidator.class);
	
	public ModerationValidator(){
		
	}
	
	
	public ModerationValidator(UserInfoUtil userInfo,AkismetCommentBuilder akismetCommentBuilder,ApplicationContext applicationContext){
		this.userInfo=userInfo;
		this.akismetCommentBuilder=akismetCommentBuilder;
		this.applicationContext=applicationContext;
	}
	
	
	public CmsEditorResponse handleUpdateModerationStatus(
			UpdateModerationStatusRequest updateRequest,String articleId,Selector selector,HttpServletRequest httpRequest,CmsEditorManager manager)
			throws CmsEditorException {
		updateRequest.setArticleId(articleId);
		CmsEditorRequest request = new CmsEditorRequest();
		if(StringUtils.isEmpty(updateRequest.getStatus())){
			throw new CmsEditorException(CmsEditorStatus.MISSING_STATUS);
		}
		validateArticleStatusForModerator(updateRequest);
		long userId=userInfo.getSignedInUserId();
		if(userId<=0){
			throw new CmsEditorException(CmsEditorStatus.USER_ACCESS_ERROR);
		}
		else{
			request.setUserId(userId);
			updateRequest.setActorIdentifier(String.valueOf(userId));
		}
		request.setApplicationContext(applicationContext);
		request.setSelector(selector);
		updateRequest.setAkismetComment(akismetCommentBuilder.buildAkismetComment(httpRequest));
		request.setFlagContentRequest(updateRequest);
		CmsEditorResponse response=manager.manage(request);
		return response;
	}
	
	private void validateArticleStatusForModerator(UpdateModerationStatusRequest updateRequest) throws CmsEditorException{
		try{
			ArticleStatusEnum status = ArticleStatusEnum.valueOf(updateRequest.getStatus());
			if(status!=ArticleStatusEnum.PUBLISHED && status!=ArticleStatusEnum.SPAM_CONFIRMED){
				throw new CmsEditorException(CmsEditorStatus.USER_ACCESS_ERROR);
			}
		}catch(IllegalArgumentException i){
			LOGGER.log(LogLevel.ERROR,i);
			throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
		}
	}
	
	private void validateArticleStatusForUser(UpdateModerationStatusRequest updateRequest) throws CmsEditorException{
		try{
			ArticleStatusEnum status = ArticleStatusEnum.valueOf(updateRequest.getStatus());
			if(status!=ArticleStatusEnum.SPAM_SUSPECTED){
				throw new CmsEditorException(CmsEditorStatus.USER_ACCESS_ERROR);
			}
		}catch(IllegalArgumentException i){
			LOGGER.log(LogLevel.ERROR,i);
			throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
		}
	}
	
	private void validateArticleStatusForSystem(UpdateModerationStatusRequest updateRequest) throws CmsEditorException{
		try{
			ArticleStatusEnum status = ArticleStatusEnum.valueOf(updateRequest.getStatus());
			if(status!=ArticleStatusEnum.PUBLISHED && status!=ArticleStatusEnum.SPAM_SUSPECTED){
				throw new CmsEditorException(CmsEditorStatus.USER_ACCESS_ERROR);
			}
		}catch(IllegalArgumentException i){
			LOGGER.log(LogLevel.ERROR,i);
			throw new CmsEditorException(CmsEditorStatus.INVALID_STATUS);
		}
	}
	
	public CmsEditorResponse handleUpdateModerationStatusForUser(
			UpdateModerationStatusRequest updateRequest,String articleId,Selector selector,HttpServletRequest httpRequest,CmsEditorManager manager)
			throws CmsEditorException {
		updateRequest.setArticleId(articleId);
		CmsEditorRequest request = new CmsEditorRequest();
		if(StringUtils.isEmpty(updateRequest.getStatus())){
			throw new CmsEditorException(CmsEditorStatus.MISSING_STATUS);
		}
		validateArticleStatusForUser(updateRequest);
		long userId=userInfo.getSignedInUserId();
		if(userId<=0){
			throw new CmsEditorException(CmsEditorStatus.USER_NOT_SIGNED_IN_ERROR);
		}
		else{
			request.setUserId(userId);
			updateRequest.setActorIdentifier(String.valueOf(userId));
		}
		request.setApplicationContext(applicationContext);
		request.setSelector(selector);
		updateRequest.setAkismetComment(akismetCommentBuilder.buildAkismetComment(httpRequest));
		request.setFlagContentRequest(updateRequest);
		CmsEditorResponse response=manager.manage(request);
		return response;
	}
	
	public CmsEditorResponse handleUpdateModerationStatusForSystem(
			UpdateModerationStatusRequest updateRequest,String articleId,Selector selector,HttpServletRequest httpRequest,CmsEditorManager manager)
			throws CmsEditorException {
		updateRequest.setArticleId(articleId);
		CmsEditorRequest request = new CmsEditorRequest();
		if(StringUtils.isEmpty(updateRequest.getStatus())){
			throw new CmsEditorException(CmsEditorStatus.MISSING_STATUS);
		}
		validateArticleStatusForSystem(updateRequest);
		if(!userInfo.isAuthorizedApplication()){
			throw new CmsEditorException(CmsEditorStatus.USER_ACCESS_ERROR);
		}else if(userInfo.isAuthorizedApplication()){
			updateRequest.setActor(ModerationActorEnum.SYSTEM);
		}
		request.setApplicationContext(applicationContext);
		request.setSelector(selector);
		updateRequest.setAkismetComment(akismetCommentBuilder.buildAkismetComment(httpRequest));
		request.setFlagContentRequest(updateRequest);
		CmsEditorResponse response=manager.manage(request);
		return response;
	}

}
