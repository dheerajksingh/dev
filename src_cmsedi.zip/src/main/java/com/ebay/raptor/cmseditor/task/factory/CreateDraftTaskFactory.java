package com.ebay.raptor.cmseditor.task.factory;

import java.util.ArrayList;
import java.util.List;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.task.CreateDraftTask;
import com.ebay.raptor.cmseditor.task.GetPublicUserIdByIdTask;
import com.ebay.raptor.cmseditor.task.GetUserNameByIdTask;
import com.ebay.raptor.cmseditor.task.ICmsEditorTask;

public class CreateDraftTaskFactory implements ICmsEditorTaskFactory{
	
private List<ICmsEditorTask> tasks = new ArrayList<>();
	
	public  CreateDraftTaskFactory(CmsEditorRequest request) {
		
		GetUserNameByIdTask userNameByIdTask = new GetUserNameByIdTask(request, new ArrayList<ICmsEditorTask>());
		tasks.add(userNameByIdTask);
		
		GetPublicUserIdByIdTask publicUserIdByIdTask = new GetPublicUserIdByIdTask(request, new ArrayList<ICmsEditorTask>());
		tasks.add(publicUserIdByIdTask);
		
		List<ICmsEditorTask> providerTasks = new ArrayList<ICmsEditorTask>();
		providerTasks.add(userNameByIdTask);
		providerTasks.add(publicUserIdByIdTask);
		
		CreateDraftTask createContentTask = new CreateDraftTask(request, providerTasks);
		tasks.add(createContentTask);
	}

	@Override
	public List<ICmsEditorTask> getTasks() {
		return tasks;
	}

}
