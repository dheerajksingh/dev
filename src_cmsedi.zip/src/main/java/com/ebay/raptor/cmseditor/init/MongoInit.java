package com.ebay.raptor.cmseditor.init;


import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.mongodb.morphia.AdvancedDatastore;
import org.mongodb.morphia.DatastoreImpl;
import org.mongodb.morphia.Morphia;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ebay.raptor.cmseditor.config.ConfigParam;
import com.ebay.resource.mddf.MDDFInitializer;
import com.ebayinc.platform.config.impl.mongo.MongoModuleInitializer;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;

@Configuration
public class MongoInit {
	
	private String PACKAGE = "com.ebay.raptor.cmseditor.entities";

	@Bean
	public AdvancedDatastore getDataStore() throws UnknownHostException {
		MDDFInitializer.initialize(Thread.currentThread().getContextClassLoader(), false);
		new MongoModuleInitializer().init();
		
		MongoClient client = new MongoClient(getServerAddress(), genCredential());
		client.setReadPreference(ReadPreference.secondaryPreferred());
		//MongoClient client = new MongoClient();
		
		AdvancedDatastore ds = new DatastoreImpl(new Morphia().mapPackage(PACKAGE), client, ConfigParam.MONGO_FOUNTAIN_DB_NAME.getStringValue());
		ds.setDefaultWriteConcern(WriteConcern.ACKNOWLEDGED);
		ds.ensureCaps(); //creates capped collections
		
		return ds;
	}
	
	 private List<MongoCredential> genCredential() {
		 List<MongoCredential> cred = new ArrayList<MongoCredential>();
		 //TODO: Get credentials from ESAMS
		 MongoCredential credential = MongoCredential.createScramSha1Credential(ConfigParam.MONGO_USERNAME.getStringValue(), ConfigParam.MONGO_FOUNTAIN_DB_NAME.getStringValue(), ConfigParam.MONGO_PASSWORD.getStringValue().toCharArray()) ;
		 cred.add(credential);
		 return cred;
	 }
	 
	 public List<ServerAddress> getServerAddress() throws UnknownHostException {
		List<ServerAddress> serverAddressesList = new ArrayList<ServerAddress>();
		String serverAddresses = ConfigParam.MONGO_FOUNTAIN_SERVER_ADDRESS.getStringValue().substring(10); // To remove the mongodb:// part from the address string
		String[] serverAddressesArray = serverAddresses.split(",");
		for(String serverAddress:serverAddressesArray) {
			String host = serverAddress.split(":")[0];
			int port = Integer.valueOf(serverAddress.split(":")[1]);
			serverAddressesList.add(new ServerAddress(host, port));
		}
		return serverAddressesList;
	 }
}
