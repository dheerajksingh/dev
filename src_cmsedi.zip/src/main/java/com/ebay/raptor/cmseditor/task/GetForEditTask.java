package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.PublishedContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.GetForEditRequest;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.ContentReadTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;

/**
 * Fetches a draft for a content
 * SELECTOR: GET_FOR_EDIT
 * @author kravikumar
 *
 */
public class GetForEditTask extends CmsEditorTask{
	
	private ContentDraftDao contentDraftDao;
	private ContentPublishDao contentPublishDao;
	
	private static final Logger LOGGER = Logger.getInstance(GetForEditTask.class);

	public GetForEditTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
		contentPublishDao=request.getApplicationContext().getBean(ContentPublishDao.class);
	}

	public GetForEditTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao,ContentPublishDao contentPublishDao) {
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
		this.contentPublishDao=contentPublishDao;
	}
	
	@Override
	protected CmsEditorTaskResponse createResponse() {
		GetForEditRequest editRequest = request.getGetForEditRequest();
		if(editRequest==null || StringUtils.isEmpty(editRequest.getContentId())){
			return createFailureResponse();
		}
		Long userId=request.getUserId();
		ContentReadTaskResponse response= new ContentReadTaskResponse();
		Set<String> permissions = findPermissions();
		boolean isAdmin = !CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name());
			PublishedContentEntity content=null;
			try {
				content = contentPublishDao.findContentById(editRequest.getContentId());
			} catch (Exception e) {
				LOGGER.log(LogLevel.ERROR,e);
				return createFailureResponse();
			}
			if(content==null){
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
				return response;
			}
			boolean hasAccess=false;
			if(!CollectionUtils.isEmpty(content.getAccessControlList()) && content.getAccessControlList().contains(userId.toString())){
				hasAccess=true;
			}
			if(!isAdmin && !hasAccess){
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
				return response;
			}
			DraftContentEntity latestDraft = contentDraftDao.findLatestDraftById(content.getContentId());
			if(latestDraft == null || latestDraft.isDeleted()){
				return handleNoDraftScenario(editRequest, latestDraft, response, content);
			}
			return getDraftResponse(latestDraft, response);
	}

	private CmsEditorTaskResponse handleNoDraftScenario(
			GetForEditRequest editRequest, DraftContentEntity latestDraft, ContentReadTaskResponse response,
			PublishedContentEntity content) {
		try{
			DraftContentEntity draft = new DraftContentEntity(content);
			draft.setContentId(content.getContentId());
			draft.setVersion(latestDraft == null ? 0 : latestDraft.getVersion() + 1);
			String contentId=contentDraftDao.createContent(draft);
			//update draft id on published content
			List<KeyValueImpl> keyValues = new ArrayList<KeyValueImpl>();
			KeyValueImpl keyValue = new KeyValueImpl();
			keyValue.setKey(ContentFields.draftId.getFieldName());
			keyValue.setValue(contentId);
			keyValues.add(keyValue);
			contentPublishDao.updateContentField(editRequest.getContentId(), keyValues);
			content.setDraftId(contentId);
			content.setContentStatus(ArticleStatusEnum.DRAFT.name());
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setContent(draft);
			return response;
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
	}

	private CmsEditorTaskResponse getDraftResponse(
			ContentEntity content, ContentReadTaskResponse response) {
		if(content==null){
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
			return response;
		}
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		content.setContentStatus(ArticleStatusEnum.DRAFT.name());
		response.setContent(content);
		return response;
	}
	
	private Set<String> findPermissions() {
		for (ICmsEditorTask task : providerTasks) {
			if (task instanceof GetUserPermissionsTask) {
				GetUserPermissionsTaskResponse permissionsResponse = ((GetUserPermissionsTaskResponse) ((GetUserPermissionsTask) task)
						.getTaskResponse());
				Set<String> permissions = permissionsResponse.getPermissions();
				return permissions;
			}
		}
		return new HashSet<String>();
	}
}
