package com.ebay.raptor.cmseditor.util;

import com.ebay.bes.common.util.BusinessEventUtil;
import com.ebay.raptor.besevents.ArticleDeleteEvent;
import com.ebay.raptor.besevents.ArticleEvent;
import com.ebay.raptor.besevents.ArticlePublishEvent;
import com.ebay.raptor.besevents.ArticleStatusChangeEvent;

public class BESUtil {

	private static final String LOGICAL_HOST = "useractivity%shost";
	
	public static void dropArticlePublishEvent(ArticlePublishEvent articlePublishEvent) {
		CALUtil.logCALEvent("BES-DROP", articlePublishEvent.getEventType(), articlePublishEvent.toString());
		publishAndLogEvents(articlePublishEvent);
	}
	
	public static void dropArticleDeleteEvent(String articleId) {
		ArticleDeleteEvent articleDeleteEvent = new ArticleDeleteEvent();
		articleDeleteEvent.setArticleId(articleId);
		CALUtil.logCALEvent("BES-DROP", articleDeleteEvent.getEventType(), articleDeleteEvent.toString());
		publishAndLogEvents(articleDeleteEvent);
	}
	
	public static void dropArticleStatusChangeEvent(ArticleStatusChangeEvent articleStatusChangeEvent) {
		CALUtil.logCALEvent("BES-DROP", articleStatusChangeEvent.getEventType(), articleStatusChangeEvent.toString());
		publishAndLogEvents(articleStatusChangeEvent);
	}
	
	private static void publishAndLogEvents(ArticleEvent event) {
		boolean status = BusinessEventUtil.publishBusinessEvent(event, getEventHost(event.getArticleId()));		
		if (!status) {
			String msg = " Exception in dropping article event:" + event;
			CALUtil.logFailedCALEvent("BES-DROP", "publishAndLogEvents", msg);
		}
	}

	private static String getEventHost(String articleId) {
		if(articleId == null) {
			return null;
		}
		int host = Math.abs(articleId.hashCode() % 10);
		return String.format(LOGICAL_HOST, host);
	}
}
