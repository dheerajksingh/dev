package com.ebay.raptor.cmseditor.task.factory;

import java.util.List;

import com.ebay.raptor.cmseditor.task.ICmsEditorTask;

public interface ICmsEditorTaskFactory {
	
	public List<ICmsEditorTask> getTasks();

}
