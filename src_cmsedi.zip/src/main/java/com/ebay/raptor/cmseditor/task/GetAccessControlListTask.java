package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.response.content.model.Article;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;

public class GetAccessControlListTask extends CmsEditorTask{

	private ContentDraftDao contentDraftDao;
	private ContentPublishDao contentPublishDao;
	private ArticleStatusEnum mode;

	public GetAccessControlListTask(CmsEditorRequest request, 
			ArticleStatusEnum contentStatusEnum, List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		this.mode = contentStatusEnum; 
		this.contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
		this.contentPublishDao = request.getApplicationContext().getBean(ContentPublishDao.class);
	}
	
	public GetAccessControlListTask(CmsEditorRequest request, 
			ArticleStatusEnum contentStatusEnum, List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao,ContentPublishDao contentPublishDao) {
		super(request, providerTasks);
		this.mode = contentStatusEnum; 
		this.contentDraftDao = contentDraftDao;
		this.contentPublishDao = contentPublishDao;
	}
	

	@Override
	protected CmsEditorTaskResponse createResponse() {
		
		List<String> contentIds = new ArrayList<String>();
		
		if(request.getContentPublishRequest() != null) {
			contentIds.add(request.getContentPublishRequest().getDraftContentId());
		} else if (request.getContentUpdateFieldRequest() != null) {
			contentIds.add(request.getContentUpdateFieldRequest().getArticleId());
		} else if (request.getContentUpdateRequest() != null) {
			contentIds.add(request.getContentUpdateRequest().getContentId());
		} else if (request.getDeleteSectionRequest() != null) {
			contentIds.add(request.getDeleteSectionRequest().getContentId());
		} else if (request.getUpdateGroupRequest() != null) {
			contentIds.add(request.getUpdateGroupRequest().getArticleId());
		} else if (request.getDeleteGroupRequest() != null) {
			contentIds.add(request.getDeleteGroupRequest().getContentId());
		} else if (request.getUpdateSectionRequest() != null) {
			contentIds.add(request.getUpdateSectionRequest().getArticleId());
		} else if (request.getDeleteSectionRequest() != null) {
			contentIds.add(request.getDeleteSectionRequest().getContentId());
		} else if (request.getCreateBulkContentRequest() != null && request.getCreateBulkContentRequest().getArticles() != null) {
			for(Article content:request.getCreateBulkContentRequest().getArticles()) {
				if(content.getArticleId() != null) {
					contentIds.add(content.getArticleId());
				}
			}
		}
		
		Map<String, ContentEntity> contentEntityMap = null;
		GetAccessControlListTaskResponse response = new GetAccessControlListTaskResponse();
		if(!CollectionUtils.isEmpty(contentIds)){
			try{
				if (this.mode.equals(ArticleStatusEnum.SUBMITTED)) {
					contentEntityMap = contentPublishDao.findContentAccessControlListByContentIds(contentIds);
					
				} else {
					contentEntityMap = contentDraftDao.findContentAccessControlListByContentIds(contentIds);
				}
			}catch(IllegalArgumentException i){
				response.setError(CmsEditorStatus.INVALID_CONTENT_ID);
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				return response;
			}
		}
		
		if(contentEntityMap==null || contentEntityMap.size()==0){
			response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			return response;
		}
		
		response.setContentEntityMap(contentEntityMap);
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

}
