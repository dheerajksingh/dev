package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.KeyValue;
import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.ContentFields;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.BulkContentDeleteRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.task.response.BulkContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.BulkDeleteContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.util.CALUtil;

/**
 * Bulk soft delete content
 *
 */
public class BulkSoftDeleteContentTask extends CmsEditorTask {
	
	//TODO: Check if this is the right place to have these strings
	private String PERMISSION_ADMIN_DELETE_CONTENT = "ADMIN_DELETE_CONTENT";

	public BulkSoftDeleteContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		
		try {
			
			// 1.) Check if user has admin permissions & can delete a content
			boolean hasAdminDeleteRights = false;
			boolean hasUpdatePermissions = false;
			for(ICmsEditorTask task: providerTasks) {
				if(task instanceof GetUserPermissionsTask) {
					GetUserPermissionsTaskResponse response = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
					Set<String> permissions = response.getPermissions();
					hasAdminDeleteRights = (permissions != null && permissions.contains(PermissionEnum.DELETE_OTHER_CONTENT.name()));
					break;
				}
			}
			
			// 2.) If the user has permissions or owns the content then delete the draft or published content
			BulkContentDeleteRequest contentDeleteRequest = request.getBulkContentDeleteRequest();
			List<String> contentIds = contentDeleteRequest.getContentIds();
			List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
			for(String contentId:contentIds){
				BulkAdaptorResponse response = new BulkAdaptorResponse();
				response.setContentId(contentId);
				response.setStatus(CmsEditorStatus.BULK_DELETE_SUCCESS);
				responses.add(response);
			}
			ArticleStatusEnum status = contentDeleteRequest.getStatus();

			ContentDraftDao contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
			ContentPublishDao contentPublishDao = request.getApplicationContext().getBean(ContentPublishDao.class);
			BulkContentTaskResponse response = new BulkContentTaskResponse();

			//2b.) If user does not have admin rights check if its his own content
			if (!hasAdminDeleteRights) {
				Map<String, List<String>> accessControlListsMap = null;
				if (ArticleStatusEnum.isPublishedContent(status)) {
					accessControlListsMap = getAccessControlListMap(contentPublishDao.findContentAccessControlListByContentIds(contentIds));
				}  else {
					accessControlListsMap = getAccessControlListMap(contentDraftDao.findContentAccessControlListByContentIds(contentIds));
				}
				if(accessControlListsMap==null || accessControlListsMap.size()==0){
					return createFailureResponse(CmsEditorStatus.CONTENT_NOT_FOUND);
				}
				for (Map.Entry<String, List<String>> entry:accessControlListsMap.entrySet()) {
					if(CollectionUtils.isEmpty(entry.getValue())) {
						response.setError(CmsEditorStatus.CONTENT_NOT_FOUND);
						response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
						return response;
					}
					hasUpdatePermissions = entry.getValue().contains(String.valueOf(request.getUserId()));
					if (!hasUpdatePermissions) {
						break;
					}
				}
			}

			KeyValueImpl kv = new KeyValueImpl();
			kv.setKey(ContentFields.isDeleted.toString());
			kv.setValue(true);
			List<KeyValue> keyValues = new ArrayList<KeyValue>();
			keyValues.add(kv);
			//3.) If the user has permissions delete the content
			if (hasAdminDeleteRights || hasUpdatePermissions) {
				if(ArticleStatusEnum.isPublishedContent(status)) {
					contentPublishDao.updateContentFieldForContentIdsInResponses(responses, keyValues);
				} else {
					contentDraftDao.updateContentFieldForContentIdsInResponses(responses, keyValues);
				}
				response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
				response.setResponses(responses);
				return response;
			} else {
				return createFailureResponse(CmsEditorStatus.USER_ACCESS_ERROR);
			}
		
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.DELETE_CONTENT_TASK_EXCEPTION, "createResponse", ExceptionUtils.getFullStackTrace(e));
			return createFailureResponse();
		}
	}
	
	private Map<String, List<String>> getAccessControlListMap(
			Map<String, ContentEntity> contentEntityMap) {
		Map<String, List<String>> accessControlListMap = new HashMap<String, List<String>>();
		
		for(ContentEntity content: contentEntityMap.values()) {
			accessControlListMap.put(content.getContentId().toString(), content.getAccessControlList());
		}
		
		return accessControlListMap;
	}

	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		BulkDeleteContentTaskResponse response = new BulkDeleteContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
	
	protected CmsEditorTaskResponse createFailureResponse(CmsEditorStatus status) {
		BulkDeleteContentTaskResponse response = new BulkDeleteContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(status);
		return response;
	}
}
