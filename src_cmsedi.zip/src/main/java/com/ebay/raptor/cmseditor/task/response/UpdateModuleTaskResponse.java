package com.ebay.raptor.cmseditor.task.response;

public class UpdateModuleTaskResponse extends CmsEditorTaskResponse{
	
}
