package com.ebay.raptor.cmseditor.task.response;

public class BulkDeleteContentTaskResponse extends BulkContentTaskResponse{

}
