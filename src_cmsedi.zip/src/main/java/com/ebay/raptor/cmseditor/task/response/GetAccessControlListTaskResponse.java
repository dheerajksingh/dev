package com.ebay.raptor.cmseditor.task.response;

import java.util.Map;

import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;

public class GetAccessControlListTaskResponse extends CmsEditorTaskResponse {
	
	private Map<String, ContentEntity> contentEntityMap;

	public Map<String, ContentEntity> getContentEntityMap() {
		return contentEntityMap;
	}

	public void setContentEntityMap(Map<String, ContentEntity> contentEntityMap) {
		this.contentEntityMap = contentEntityMap;
	}

}
