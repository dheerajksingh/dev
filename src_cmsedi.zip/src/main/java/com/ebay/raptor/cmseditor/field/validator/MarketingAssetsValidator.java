package com.ebay.raptor.cmseditor.field.validator;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ebay.cos.type.v3.base.LanguageEnum;
import com.ebay.cos.type.v3.base.Text;
import com.ebay.raptor.cmseditor.dao.entities.MarketingAssetsEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

public class MarketingAssetsValidator implements IFieldValidator{

	@SuppressWarnings("unchecked")
	@Override
	public void validate(KeyValueImpl keyValue) throws CmsEditorException {
		
		if(StringUtils.isEmpty(keyValue.getKey())){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		
		if(!AllowedFields.getAllowedFields().contains(keyValue.getKey())){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		
		try{
			MarketingAssetsEntity assets = new MarketingAssetsEntity();
			LinkedHashMap<Object, Object> value = (LinkedHashMap<Object, Object>) keyValue.getValue();
			LinkedHashMap<Object, Object> assetsMap = (LinkedHashMap<Object, Object>) value.get("assets");
			Map<String, String> map = new HashMap<String, String>();
			for(Map.Entry<Object, Object> inputMap:assetsMap.entrySet()){
				String imgURL="";
				if(inputMap.getValue()!=null){
					LinkedHashMap<Object, Object> marketingAssetsMap = (LinkedHashMap<Object, Object>) inputMap.getValue();
					if(marketingAssetsMap.get("imageURL")!=null && !StringUtils.isEmpty((String)marketingAssetsMap.get("imageURL"))) {
						imgURL=(String)marketingAssetsMap.get("imageURL");
					}
				}
				map.put((String)inputMap.getKey(), imgURL);
			}
			assets.setMarketingAssetImages(map);
			LinkedHashMap<Object, Object> marketingContentMap = (LinkedHashMap<Object, Object>) value.get("marketingContent");
			if(marketingContentMap!=null && !StringUtils.isEmpty((String)marketingContentMap.get("content"))) {
				Text marketingContent = new Text();
				marketingContent.setContent((String)marketingContentMap.get("content"));
				if(marketingContentMap.get("language") != null && !StringUtils.isEmpty((String)marketingContentMap.get("language"))) {
					marketingContent.setLanguage(LanguageEnum.valueOf((String)marketingContentMap.get("language")));
				}
				assets.setMarketingContent(marketingContent);
			}			
			keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
			keyValue.setValue(assets);
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
	}

}
