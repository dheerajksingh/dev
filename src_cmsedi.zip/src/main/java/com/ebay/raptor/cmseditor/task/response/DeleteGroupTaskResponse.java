package com.ebay.raptor.cmseditor.task.response;

public class DeleteGroupTaskResponse extends CmsEditorTaskResponse{
	
}
