package com.ebay.raptor.cmseditor.manager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.composer.ComposerFactory;
import com.ebay.raptor.cmseditor.response.composer.IResponseComposer;
import com.ebay.raptor.cmseditor.task.ICmsEditorTask;
import com.ebay.raptor.cmseditor.task.factory.CmsEditorTaskFactory;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.orchestration.ITaskOrchestrator;
import com.ebay.raptor.orchestration.ITaskResult;
import com.ebay.raptor.orchestration.TaskConfiguration;
import com.ebay.raptor.orchestration.TaskExecutionException;
import com.ebay.raptor.orchestration.TaskOrchestratorFactory;

public class CmsEditorManager implements ICmsEditorManager {

	private static final Logger LOGGER = Logger
			.getInstance(CmsEditorManager.class);
	
	OrchestratorFactory orchestratorFactory;
	ComposerFactory composerFactory;
	
	public CmsEditorManager(){
		composerFactory=new ComposerFactory();
		orchestratorFactory=new OrchestratorFactory();
	}
	
	public CmsEditorManager(OrchestratorFactory orchestratorFactory){
		this.orchestratorFactory=orchestratorFactory;
		composerFactory=new ComposerFactory();
	}

	@Override
	public CmsEditorResponse manage(CmsEditorRequest request) throws CmsEditorException{
		if (null == request)
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		List<ICmsEditorTask> tasks = CmsEditorTaskFactory.getTasks(request);
		if (CollectionUtils.isEmpty(tasks)) {
			return new CmsEditorResponse();
		}

		ITaskOrchestrator orchestrator = orchestratorFactory.create();

		Set<ICmsEditorTask> submittedTasks = new HashSet<>();
		List<CmsEditorTaskResponse> taskResponses = null;
		try {
			// First schedule the provider tasks (the tasks which other tasks
			// depend on)
			List<ITaskResult<Object>> results = submitProviderTasks(tasks,
					orchestrator, submittedTasks);
			// Now schedule the dependent tasks.Always submit provider tasks
			// before dependent tasks to be safe.
			results.addAll(submitDependentTasks(tasks, orchestrator,
					submittedTasks));
			taskResponses = new ArrayList<>();
			for (ITaskResult<Object> taskResult : results) {

				taskResponses.add((CmsEditorTaskResponse) taskResult
						.getResult());
			}
		} catch (TaskExecutionException t) {
			LOGGER.log(LogLevel.ERROR, t);
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
		return aggregateResponse(taskResponses, request);
	}

	/**
	 * Method to submit dependent tasks for execution
	 * 
	 * @param tasks
	 * @param orchestrator
	 * @param submittedTasks
	 * @return
	 * @throws TaskExecutionException
	 */
	private List<ITaskResult<Object>> submitDependentTasks(
			List<ICmsEditorTask> tasks, ITaskOrchestrator orchestrator,
			Set<ICmsEditorTask> submittedTasks) throws TaskExecutionException {
		List<ITaskResult<Object>> results = new ArrayList<>();
		for (ICmsEditorTask task : tasks) {
			ITaskResult<Object> result = null;
			if (submittedTasks.contains(task))
				continue;
			submittedTasks.add(task);
			List<ICmsEditorTask> providerTasks = task.getProviderTasks();
			TaskConfiguration config = TaskConfiguration.create();
			for (ICmsEditorTask providerTask : providerTasks) {
				config.addDependency(providerTask);
			}
			result = orchestrator.execute(task, config);
			if (null != result) {
				results.add(result);
			}
		}
		return results;
	}

	/**
	 * Method to submit provider tasks for execution
	 * 
	 * @param tasks
	 * @param orchestrator
	 * @param submittedTasks
	 * @return
	 * @throws TaskExecutionException
	 */
	private List<ITaskResult<Object>> submitProviderTasks(
			List<ICmsEditorTask> tasks, ITaskOrchestrator orchestrator,
			Set<ICmsEditorTask> submittedTasks) throws TaskExecutionException {
		List<ITaskResult<Object>> results = new ArrayList<>();
		for (ICmsEditorTask task : tasks) {
			List<ICmsEditorTask> providerTasks = task.getProviderTasks();
			if (!CollectionUtils.isEmpty(providerTasks)) {
				for (ICmsEditorTask providerTask : providerTasks) {
					if (!submittedTasks.contains(providerTask)
							&& CollectionUtils.isEmpty(providerTask
									.getProviderTasks())) {
						submittedTasks.add(providerTask);
						results.add(orchestrator.execute(providerTask,
								TaskConfiguration.create()));
					}
				}
			}
		}
		return results;
	}

	/**
	 * @param taskResponses
	 * @param selector
	 * @return
	 */
	private CmsEditorResponse aggregateResponse(
			List<CmsEditorTaskResponse> taskResponses, CmsEditorRequest request) throws CmsEditorException{

		IResponseComposer composer = composerFactory.getComposer(taskResponses, request);
		if(composer!=null){
			return composer.compose();
		}
		return new CmsEditorResponse();
	}
	

	static class OrchestratorFactory{
		
		public ITaskOrchestrator create(){
			return TaskOrchestratorFactory.create();
		}
	}
}
