package com.ebay.raptor.cmseditor.exception;

public class IllegalContentIdException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public IllegalContentIdException(String message,Throwable cause){
		super(message,cause);
	}

}
