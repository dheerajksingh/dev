package com.ebay.raptor.cmseditor.field.validator;

import java.util.LinkedHashMap;

import org.apache.commons.lang.StringUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

public class CosTextFieldValidator implements IFieldValidator {

	@SuppressWarnings("unchecked")
	public void validate(KeyValueImpl keyValue) throws CmsEditorException {

		if (StringUtils.isEmpty(keyValue.getKey())) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		if (!AllowedFields.getAllowedFields().contains(keyValue.getKey())) {
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		try{
		LinkedHashMap<Object, Object> value = (LinkedHashMap<Object, Object>) keyValue.getValue();
		String content="";
		if(value.get("content")!=null && !StringUtils.isEmpty((String)value.get("content"))){
			content=(String)value.get("content");
		}
		keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
		keyValue.setValue(content);
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
	}

}
