package com.ebay.raptor.cmseditor.task;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.entities.ContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.DraftContentEntity;
import com.ebay.raptor.cmseditor.dao.entities.GroupEntity;
import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.PermissionEnum;
import com.ebay.raptor.cmseditor.request.UpdateSectionRequest;
import com.ebay.raptor.cmseditor.response.adaptor.ContentEntityAdaptor;
import com.ebay.raptor.cmseditor.response.content.model.Section;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetAccessControlListTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.task.response.UpdateModuleTaskResponse;

/**
 * Updates a specific module specified by module id
 * SELECTOR: UPDATE_MODULE
 * @author kravikumar
 *
 */
public class UpdateModuleTask extends CmsEditorTask{
	
	@Inject ContentDraftDao contentDraftDao;
	
	
	private static final Logger LOGGER = Logger.getInstance(UpdateModuleTask.class);
	
	private ContentEntityAdaptor adaptor;

	public UpdateModuleTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
		contentDraftDao=request.getApplicationContext().getBean(ContentDraftDao.class);
		adaptor =new ContentEntityAdaptor();
	}
	
	public UpdateModuleTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks,ContentDraftDao contentDraftDao) {
		super(request, providerTasks);
		this.contentDraftDao=contentDraftDao;
		adaptor =new ContentEntityAdaptor();
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		List<CmsEditorTaskResponse> taskResponses = getTaskResponses();
		if(CollectionUtils.isEmpty(taskResponses)){
			return createFailureResponse();
		}
		UpdateSectionRequest req = request.getUpdateSectionRequest();
		if(req==null){
			return createFailureResponse();
		}
		boolean isAdmin=false;
		boolean hasAccess=false;
		UpdateModuleTaskResponse response = new UpdateModuleTaskResponse();
		for(CmsEditorTaskResponse taskResponse:taskResponses){
			if(taskResponse instanceof GetUserPermissionsTaskResponse){
				Set<String> permissions = ((GetUserPermissionsTaskResponse) taskResponse).getPermissions();
				if(!CollectionUtils.isEmpty(permissions) && permissions.contains(PermissionEnum.EDIT_OTHER_CONTENT.name())){
					isAdmin=true;
				}
			} else if(taskResponse instanceof GetAccessControlListTaskResponse) {
				if(taskResponse.getTaskStatus()==CmsEditorTaskStatus.FAILURE){
					response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
					response.setError(taskResponse.getError());
					return response;
				}
				Map<String, ContentEntity> contentEntityMap = ((GetAccessControlListTaskResponse) taskResponse)
						.getContentEntityMap();
				if(contentEntityMap != null && contentEntityMap.get(req.getArticleId()) != null) {
					hasAccess = contentEntityMap.get(req.getArticleId())
							.getAccessControlList()
							.contains(String.valueOf(request.getUserId()));
				}		
				
			}
		}
		if(!isAdmin && !hasAccess){
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(CmsEditorStatus.USER_ACCESS_ERROR);
			return response;
		}
		
		try{
			//Update the module in the database.
			updateModule(req.getArticleId(), req.getGroupId(), req.getSection()); 
			int updateCount= contentDraftDao.updateContentModule(req.getArticleId(), req.getGroupId(), adaptor.adaptToModuleEntity(req.getSection()));
			if(updateCount<=0){
				response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
				response.setError(CmsEditorStatus.SAVE_ERROR);
				return response;
			} else {
				return getSuccessResponse(req.getSection());
			}
		}catch(CmsEditorException c){
			LOGGER.log(LogLevel.ERROR,c);
			response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
			response.setError(c.getError());
			return response;
		}catch(Exception e){
			LOGGER.log(LogLevel.ERROR,e);
			return createFailureResponse();
		}
	}

	protected CmsEditorTaskResponse getSuccessResponse(Section section) {
		UpdateModuleTaskResponse response = new UpdateModuleTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
		return response;
	}

	/* This method sets the groupId and moduleId for new groups / modules based on the existing Ids.
	 * It takes the max of currentIds and adds 1 to generated the new Id.
	 * After generating the appropriate Ids it updates the database too.
	 */
	private void updateModule(String contentId, String groupId, Section module) throws Exception {
		//In case of new module.
		if(module.getSectionId() == null) {
			DraftContentEntity draftContent = contentDraftDao.findContentById(contentId);
			if(draftContent == null) {
				throw new CmsEditorException(CmsEditorStatus.CONTENT_NOT_FOUND);
			}
			long maxModuleId = 0l;
			boolean groupFound=false;
			if(!CollectionUtils.isEmpty(draftContent.getUserGeneratedContent().getGroups())) {
				for(GroupEntity group:draftContent.getUserGeneratedContent().getGroups()) {
					if(groupId == group.getGroupId()) {
		 				for(String moduleId:group.getModuleMap().keySet()) {
		 					maxModuleId = Math.max(maxModuleId, Long.parseLong(moduleId));
		 				}
		 				groupFound=true;
					}
				}
			}
			if(!groupFound){
				throw new CmsEditorException(CmsEditorStatus.INVALID_GROUP_ID);
			}
			module.setSectionId(String.valueOf(maxModuleId + 1));
		}
	}
}
