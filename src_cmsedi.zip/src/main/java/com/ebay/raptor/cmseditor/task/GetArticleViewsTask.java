package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.serviceclient.CrunchyServiceClient;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.GetArticleViewsTaskResponse;

public class GetArticleViewsTask extends CmsEditorTask{

	public GetArticleViewsTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		String articleId = request.getContentReadRequest().getContentId();
		List<String> articleIds = new ArrayList<String>();
		articleIds.add(articleId);
		CrunchyServiceClient client = new CrunchyServiceClient();
		Map<String, Long> articleViewsMap = client.getArticleViews(articleIds);
		GetArticleViewsTaskResponse response = new GetArticleViewsTaskResponse();
		response.setArticleViewsMap(articleViewsMap);
		return response;
	}	
}
