package com.ebay.raptor.cmseditor.response.composer;

import java.util.List;

import org.springframework.util.CollectionUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;
import com.ebay.raptor.cmseditor.response.CmsEditorResponseStatus;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.UpdateContentFieldTaskResponse;

public class UpdateContentFieldResponseComposer implements IResponseComposer{

	private List<CmsEditorTaskResponse> taskResponses;
	
	public UpdateContentFieldResponseComposer(List<CmsEditorTaskResponse> taskResponses) {
		this.taskResponses = taskResponses;
	}
	
	@Override
	public CmsEditorResponse compose()  throws CmsEditorException{
		CmsEditorResponse response = new CmsEditorResponse();
		if(CollectionUtils.isEmpty(taskResponses)){
			throw new CmsEditorException(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		}
		for(CmsEditorTaskResponse taskResponse:taskResponses) {
			if(taskResponse instanceof UpdateContentFieldTaskResponse) {
				if(taskResponse.getTaskStatus()!=null && taskResponse.getTaskStatus().equals(CmsEditorTaskStatus.SUCCESS)) {
					response.status = CmsEditorResponseStatus.SUCCESS;
				} else {
					throw new CmsEditorException(taskResponse.getError());
				}
				break;
			}
		}
		return response;
	}
}
