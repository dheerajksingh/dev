package com.ebay.raptor.cmseditor.field.validator;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.KeyValueImpl;

public class TagsFieldValidator implements IFieldValidator{

	@SuppressWarnings("unchecked")
	@Override
	public void validate(KeyValueImpl keyValue) throws CmsEditorException {
		if(StringUtils.isEmpty(keyValue.getKey())){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		
		if(keyValue.getValue()==null){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
		if(!AllowedFields.getAllowedFields().contains(keyValue.getKey())){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_PATH);
		}
		try{
			List<String> tags = (List<String>) keyValue.getValue();
			keyValue.setKey(AllowedFields.getEntityField(keyValue.getKey()));
			keyValue.setValue(tags);
		}catch(Exception e){
			throw new CmsEditorException(CmsEditorStatus.INVALID_ATTRIBUTE_VALUE);
		}
	}

}
