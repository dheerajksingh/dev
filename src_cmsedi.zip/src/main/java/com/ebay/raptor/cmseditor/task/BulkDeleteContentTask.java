package com.ebay.raptor.cmseditor.task;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;
import com.ebay.raptor.cmseditor.dao.ContentDraftDao;
import com.ebay.raptor.cmseditor.dao.ContentPublishDao;
import com.ebay.raptor.cmseditor.error.CmsEditorStatus;
import com.ebay.raptor.cmseditor.request.BulkContentDeleteRequest;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.request.ArticleStatusEnum;
import com.ebay.raptor.cmseditor.task.response.BulkContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.BulkDeleteContentTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskResponse;
import com.ebay.raptor.cmseditor.task.response.CmsEditorTaskStatus;
import com.ebay.raptor.cmseditor.task.response.GetUserPermissionsTaskResponse;
import com.ebay.raptor.cmseditor.util.CALUtil;

/**
 * Deletes content specified by Id
 * SELECTOR: DELETE_CONTENT
 * @author kravikumar
 *
 */
public class BulkDeleteContentTask extends CmsEditorTask {
	
	//TODO: Check if this is the right place to have these strings
	private String PERMISSION_ADMIN_DELETE_CONTENT = "ADMIN_DELETE_CONTENT";

	public BulkDeleteContentTask(CmsEditorRequest request,
			List<ICmsEditorTask> providerTasks) {
		super(request, providerTasks);
	}

	@Override
	protected CmsEditorTaskResponse createResponse() {
		
		try {
			
			// 1.) Check if user has admin permissions & can delete a content
			boolean hasAdminDeleteRights = false;
			for(ICmsEditorTask task: providerTasks) {
				if(task instanceof GetUserPermissionsTask) {
					GetUserPermissionsTaskResponse response = ((GetUserPermissionsTaskResponse)((GetUserPermissionsTask) task).getTaskResponse());
					Set<String> permissions = response.getPermissions();
					hasAdminDeleteRights = (permissions != null && permissions.contains(PERMISSION_ADMIN_DELETE_CONTENT));
					break;
				}
			}
			
			// 2.) If the user has permissions or owns the content then delete the draft or published content
			BulkContentDeleteRequest contentDeleteRequest = request.getBulkContentDeleteRequest();
			List<String> contentIds = contentDeleteRequest.getContentIds();
			List<BulkAdaptorResponse> responses = new ArrayList<BulkAdaptorResponse>();
			for(String contentId:contentIds){
				BulkAdaptorResponse response = new BulkAdaptorResponse();
				response.setContentId(contentId);
				response.setStatus(CmsEditorStatus.BULK_DELETE_SUCCESS);
				responses.add(response);
			}
			ArticleStatusEnum status = contentDeleteRequest.getStatus();

			ContentDraftDao contentDraftDao = request.getApplicationContext().getBean(ContentDraftDao.class);
			ContentPublishDao contentPublishDao = request.getApplicationContext().getBean(ContentPublishDao.class);
			BulkContentTaskResponse response = new BulkContentTaskResponse();
			if(hasAdminDeleteRights) {
				if(ArticleStatusEnum.isPublishedContent(status)) {
					contentPublishDao.deleteByContentIds(responses);
				}else{
				contentDraftDao.deleteByContentIds(responses);
				}
			} else {
				//TODO: Should we check for a case when a request comes from a non admin user deleting someone else's content?
				String userId = String.valueOf(request.getUserId());
				if(ArticleStatusEnum.isPublishedContent(status)) {
					contentPublishDao.deleteByContentIdsAndUserId(responses, userId);
				}else{
				contentDraftDao.deleteByContentIdsAndUserId(responses, userId);
				}
			}
			response.setTaskStatus(CmsEditorTaskStatus.SUCCESS);
			response.setResponses(responses);
			return response;
		} catch (Exception e) {
			CALUtil.logFailedCALEvent(CALUtil.DELETE_CONTENT_TASK_EXCEPTION, "createResponse", ExceptionUtils.getFullStackTrace(e));
			return createFailureResponse();
		}
	}
	
	@Override
	protected CmsEditorTaskResponse createFailureResponse() {
		BulkDeleteContentTaskResponse response = new BulkDeleteContentTaskResponse();
		response.setTaskStatus(CmsEditorTaskStatus.FAILURE);
		response.setError(CmsEditorStatus.INTERNAL_SERVER_ERROR);
		return response;
	}
}
