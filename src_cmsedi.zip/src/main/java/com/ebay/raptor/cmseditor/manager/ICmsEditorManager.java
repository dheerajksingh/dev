package com.ebay.raptor.cmseditor.manager;

import com.ebay.raptor.cmseditor.error.CmsEditorException;
import com.ebay.raptor.cmseditor.request.CmsEditorRequest;
import com.ebay.raptor.cmseditor.response.CmsEditorResponse;

public interface ICmsEditorManager {

	public CmsEditorResponse manage(CmsEditorRequest request) throws CmsEditorException;
}
