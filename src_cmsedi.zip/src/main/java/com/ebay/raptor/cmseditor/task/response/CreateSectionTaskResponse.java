package com.ebay.raptor.cmseditor.task.response;

import com.ebay.raptor.cmseditor.response.content.model.Section;

public class CreateSectionTaskResponse extends CmsEditorTaskResponse{
	
	private Section section;

	public Section getSection() {
		return section;
	}

	public void setSection(Section section) {
		this.section = section;
	}
	
}