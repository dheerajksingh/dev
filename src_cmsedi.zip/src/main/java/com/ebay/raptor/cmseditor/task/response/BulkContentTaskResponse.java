package com.ebay.raptor.cmseditor.task.response;

import java.util.List;

import com.ebay.raptor.cmseditor.bulk.BulkAdaptorResponse;

public class BulkContentTaskResponse extends CmsEditorTaskResponse{
	
	List<BulkAdaptorResponse> responses;

	public List<BulkAdaptorResponse> getResponses() {
		return responses;
	}

	public void setResponses(List<BulkAdaptorResponse> responses) {
		this.responses = responses;
	}
	
	
	
	

}
