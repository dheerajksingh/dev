package com.ebay.raptor.cmseditor.config;

import org.apache.commons.lang3.concurrent.ConcurrentException;

import com.ebay.kernel.logger.LogLevel;
import com.ebay.kernel.logger.Logger;
import com.ebayinc.platform.config.api.ContextConfiguration;
import com.ebayinc.platform.config.api.util.ConfigurationContextHelper;

public final class ConfigUtil {

    private static final String SITE = "site";

    private static final Logger LOGGER = Logger.getInstance(ConfigUtil.class);

    protected static LazyContextConfigurationInitializer contextConfigurationHolder = new LazyContextConfigurationInitializer();

    private ConfigUtil() {
        //prevent instantiation.
    }

    public static ContextConfiguration getConfig() {
        try {
            return contextConfigurationHolder.get();
        } catch (ConcurrentException initializationException) {
            LOGGER.log(LogLevel.ERROR, initializationException);
        }

        return null;
    }

    public static boolean getBoolean(String key, boolean defaultValue, int siteId) {
        try {
            return getConfig().getBoolean(
                    key, defaultValue, ConfigurationContextHelper.nv(SITE,String.valueOf(siteId)));
        } catch (Exception e) {
            LOGGER.log(LogLevel.ERROR, e);
        }
        return defaultValue;
    }
    
    public static long getLong(String key, long defaultValue, int siteId) {
        try {
            return getConfig().getLong(
                    key, defaultValue, ConfigurationContextHelper.nv(SITE,String.valueOf(siteId)));
        } catch (Exception e) {
            LOGGER.log(LogLevel.ERROR, e);
        }
        return defaultValue;
    }

    public static int getInt(String key, int defaultValue, int siteId) {
        try {
            return getConfig().getInteger(
                    key, defaultValue, ConfigurationContextHelper.nv(SITE, String.valueOf(siteId)));
        } catch (Exception e) {
            LOGGER.log(LogLevel.ERROR, e);
        }
        return defaultValue;
    }

    public static String getString(String key, String defaultValue, int siteId) {
        try {
            return getConfig().getString(
                    key, defaultValue, ConfigurationContextHelper.nv(SITE,String.valueOf(siteId)));
        } catch (Exception e) {
            LOGGER.log(LogLevel.ERROR, e);
        }
        return defaultValue;
    }
    
	public static double getDouble(String key, double defaultValue, int siteId) {
		try {
            return getConfig().getDouble(
                    key, defaultValue, ConfigurationContextHelper.nv(SITE,String.valueOf(siteId)));
        } catch (Exception e) {
            LOGGER.log(LogLevel.ERROR, e);
        }
        return defaultValue;
	}
	

}
