package org.ebayopensource.ginger.client.config.crunchysvc;

import org.ebayopensource.ginger.client.config.DefaultInitGingerClientConfig;
import org.ebayopensource.ginger.core.constants.PayloadLoggerSetting;
import com.ebay.raptor.ginger.client.filter.ContextPropagator;
import com.ebay.raptor.ginger.client.filter.RaptorContextInjector;

public abstract class BaseCrunchyServiceClientInitConfig extends DefaultInitGingerClientConfig {

	private static final int READ_TIMEOUT = 100;
	private static final int THREAD_POOL_SIZE = 30;
	private static final int ERROR_THRESHOLD = 100;
	
	public BaseCrunchyServiceClientInitConfig() {
		super();
	}

	@Override
	public int getReadTimeout() {
		return READ_TIMEOUT;
	}

	@Override
	public int getThreadPoolSize() {
		return THREAD_POOL_SIZE;
	}
	
	@Override
	public PayloadLoggerSetting getRequestPayloadLoggerSetting() {
		return PayloadLoggerSetting.ON;
	}


	@Override
	public int getErrorCountThreshold() {
		return ERROR_THRESHOLD;
	}
	
	@Override
	public Object[] getProviders() {
		return new Object[] { new ContextPropagator(),
				new RaptorContextInjector(),
				new JsonObjectMapperProvider() 
		};
	}
	
}
