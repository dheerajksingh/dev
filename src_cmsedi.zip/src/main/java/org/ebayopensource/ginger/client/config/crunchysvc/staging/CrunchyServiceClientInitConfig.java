package org.ebayopensource.ginger.client.config.crunchysvc.staging;

import org.ebayopensource.ginger.client.config.crunchysvc.BaseCrunchyServiceClientInitConfig;

import com.ebay.raptor.cmseditor.config.ConfigParam;

public class CrunchyServiceClientInitConfig extends BaseCrunchyServiceClientInitConfig{

	@Override
	public String getEndPoint() {
		return ConfigParam.CRUNCHY_SERVICE_ENDPOINT.getStringValue();
	}	
	
}
